/*$Header: BDEprdcl.sql 11.5.1 03/31/03 */

set serveroutput on;
set term off;
set linesize 250;

/*
 TITLE BDEprdcl.sql

  In the Applications if you follow the navigation path 
  Inventory-->Accounting Close Cycle-->Inventory Accounting Period 
  and select an Open accounting period and click on the 'Pending...' 
  button it shows you the number of pending transactions in various 
  modules of the application.

  This script is an extension of the form - instead of the number of pending
  transactions, this script will provide you the detail information about
  the pending transactions.
 
 EXECUTION

 This script requires a period_id to be passed in as a parameter.

 DESCRIPTION 
 
 This script prints the data related to pending transactions from the 
 following tables: 

 MTL_MATERIAL_TRANSACTIONS_TEMP MMTT
 MTL_TRANSACTIONS_INTERFACE     MTI
 MTL_MATERIAL_TRANSACTIONS      MMT
 WIP_MOVE_TXN_INTERFACE         WMTI
 WIP_COST_TXN_INTERFACE         WCTI
 WSM_SPLIT_MERGE_TRANSACTIONS   WSMT
 WSM_SPLIT_MERGE_TXN_INTERFACE  WSMTI
 WSH_DELIVERY_DETAILS           WDD


 MTL_MATERIAL_TRANSACTIONS_TEMP 
 ==============================
 For Processor to pick up these records the following must exist:
    PROCESS_FLAG      = 'Y'
    LOCK_FLAG         = 'N' or NULL
    TRANSACTION_MODE  = 3
    ERROR_CODE        = NULL
    ERROR_EXPLANATION = NULL

 COLUMN transaction_type_id
 ==========================
 select transaction_type_id,
        transaction_type_name
 from   mtl_transaction_types
 order  by 1;
 
 TRANSACTION_TYPE_ID TRANSACTION_TYPE_NAME
 =================== ==============================
                   1 Account issue
                   2 Subinventory Transfer
                   3 Direct Org Transfer
                   4 Cycle Count Adjust
                   5 Cycle Count Transfer
                   8 Physical Inv Adjust
                   9 Physical Inv Transfer
                  12 Intransit Receipt
                  15 RMA Receipt
                  17 WIP Assembly Return
                  18 PO Receipt
                  21 Intransit Shipment
                  24 Standard cost update
                  25 WIP cost update
                  26 Periodic Cost Update
                  28 Layer Cost Update
                  31 Account alias issue
                  32 Miscellaneous issue
                  33 Sales order issue
                  34 Internal order issue
                  35 WIP component issue
                  36 Return to Vendor
                  37 RMA Return
                  38 WIP Neg Comp Issue
                  40 Account receipt
                  41 Account alias receipt
                  42 Miscellaneous receipt
                  43 WIP Component Return
                  44 WIP Assy Completion
                  48 WIP Neg Comp Return
                  50 Internal Order Xfer
                  51 Backflush Transfer
                  52 Sales Order Pick
                  53 Internal Order Pick
                  54 Int Order Direct Ship
                  55 WIP Lot Split
                  56 WIP Lot Merge
                  57 Lot Bonus
                  58 Lot Update Quantity
                  61 Int Req Intr Rcpt
                  62 Int Order Intr Ship
                  63 Move Order Issue
                  64 Move Order Transfer
                  66 Project Borrow
                  67 Project Transfer
                  68 Project Payback
                  70 Shipment Rcpt Adjust
                  71 PO Rcpt Adjust
                  72 Int Req Rcpt Adjust
                  73 Planning Transfer
                  77 ProjectContract Issue
                  80 Average cost update
                  82 Inventory Lot Split
                  83 Inventory Lot Merge
                  84 Inventory Lot Translate
                  86 Cost Group Transfer
                  87 Container Pack
                  88 Container Unpack
                  89 Container Split
                  90 WIP assembly scrap
                  91 WIP return from scrap
                  92 WIP estimated scrap
                  93 Field Service Usage
                  94 Field Service Recovery
                 100 Deposito presso terzi
                 101 Trasferimento interno
                 120 Obsolete Inventory
                 121 Charitable Contribution
                 122 Issue to Project
                 123 Receipt From
                 142 Field Service
                 162 FES Issue
                 163 FES Reciept
                 164 FES Wip Issue
                 182 Patient Issue
                 183 Window Issue
                 184 NL Issue to Project
                 185 NL Sub=inventory Transfer
                 186 eIB Issue to Project
                 187 eIB Subinventory Transfer
                 188 eIB Misc. Issue to Project
                 189 eIB Misc. Receipt from Project

 COLUMN transaction_action_id
 ============================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='MTL_TRANSACTION_ACTION'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ==============================
           1 Issue from stores
           2 Subinventory transfer
           3 Direct organization transfer
           4 Cycle count adjustment
           8 Physical inventory adjustment
          12 Intransit receipt
          21 Intransit shipment
          24 Cost update
          27 Receipt into stores
          28 Staging transfer
          29 Delivery adjustments
          30 WIP scrap transaction
          31 Assembly completion
          32 Assembly return
          33 Negative component issue
          34 Negative component return
          35 Container transaction
          40 Lot Split
          41 Lot Merge
          42 Lot Translate
          43 Lot Update Quantity
          50 Container Pack
          51 Container Unpack
          52 Container Split
          55 Cost Group Transfer
 
 COLUMN transaction_source_type_id
 =================================
 
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='MTL_DISPOSITION'
 order  by 1;
 
 LOOKUP_CODE MEANING
 =========== ==============================
           1 Purchase order
           2 Sales order
           3 Account number
           4 Job or schedule
           5 Subinventory transfer order
           6 Account alias
 
 WIP_COST_TXN_INTERFACE
 ======================

 COLUMN AUTOCHARGE_TYPE
 ======================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='BOM_AUTOCHARGE_TYPE'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ==============================
           1 WIP move
           2 Manual
           3 PO receipt
           4 PO move

 COLUMN BASIS_TYPE
 =================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='CST_BASIS'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ==============================
           1 Item
           2 Lot
           3 Resource Units
           4 Resource Value
           5 Total Value
           6 Activity

 COLUMN ENTITY_TYPE
 ==================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='WIP_ENTITY'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ==============================
           1 Discrete job
           2 Repetitive assembly
           3 Closed discrete job
           4 Flow schedule
           5 Lot based job
           6 Maintenance job
           7 Closed maintenance job
           8 Closed lot based job

 COLUMN PROCESS_PHASE
 ====================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='WIP_RESOURCE_PROCESS_PHASE'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ==============================
           1 Resource validation
           2 Resource processing
           3 Job close
           4 Period close

 COLUMN PROCESS_STATUS
 =====================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='WIP_PROCESS_STATUS'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ==============================
           1 Pending
           2 Running
           3 Error
           4 Complete
           5 Warning

 COLUMN RESOURCE_TYPE
 ====================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='BOM_RESOURCE_TYPE'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ==============================
           1 Machine
           2 Person
           3 Space
           4 Miscellaneous
           5 Amount

 COLUMN TRANSACTION_TYPE
 =======================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='WIP_TRANSACTION_TYPE'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ==============================
           1 Resource transaction
           2 Overhead transaction
           3 Outside processing
           4 Cost update
           5 Period close variance
           6 Job close variance
           7 Final completion variance
          11 Lot Based Split
          12 Lot Based Merge
          13 Lot Based Bonus
          14 Lot Based Quantity Update
          15 Estimated Scrap Absorption
          16 Estimated Scrap Reallocation
          17 Direct Shopfloor Delivery

 WIP_MOVE_TXN_INTERFACE
 ======================

 COLUMN ENTITY_TYPE
 ==================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='WIP_ENTITY'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ========================================
           1 Discrete job
           2 Repetitive assembly
           3 Closed discrete job
           4 Flow schedule
           5 Lot based job
           6 Maintenance job
           7 Closed maintenance job
           8 Closed lot based job


 COLUMN PROCESS_PHASE
 ====================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='WIP_MOVE_PROCESS_PHASE'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ========================================
           1 Move validation
           2 Move processing
           3 Backflush setup

 COLUMN PROCESS_STATUS
 =====================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='WIP_PROCESS_STATUS'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ========================================
           1 Pending
           2 Running
           3 Error
           4 Complete
           5 Warning

 COLUMN TRANSACTION_TYPE
 =======================
 select lookup_code,meaning
 from   mfg_lookups
 where  lookup_type ='WIP_MOVE_TRANSACTION_TYPE'
 order  by 1;

 LOOKUP_CODE MEANING
 =========== ========================================
           1 Move transaction
           2 Move and completion transaction
           3 Return and move transaction

 MTL_TRANSACTIONS_INTERFACE 
 ==========================
 For Processor to pick up these records the following must exist:
    PROCESS_FLAG      = 'Y'
    LOCK_FLAG         = 'N' or NULL
    TRANSACTION_MODE  = 3
    ERROR_CODE        = NULL
    ERROR_EXPLANATION = NULL

 RCV_TRANSACTIONS_INTERFACE
 ==========================

 COLUMN AUTO_TRANSACT_CODE
 =========================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type ='AUTO TRANSACT CODE'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 DELIVER                        Create a shipment line ,a receipt and de
                                liver an item
 RECEIVE                        Create a shipment line and a receipt for
                                an item 
 SHIP                           Create a shipment line for an item


 COLUMN DESTINATION_TYPE_CODE
 ============================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type ='RCV DESTINATION TYPE'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 EXPENSE                        Expense
 INVENTORY                      Inventory
 MULTIPLE                       Multiple
 RECEIVING                      Receiving
 SHOP FLOOR                     Shop Floor

 COLUMN INSPECTION_STATUS_CODE
 =============================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type ='INSPECTION STATUS'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 ACCEPTED                       Accepted
 NOT INSPECTED                  Not Inspected
 REJECTED                       Rejected

 COLUMN PROCESSING_MODE_CODE
 ===========================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type ='RCV PROCESSING MODE'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 BATCH                          Batch processing mode
 IMMEDIATE                      Immediate processing mode
 ONLINE                         On-line processing mode

 COLUMN PROCESSING_STATUS_CODE
 =============================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type ='PROCESSING STATUS'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 COMPLETED                      Transaction has been processed
 PENDING                        Transaction is pending
 RUNNING                        Transaction is currently being processed

 COLUMN RECEIPT_SOURCE_CODE
 ==========================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type ='SHIPMENT SOURCE TYPE'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 CUSTOMER                       Return from Customer
 INTERNAL ORDER                 In Transit Shipment backed by an Interna
                                l Requisition
 INVENTORY                      In Transit Shipment
 VENDOR                         Shipment from Supplier

 COLUMN SOURCE_DOCUMENT_CODE
 ===========================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type ='SHIPMENT SOURCE DOCUMENT TYPE'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 INVENTORY                      Inventory
 PO                             Purchase Order
 REQ                            Requisition
 RMA                            Return Material Authorization

 COLUMN TRANSACTION_STATUS_CODE
 ==============================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type = 'TRANSACTION STATUS'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 COMPLETED                      Transaction has been successfully proces
                                sed
 ERROR                          An Error occured during the processing o
                                f the transaction
 PENDING                        Transaction is waiting to be processed

 COLUMN TRANSACTION_TYPE
 =======================
 select lookup_code,DESCRIPTION Meaning
 from   po_lookup_codes
 where  lookup_type = 'RCV TRANSACTION TYPE'
 order  by 1;

 LOOKUP_CODE                    MEANING
 ============================== ========================================
 ACCEPT                         Accept items following an inspection
 CANCEL                         Advanced Shipment Notice Transaction to
                                Cancel ASN
 CORRECT                        Correct a previous transaction entry
 DELIVER                        Deliver a shipment of items to the reque
                                stor
 MATCH                          Match unordered items to a purchase orde
                                r
 RECEIVE                        Receive a shipment of items
 REJECT                         Reject items following an inspection
 RETURN TO CUSTOMER             Return items to Customer
 RETURN TO RECEIVING            Return delivered items to receiving
 RETURN TO VENDOR               Return Items to the supplier
 SHIP                           Intransit shipment or internal order
 TRANSFER                       Transfer items between receiving locatio
                                ns
 UNORDERED                      Receive items without matching to a sour
                                ce document

 DISCLAIMER 
 
 This script is provided for educational purposes only.  It is not supported 
 by Oracle World Wide Technical Support.  The script has been tested and 
 appears to works as intended.  However, you should always test any script 
 before relying on it. 
 
 Proofread this script prior to running it!  Due to differences in the way text 
 editors, email packages and operating systems handle text formatting (spaces, 
 tabs and carriage returns), this script may not be in an executable state 
 when you first receive it.  Check over the script to ensure that errors of 
 this type are corrected. 

 This script can be given to customers.  Do not remove disclaimer paragraph.
 
 HISTORY 
 
 31-MAR-03 Created                            skale/rarchule 
*/

variable        v_period_id        number;
variable        v_org_id           number;
variable        v_closing_fm_date  varchar2(10);
variable        v_closing_to_date  varchar2(10);
variable        v_return_status    number;
variable        v_msg_count        number;
variable        v_msg_data         VARCHAR2(200);
variable        v_close_option     number;
variable        v_message          VARCHAR2(60);

set arraysize 4;
set term on;
set pagesize 58; 
set linesize 400;
set underline =; 
set verify off;

-- MTL_MATERIAL_TRANSACTIONS_TEMP 
COLUMN Txn_Iface_id                      FORMAT 999999999;
COLUMN Txn_id                            FORMAT 999999999;
COLUMN Txn_hdr_id                        FORMAT 999999999;
COLUMN Txn_tmp_id                        FORMAT 999999999;
COLUMN Txn_typ_id                        FORMAT 999999999;
COLUMN Txn_act_id                        FORMAT 999999999;
COLUMN Txn_rcv_id                        FORMAT 999999999;
COLUMN Txn_mov_id                        FORMAT 999999999;
COLUMN Txn_com_id                        FORMAT 999999999;
COLUMN Txn_sty_id                        FORMAT 999999999;
COLUMN Txn_src_id                        FORMAT 999999999;
COLUMN Txn_req_id                        FORMAT 999999999;
COLUMN Txn_xfr_id                        FORMAT 999999999;
COLUMN Txn_grp_id                        FORMAT 999999999;
COLUMN Error_code                        FORMAT A20;
COLUMN Error_explanation                 FORMAT A50;
COLUMN Error_column                      FORMAT A20;
COLUMN Error_message                     FORMAT A50;
COLUMN Rev                               FORMAT A3;
COLUMN Uom                               FORMAT A3;
COLUMN PUom                              FORMAT A3;
COLUMN Subinv_code                       FORMAT A10;
COLUMN Loc_id                            FORMAT 999999;
COLUMN Txn_qty                           FORMAT 999999999;
COLUMN Pri_qty                           FORMAT 999999999;
COLUMN cst_grp_id                        FORMAT 999999999;
COLUMN Xfr_cst_grp_id                    FORMAT 999999999;
COLUMN act_Prd_id                        FORMAT 999999999;
COLUMN Txn_cst                           FORMAT 999999;
COLUMN Pflg                              FORMAT A4;
COLUMN Cflg                              FORMAT A4
COLUMN Lflg                              FORMAT A4;
COLUMN Tmode                             FORMAT 9999;
COLUMN Xfr_subinv                        FORMAT A10;
COLUMN Xfr_Loc                           FORMAT 999999;
COLUMN Xfr_OrgId                         FORMAT 999999;
COLUMN Pick_slip                         FORMAT 999999;
COLUMN Pick_lineid                       FORMAT 999999;
COLUMN Reserv_id                         FORMAT 999999;
COLUMN Wms_task                          FORMAT 999999;
COLUMN Std_Oprid                         FORMAT 999999;
COLUMN Src_code                          FORMAT A15;
COLUMN Src_line_id                       FORMAT 999999;
COLUMN Src_Hdr_id                        FORMAT 999999999;
COLUMN PPhase                            FORMAT 99999;
COLUMN PStatus                           FORMAT 99999;
COLUMN BType                             FORMAT 99999;
COLUMN EType                             FORMAT 99999;
COLUMN Entity_type                       FORMAT 99999;
COLUMN wip_entity_id                     FORMAT 999999999;
COLUMN Rep_sch_id                        FORMAT 999999999;
COLUMN Wip_entity_name                   FORMAT A20;
COLUMN TMode_desc                        FORMAT A10;
COLUMN Pflag_desc                        FORMAT A10;
COLUMN LFlag_desc                        FORMAT A13;
COLUMN Src_Hdr_num                       FORMAT A20;
COLUMN Src_line_num                      FORMAT A20;
COLUMN DelvryDetailId                    FORMAT 999999999;
COLUMN Hdr_Iface_id                      FORMAT 999999999;
COLUMN DTCode                            FORMAT A10;
COLUMN CCode                             FORMAT A10;
COLUMN Prt_Txn_id                        FORMAT 999999999;
COLUMN OeLine_id                         FORMAT 999999999;
COLUMN OeHdr_id                          FORMAT 999999999;
COLUMN PSCode                            FORMAT A10;
COLUMN PMCode                            FORMAT A10;
COLUMN TSCODE                            FORMAT A10;
COLUMN ATCode                            FORMAT A7;
COLUMN RSCODE                            FORMAT A15;
COLUMN SDCODE                            FORMAT A10;
COLUMN TranType                          FORMAT A20;
COLUMN Doc_num                           FORMAT 999999999;
COLUMN STLId                             FORMAT 999999999;
COLUMN PO_Hdr_id                         FORMAT 999999999;
COLUMN PO_Line_id                        FORMAT 999999999;
COLUMN VendorId                          FORMAT 999999999;
COLUMN VendorSiteid                      FORMAT 999999999;
COLUMN VFlag                             FORMAT A5;
COLUMN Lot_Number                        FORMAT A10;
COLUMN FmSerial_Num                      FORMAT A10;
COLUMN ToSerial_Num                      FORMAT A10;


prompt
accept selected_org_id prompt 'Please enter ORGANIZATION_ID : '
prompt


select ACCT_PERIOD_ID,
       PERIOD_NAME,
       OPEN_FLAG,
       PERIOD_START_DATE,
       SCHEDULE_CLOSE_DATE
from   org_acct_periods
where  organization_id = &selected_org_id
and    DECODE(NVL(PERIOD_CLOSE_DATE,SYSDATE),PERIOD_CLOSE_DATE, DECODE(OPEN_FLAG, 'N', 'CLOSED', 'Y', 'ERROR', 'P', 'PROCESSING', 'ERROR'), 'OPEN' ) = 'OPEN';

prompt
accept selected_period_id prompt 'Please enter PERIOD_ID from list above : '
prompt

begin
  select ACCT_PERIOD_ID,
         to_char(PERIOD_START_DATE),
         to_char(SCHEDULE_CLOSE_DATE),
         ORGANIZATION_ID
  into   :v_period_id, 
         :v_closing_fm_date, 
         :v_closing_to_date, 
         :v_org_id
  from   org_acct_periods
  where  organization_id = &selected_org_id
  and    acct_period_id  = &selected_period_id;

  dbms_output.put_line('Please upload the following file to the TAR :');
  dbms_output.put_line(:v_period_id||'.lst');

end;
/

set term off;
spool &selected_period_id;

begin
  dbms_output.put_line('This Output is for following parameter');
  dbms_output.put_line('Account Period Id : '||:v_period_id);
  dbms_output.put_line('Organization Id   : '||:v_org_id);
end;
/

PROMPT =========================================
PROMPT   R E S O L U T I O N   R E Q U I R E D 
PROMPT =========================================
PROMPT 
PROMPT ************************************************************************
PROMPT UNPROCESSED MATERIAL
PROMPT ************************************************************************
PROMPT
PROMPT mtl_material_transactions_temp (mmtt)  
PROMPT
PROMPT ************************************************************************
PROMPT Pflg       ==> Process_Flag                Lflg       ==> Lock_flag 
PROMPT Txn_typ_id ==> Transaction_type_id    
PROMPT Txn_act_id ==> Transaction_action_id
PROMPT Txn_sty_id ==> Transaction_source_type_id
PROMPT Txn_Src_id ==> Transaction_source_id
PROMPT Txn_Rcv_id ==> Rcv_Transaction_id
PROMPT Txn_mov_id ==> move_order-line_id
PROMPT Txn_com_id ==> completion_transaction_id
PROMPT ************************************************************************
PROMPT

select transaction_header_id                Txn_hdr_id,
       mmtt.transaction_temp_id             Txn_tmp_id,
       mmtt.inventory_item_id               Inv_Item_id,
       revision                             Rev,
       subinventory_code                    Subinv_code,
       locator_id                           Loc_id,
       mtlt.LOT_NUMBER                      Lot_Number,
       msnt.fm_serial_number                FmSerial_Num,
       msnt.to_serial_number                ToSerial_Num,
       mmtt.transaction_quantity            Txn_qty, 
       mmtt.primary_quantity                Pri_qty,
       transaction_uom                      Uom,
       transaction_cost                     Txn_cst,
       transaction_type_id                  Txn_typ_id,
       transaction_action_id                Txn_act_id,
       transaction_source_type_id           Txn_sty_id,
       transaction_source_id                Txn_src_id,
       transaction_date                     Txn_date,
       -- Interface id
       rcv_transaction_id                   Txn_rcv_id,
       move_order_line_id                   Txn_mov_id,
       completion_transaction_id            Txn_com_id,
       -- Process info
       process_flag                         Pflg,
       lock_flag                            Lflg,
       transaction_mode                     TMode,
       mmtt.request_id                      Txn_req_id,
       -- Trnx Info
       transfer_subinventory                Xfr_subinv,
       transfer_to_location                 Xfr_Loc,
       pick_slip_number                     Pick_slip,
       picking_line_id                      Pick_lineid,
       reservation_id                       Reserv_id,
       wms_task_type                        Wms_task,
       standard_operation_id                Std_Oprid,
       -- Error
       mmtt.error_code                      Error_code,
       error_explanation                    Error_explanation
FROM   mtl_material_transactions_temp mmtt,
       mtl_transaction_lots_temp      mtlt,
       mtl_serial_numbers_temp        msnt
WHERE  ORGANIZATION_ID = :v_org_id
AND    ACCT_PERIOD_ID  = :v_period_id
AND    nvl(transaction_status,0) <> 2
AND    (mtlt.transaction_temp_id (+)     = mmtt.transaction_temp_id
        AND msnt.transaction_temp_id (+) = mmtt.transaction_temp_id)
ORDER BY TRANSACTION_DATE, mmtt.CREATION_DATE, mmtt.transaction_temp_id;

PROMPT ************************************************************************
PROMPT UNCOSTED MATERIAL
PROMPT ************************************************************************
PROMPT
PROMPT mtl_material_transactions (mmt)  
PROMPT ************************************************************************
PROMPT cflg       ==> costed_flag
PROMPT Txn_typ_id ==> Transaction_type_id    
PROMPT Txn_act_id ==> Transaction_action_id
PROMPT Txn_sty_id ==> Transaction_source_type_id
PROMPT Txn_Src_id ==> Transaction_source_id
PROMPT Txn_com_id ==> completion_transaction_id
PROMPT act_prd_id ==> acct_period_id
PROMPT ************************************************************************

select  TRANSACTION_ID                       Txn_id,
        inventory_item_id                    Inv_Item_id,
        revision                             Rev,
        subinventory_code                    Subinv_code,
        locator_id                           Loc_id,
        transaction_quantity                 Txn_qty, 
        primary_quantity                     Pri_qty,
        transaction_uom                      Uom,
        transaction_type_id                  Txn_typ_id,
        transaction_action_id                Txn_act_id,
        transaction_source_type_id           Txn_sty_id,
        transaction_source_id                Txn_src_id,
        transaction_quantity                 Txn_qty,
        transaction_uom                      Uom,
        transaction_date                     Txn_date,
        cost_group_id                        cst_grp_id,
        transfer_transaction_id              Txn_xfr_id,
        transfer_organization_id             Xfr_OrgId,
        transfer_subinventory                Xfr_subinv,
        transfer_cost_group_id               Xfr_cst_grp_id,
        TRANSACTION_GROUP_ID                 Txn_grp_id,
        completion_transaction_id            Txn_com_id,
        SOURCE_CODE                          Src_code,
        SOURCE_LINE_ID                       Src_line_id,
        request_id                           Txn_req_id,
        acct_period_id                       act_Prd_id,
        costed_flag                          Cflg,
        error_code                           Error_code,
        error_explanation                    Error_explanation
from    MTL_MATERIAL_TRANSACTIONS mmt
where   organization_id = :v_org_id
and     acct_period_id  = :v_period_id
and     costed_flag is not null
ORDER BY TRANSACTION_DATE, CREATION_DATE, transaction_id;

PROMPT ************************************************************************
PROMPT PENDING WIP COSTING
PROMPT ************************************************************************
PROMPT
PROMPT wip_cost_txn_interface (wcti)  
PROMPT
PROMPT ************************************************************************
PROMPT TType      ==> TRANSACTION_TYPE          AChrg ==> AUTOCHARGE_TYPE 
PROMPT BType      ==> BASIS_TYPE                RType ==> RESOURCE_TYPE
PROMPT Sflg       ==> STANDARD_RATE_FLAG        EType ==> Entity Type
PROMPT Txn_mov_id ==> move_order-line_id
PROMPT Txn_com_id ==> completion_transaction_id
PROMPT ************************************************************************
PROMPT 
SELECT  wcti.TRANSACTION_ID                  Txn_id,
        PRIMARY_ITEM_ID                      Assembly_id,
        WIP_ENTITY_ID                        Wip_entity_id,
        substr(WIP_ENTITY_NAME,1,40)         Wip_entity_name,
        ENTITY_TYPE                          EType,
        REPETITIVE_SCHEDULE_ID               Rep_Sch_id,
        TRANSACTION_DATE                     Txn_date,
        TRANSACTION_QUANTITY                 Txn_qty,
        TRANSACTION_UOM                      Uom,
        TRANSACTION_TYPE                     TType,
        AUTOCHARGE_TYPE                      AChrg,
        BASIS_TYPE                           BType,
        RESOURCE_TYPE                        RType,
        STANDARD_RATE_FLAG                   SFlg,
        wcti.REQUEST_ID                      Txn_req_id,
        GROUP_ID                             Grp_id,
        OPERATION_SEQ_NUM                    Op_SeqNum,
        RESOURCE_SEQ_NUM                     Re_SeqNum,
        RESOURCE_ID                          Resrc_Id,
        COMPLETION_TRANSACTION_ID            Txn_com_id,
        MOVE_TRANSACTION_ID                  Txn_mov_id,
        PROCESS_PHASE                        PPhase,
        PROCESS_STATUS                       PStatus,
        SOURCE_CODE                          Src_code,
        SOURCE_LINE_ID                       Src_line_id,
        ERROR_COLUMN                         Error_column,
        ERROR_MESSAGE                        Error_Message
from    wip_cost_txn_interface   wcti,
        wip_txn_interface_errors wtie
WHERE   ORGANIZATION_ID = :v_org_id
AND     ACCT_PERIOD_ID  = :v_period_id
AND     wtie.transaction_id (+) = wcti.transaction_id
ORDER   BY TRANSACTION_DATE, wcti.CREATION_DATE, wcti.transaction_id;

PROMPT ************************************************************************
PROMPT UNCOSTED WSM TRANSACTIONS 
PROMPT ************************************************************************
PROMPT
PROMPT  wsm_split_merge_transactions (wsmt)
PROMPT

select  transaction_id                       Txn_id,
        transaction_type_id                  Txn_typ_id,
        TRANSACTION_DATE                     Txn_date, 
        status                               Staus, 
        GROUP_ID                             Grp_id,
        request_id                           Txn_req_id,
        error_message                        Error_Message
FROM    WSM_SPLIT_MERGE_TRANSACTIONS
WHERE   ORGANIZATION_ID = :v_org_id
AND     COSTED <> 4
AND     TRUNC(TRANSACTION_DATE) < (trunc(to_date(:v_closing_to_date))+1)
order   by TRANSACTION_DATE;

PROMPT ************************************************************************
PROMPT PENDING WSM INTERFACE
PROMPT ************************************************************************
PROMPT
PROMPT wsm_split_merge_txn_interface (wsmti)
PROMPT

select  header_id                            Txn_hdr_id,
        transaction_type_id                  Txn_typ_id, 
        transaction_date                     Txn_date,
        process_status                       PStatus,
        transaction_id                       Txn_id,
        group_id                             Grp_id,
        request_id                           Txn_req_id,
        error_message                        Error_Message
from    wsm_split_merge_txn_interface
WHERE   ORGANIZATION_ID = :v_org_id
AND     PROCESS_STATUS <> 4
AND     TRUNC(TRANSACTION_DATE) < (trunc(to_date(:v_closing_to_date))+1)
ORDER   BY TRANSACTION_DATE;

PROMPT ===============================================
PROMPT   R E S O L U T I O N   R E C O M M E N D E D  
PROMPT ===============================================
PROMPT 
PROMPT ************************************************************************
PROMPT PENDING RECEIVEING
PROMPT ************************************************************************
PROMPT 
PROMPT rcv_transactions_interface (rti)
PROMPT
PROMPT ************************************************************************
PROMPT TranType  ==> Transaction_type       PSCode ==> Processing_Status_Code
PROMPT PMCode    ==> Processing_mode_code   ATCode ==> Auto_Transact_code
PROMPT RSCode    ==> Receipt_source_code    SDCode ==> Source_document_code
PROMPT STLId     ==> Ship_to_location_Id    VFlag  ==> VALIDATION_FLAG 
PROMPT ************************************************************************

SELECT  INTERFACE_TRANSACTION_ID             Txn_Iface_id,
        HEADER_INTERFACE_ID                  Hdr_Iface_id,
        Item_id                              Inv_Item_id,
        GROUP_ID                             Grp_id,
        TRANSACTION_TYPE                     TranType,
        TRANSACTION_DATE                     Txn_date,
        PROCESSING_STATUS_CODE               PSCOde,
        PROCESSING_MODE_CODE                 PMCode,
        TRANSACTION_STATUS_CODE              TSCODE,
        QUANTITY                             Txn_qty,
        UNIT_OF_MEASURE                      Uom,
        AUTO_TRANSACT_CODE                   ATCode,
        RECEIPT_SOURCE_CODE                  RSCode,
        DESTINATION_TYPE_CODE                DTCode,
        SOURCE_DOCUMENT_CODE                 SDCode,
        CURRENCY_CODE                        CCode,
        DOCUMENT_NUM                         Doc_num,
        SHIP_TO_LOCATION_ID                  STLId,
        PARENT_TRANSACTION_ID                Prt_Txn_id,
        PO_HEADER_ID                         Po_Hdr_id,
        PO_LINE_ID                           PO_Line_id,
        VENDOR_ID                            VendorId,
        VENDOR_SITE_ID                       VendorSiteId,
        OE_ORDER_HEADER_ID                   OeHdr_id,
        OE_ORDER_LINE_ID                     OeLine_id,
        VALIDATION_FLAG                      VFlag,
        SUBINVENTORY                         SubInventory
FROM    RCV_TRANSACTIONS_INTERFACE
WHERE   TO_ORGANIZATION_ID = :v_org_id
AND     TRUNC(TRANSACTION_DATE) < (trunc(to_date(:v_closing_to_date))+1)
AND     DESTINATION_TYPE_CODE = 'INVENTORY'
ORDER   BY TRANSACTION_DATE;

PROMPT ************************************************************************
PROMPT PENDING MATERIAL
PROMPT ************************************************************************
PROMPT
PROMPT mtl_transactions_interface (mti)  
PROMPT
PROMPT ************************************************************************
PROMPT PFlag ==> Process_Flag     TMode ==> Transaction_Mode
PROMPT LFlag ==> Lock Flag        
PROMPT Txn_typ_id ==> Transaction_type_id    
PROMPT Txn_act_id ==> Transaction_action_id
PROMPT Txn_sty_id ==> Transaction_source_type_id
PROMPT Txn_Src_id ==> Transaction_source_id
PROMPT Txn_Rcv_id ==> Rcv_Transaction_id
PROMPT Txn_mov_id ==> move_order-line_id
PROMPT Txn_com_id ==> completion_transaction_id
PROMPT ************************************************************************
PROMPT 

select mti.transaction_interface_id         Txn_IFace_id,
       transaction_header_id                Txn_hdr_id,
       inventory_item_id                    Inv_Item_id,
       revision                             Rev,
       subinventory_code                    Subinv_code,
       locator_id                           Loc_id,
       mtli.LOT_NUMBER                      Lot_Number,
       msni.fm_serial_number                FmSerial_Num,
       msni.to_serial_number                ToSerial_Num,
       mti.transaction_quantity             Txn_qty, 
       mti.primary_quantity                 Pri_qty,
       transaction_uom                      Uom,
       transaction_cost                     Txn_cst,
       transaction_type_id                  Txn_typ_id,
       transaction_action_id                Txn_act_id,
       transaction_source_type_id           Txn_sty_id,
       transaction_source_id                Txn_src_id,
       transaction_date                     Txn_date,
       transfer_subinventory                Xfr_subinv,
       transfer_organization                Xfr_OrgId,
       mti.request_id                       Txn_req_id,
       mti.source_code                      Src_code,
       mti.source_line_id                   Src_line_id,
       source_header_id                     Src_Hdr_id,
       mti.process_flag                     PFlag,
       decode(to_char(nvl(mti.process_flag,0)),
              '1','Ready',
              '2','Not Ready',
              '3','Error',
              to_char(mti.process_flag))    Pflag_Desc,
       transaction_mode                     TMode,
       decode(transaction_mode,
              '2','Immediate',
              '3','Background',
              to_char(transaction_mode))    TMode_desc,
       lock_flag                            LFlag,
       decode(lock_flag,
              '1','Locked',
              '2','Not Locked')             LFlag_desc,
        mti.error_code                      Error_code,
        error_explanation                   Error_explanation
from   mtl_transactions_interface     mti,
       mtl_serial_numbers_interface   msni,
       mtl_transaction_lots_interface mtli
where  ORGANIZATION_ID  = :v_org_id
AND    (ACCT_PERIOD_ID  = :v_period_id
        OR (ACCT_PERIOD_ID IS NULL
       AND TRUNC(TRANSACTION_DATE) < (trunc(to_date(:v_closing_to_date))+1)))
AND    mti.PROCESS_FLAG <> 9
AND    (mtli.transaction_interface_id (+)     = mti.transaction_interface_id
        AND msni.transaction_interface_id (+) = mti.transaction_interface_id)
ORDER  BY TRANSACTION_DATE;

PROMPT ************************************************************************
PROMPT PENDING SHOP FLOOR MOVE
PROMPT ************************************************************************
PROMPT
PROMPT wip_move_txn_interface (wmti)  
PROMPT
PROMPT ************************************************************************
PROMPT TType ==> TRANSACTION_TYPE  EType ==> Entity Type 
PROMPT ************************************************************************
PROMPT 
SELECT wmti.TRANSACTION_ID                  Txn_id,
       PRIMARY_ITEM_ID                      Assembly_id,
       WIP_ENTITY_ID                        Wip_entity_id,
       WIP_ENTITY_NAME                      Wip_entity_name,
       ENTITY_TYPE                          EType,
       REPETITIVE_SCHEDULE_ID               Rep_Sch_id,
       TRANSACTION_DATE                     Txn_date,
       TRANSACTION_QUANTITY                 Txn_qty,
       TRANSACTION_UOM                      Uom,
       PRIMARY_QUANTITY                     PQty,
       PRIMARY_UOM                          PUom,
       TRANSACTION_TYPE                     TType,
       FM_OPERATION_SEQ_NUM                 Fmopseq,
       FM_INTRAOPERATION_STEP_TYPE          Fmopstep,
       TO_OPERATION_SEQ_NUM                 Toopseq,
       TO_INTRAOPERATION_STEP_TYPE          Toopstep,
       OVERCOMPLETION_TRANSACTION_QTY       Txn_ocom_qty,
       OVERCOMPLETION_TRANSACTION_ID        Txn_ocom_id,
       SCRAP_ACCOUNT_ID                     ScrpAccId,
       GROUP_ID                             Grp_id,
       wmti.REQUEST_ID                      Txn_req_id,
       PROCESS_PHASE                        PPhase,
       PROCESS_STATUS                       PStatus,
       SOURCE_CODE                          Src_code,
       SOURCE_LINE_ID                       Src_line_id,
       ERROR_COLUMN                         Error_column,
       ERROR_MESSAGE                        Error_Message
from   wip_move_txn_interface   wmti,
       wip_txn_interface_errors wtie
where  ORGANIZATION_ID  = :v_org_id
AND    (ACCT_PERIOD_ID  = :v_period_id
        OR (ACCT_PERIOD_ID IS NULL
      AND TRUNC(TRANSACTION_DATE) < (TRUNC(to_date(:v_closing_to_date))+ 1)))
AND   wtie.transaction_id (+) = wmti.transaction_id
ORDER BY TRANSACTION_DATE, wmti.CREATION_DATE, wmti.transaction_id;

PROMPT =====================================================================
PROMPT   U N P R O C E S S E D   S H I P P I N G   T R A N S A C T I O N S
PROMPT =====================================================================

begin
 cst_periodCloseOption_pub.shipping_txn_hook(p_api_version    => 1.0,
                                             i_org_id         => :v_org_id,
                                             i_acct_period_id => :v_period_id,
                                             x_close_option   => :v_close_option,
                                             x_return_status  => :v_return_status,
                                             x_msg_count      => :v_msg_count,
                                             x_msg_data       => :v_msg_data);

 if :v_close_option = 0 then
    :v_message := 'Resolving Unprocessed Shipping Transasactions is Required';
 else
  if :v_close_option = 1 then
     :v_message := 'Resolving Unprocessed Shipping Transasactions is Recommended';
  end if;
 end if;
 dbms_output.put_line(:v_message);
end;
/ 

PROMPT 
PROMPT ************************************************************************
PROMPT PENDING TRANSACTIONS
PROMPT ************************************************************************
PROMPT 
PROMPT wsh_delivery_details (wdd)
PROMPT

select source_header_number                  Src_Hdr_num,
       source_line_number                    Src_line_num,
       wdd.delivery_detail_id                DelvryDetailId
from   wsh_delivery_details     wdd, 
       wsh_delivery_assignments wda,
       wsh_new_deliveries       wnd, 
       wsh_delivery_legs        wdl, 
       wsh_trip_stops           wts
where  wdd.source_code         = 'OE'
and    wdd.released_status     = 'C'
and    wdd.inv_interfaced_flag in ('N' ,'P')
and    wdd.organization_id     = :v_org_id
and    wda.delivery_detail_id  = wdd.delivery_detail_id
and    wnd.delivery_id         = wda.delivery_id
and    wnd.status_code in      ('CL','IT')
and    wdl.delivery_id         = wnd.delivery_id
and    trunc(wts.actual_departure_date) between to_date(:v_closing_fm_date)
and    to_date(:v_closing_to_date)
and    wdl.pick_up_stop_id     = wts.stop_id;

spool off
exit;

