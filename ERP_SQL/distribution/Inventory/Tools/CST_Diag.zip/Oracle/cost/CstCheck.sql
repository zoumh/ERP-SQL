REM $Header: cstcheck.sql 115.0 2002/07/11 18:31:27 pmandal noship $
REM +=======================================================================+
REM |    Copyright (c) 2000 Oracle Corporation, Redwood Shores, CA, USA     |
REM |                         All rights reserved.                          |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |     cstcheck.sql                                                      |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM |     This SQL script is  to  generate  a  report useful for            |
REM |     diagnostic purposes.                                              |
REM |                                                                       |
REM | NOTES                                                                 |
REM |     This script is to be run in the SERVER at sqlplus with APPS user. |
REM |     Spooling of output is taken care. No Explicit spooling is         |
REM |     required.                                                         |
REM |                                                                       |
REM | HISTORY                                                               |
REM |     27-JUN-2003       Prabhat Mandal       Initial Creation           |
REM |                                                                       |
REM +=======================================================================+

define Customer = '&Customer'

spool CstDiag115.txt

prompt ************** Oracle Cost Management Diagnostic Report **************
prompt
prompt Diagnostic report generated for Customer &Customer.
prompt
prompt **********************************************************************

clear buffer;

set heading on
set verify off
set feed off
set linesize 80
set pagesize 1000
set underline '='
set serveroutput on size 100000

col dtime format a30 heading 'Report started at Date/Time' ;
select to_char(sysdate, 'DD/MON/RRRR HH24:MI:SS') dtime from dual;

col db format a9 heading 'DB Name';
col created format a9 heading 'Created';

prompt
prompt 1. Database Name and Created Date :
select 
  name db
, created 
from V$DATABASE;

col ver format a64 heading 'Oracle RDBMS/Tools Version(s)';

prompt
prompt 2. Oracle Version(s) : 
select 
  banner ver 
from V$VERSION;

col parameter format a30 heading 'NLS Parameter Name';
col param_value format a30 heading 'Currently Set Value';

prompt
prompt 3. NLS Parameter Settings :
select 
  parameter
, value param_value 
from nls_session_parameters;

set linesize 120

prompt
prompt 4. Profile Option Values :
prompt

declare

  cursor profile_values is
  select fpo.user_profile_option_name upon,fpv.profile_option_value pov 
  from fnd_profile_option_values fpv, fnd_profile_options_vl fpo
  where fpv.application_id in (702)
  and ( fpv.level_id = 10001 and fpv.level_value = 0 ) 
  and fpv.profile_option_id = fpo.profile_option_id
  order by fpv.application_id , fpo.user_profile_option_name; 

begin

   dbms_output.put_line(chr(10)||'================================================================================'); 
   dbms_output.put_line('Profile Option Values Set at Site Level');
   dbms_output.put_line(chr(10)||'================================================================================'); 
   dbms_output.put_line(chr(10)||'User Profile Option Name                           Profile Option Value         ');
   dbms_output.put_line(chr(10)||'================================================================================'); 
   for rec in profile_values loop
      dbms_output.put_line(rpad(rec.upon, 50)||' '||rpad(rec.pov, 52));
   end loop;

end;
/

set linesize 190

prompt
prompt 5. Organization Structure :

col org_id format 999999 heading 'Org Id'
col org format a4 heading 'Org'
col PCM format a15 heading 'Costing Method'
col c_org format 9999999999 heading 'Costing Org'
col m_org format 9999999999 heading 'Master Org'
col dcg format 9999999999 heading 'Default CG'
col ccd format a12 heading 'Cost CutOff'
col PRE format a12 heading 'Project Ref'
col WMS format a12 heading 'WMS Enabled'
col EAM format a12 heading 'EAM Enabled'
col WSM format a12 heading 'WSM Enabled'
col ENC format a28 heading 'Ecumbrance Reversal Enabled'
col neg_moq format a23 heading 'Allow Negative Onhand'

SELECT organization_id org_id, 
       organization_code org,
       decode(primary_cost_method,
              1, 'Standard',
              2, 'Average',
              5, 'FIFO',
              6, 'LIFO') PCM,
       cost_organization_id c_org,
       master_organization_id m_org,
       default_cost_group_id dcg,
       decode(project_reference_enabled,
              1, 'Yes',
              2, 'No') PRE,
       decode(wms_enabled_flag,
              'Y', 'Yes',
              'N', 'No') WMS,
       to_char(cost_cutoff_date,'dd-mon-rrrr') ccd,
       decode(eam_enabled_flag,
              'Y','Yes',
              'N','No') EAM,
       decode(wsm_enabled_flag,
              'Y','Yes',
              'N','No') WSM,
       decode (encumbrance_reversal_flag,
               1, 'Yes',
               2, 'No') ENC,
       decode(NEGATIVE_INV_RECEIPT_CODE,
              1, 'Yes',
              2, 'No') neg_moq
  FROM mtl_parameters
ORDER BY organization_code;


set linesize 190

prompt
prompt 6. Organization Accounts :

col org_code format A8 heading 'Org Code'
col mtl_acct format 99999999 heading 'Material'
col MOH format 99999999 heading 'MOH'
col res_acct format 99999999 heading 'Resource'
col OSP format 99999999 heading 'OSP'
col Ovhd_acct format 99999999 heading 'Overhead'
col ppv_acct format 99999999 heading 'PPV'
col avgvar_acct format 99999999 heading 'Avg CVar'
col intr_acct format 999999999 heading 'Intransit'
col exp_acct format 99999999 heading 'Expense'
col io_xcr format 99999999  heading 'IO XCR'
col io_rcvbl format 99999999 heading 'IO Rcvbl'
col io_pybl format 99999999 heading 'IO Pybl'
col io_ppv format 99999999 heading 'IO PPV'
col ap_accr format 99999999 heading 'AP Accrl'
col ipv_acct format 99999999 heading 'IPV'
col sales_acct format 99999999 heading 'Sales'
col cogs_acct format 99999999 heading 'COGS'


select organization_code Org_Code,
       material_account Mtl_acct,
       material_overhead_account MOH,
       resource_account res_acct,
       outside_processing_account OSP,
       overhead_account Ovhd_acct,
       purchase_price_var_account PPV_acct,
       average_cost_var_account avgvar_acct,
       intransit_inv_account Intr_acct,
       expense_account Exp_acct,
       interorg_transfer_cr_account io_xcr,
       interorg_receivables_account io_rcvbl,
       interorg_payables_account io_pybl,
       interorg_price_var_account io_ppv,
       ap_accrual_account ap_accr,
       invoice_price_var_account ipv_acct,
       sales_account sales_acct,
       cost_of_sales_account cogs_acct
  from mtl_parameters
 order by 1;

set linesize 130

prompt
prompt 7. Cost group Accounts :

col cg format A10 heading 'Cost Group'
col cg_id format 99999 heading 'CG Id'
col org_id format 99999 heading 'Org Id'
col cg_type format A12 heading 'CG Type'
col mtl_acct format 99999999 heading 'Material'
col moh_acct format 99999999 heading 'MOH'
col res_acct format 99999999 heading 'Resource'
col ovhd_acct format 99999999 heading 'Overhead'
col osp_acct format 99999999 heading 'OSP'
col avg_cvar format 99999999 heading 'Avg CVar'
col exp_acct format 99999999 heading 'Expense'
col ppv_acct format 99999999 heading 'PPV'

select ccg.cost_group cg,
       ccga.cost_group_id cg_id,
       ccga.organization_id org_id,
       decode(ccg.cost_group_type,
            1, 'Project',
            2, 'Organization',
            3, 'Inventory') cg_type,
       ccga.MATERIAL_ACCOUNT mtl_acct,
       ccga.MATERIAL_OVERHEAD_ACCOUNT moh_acct,
       ccga.RESOURCE_ACCOUNT res_acct,
       ccga.OVERHEAD_ACCOUNT ovhd_acct,
       ccga.OUTSIDE_PROCESSING_ACCOUNT osp_acct,
       ccga.AVERAGE_COST_VAR_ACCOUNT avg_cvar,
       ccga.EXPENSE_ACCOUNT exp_acct,
       ccga.PURCHASE_PRICE_VAR_ACCOUNT ppv_acct
  from cst_cost_groups ccg,
       cst_cost_group_accounts ccga,
       mtl_parameters mp
 where ccga.cost_group_id = mp.default_cost_group_id
   and ccga.organization_id = mp.organization_id
   and ccg.cost_group_id = mp.default_cost_group_id
   and ccg.organization_id = mp.organization_id(+)
 order by 1,3;


set linesize 165

prompt
prompt 8. Interorg Parameters :

col from_org format 999999999 heading 'From Org'
col to_org format 9999999 heading 'To Org'
col tr_type format a10 heading 'Xfer Type'
col fob_pt format a10 Heading 'FOB Point'
col ior_flg format a12 heading 'IO Required'
col io_xfr_cd format a26 heading 'Interorg Transfer Code'
col ele_vsbl format a12 heading 'Ele Visible'
col io_xchg format 9999.99 heading 'Xfr Charge'
col intr_acct format 999999999 heading 'Intransit'
col io_xcr format 99999999 heading 'IO XCR'
col io_rcvbl format 99999999 heading 'IO Rcvbl'
col io_pybl format 99999999 heading 'IO Pybl'
col io_ppv format 99999999 heading 'IO PPV'

SELECT from_organization_id from_org,
       to_organization_id to_org,
       decode(intransit_type,
                 1,'Direct',
                 2,'Intransit',
                 'None') tr_type,
       decode(fob_point,
                 1,'Shipment',
                 2,'Receipt',
                 'None') fob_pt,
       decode(INTERNAL_ORDER_REQUIRED_FLAG,
                 1,'Yes',
                 2,'No') ior_flg,
       decode(MATL_INTERORG_TRANSFER_CODE,
                 1, 'No Transfer Charges',
                 2, 'Reuested added value',
                 3, 'Requested % of txn value',
                 4, 'Predefined % of txn value') io_xfr_cd,
       decode(ELEMENTAL_VISIBILITY_ENABLED,
                 'Y', 'Yes',
                 'N', 'No') ele_vsbl,
       interorg_trnsfr_charge_percent io_xchg,
       intransit_inv_account intr_acct,
       interorg_transfer_cr_account io_xcr,
       interorg_receivables_account io_rcvbl,
       interorg_payables_account io_pybl,
       interorg_price_var_account io_ppv
  FROM mtl_interorg_parameters
 ORDER BY 1,2;

set linesize 180

prompt
prompt 9. Wip Parameters :

col org_code format A8 heading 'Org Code'
col org_id format 999999 heading 'Org Id'
col ms_flg format A18 heading 'Scrap Acct Option'
col comp_cst_src format A22 heading 'Completion Cost Source'
col ct_id format 999999999 heading 'Cost Type'
col acf_comp format A30 heading 'Auto Compute Final Completion'
col sys_opt format A26 heading 'System Option'
col rep_var_type format A48 heading 'Recognize Period Variance'

select mp.organization_code org_code,
       wp.organization_id org_id,
       decode(mandatory_scrap_flag,
              1, 'Mandatory',
              2, 'Optional') ms_flg,
       decode(completion_cost_source,
              1, 'System Calculated',
              2, 'User Defined') comp_cst_src,
       cost_type_id ct_id,
       decode(auto_compute_final_completion,
              1, 'Yes',
              2, 'No') acf_comp,
       decode(system_option_id,
              1, 'Use Actual Resources',
              2, 'Use Pre-defined Resources') sys_opt,
       decode(repetitive_variance_type,
              1, 'All Schedules',
              2, 'Complete - no charges, Cancelled schedules only') rep_var_type
  from wip_parameters wp,
       mtl_parameters mp
 where mp.organization_id = wp.organization_id
 order by 1;


set linesize 120

col pname format a35 heading 'Package Name-Specification/Body';
col pfname format a18 heading 'File Name';
col pversion format a15 heading 'Version';
col pstatus format a8 heading 'Status';

prompt
prompt 10. Package Versions :

select ds.name||'-'||decode(ds.type,'PACKAGE', 'Spec', 'PACKAGE BODY', 'Body') pname ,
ltrim(rtrim(substr(substrb(ds.text, instr(ds.text,'Header: ')),
instr(substr(ds.text, instr(ds.text,'Header: ')), ' ', 1, 1),
instr(substr(ds.text, instr(ds.text,'Header: ')), ' ', 1, 2) -
instr(substr(ds.text, instr(ds.text,'Header: ')), ' ', 1, 1) ))) pfname ,
ltrim(rtrim(substr(substrb(ds.text, instr(ds.text,'Header: ')),
instr(substr(ds.text, instr(ds.text,'Header: ')), ' ', 1, 2),
instr(substr(ds.text, instr(ds.text,'Header: ')), ' ', 1, 3) -
instr(substr(ds.text, instr(ds.text,'Header: ')), ' ', 1, 2) ))) pversion ,
do.status pstatus
from dba_source ds, dba_objects do
where ds.line = 2
and   ds.name like 'CST%'
and   ds.owner = 'APPS'
and   do.owner = ds.owner
and   do.object_name = ds.name
and   do.object_type = ds.type;

set linesize 120

spool off

prompt
prompt 11. Finding Product Tops ..

host echo '' >> CstDiag115.txt
host echo '11. Checking Product Tops : ' >> CstDiag115.txt
host echo '' >> CstDiag115.txt
host echo 'BOM_TOP is '$BOM_TOP >> CstDiag115.txt
host echo 'FND_TOP  is '$FND_TOP  >> CstDiag115.txt

prompt
prompt 12. Exploring Reports directory..


host echo '' >> CstDiag115.txt
host echo '12. Product Reports Directory :' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/reports/'||userenv('LANG')||'/CST*.rdf | grep ''$Header''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt
host echo '' >> CstDiag115.txt


prompt
prompt 13. Checking $BOM_TOP/forms/<lang>/ Directory..

host echo '' >> CstDiag115.txt
host echo '13. Product Forms Directory :' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/forms/'||userenv('LANG')||'/CST*.fmx | grep ''$Header''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

prompt
prompt 14. Checking $AU_TOP/resource/ Directory..

host echo '' >> CstDiag115.txt
host echo '14. Product Resource Directory :' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select distinct 'strings -a $AU_TOP/resource/'||substr(ff.form_name, 1, 2)||'CST*.plx | grep ''$Header: '''
   from fnd_form ff
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

prompt
prompt 15. Checking $BOM_TOP/import/<lang>/ (for .wft files) Directory..

host echo '' >> CstDiag115.txt
host echo '15. Product Workflow Files :' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/patch/115/import/'||userenv('LANG')||'/cst*.wft | grep ''$Header''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

prompt
prompt 16. Checking $BOM_TOP/patch/115/odf/ Directory..

host echo '' >> CstDiag115.txt
host echo '16. Product ODF Files :' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/patch/115/odf/cst*.odf | grep ''$Header''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host cat comm.lst >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

prompt
prompt 17. Checking $BOM_TOP/bin/ Directory..

host echo '' >> CstDiag115.txt
host echo '17. Product Pro*C Files :' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCTCM | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCTCM :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCMCW | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702
   union all
   select 'strings -a $'||basepath||'/bin/CMCMCW | grep ''$Header'' | grep ''inltcp.lpc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCMCW :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCACW | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCACW :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCLCW | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCLCW :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCICU | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702
   union all
   select 'strings -a $'||basepath||'/bin/CMCICU | grep ''$Header'' | grep ''inltcp.lpc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCICU :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCMEC | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCMEC :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCCCM | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCCCM :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCCCI | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCCCI :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCCCW | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCCCW :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCCOC | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCCOC :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCCTW | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCCTW :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCPAM | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCPAM :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCPAW | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCPAW :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCPIM | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCPIM :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMCPIW | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMCPIW :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/CMRICU | grep ''$Header'' | grep ''cm.*.*.pc''' 
   from fnd_application 
   where application_id  = 702;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'CMRICU :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/INCTPC | grep ''$Header'' | grep ''in.*.*.pc''' 
   from fnd_application 
   where application_id  = 401;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'INCTPC :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
set verify off
set feed off
set head off
spool comm.lst
   select 'strings -a $'||basepath||'/bin/INCTGL | grep ''$Header'' | grep ''in.*.*.pc''' 
   from fnd_application 
   where application_id  = 401;
spool off
set verify on
set feed on
set head on
host chmod 777 comm.lst
host echo 'INCTGL :' >> CstDiag115.txt
host cat comm.lst >> CstDiag115.txt
host echo ' ' >> CstDiag115.txt
host comm.lst >> CstDiag115.txt

host echo '' >> CstDiag115.txt
host echo 'Report completed at Date/Time' >> CstDiag115.txt
host date '+%d/%m/%y %H:%M:%S' >> CstDiag115.txt
host echo '' >> CstDiag115.txt
host echo 'End of Diagnostic Report' >> CstDiag115.txt
host echo '' >> CstDiag115.txt

prompt
prompt End of Diagnostic Report. Look for CstDiag115.txt in user's current directory.
prompt

exit;


