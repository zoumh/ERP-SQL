
  In the Applications if you follow the navigation path 
  Inventory-->Accounting Close Cycle-->Inventory Accounting Period 
  and select an Open accounting period and click on the 'Pending...' 
  button it shows you the number of pending transactions in various 
  modules of the application.

  This script is an extension of the form - instead of the number of pending
  transactions, this script will provide you the detail information about
  the pending transactions.


  The Data is classified in the following three categories.

    a) Resolution required
    b) Resolution recommended
    c) Unprocessed shipping transactions.

=========================================
R E S O L U T I O N   R E Q U I R E D 
=========================================

********************
UNPROCESSED MATERIAL
********************
     mtl_material_transactions_temp (mmtt)  
*****************
UNCOSTED MATERIAL
*****************
     mtl_material_transactions (mmt) 
*******************
PENDING WIP COSTING
*******************
     wip_cost_txn_interface (wcti)  
*************************
UNCOSTED WSM TRANSACTIONS 
*************************
     wsm_split_merge_transactions (wsmt)
*********************
PENDING WSM INTERFACE
*********************
     wsm_split_merge_txn_interface (wsmti)

===============================================
R E S O L U T I O N   R E C O M M E N D E D  
===============================================
******************
PENDING RECEIVEING
******************
     rcv_transactions_interface (rti)
****************
PENDING MATERIAL
****************
     mtl_transactions_interface (mti)  
************************************************************************
PENDING SHOP FLOOR MOVE
************************************************************************
     wip_move_txn_interface (wmti)  

=====================================================================
U N P R O C E S S E D   S H I P P I N G   T R A N S A C T I O N S
=====================================================================

************************************************************************
PENDING TRANSACTIONS
************************************************************************
     wsh_delivery_details (wdd)

