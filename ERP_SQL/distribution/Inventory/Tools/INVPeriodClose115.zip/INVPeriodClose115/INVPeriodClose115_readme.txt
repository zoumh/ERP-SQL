================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract          Oracle Inventory (INV): Period Close Check 
================================================================================
PRODUCT:          Oracle Inventory(INV)
SUBCOMPONENT:     INV Accounting Periods
PRODUCT VERSIONS: Release 11.5.x -
PLATFORM:         Generic
DATE CREATED:     24-OCT-2003
PARAMETERS:       Username(Required)
                  Responsibility ID(Required)
                  Organization Code(Required)
		      Period Name  (Required)
                  Detail/Summary Information (Required)
		  
================================================================================
Instructions
================================================================================
Included Files:
	CoreApiHtml.sql
	INVApiHtml.sql
	INVPeriodClose115.sql
	INVPeriodClose115_readme.html
	INVPeriodClose115_readme.txt
      INVPeriodClose115_Sample_Output.html



Execution Environment:
SQL*Plus


Access Privileges:
Requires APPS user access


Usage:
sqlplus <apps user>/<apps pw> @INVPeriodClose115.sql


Instructions:
The files INVPeriodClose115.sql , INVApiHtml.sql and CoreApiHtml.sql should
be unzipped to a common directory.
From this directory run the file INVPeriodClose115.sql in SQL*Plus in the 
APPS schema.
 
You will be prompted for an Applications User name.
 
Then you see a list of valid responsibilities for the user entered.
When prompted, enter the responsibility id of the responsibility used when
logged into Applications.
 
You then see a list of Inventory organizations.
When prompted, enter the organization code of the organization used when the 
problem is occuring.
 
Then you see a list of open periods.
When prompted, enter the Periodname of the period you want an analysis of 
pending material transactions.
 
Finally you are prompted whether you want Summary or Detail information.
You normally choose Detail unless you know the generated output is far too huge.

The test will produce an output file named
INVPeriodClose115_[OrgCode]_[Period]_diag.html
This file can be viewed in a browser or uploaded for support analysis.

================================================================================
Description
================================================================================
This diagnostic test checks whether a given Inventory accounting period might be closed. 
It gathers and analyses key information on different transactions that would prevent a real period close. 
Depending on user-input , it reports summary or detailed information. 

This test should be run proactivly before issues become critical during real month-end processing..

The retrieved information is similar to the output provided by "Inventory Accounting Period" form
and clicking the �Pending� button.
This test will display more details about the transactions that might prevent a period close.
 
Summary and detail information is provided.
Error and warning messages, followed by suggested actions, identify possible 
problem areas.
 
Following Information is provided:
          Database Information
          Application Information
          Patchset Level ( e.g. INV.H )
          Organization Information ( e.g. Cost method, WMS-Org )

          Summary and detailed Information about : 
            > Unprocessed material transactions ( MTL_MATERIAL_TRANSACTIONS_TEMP )
              - Distinct error messages ( e.g. many transactions have same error)

            > Uncosted material transactions ( MTL_MATERIAL_TRANSACTIONS )
              - Distinct error messages ( e.g. many transactions have same error)

            > Pending WIP costing transactions ( WIP_COST_TRANSACTION_INTERFACE )
              - Distinct values for Process Phase and Process Status

            > Uncosted WSM transactions (  WSM_SPLIT_MERGE_TRANSACTIONS )
              - Distinct values for Status and Costed Flag 
                ( e.g. many transactions have status pending)

            > Pending WSM interface transactions ( WSM_SPLIT_MERGE_TXN_INTERFACE )

            > Rending receiving transactions ( RCV_TRANSACTIONS_INTERFACE)
              - Distinct values for Transaction Status ( e.g. many transactions error)
              - Distinct values for Processing Status and Processing Mode
                ( e.g. majority of transactions is Background)

            > Pending material interface transactions ( MTL_TRANSACTIONS_INTERFACE )
              - Distinct process flags( e.g. majority of transactions is errored or ready)
              - Distinct lock flags ( e.g. most of transactions are locked)

            > Pending Shop Floor Move transactions ( WIP_MOVE_TXN_INTERFACE )
              - Distinct values for Process Phase and Process Status 

            > Material and WIP Batches not transfered to GL

          Setup/Configuration of Transaction Interface Managers
          Status of Transaction Interface Managers ( e.g. Running/Pending/Cancelled)
          Setting of INV-Profiles
          Setting of MFG-Debbuging/Tracing profiles
          References to Solution Notes
 
The output file of this test are very useful for support and development
in case there are issues with period close.
 
INVPeriodClose115_[OrgCode]_[Period]_diag.html may be viewed using a
browser or uploaded to support for analysis.

================================================================================
Reference
================================================================================
None

================================================================================
Disclaimer
================================================================================
Except where expressly provided otherwise, the information, software,
provided on an "as is" and "as available" basis. Oracle expressly disclaims
all warranties of any kind, whether express or implied, including, but not
limited to, the implied warranties of merchantability, fitness for a particular
purpose and non-infringement. Oracle makes no warranty that: (a) the results
that may be obtained from the use of the software will be accurate or
reliable; or (b) the information, or other material obtained will meet your
expectations. Any content, materials, information or software downloaded or
otherwise obtained is done at your own discretion and risk. Oracle shall have
no responsibility for any damage to your computer system or loss of data that
results from the download of any content, materials, information or software.


Oracle reserves the right to make changes or updates to the software at any
time without notice.


================================================================================
Limitation Of Liability
================================================================================
In no event shall oracle be liable for any direct, indirect, incidental,
special or consequential damages, or damages for loss of profits, revenue,
data or use, incurred by you or any third party, Whether in an action in
contract or tort, arising from your access to, or use of, the software.
Some jurisdictions do not allow the limitation or exclusion of liability.
accordingly, some of the above limitations may not apply to you.
================================================================================
