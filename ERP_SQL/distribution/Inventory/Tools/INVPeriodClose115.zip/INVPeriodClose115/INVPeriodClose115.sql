UNDEFINE v_headerinfo
DEFINE   v_headerinfo = '$Header: INVPeriodClose115.sql 1.7 28-Nov-2003 support $'
UNDEFINE v_testlongname
DEFINE   v_testlongname = 'Inventory Period Close Check Diagnostic Test'

REM   =========================================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM   Oracle Support Services.  All rights reserved.
REM   =========================================================================
REM   PURPOSE:           Inventory Close Period Check script
REM
REM                      In Applications if you follow the navigation path
REM                      Inventory --> Accounting Close Cycle -->
REM                      --> Inventory Accounting Period
REM                      and select an Open accounting period and click on the
REM                      'Pending...' button it shows you the number of pending
REM                      transactions in various modules of the application.
REM
REM                      This test is an extension of the form - instead of the
REM                      number of pending transactions, this script provides
REM                      detail information about the pending transactions.
REM                      It also shows untransfered GL and WIP Batches
REM
REM   PRODUCT:           Oracle Inventory (INV) 
REM   PRODUCT VERSIONS:  11.5.X
REM   PLATFORM:          Generic
REM   PARAMETERS:        Apps Username ( e.g. Operations )
REM                      Apps Responsibility ID ( e.g. 51231 )
REM                      Organization Code ( e.g. M1 )
REM                      Inventory Accounting Period Name( e.g. Jul-03 )
REM                      Summary or Detail Report: S or D
REM   =========================================================================


REM   =========================================================================
REM   USAGE:    sqlplus <apps_username/apps_password> @INVPeriodClose115.sql
REM   EXAMPLE:  sqlplus apps/apps @INVPeriodClose115.sql
REM   OUTPUT:   HTML
REM   =========================================================================


REM   =========================================================================
REM   CHANGE HISTORY:
REM     30-Jul-2002   Jonathan Corker   Created
REM     21-Oct-2003   Gerhard Schmidt   Rewrites plus BDE ERs
REM     10-Nov-2003   Sanjeev Kale      CoAuthor
REM     25-NOV-2003   Gerhard Schmidt   Implement FQA Feedback from 19-Nov-03
REM   =========================================================================



REM  ================SQL PLUS Environment setup================================
set serveroutput on size 1000000
set verify off
set feedback off


REM ============== Define SQL Variables for input parameters ==================
VARIABLE v_username  VARCHAR2(100);
VARIABLE error_flag  VARCHAR2(1);
VARIABLE v_org_id    NUMBER;
VARIABLE v_detail    VARCHAR2(1);
VARIABLE v_period_id NUMBER;

REM =========================Validate DATABASE Version ========================
REM ==========NOTE - This section only needed for tests using HTML API's=======

DECLARE 
  l_version           VARCHAR2(30);
BEGIN 

  SELECT MAX(version)
  INTO   l_version
  FROM   v$instance;

  IF l_version < '8.1.7.0.0' THEN 
     DBMS_OUTPUT.PUT_LINE(chr(10));
     DBMS_OUTPUT.PUT_LINE('ERROR - Invalid Database Version '||l_version || '. The test requires RDBMS version 8.1.7 or higher');
     DBMS_OUTPUT.PUT_LINE('ACTION - Type Ctrl-C <Enter> to exit the test.');
     DBMS_OUTPUT.PUT_LINE(chr(10));
  END IF;

EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - Database Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/


REM ============Validate SQL*Plus Version Character Set Combination============
REM =======NOTE - This section only needed for tests using HTML API's==========

DECLARE
  l_nls_characterset    nls_database_parameters.value%TYPE;
  l_sql_release_int     INTEGER(20) :=  to_number('&_SQLPLUS_RELEASE');
  l_sql_release_chr     VARCHAR2(50) := '&_SQLPLUS_RELEASE';
BEGIN
 
  SELECT value
    INTO  l_nls_characterset
    FROM  nls_database_parameters
    WHERE parameter = 'NLS_CHARACTERSET';
 
  FOR i IN 1..4 LOOP
    l_sql_release_chr := substr(l_sql_release_chr,1,(2*i)-1)||'.'||
      substr(l_sql_release_chr,(2*i)+1);
  END LOOP;


  IF l_nls_characterset LIKE 'UTF%' THEN
    IF l_sql_release_int IS null THEN
      DBMS_OUTPUT.PUT_LINE(chr(10));
      DBMS_OUTPUT.PUT_LINE('ATTENTION - Cannot determine version of SQL*plus being used for test run.');
      DBMS_OUTPUT.PUT_LINE('.           This test may fail if not run using version 8.1.X or higher of SQL*Plus.');
      DBMS_OUTPUT.PUT_LINE('Attempting to run the test.......');
      DBMS_OUTPUT.PUT_LINE(chr(10));
    ELSIF l_sql_release_int < 801000000 THEN
      DBMS_OUTPUT.PUT_LINE(chr(10));
      DBMS_OUTPUT.PUT_LINE('ERROR - Invalid SQL*plus Version '||l_sql_release_chr);
      DBMS_OUTPUT.PUT_LINE('ACTION - On databases using the '||l_nls_characterset||' NLS characterset this test should not be run using this ');
      DBMS_OUTPUT.PUT_LINE('.        SQL*plus Version.  Please rerun this test using version 8.1.X or higher of SQL*Plus.');
      DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
      DBMS_OUTPUT.PUT_LINE(chr(10));
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - SQL*plus Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM ================Show responsibilities assigned to given user===============
DECLARE
  l_applversion  fnd_product_groups.release_name%TYPE;
  l_counter      INTEGER;
  l_cursor       INTEGER;
  sqltxt         VARCHAR2(3000);
  l_resp_id      INTEGER;
  l_resp_name    VARCHAR2(100);
BEGIN

  SELECT substr(release_name,1,4)
    INTO l_applversion
    FROM fnd_product_groups;

  IF l_applversion = '11.5' THEN

    SELECT NVL(RTRIM(LTRIM(UPPER('&Application_user_name'))), '<NULL username>')
      INTO :v_username
      FROM dual;
 
    sqltxt := 'SELECT to_char(a.responsibility_id) id, '||
              '       b.responsibility_name name '||
              'FROM   fnd_user_resp_groups a, '||
              '       fnd_responsibility_vl b, '||
              '       fnd_user u '||
              'where  a.user_id = u.user_id '||
              'and    a.responsibility_id = b.responsibility_id '||
              'and    a.responsibility_application_id = b.application_id '||
              'and    sysdate between '||
              '          a.start_date and nvl(a.end_date,sysdate+1) '||
              'and    upper(u.user_name) = '''|| :v_username ||''''||
              'order  by b.responsibility_name';

    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('Responsibilities assigned to User:  '|| :v_username);
    DBMS_OUTPUT.PUT_LINE('=================================================================' || chr(10) );
  
    l_cursor := dbms_sql.open_cursor; 
    dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
    dbms_sql.define_column(l_cursor, 1, l_resp_id);
    dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
    l_counter := dbms_sql.EXECUTE(l_cursor); 
    l_counter := 0;
    WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP
      l_counter := l_counter + 1;
      dbms_sql.column_value(l_cursor, 1, l_resp_id);
      dbms_sql.column_value(l_cursor, 2, l_resp_name);
      DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
    END LOOP;
  
    IF l_counter = 0 THEN
       RAISE no_data_found;
    END IF;
    dbms_sql.close_cursor(l_cursor);
  ELSE
     DBMS_OUTPUT.PUT_LINE(chr(10));
     DBMS_OUTPUT.PUT_LINE('ERROR  - Invalid Application Version  '|| l_applversion);
     DBMS_OUTPUT.PUT_LINE('ACTION - This Test is not intended for this Application version.'  );
     DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
     DBMS_OUTPUT.PUT_LINE(chr(10));
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
    DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.' || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.  Rerun the test with a valid user name.' );
    DBMS_OUTPUT.PUT_LINE(chr(10));
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error: '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

PROMPT 
UNDEFINE v_respid
ACCEPT v_respid NUMBER PROMPT  'Please choose a Responsibility ID FROM the list : '
PROMPT 


REM ============= Accept other Input Parameters ===============================

PROMPT 

DECLARE -- list organizations
  l_counter      INTEGER;
  l_cursor       INTEGER;
  sqltxt         VARCHAR2(1000);
  l_org_code     mtl_parameters.organization_code%TYPE;
  l_org_name     org_organization_definitions.organization_name%TYPE;
  l_org_id       mtl_parameters.organization_id%TYPE;
  l_space        VARCHAR2(10);
  l_temp         VARCHAR2(200);

BEGIN -- list organizations

  sqltxt :=  'SELECT mp.organization_code, mp.organization_id,
                     ood.organization_name
                FROM mtl_parameters mp ,org_organization_definitions ood, 
                     hr_operating_units ou
               WHERE mp.organization_id = ood.organization_id
                 AND ood.operating_unit = ou.organization_id(+)
               ORDER BY mp.organization_code';

  DBMS_OUTPUT.PUT_LINE(chr(10) || 'Organization Code and Name:  ');
  DBMS_OUTPUT.PUT_LINE('=================================================================' || chr(10) );
  l_cursor := dbms_sql.open_cursor; 
  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
  dbms_sql.define_column(l_cursor, 1, l_org_code,3);
  dbms_sql.define_column(l_cursor, 2, l_org_id);
  dbms_sql.define_column(l_cursor, 3, l_org_name,100);
  l_counter := dbms_sql.execute(l_cursor); 
  l_counter := 0;
  WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP
    l_counter := l_counter + 1;
    dbms_sql.column_value(l_cursor, 1, l_org_code);
    dbms_sql.column_value(l_cursor, 2, l_org_id);
    dbms_sql.column_value(l_cursor, 3, l_org_name);
    l_space := rpad (' ' , 4 - length(l_org_code), ' ');
    l_temp := l_org_code || l_space || '... '|| l_org_name;
    DBMS_OUTPUT.PUT_LINE( l_temp ); 
  END LOOP;
  
  DBMS_OUTPUT.PUT_LINE(' ');
  IF l_counter = 0 THEN
    RAISE NO_DATA_FOUND;
  END IF;
  DBMS_SQL.CLOSE_CURSOR(l_cursor);

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any organizations');
    DBMS_OUTPUT.PUT_LINE('ACTION - Ensure an organization is defined before running this test.' || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.' || chr(10));
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR  - Organization retrieval error: '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.'  || chr(10) );
END; -- list organizations
/ 

PROMPT 
UNDEFINE v_org
ACCEPT v_org CHAR FORMAT A3 DEFAULT 'ORA' PROMPT 'Enter Inventory Organization Code : ' 

REM ================= List open periods for user-entered OrgCode ==============
DECLARE -- List open periods for user entered OrgCode
  l_counter      INTEGER;
  l_cursor       INTEGER;
  sqltxt         VARCHAR2(1000);
  l_space        VARCHAR2(10);
  l_temp         VARCHAR2(200);
  l_period_name       org_acct_periods.period_name%TYPE;
  l_period_start_date org_acct_periods.period_start_date%TYPE;
 
BEGIN -- List open periods for user-entered OrgCode
  sqltxt := 'SELECT period_name, period_start_date
               FROM org_acct_periods oap, mtl_parameters mp
              WHERE oap.open_flag = ''Y''
                AND oap.organization_id = mp.organization_id
                AND mp.organization_code = ''&&v_org''
              ORDER BY period_start_date DESC';
 
  DBMS_OUTPUT.PUT_LINE(chr(10) || 'Open Periods for Organization &&v_org' );
  DBMS_OUTPUT.PUT_LINE('=================================================================' || chr(10) );
  DBMS_OUTPUT.PUT_LINE('Periodname  Startdate' );
  DBMS_OUTPUT.PUT_LINE('----------  ---------' );
  l_cursor := dbms_sql.open_cursor;
  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
  dbms_sql.define_column(l_cursor, 1, l_period_name,15);
  dbms_sql.define_column(l_cursor, 2, l_period_start_date);
  l_counter := dbms_sql.execute(l_cursor);
  l_counter := 0;
  WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP
    l_counter := l_counter + 1;
    dbms_sql.column_value(l_cursor, 1, l_period_name);
    dbms_sql.column_value(l_cursor, 2, l_period_start_date);
    l_space := rpad (' ' , 8 - length(l_period_name), ' ');
    l_temp := l_period_name || l_space || ' ... '|| l_period_start_date;
    DBMS_OUTPUT.PUT_LINE( l_temp );
  END LOOP;
  DBMS_OUTPUT.PUT_LINE(' ');
  IF l_counter = 0 THEN
    RAISE NO_DATA_FOUND;
  END IF;
  DBMS_SQL.CLOSE_CURSOR(l_cursor);
 
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any open period for organization &&v_org');
    DBMS_OUTPUT.PUT_LINE('ACTION - Ensure a period is open before running this test.' || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.' || chr(10));
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR  - Inventory Period retrieval error: '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.'  || chr(10) );
END; -- list periods
/

UNDEFINE v_period_name
ACCEPT v_period_name CHAR DEFAULT 'period' PROMPT 'Enter Period Name : '

REM ======== check userinput periodname =================
DECLARE
    l_rc INTEGER;
BEGIN
    SELECT 1
      INTO l_rc
      FROM org_acct_periods oap, mtl_parameters mp
     WHERE period_name = '&&v_period_name'
       AND oap.organization_id = mp.organization_id
       AND mp.organization_code = '&&v_org';

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE( chr(10) );
        DBMS_OUTPUT.PUT_LINE('ERROR  - Invalid periodname ''&&v_period_name''');
        DBMS_OUTPUT.PUT_LINE('ACTION - Ensure a valid periodname is entered' );
        DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.' );
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE( chr(10) );
        DBMS_OUTPUT.PUT_LINE('ERROR  - periodname_check_error : ' || sqlerrm);
        DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services' );
        DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.' );
END; -- check userinput periodname
/

PROMPT
UNDEFINE v_summary_or_detail
ACCEPT v_summary_or_detail CHAR FORMAT A1 DEFAULT 'D' PROMPT '(S)ummary or (D)etail : ' 
PROMPT

DECLARE

    e_invalid_responsibilty EXCEPTION;
    e_invalid_organization  EXCEPTION;
    e_invalid_period        EXCEPTION;
    e_invalid_period_status EXCEPTION;

    l_number   NUMBER;

    l_open_flag           org_acct_periods.open_flag%TYPE;
    l_period_close_date   org_acct_periods.period_close_date%TYPE;
    l_period_year         org_acct_periods.period_year%TYPE;
    l_period_num          org_acct_periods.period_num%TYPE;
    l_schedule_close_date org_acct_periods.schedule_close_date%TYPE;
    l_period_start_date   org_acct_periods.period_start_date%TYPE;
    l_period_id           org_acct_periods.acct_period_id%TYPE;

BEGIN -- Check_User_Input

    IF UPPER( '&v_summary_or_detail' ) = 'S' THEN
        :v_detail := 'N';
    ELSE
        :v_detail := 'Y';
    END IF;
    :error_flag := 'N';

    SELECT count(*) 
      INTO l_number
      FROM fnd_responsibility
     WHERE responsibility_id = &v_respid;

    If l_number <> 1 THEN RAISE e_invalid_responsibilty; END IF;

    SELECT COUNT(*) 
      INTO l_number
      FROM org_organization_definitions
     WHERE organization_code = '&v_org';

    If l_number <> 1 THEN RAISE e_invalid_organization; END IF;

    -- Get Organisation_ID
    SELECT organization_id 
      INTO :v_org_id
      FROM org_organization_definitions
     WHERE organization_code = '&v_org';

    SELECT COUNT(*) 
      INTO l_number
      FROM mtl_parameters 
     WHERE organization_id = :v_org_id;

    If l_number <> 1 THEN RAISE e_invalid_organization; END IF;

    SELECT COUNT(*) 
      INTO l_number 
      FROM org_acct_periods
     WHERE organization_id = :v_org_id
       AND period_name = '&v_period_name';

    If l_number <> 1 THEN RAISE e_invalid_period; END IF;

    -- Has user entered an open period ?
    SELECT open_flag, period_close_date
          ,period_year, period_num
          ,schedule_close_date, acct_period_id, period_start_date
      INTO l_open_flag, l_period_close_date
          ,l_period_year, l_period_num
          ,l_schedule_close_date, :v_period_id, l_period_start_date
      FROM org_acct_periods
     WHERE organization_id = :v_org_id
       AND period_name = '&v_period_name';

    IF ( l_open_flag <> 'Y' OR l_period_close_date IS NOT NULL ) THEN
        RAISE e_invalid_period_status;
    END IF;

    DBMS_OUTPUT.put_line('Inventory Close Diagnostic Report for Organization '||'&v_org'||' will be produced');
    DBMS_OUTPUT.put_line('for Period Name '||'&v_period_name'|| ' Year ' ||l_period_year|| ' Period Number ' || l_period_num);
    DBMS_OUTPUT.put_line('Period schedule close date '||TO_CHAR(l_schedule_close_date,'DD-MON-RRRR'));

EXCEPTION
    WHEN e_invalid_responsibilty THEN
        DBMS_OUTPUT.put_line('!');
        DBMS_OUTPUT.put_line('ERROR - Responsibility ID '||&v_respid ||' Does not exist');
        DBMS_OUTPUT.put_line('ACTION - Enter a valid Responsibility');
        DBMS_OUTPUT.put_line('!');
        DBMS_OUTPUT.put_line('Type Ctrl-C <Enter> to exit the test.'||CHR(10));
        :error_flag := 'Y';

    WHEN e_invalid_organization THEN
        DBMS_OUTPUT.put_line('!');
        DBMS_OUTPUT.put_line('ERROR - Organization '||'&v_org' ||' is not a Inventory Organization');
        DBMS_OUTPUT.put_line('ACTION - Rerun this test and enter a valid Inventory Organization');
        DBMS_OUTPUT.put_line('!');
        DBMS_OUTPUT.put_line('Type Ctrl-C <Enter> to exit the test.'||CHR(10));
        :error_flag := 'Y';

    WHEN e_invalid_period THEN
        DBMS_OUTPUT.put_line('!');
        DBMS_OUTPUT.put_line('ERROR - Period Name '||'&v_period_name' ||' is not a valid period');
        DBMS_OUTPUT.put_line('ACTION - Rerun this test and enter a valid period name');
        DBMS_OUTPUT.put_line('!');
        DBMS_OUTPUT.put_line('Type Ctrl-C <Enter> to exit the test.'||CHR(10));
        :error_flag := 'Y';

    WHEN e_invalid_period_status THEN
        DBMS_OUTPUT.put_line('!');
        DBMS_OUTPUT.put_line('ERROR - Period Name '||'&v_period_name' ||' is not in the correct status '||l_open_flag);
        DBMS_OUTPUT.put_line('ACTION - Enter a period with an open status');
        DBMS_OUTPUT.put_line('!');
        DBMS_OUTPUT.put_line('Type Ctrl-C <Enter> to exit the test.'||CHR(10));
        :error_flag := 'Y';

END; -- Check_User_Input
/

REM ============ Spooling the output file======================================
UNDEFINE v_spoolfilename
DEFINE v_spoolfilename  = 'INVPeriodClose115_&v_org._&v_period_name._diag.html'

PROMPT  =======================================================================
PROMPT  Output will be spooled to &v_spoolfilename
PROMPT  =======================================================================
PROMPT
PROMPT Running.....
PROMPT 
SPOOL  &v_spoolfilename

REM =================Run the Pl/SQL api file ==================================
@@CoreApiHtml.sql -- declare (block 0), kein begin, procedures, kein end

-- =================Run the INV api file ==================================
@@INVApiHtml.sql -- begin (block 0), declare (block 1), procedure, kein end

BEGIN -- begin (block 1)

  DECLARE -- declare (block 2)
    l_number    NUMBER;

    l_1_schedule_close_date  org_acct_periods.schedule_close_date%TYPE;
    l_1_period_start_date  org_acct_periods.period_start_date%TYPE;
    l_1_period_name          org_acct_periods.period_name%TYPE;

    l_period_id            org_acct_periods.acct_period_id%TYPE;
    l_schedule_close_date  org_acct_periods.schedule_close_date%TYPE;
    l_period_start_date  org_acct_periods.period_start_date%TYPE;
    l_period_name          org_acct_periods.period_name%TYPE;
    p_username VARCHAR2(100);
    p_respid NUMBER;
    p_organization_id NUMBER;
    g_period_name org_acct_periods.period_name%TYPE;

    -- ------------------------ Test Declare Section ----------------------

------------------------------------------------------------------------------
-- PROCEDURE: Display_Mti_Info
-- DESCRIPTION:
--        If records exist in MTI:
--            Display Summary and Detail information about 
--            Pending Interface Material Transactions
--        Resolution recommended
-- Input:
--        p_org_id
--        p_period_id
--        p_schedule_close_date
-- Return-Code:
--        None
-- USAGE:
--        Display_MTI_Info( org_id, period_id, sched_close_date)
-- USAGE-EXAMPLES:
--        Display_MTI_Info( 207 , 1234, 31-Aug-03 )
------------------------------------------------------------------------------
PROCEDURE Display_MTI_Info( p_org_id IN NUMBER
                          , p_period_id IN org_acct_periods.ACCT_PERIOD_ID%TYPE
           , p_schedule_close_date IN org_acct_periods.schedule_close_date%TYPE)
IS
    l_proc VARCHAR2(30) := 'Display_MTI_Info';
    l_schedule_close  NUMBER; -- to make BETWEEN work properly GSM
BEGIN -- Display_MTI_Info

    SectionPrintBig( 'Pending Interface Material Transactions (MTL_TRANSACTIONS_INTERFACE)' );
    BRPrint;

    -- Assigning to local variables because they are used multiple times
    -- and make the select easier to read.
    -- TRUNC() does not work properly when sql-string is built . ORA-1840
    l_schedule_close := TO_CHAR( p_schedule_close_date, 'YYYYDDD' );

    -- Count records in MTI
    SELECT COUNT(*) 
      INTO v_rc
      FROM mtl_transactions_interface
     WHERE organization_id = p_org_id 
       AND (acct_period_id = p_period_id 
            OR (acct_period_id IS NULL
                AND
                TRUNC( transaction_date ) <= TRUNC( p_schedule_close_date )
               )
           )
       AND process_flag <> 9; -- 9=sales orders

    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
        RETURN; -- exit procedure
    END IF;

    Tab1Print( 'There are ' || v_rc || ' transactions' );
    BRPrint;
    WarningPrint( 'Pending interface material transactions exist.<BR>
                   Resolution of pending interface material transactions is recommended' );
    ActionWarningLink( 'Resubmit those transactions using the "Transaction Interface" form.<BR>
                         ( E.g. Inventory : Transactions > Transaction Open Interface<BR>
                         See Note ', '110424.1', ' (Unprocessed Transactions/Closing INV Accounting Period FAQ) on how to solve pending interface material transactions<BR>
                         See following information for transaction details' );

    BRPrint;

-------------------------------------------------------------------------------
    g_title := 'Values for Process Flag';
    g_text := 'SELECT DECODE( process_flag, 1, ''Ready''
                                          , 2, ''Not Ready''
                                          , 3, ''Error''
                            , process_flag ) "Process Flag"
                    , COUNT(*) count
                 FROM mtl_transactions_interface
                WHERE organization_id = '|| p_org_id || '
                  AND (acct_period_id = '|| p_period_id || '
                       OR (acct_period_id IS NULL
                           AND
                           TO_CHAR( transaction_date, ''YYYYDDD'' ) <=
                           ' || l_schedule_close || '
                          ) 
                      )
                  AND process_flag <> 9 -- 9=sales orders
                GROUP BY process_flag';
 
    Run_sql( g_title, g_text, 'N', NULL, 1 );
-------------------------------------------------------------------------------
    g_title := 'Values for Lock Flag';
    g_text := 'SELECT DECODE( NVL( lock_flag, 2 ), 1, ''Locked''
                                                 , 2, ''Not Locked''
                            , lock_flag ) "Lock Flag"
                    , COUNT(*) count
                 FROM mtl_transactions_interface
                WHERE organization_id = '|| p_org_id || '
                  AND (acct_period_id = '|| p_period_id || '
                       OR (acct_period_id IS NULL
                           AND
                           TO_CHAR( transaction_date, ''YYYYDDD'' ) <=
                           ' || l_schedule_close || '
                          )
                      )
                  AND process_flag <> 9 -- 9=sales orders
                GROUP BY lock_flag';
 
    Run_sql( g_title, g_text, 'N', NULL, 1 );

-------------------------------------------------------------------------------
    IF ( :v_detail = 'Y' )
    THEN
        g_title := 'Pending Interface Transactions';
        g_text := 'SELECT mti.transaction_interface_id "Txn IntFace|ID"
                    , transaction_header_id "Txn|Header Id"
                    , mif.item_number 
                      ||'' (''|| mti.inventory_item_id ||'')'' "Item (ID)"
                    , subinventory_code "Subinv"
                    , locator_id Loc_id
                    , mtli.lot_number "Lot|Number"
                    , revision "Rev"
                    , msni.fm_serial_number "From|Serial #"
                    , msni.to_serial_number "To|Serial #"
                    , mti.transaction_quantity "Txn Qty"
                    , mti.primary_quantity "Primary|Qty"
                    , transaction_uom "Txn UoM"
                    , transaction_cost "Txn Cost"
                    , transaction_type_name
                      ||'' (''|| transaction_type_id ||'')'' "Txn Type (ID)"
                    , transaction_action_name
                      ||'' (''|| transaction_action_id ||'')'' "Txn Action (ID)"
                    , transaction_source_type_name
                      ||'' (''|| transaction_source_type_id ||'')''
                      "Txn Source Type (ID)"
                    , transaction_source_name
                      ||'' (''|| transaction_source_id ||'')'' "Txn Source (ID)"
                    , transaction_date "Txn Date"
                    , transfer_subinventory "Transfer|Subinv"
                    , transfer_organization_code
                      ||'' (''|| transfer_organization ||'')''
                      "Transfer|Organization"
                    , mti.request_id "Txn|Request ID"
                    , mti.source_code "Source|Code"
                    , mti.source_line_id "Source|Line ID"
                    , source_header_id "Source|Header ID"
                    , mti.process_flag_desc
                      ||'' ('' || mti.process_flag || '')'' "Process Flag"
                    , transaction_mode_desc
                      ||'' ('' || transaction_mode || '')'' "Txn Mode"
                    , lock_flag_desc 
                      ||'' ('' || lock_flag || '')'' "Lock|Flag"
                    , mti.error_code "Error Code"
                    , error_explanation "Error Explanation"
                 FROM mtl_transactions_interface_v mti,
                      mtl_item_flexfields mif,
                      mtl_serial_numbers_interface msni,
                      mtl_transaction_lots_interface mtli
                WHERE mti.organization_id  = ' || p_org_id || '
                  AND (mti.acct_period_id  = ' || p_period_id || '
                       OR (mti.acct_period_id IS NULL 
                           AND
                           TO_CHAR( mti.transaction_date, ''YYYYDDD'' ) <=
                           ' || l_schedule_close || '
                          )
                      )
                  AND mti.organization_id = mif.organization_id
                  AND mti.inventory_item_id = mif.inventory_item_id
                  AND mti.process_flag <> 9
                  AND (mtli.transaction_interface_id (+) = mti.transaction_interface_id
                       AND
                       msni.transaction_interface_id (+) = mti.transaction_interface_id)
             ORDER BY transaction_date' ;

        Run_sql( 'Pending Interface Transactions', g_text, 'N', NULL, 1 );
    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_period_id=' || p_period_id || ' / p_schedule_close_date=' || p_schedule_close_date );
        Tab0Print( g_text );

END Display_MTI_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_WCTI_Info
-- DESCRIPTION:
--        Pending WIP Costing (WIP_COST_TXN_INTERFACE) (WCTI)
--        Resolution required
-- Input:
--        p_org_id
--        p_period_id
-- Return-Code:
--        None
-- USAGE:
--        Display_WCTI_Info( org_id, period_id )
-- USAGE-EXAMPLES:
--        Display_WCTI_Info( 207 , 1234 )
------------------------------------------------------------------------------
PROCEDURE Display_WCTI_Info( p_org_id IN NUMBER
                          , p_period_id IN org_acct_periods.ACCT_PERIOD_ID%TYPE)
IS
    l_proc VARCHAR2(30) := 'Display_WCTI_Info';
BEGIN -- Display_WCTI_Info

    SectionPrintBig( 'Pending WIP costing transactions (WIP_COST_TXN_INTERFACE)' );
    BRPrint;

    -- Count records in WCTI
    SELECT COUNT(*)
      INTO v_rc
      FROM wip_cost_txn_interface
     WHERE organization_id = p_org_id
       AND acct_period_id = p_period_id ;
 
    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
        RETURN; -- exit procedure
    END IF;
 
    Tab1Print( 'There are ' || v_rc || ' transactions' );
    BRPrint;
    ErrorPrint( 'Pending WIP costing transactions exist.<BR>
                 Resolution of pending WIP costing transactions is required' );
    ActionErrorLink( 'Resubmit all pending WIP costing transactions using the "Pending Resource Transactions" form.<BR>
                       ( E.g WIP > Resource Transactions > Pending Resource Transactions<BR>
                       See Oracle Work in Process User''s Guide or Note ', '110424.1', ' (Unprocessed Transactions/Closing INV Accounting Period FAQ) on how to solve pending WIP costing transactions<BR>
                       See following information for transaction details');

-------------------------------------------------------------------------------
    g_title := 'Values for Process Phase and Process Status';
 
    g_text := 'SELECT DISTINCT process_phase_meaning
                      ||'' (''|| process_phase ||'')'' "Process Phase"
                    , process_status_meaning
                      ||'' (''|| process_status ||'')'' "Process Status"
                    , COUNT(*) count
                 FROM wip_cost_txn_interface_v
                WHERE organization_id = ' || p_org_id || '
                  AND acct_period_id = ' || p_period_id || '
                GROUP BY process_phase_meaning ||'' (''|| process_phase ||'')''
                    , process_status_meaning ||'' (''|| process_status ||'')''';
 
    Run_sql( g_title, g_text, 'N', NULL, 1 );
-------------------------------------------------------------------------------
    g_title := 'Pending WIP Costing Transactions ( WIP_COST_TXN_INTERFACE )';

    IF ( :v_detail = 'Y' )
    THEN
        g_text := 'SELECT wcti.transaction_id "Txn ID"
                        , mif.item_number
                          ||'' (''|| primary_item_id ||'')''
                          "Primary Item ID" --"Assembly ID"
                        , wip_entity_id "WIP Entity|ID"
                        , wip_entity_name "WIP Entity Name"
                        , entity_type "Entity|Type"
                        , repetitive_schedule_id "Repetitive|Schedule ID"
                        , transaction_date "Txn Date"
                        , transaction_quantity "Txn Qty"
                        , transaction_uom "Txn UoM"
                        , transaction_type "Txn Type"
                        , autocharge_type "AutoCharge|Type"
                        , basis_type "Basis|Type"
                        , resource_type "Resource|Type"
                        , standard_rate_flag "Standard|Rate Flag"
                        , wcti.request_id "Txn Request|ID"
                        , group_id "Group ID"
                        , operation_seq_num "Operation|Seq #"
                        , resource_seq_num "Resource|Seq #"
                        , resource_id "Resource|ID"
                        , completion_transaction_id "Completion|Txn ID"
                        , move_transaction_id "Move Txn|ID"
                        , process_phase "Process|Phase"
                        , process_status "Process|Status"
                        , source_code "Source Code"
                        , source_line_id "Source|Line ID"
                        , error_column "Error|Column"
                        , error_message "Error|Message"
                     FROM wip_cost_txn_interface wcti
                        , wip_txn_interface_errors wtie
                        , mtl_item_flexfields mif
                    WHERE wcti.organization_id = ' || p_org_id || '
                      AND wcti.acct_period_id = ' || p_period_id || '
                      AND wtie.transaction_id (+) = wcti.transaction_id
                      AND wcti.organization_id = mif.organization_id
                      AND NVL( wcti.primary_item_id, -1) = mif.inventory_item_id(+)
                    ORDER BY transaction_date, wcti.creation_date
                           , wcti.transaction_id';

        Run_sql( g_title, g_text, 'N', NULL, 1 );
    END IF;
 
    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_period_id=' || p_period_id );
 
END Display_WCTI_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_WSMT_Info
-- DESCRIPTION:
--      Uncosted WSM (Shop Floor Management) Transactions 
--      WSM_SPLIT_MERGE_TRANSACTIONS (WSMT)
--        Resolution required
-- Input:
--        p_org_id
--        p_schedule_close_date
-- Return-Code:
--        None
-- USAGE:
--        Display_WSMT_Info( org_id, period_schedule_clode_date )
-- USAGE-EXAMPLES: 
--        Display_WSMT_Info( 207 , 31-Jul-03 ) 
------------------------------------------------------------------------------
PROCEDURE Display_WSMT_Info( p_org_id IN NUMBER
           , p_schedule_close_date IN org_acct_periods.schedule_close_date%TYPE)
IS
    l_proc VARCHAR2(30) := 'Display_WSMT_Info';
    l_schedule_close  NUMBER; -- Intentionally using type NUMBER
BEGIN -- Display_WSMT_Info

    SectionPrintBig( 'Uncosted WSM transactions ( WSM_SPLIT_MERGE_TRANSACTIONS )' );
    BRPrint;

    -- Assigning to local variables because they are used multiple times
    -- and make the select easier to read.
    -- TRUNC() does not work properly when sql-string is built . ORA-1840
    l_schedule_close := TO_CHAR( p_schedule_close_date, 'YYYYDDD' );

    -- Count records in WSMT
    SELECT COUNT(*)
      INTO v_rc
      FROM wsm_split_merge_transactions
     WHERE organization_id = p_org_id
       AND costed <> 4 -- 4=completed/costed
       AND TRUNC( transaction_date ) <= TRUNC( p_schedule_close_date );

    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
        RETURN; -- exit procedure
    END IF;

    BRPrint;
    Tab1Print( 'There are ' || v_rc || ' transactions with a transaction date before the scheduled period close date' );
    BRPrint;

    ErrorPrint( 'Uncosted WSM transactions exist.<BR>
                 Resolution of uncosted WSM transactions is required' );
    ActionErrorLink(  'Run the WIP lot transactions processor<BR>
                       Navigate to the WIP Lot Transactions Processor window. Choose Submit.<BR>
                       To get details about the transactions navigate to the "WIP Lot Transaction" form<BR>
                       ( E.g Shop Floor Manager : Lot Transactions > WIP Lot Transactions)<BR>
                       Setting profileoption "MRP:Debug Mode" to Yes may give a better error message in the log file.<BR>
                       Note ', '242927.1 ', '( 11i - Resolving Period Close Pending Transaction) will give further information<BR>
                       See following information for transaction details');

-------------------------------------------------------------------------------

    -- wsmt.status and wsmt.costed:
    -- WIP_PROCESS_STATUS : 1 Pending 2 Running 3 Error 4 Complete 5 Warning

    g_title := 'Values for Status and Costed Flag';
    g_text := 'SELECT DISTINCT 
                      mls.meaning ||'' (''|| wsmt.status ||'')'' "Status"
                    , mlc.meaning ||'' (''|| wsmt.costed||'')'' "Costed"
                    , COUNT(*) count
                 FROM wsm_split_merge_transactions wsmt
                    , mfg_lookups mls
                    , mfg_lookups mlc
                WHERE wsmt.organization_id = '|| p_org_id || '
                  AND wsmt.costed <> 4 -- 4=completed/costed
                  AND mls.lookup_code(+) = wsmt.status
                  AND mls.lookup_type(+) = ''WIP_PROCESS_STATUS''
                  AND mlc.lookup_code(+) = wsmt.costed
                  AND mlc.lookup_type(+) = ''WIP_PROCESS_STATUS''
                  AND TO_CHAR( wsmt.transaction_date, ''YYYYDDD'' ) <=
                           ' || l_schedule_close || '
                GROUP BY mls.meaning ||'' (''|| wsmt.status ||'')'' 
                       , mlc.meaning ||'' (''|| wsmt.costed||'')''';
 
    Run_sql( g_title, g_text, 'N', NULL, 1 );
-------------------------------------------------------------------------------

    IF v_rc < 1 THEN
        Tab1Print( 'There are no transactions' );
        RETURN; -- exit procedure
    END IF;

    -- TRUNC() does not work properly when sql-string is built . ORA-1840
    l_schedule_close := TO_CHAR( p_schedule_close_date, 'YYYYDDD');

    g_title := 'Uncosted WSM Transactions';

    IF ( :v_detail = 'Y' )
    THEN
        g_text := 'SELECT wsmt.transaction_id  "Txn ID"
                        , wsmt.transaction_type_id "Txn Type ID"
                        , wsmt.transaction_date "Txn Date"
                        , wsmt.transaction_reference "Txn Reference"
                        , mls.meaning
                          ||'' ('' || wsmt.status || '')'' "Txn|Status"
                        , mlc.meaning
                          ||'' ('' || wsmt.costed || '')'' "Costed"
                        , wsmt.group_id "Txn|Group ID"
                        , wsmt.request_id  "Request ID"
                        , wsmt.error_message "Error Message"
                     FROM wsm_split_merge_transactions wsmt
                        , mfg_lookups mls
                        , mfg_lookups mlc
                    WHERE wsmt.organization_id = ' || p_org_id || '
                      AND wsmt.costed <> 4 -- 4=completed/costed
                      AND mls.lookup_code(+) = wsmt.status
                      AND mls.lookup_type(+) = ''WIP_PROCESS_STATUS''
                      AND mlc.lookup_code(+) = wsmt.costed
                      AND mlc.lookup_type(+) = ''WIP_PROCESS_STATUS''
                      AND TO_CHAR( transaction_date, ''YYYYDDD'' ) <=
                          ' || l_schedule_close || '
                    ORDER BY transaction_id';

        Run_sql( g_title, g_text, 'N', NULL, 1 );
    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_schedule_close_date=' || p_schedule_close_date );

END Display_WSMT_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_WSMTI_Info
-- DESCRIPTION:
--        Pending WSM Interface wsm_split_merge_txn_interface (wsmti)
--        Resolution required
-- Input:
--        p_org_id
--        p_schedule_close_date
-- Return-Code:
--        None
-- USAGE:
--        Display_WSMTI_Info( org_id, period_schedule_clode_date )
-- USAGE-EXAMPLES: 
--        Display_WSMTI_Info( 207 , 31-Jul-03 ) 
------------------------------------------------------------------------------
PROCEDURE Display_WSMTI_Info( p_org_id IN NUMBER
           , p_schedule_close_date IN org_acct_periods.schedule_close_date%TYPE)
IS
    l_proc VARCHAR2(30) := 'Display_WSMTI_Info';
    l_schedule_close  NUMBER; -- to make BETWEEN work properly GSM
BEGIN -- Display_WSMTI_Info

    SectionPrintBig( 'Pending WSM interface transactions (WSM_SPLIT_MERGE_TXN_INTERFACE)' );
    BRPrint;

    l_schedule_close := TO_CHAR( p_schedule_close_date, 'YYYYDDD' );

    -- Count records in WSMTI
    SELECT COUNT(*)
      INTO v_rc
      FROM wsm_split_merge_txn_interface
     WHERE organization_id = p_org_id
       AND process_status <> 4 -- completed
       AND TRUNC( transaction_date ) <= TRUNC( p_schedule_close_date );
 
    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
        RETURN; -- exit procedure
    END IF;

    Tab1Print( 'There are ' || v_rc || ' transactions with a transaction date before the scheduled period close date' );
    BRPrint;
 
    ErrorPrint( 'Pending WSM interface transactions exist.<BR>
                 Resolution of pending WSM interface transactions is required');
    ActionErrorLink( 'Please see Note ', '242927.1', ' ( 11i - Resolving Period Close Pending Transaction) for further information<BR>
See following information for transaction details' );
 
    BRPrint;

    g_title := 'Pending WSM Interface Transactions' ;

    IF ( :v_detail = 'Y' )
    THEN
        g_text := 'SELECT header_id "Header ID"
                        , transaction_type_id "Txn Type ID"
                        , transaction_date "Txn Date"
                        , process_status "Process|Status"
                        , transaction_id "Txn ID"
                        , group_id "Group|ID"
                        , request_id "Request|ID"
                        , error_message "Error Message"
                     FROM wsm_split_merge_txn_interface
                    WHERE organization_id = ' || p_org_id || '
                      AND process_status <> 4 -- completed
                      AND TO_CHAR( transaction_date, ''YYYYDDD'' ) <=
                          ' || l_schedule_close || '
                    ORDER BY transaction_date';

        Run_sql( g_title, g_text, 'N', NULL, 1 );
    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_schedule_close_date=' || p_schedule_close_date );

END Display_WSMTI_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_WDD_Info
-- DESCRIPTION:
--        Unprocessed Shipping Transactions
--        Resolution required OR recommended depening on Environment
-- Input:
--        p_org_id
--        p_period_start_date
--        p_schedule_close_date
-- Return-Code:
--        None
-- USAGE:
--        Display_WDD_Info( orgid, periodid, period_start, period_sched_close )
-- USAGE-EXAMPLES: 
--        Display_WDD_Info( 207 , 1234, 01-Jul-03, 31-Jul-03 ) 
------------------------------------------------------------------------------
PROCEDURE Display_WDD_Info( p_org_id IN NUMBER
                           , p_period_id IN org_acct_periods.ACCT_PERIOD_ID%TYPE
                , p_period_start_date IN org_acct_periods.period_start_date%TYPE
           , p_schedule_close_date IN org_acct_periods.schedule_close_date%TYPE)
IS
    l_proc            VARCHAR2(30) := 'Display_WDD_Info';
    l_period_start    NUMBER; -- Intentionally using type NUMBER
    l_schedule_close  NUMBER; -- to make BETWEEN work properly GSM

    l_cursor          NUMBER;
    l_counter         NUMBER;
    l_close_option    NUMBER;
    l_return_status   NUMBER;
    l_msg_count       NUMBER;
    l_msg_data        VARCHAR2(200);
BEGIN -- Display_WDD_Info

    SectionPrintBig( 'Unprocessed Shipping Transactions (WSH_DELIVERY_DETAILS)' );
    BRPrint;

    -- Assigning to local variables because they are used multiple times
    -- and make the select easier to read.
    l_period_start := TO_CHAR( p_period_start_date, 'YYYYDDD');
    l_schedule_close := TO_CHAR( p_schedule_close_date, 'YYYYDDD');

    -- Count records in WDD etc.
    SELECT COUNT(*)
      INTO v_rc
      FROM wsh_delivery_details     wdd
         , wsh_delivery_assignments wda
         , wsh_new_deliveries       wnd
         , wsh_delivery_legs        wdl
         , wsh_trip_stops           wts
     WHERE wdd.organization_id = p_org_id
       AND wdd.source_code = 'OE'
       AND wdd.released_status = 'C'
       AND wdd.inv_interfaced_flag in ( 'N', 'P' ) 
       AND wda.delivery_detail_id  = wdd.delivery_detail_id
       AND wnd.delivery_id = wda.delivery_id
       AND wnd.status_code IN ( 'CL', 'IT' )
       AND wdl.delivery_id = wnd.delivery_id
       AND wdl.pick_up_stop_id = wts.stop_id
       AND TO_CHAR( wts.actual_departure_date, 'YYYYDDD' )
                      BETWEEN l_period_start 
                        AND l_schedule_close ;

    IF v_rc < 1 THEN
        Tab1Print( 'There are no transactions' );
        RETURN; -- exit procedure
    END IF;
 
    Tab1Print( 'There are ' || v_rc || ' transactions' );
    BRPrint;

    -- Is resolution of pending shipping txn required or recommended ?
    -- This hook exists only in INV.H onwards ( CSTINVRB.pls )
    -- See also bug 3136154 and bug 3124108 and Note 238700.1 
    SELECT COUNT(*)
      INTO v_rc
      FROM user_objects
     WHERE OBJECT_NAME ='CST_PERIODCLOSEOPTION_PUB'
       AND OBJECT_TYPE = 'PACKAGE';

    IF v_rc > 0 THEN -- Package CST_PERIODCLOSEOPTION_PUB exists
        BEGIN
            g_text := 'BEGIN cst_periodCloseOption_pub.shipping_txn_hook(
                                  :p_api_version
                                , :i_org_id
                                , :i_acct_period_id
                                , :x_close_option
                                , :x_return_status
                                , :x_msg_count
                                , :x_msg_data ); END;';

            EXECUTE IMMEDIATE g_text using IN 1.0, IN p_org_id, IN p_period_id
                                 , OUT l_close_option, OUT l_return_status
                                 , OUT l_msg_count, OUT l_msg_data ;

            -- From CSTINVRB.pls : x_close_option=0=default=required
            -- From bug 3136154 and bug 3124108 : x_close_option=1=recommended
            
            g_text := 'Resolution of unprocessed shipping transactions is ';
            IF l_close_option = 0 THEN -- required
                ErrorPrint( 'Unprocessed shipping transactions exist.<BR>
                             Resolution of unprocessed shipping transactions is required' );
                ActionErrorLink( 'Please resolve unprocessed shipping transactions.<BR>
Details can be found in the "Query Manager" form<BR>
( E.g. Navigate ONT : Shipping > Transactions )<BR>
Note ', '242927.1', ' ( 11i - Resolving Period Close Pending Transaction) will give detailed information<BR>
See following information for transaction details' );
            ELSE
                WarningPrint( 'Unprocessed shipping transactions exist.<BR>
                               Resolution of unprocessed shipping transactions is highly recommended' );
                ActionWarningLink( 'Please see Note 238700.1 (Unprocessed Shipping Transactions Stop Period Close) for possible side effects on not solving pending shipping transactions.<BR>
Details about unprocessed shipping transactions can be found in the "Query Manager" form<BR>
( E.g. Navigate ONT : Shipping > Transactions )<BR>
Note', '242927.1', '( 11i - Resolving Period Close Pending Transaction) will give detailed information<BR>
See following information for transaction details' );
            END IF;
        END;
    ELSE
        ErrorPrint( 'Pending shipping transactions exist.<BR>
                     Resolution of pending shipping transactions is required' );
        ActionErrorLink( 'Please resolve pending shipping transactions.<BR>
( E.g. Navigate ONT : Shipping > Transactions )<BR>
Note ', '242927.1', ' ( 11i - Resolving Period Close Pending Transaction) will give detailed information<BR>
See following information for transaction details' );
    END IF;
      
    g_title := 'Unprocessed Shipping Transactions';

    IF ( :v_detail = 'Y' ) 
    THEN
        g_text := 'SELECT wdd.delivery_detail_id "Delivery|Detail ID"
                        , wnd.delivery_id "Delivery|ID"
                        , wdd.source_code "Source Code"
                        , wdd.source_header_id "Source Header|ID"
                        , wdd.source_line_id "Source Line|ID"
                        , wdd.source_header_number "Source Header|Number"
                        , wdd.source_line_number "Source Line|Number"
                        , wdd.inventory_item_id "Item ID"
                        , wdd.item_description "Item Description"
                     FROM wsh_delivery_details wdd,
                          wsh_delivery_assignments wda,
                          wsh_new_deliveries wnd,
                          wsh_delivery_legs wdl,
                          wsh_trip_stops wts
                    WHERE wdd.source_code         = ''OE''
                      AND wdd.released_status     = ''C''
                      AND wdd.inv_interfaced_flag in (''N'' ,''P'')
                      AND wdd.organization_id     = ' || p_org_id || '
                      AND wda.delivery_detail_id  = wdd.delivery_detail_id
                      AND wnd.delivery_id         = wda.delivery_id
                      AND wnd.status_code in      (''CL'',''IT'')
                      AND wdl.delivery_id         = wnd.delivery_id
                      AND TO_CHAR( wts.actual_departure_date, ''YYYYDDD'' )
                          BETWEEN ' || l_period_start || '
                            AND ' || l_schedule_close || '
                      AND wdl.pick_up_stop_id = wts.stop_id' ;

        Run_sql( g_title, g_text, 'N', NULL, 1 );
    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_period_start_date=' || p_period_start_date || ' / p_schedule_close_date=' || p_schedule_close_date );

END Display_WDD_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_MMTT_Info 
-- DESCRIPTION:
--        Unprocessed Material Transactions (MTL_MATERIAL_TRANSACTIONS_TEMP)
--        Resolution required
-- Input:
--        p_org_id
--        p_period_id
-- Return-Code:
--        None
-- USAGE:
--        Display_MMTT_Info ( p_org_id , p_period_id )
-- USAGE-EXAMPLES: 
--        Display_MMTT_Info ( 207 , 1234 ) 
------------------------------------------------------------------------------
PROCEDURE Display_MMTT_Info( p_org_id IN NUMBER
                          , p_period_id IN org_acct_periods.acct_period_id%TYPE)
IS
    l_proc VARCHAR2(30) := 'Display_MMTT_Info';
BEGIN -- Display_MMTT_Info

    SectionPrintBig( 'Unprocessed Material Transactions (MTL_MATERIAL_TRANSACTIONS_TEMP)' );
    BRPrint;

    -- Count records in MMTT
    SELECT COUNT(*) 
      INTO v_rc
      FROM mtl_material_transactions_temp
     WHERE organization_id = p_org_id
       AND acct_period_id = p_period_id
       AND NVL( transaction_status, 0 ) <> 2;

    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
        RETURN; -- exit procedure
    END IF; 

    Tab1Print( 'There are ' || v_rc || ' transactions' );
    BRPrint;

    ErrorPrint( 'Unprocessed material transactions exist.<BR>
                 Resolution of unprocessed material transactions is required');
    ActionErrorLink( 'Resubmit those transactions using the "Pending Transactions" form.<BR>
( E.g. Inventory > Transactions > Pending Transactions)<BR>
Make sure the Process transaction interface Manager ( Material transaction Manager ) is running<BR>
Check the logfiles of the "Inventory transaction worker"<BR>
If those transactions dont get processed, please see Note ', '246816.1', ' (Pending Errored Material Transactions Diagnostic) on solving these Transactions<BR>
See following information for transaction details' );

    BRPrint;
-------------------------------------------------------------------------------
    g_title := 'Types of Errors';
 
    g_text := 'SELECT DISTINCT NVL( error_code, ''Empty Error_Code'') "Error Code"
                    , NVL( error_explanation, ''Empty Error_Explanation'' ) "Error Explanation"
                    , COUNT(*) count
                 FROM mtl_material_transactions_temp
                WHERE organization_id = ' || p_org_id || '
                  AND acct_period_id = ' || p_period_id || '
                  AND NVL( transaction_status, 0 ) <> 2
                GROUP BY error_code, error_explanation';
 
    Run_sql( g_title, g_text, 'N', NULL, 1 );

-------------------------------------------------------------------------------
    g_title := 'Unprocessed Material Transactions';

    IF ( :v_detail = 'Y' ) 
    THEN
        -- Attention: number of rows from summary and detail can differ, if
        --            transaction for serial items exists and the are more than 
        --            one MSNT record for a given transaction in MMTT. Gerhard

        g_text := 
            'SELECT mmtt.transaction_temp_id "Txn|Temp Id"
                  , transaction_header_id "Txn|Header Id"
                  , mmtt.source_code "Source Code"
                  , mif.item_number
                  ||'' (''|| mmtt.inventory_item_id ||'')'' "Item (ID)"
                  , subinventory_code "Subinv"
                  , locator_id "Stock Locator"
                  , revision "Rev"
                  , mtlt.lot_number "Lot|Number"
                  , msnt.fm_serial_number "From|Serial#"
                  , msnt.to_serial_number "To|Serial#"
                  , transaction_date "Txn Date"
                  , mmtt.transaction_quantity "Txn Qty"
                  , mmtt.primary_quantity "Primary|Qty"
                  , transaction_uom "Txn UoM"
                  , transaction_cost "Txn Cost"
                  , tt.transaction_type_name
                  ||'' (''||mmtt.transaction_type_id||'')'' "Txn Type (ID)"
                  , ml.meaning
                  ||'' (''|| mmtt.transaction_action_id ||'')'' 
                  "Txn Action (ID)"
                  , st.transaction_source_type_name
                  ||'' (''|| mmtt.transaction_source_type_id ||'')''
                  "Txn Source Type (ID)"
                  , transaction_source_id "Txn Source ID"
                  -- Interface id
                  , rcv_transaction_id "Receiving|Txn ID"
                  , move_order_line_id "Move Order|Line ID"
                  , completion_transaction_id "Completion|Txn ID"
                  -- Process info
                  , process_flag "Process|Flag"
                  , lock_flag "Lock|Flag"
                  , DECODE( mmtt.transaction_mode,1, ''Online processing''
                  ,2, ''Concurrent processing''
                  ,3, ''Background processing''
                  , mmtt.transaction_mode )
                  ||'' ('' || mmtt.transaction_mode ||'')'' 
                  "Transaction|Mode"
                  , mmtt.request_id "Request|ID"
                  -- Trnx Info
                  , transfer_subinventory "Transfer|Subinv"
                  , transfer_to_location "Transfer to|Location"
                  , pick_slip_number "Pick Slip#"
                  , picking_line_id "Picking|Line ID"
                  , reservation_id "Reservation|ID"
                  , wms_task_type "WMS|Task Type"
                  , standard_operation_id "Standard|Operation ID"
                  -- Error
                  , mmtt.error_code "Error|Code"
                  , error_explanation "Error|Explanation"
               FROM mtl_material_transactions_temp mmtt
                  , mtl_item_flexfields mif
                  , mtl_transaction_types tt
                  , mtl_txn_source_types st
                  , mfg_lookups ml
                  , mtl_transaction_lots_temp mtlt
                  , mtl_serial_numbers_temp msnt
              WHERE mmtt.organization_id = ' || p_org_id || '
                AND mmtt.acct_period_id  = ' || p_period_id || '
                AND NVL( transaction_status, 0 ) <> 2
                AND mmtt.inventory_item_id = mif.inventory_item_id(+)
                AND mmtt.organization_id = mif.organization_id(+)
                AND mmtt.transaction_type_id = tt.transaction_type_id(+)
                AND mmtt.transaction_source_type_id = st.transaction_source_type_id(+)
                AND mmtt.transaction_action_id = ml.lookup_code
                AND ml.lookup_type = ''MTL_TRANSACTION_ACTION''
                AND (mtlt.transaction_temp_id (+) = mmtt.transaction_temp_id
                     AND
                     msnt.transaction_temp_id (+) = mmtt.transaction_temp_id)
              ORDER BY mmtt.transaction_temp_id, transaction_header_id';

        Run_sql( g_title, g_text, 'N', NULL, 1 );
    
    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_period_id=' || p_period_id );

END Display_MMTT_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_MMT_Info 
-- DESCRIPTION:
--        Identify Uncosted Material Transactions (MTL_MATERIAL_TRANSACTIONS)
--        Resolution required
-- Input:
--        p_org_id
--        p_period_id
-- Return-Code:
--        None
-- USAGE:
--        Display_MMT_Info ( ordid, period_id )
-- USAGE-EXAMPLES: 
--        Display_MMT_Info ( 207 , 1234 ) 
------------------------------------------------------------------------------

PROCEDURE Display_MMT_Info( p_org_id IN NUMBER
                          , p_period_id IN org_acct_periods.acct_period_id%TYPE)
IS
    l_proc VARCHAR2(30) := 'Display_MMT_Info';
BEGIN -- Display_MMT_Info

    SectionPrintBig( 'Uncosted Material Transactions (MTL_MATERIAL_TRANSACTIONS)' );
    BRPrint;

    -- Count uncosted transactions in MMT
    SELECT COUNT(*)
      INTO v_rc
      FROM mtl_material_transactions
     WHERE organization_id = p_org_id
       AND acct_period_id =  p_period_id 
       AND costed_flag IN ('E','N') ;
 
    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
        RETURN; -- exit procedure
    END IF;

    Tab1Print( 'There are ' || v_rc || ' transactions' );
    BRPrint;

    ErrorPrint( 'Uncosted material transactions exist.<BR>
                 Resolution of uncosted material transactions is required' );
    ActionErrorLink( 'Resolve the uncosted material transactions<BR>
E.g. Make sure the Cost Manager is running.<BR>
Note ', '242927.1', ' ( 11i - Resolving Period Close Pending Transaction) will give detailed information<BR>
See following information for transaction details' );

------------------------------------------------------------------------------
/*****************************************************************************
    g_title := 'Transactions with costed_flag = ''E'' or ''N''';

    g_text := 'SELECT DECODE( costed_flag,''E'',''Error'',
                                          ''N'',''Not Costed'',
                              costed_flag) "Costed"
                    , COUNT(*) "Count"
                 FROM mtl_material_transactions
                WHERE organization_id = '||p_org_id || '
                  AND acct_period_id =  ' ||p_period_id ||'
                  AND costed_flag IN (''E'',''N'')
                GROUP BY costed_flag';

    Run_sql ( g_title, g_text, 'N', NULL, 1 );
 *****************************************************************************/
------------------------------------------------------------------------------
    BRPrint;
    g_title := 'Types of Errors';

    g_text := 'SELECT DISTINCT NVL(error_code, ''Empty Error_Code'') "Error Code"
                    , NVL( error_explanation, ''Empty Error_Explanation'' ) "Error Explanation"
                    , COUNT(*) "Count"
                 FROM mtl_material_transactions
                WHERE organization_id = '||p_org_id || '
                  AND acct_period_id =  ' ||p_period_id ||'
                  AND costed_flag IN (''E'',''N'')
                GROUP BY error_code, error_explanation';

    Run_sql ( g_title, g_text, 'N', NULL, 1 );
------------------------------------------------------------------------------
    BRPrint;

    g_title := 'Uncosted Material Transactions' ;

    IF ( :v_detail = 'Y' ) 
    THEN
        g_text := 'SELECT mmt.transaction_id "Txn ID"
                        , mif.item_number
                          ||'' (''|| mmt.inventory_item_id ||'')'' "Item (ID)"
                        , mmt.transaction_date "Txn Date"
                        , mmt.transaction_quantity "Txn Qty"
                        , mmt.primary_quantity "Pri Qty"
                        , mmt.transaction_uom "Uom"
                        , tt.transaction_type_name 
                          ||'' (''||mmt.transaction_type_id||'')'' 
                          "Txn Type (ID)"
                        , mmt.subinventory_code "Subinv"
                        , mmt.locator_id "Stock|Locator"
                        , mmt.revision "Rev"
                        , mmt.costed_flag "Costed|Flag"
                        , mmt.cost_group_id "Cost Group|ID"
                        , mmt.transaction_group_id "Txn Group (ID)"
                        , mmt.transaction_set_id "Txn Set (ID)"
                        , mmt.last_update_date "Last Updated"
                        , mmt.transaction_action_id "Txn Action (ID)"
                        , mmt.completion_transaction_id "Completion|Txn ID"
                        , st.transaction_source_type_name
                          ||'' (''|| mmt.transaction_source_type_id ||'')''
                          "Txn Source Type (ID)"
                        , mmt.transaction_source_id "Txn Source (ID)"
                        , mmt.transaction_source_name "Txn Source"
                        , mmt.source_code "Source|Code"
                        , mmt.source_line_id "Source|Line ID"
                        , mmt.request_id "Txn|Request ID"
                        , mmt.transfer_transaction_id "Transfer|Txn ID"
                        , mmt.transfer_organization_id "Transfer|Organization ID"
                        , mmt.transfer_subinventory "Transfer|Subinv"
                        , mmt.error_code "Error Code"
                        , mmt.error_explanation "Error Explanation"
                     FROM mtl_material_transactions mmt 
                         ,mtl_item_flexfields mif 
                         ,mtl_transaction_types tt 
                         ,mtl_txn_source_types st
                   WHERE mmt.organization_id = ' || p_org_id || '
                     AND mmt.acct_period_id = '|| p_period_id || '
                     AND mmt.costed_flag IN (''E'',''N'')
                     AND mmt.inventory_item_id = mif.inventory_item_id(+)
                     AND mmt.organization_id = mif.organization_id(+)
                     AND mmt.transaction_type_id = tt.transaction_type_id(+)
                     AND mmt.transaction_source_type_id = st.transaction_source_type_id(+)
                   ORDER BY mmt.transaction_id';

        Run_sql( g_title, g_text, 'N', NULL, 1 );

    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_period_id=' || p_period_id );

END Display_MMT_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_RTI_Info
-- DESCRIPTION:
--        Resolution recommended
--        Receiving Interface Transaction 
-- Input:
--        p_org_id
--        p_schedule_close_date
-- Return-Code:
--        None
-- USAGE:
--        Display_RTI_Info( OrgID, Period_start_date)
-- USAGE-EXAMPLES: 
--        Display_RTI_Info( 207 , 31-jul-2003 ) 
------------------------------------------------------------------------------
PROCEDURE Display_RTI_Info( p_org_id IN NUMBER
           , p_schedule_close_date IN org_acct_periods.schedule_close_date%TYPE)
IS
    l_schedule_close   NUMBER; -- Intentionally using type NUMBER
    l_proc VARCHAR2(30) := 'Display_RTI_Info';
BEGIN -- Display_Rti_Info

    SectionPrintBig( 'Pending Receiving Interface Transactions (RCV_TRANSACTIONS_INTERFACE)' );
    BRPrint;

    l_schedule_close := TO_CHAR( p_schedule_close_date, 'YYYYDDD'); 

    SELECT COUNT(*) 
      INTO v_rc
      FROM rcv_transactions_interface
     WHERE to_organization_id = p_org_id
       AND destination_type_code = 'INVENTORY'
       AND TRUNC( transaction_date ) <= TRUNC( p_schedule_close_date ) ;

    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
        RETURN; -- exit procedure
    END IF;

    Tab1Print( 'There are ' || v_rc || ' transactions with a transaction date before the scheduled period close date' );
    BRPrint;

    WarningPrint( 'Pending receiving transactions exist.<BR>
                   Resolution of pending receiving transactions is recommended');
    ActionWarningLink( 'Note ', '242927.1', ' ( 11i - Resolving Period Close Pending Transaction) will give detailed information<BR>
See following information for transaction details' );

-------------------------------------------------------------------------------
    g_title := 'Values for Transaction Status';
    g_text := 'SELECT DISTINCT transaction_status_code "Txn Status Code"
                    , COUNT(*) count
                 FROM rcv_transactions_interface
                WHERE to_organization_id = ' || p_org_id || '
                  AND destination_type_code = ''INVENTORY''
                  AND TO_CHAR( transaction_date, ''YYYYDDD'' ) <= 
                      '|| l_schedule_close ||'
                GROUP BY transaction_status_code';
 
    Run_sql( g_title, g_text, 'N', NULL, 1 );
-------------------------------------------------------------------------------
    g_title := 'Values for Processing Status and Processing Mode';
    g_text := 'SELECT DISTINCT processing_status_code "Processing Status Code"
                    , processing_mode_code "Processing Mode Code"
                    , COUNT(*) count
                 FROM rcv_transactions_interface
                WHERE to_organization_id = ' || p_org_id || '
                  AND destination_type_code = ''INVENTORY''
                  AND TO_CHAR( transaction_date, ''YYYYDDD'' ) <= 
                      '|| l_schedule_close ||'
                GROUP BY processing_status_code, processing_mode_code';
 
    Run_sql( g_title, g_text, 'N', NULL, 1 );
-------------------------------------------------------------------------------

    IF ( :v_detail = 'Y' ) 
    THEN
        g_title := 'Pending Receiving Interface Transactions';
        g_text := 'SELECT rti.interface_transaction_id "Interface|Txn ID"
                        , rti.header_interface_id "Header|Interface ID"
                        , mif.item_number 
                          ||'' (''|| rti.item_id ||'')'' "Item ID"
                        , rti.group_id "Group ID"
                        , rti.transaction_type "Txn Type"
                        , rti.transaction_date "Txn Date"
                        , rti.processing_status_code "Processing|Status Code"
                        , rti.processing_mode_code "Processing|Mode Code"
                        , rti.transaction_status_code "Txn Status Code"
                        , rti.quantity "Qty"
                        , rti.unit_of_measure "UoM"
                        , rti.auto_transact_code "Auto|Transact Code"
                        , rti.receipt_source_code "Receipt|Source Code"
                        , rti.destination_type_code "Destination|Type Code"
                        , rti.source_document_code "Source|Document Code"
                        , rti.currency_code "Currency|Code"
                        , rti.document_num "Document|Num"
                        , rti.ship_to_location_id "Ship to|Location ID"
                        , rti.parent_transaction_id "Parent|Txn ID"
                        , rti.po_header_id "PO Header|ID"
                        , rti.po_line_id "PO Line|ID"
                        , rti.po_release_id "PO Release|ID"
                        , r.release_num "Release|Num"
                        , h.segment1 "PO Number"
                        , rti.vendor_id "Vendor|ID"
                        , rti.vendor_site_id "Vendor Site|ID"
                        , rti.oe_order_header_id "OE Order Header|ID"
                        , rti.oe_order_line_id "OE Order Line|ID"
                        , rti.validation_flag "Validation|Flag"
                        , rti.subinventory "Subinv"
                        , l.line_num "Line|Num"
                        , pie.column_name
                        , pie.error_message
                     FROM rcv_transactions_interface rti
                         ,po_interface_errors pie
                         ,mtl_item_flexfields mif
                         ,po_headers_all h
                         ,po_lines_all l
                         ,po_releases_all r
                    WHERE rti.to_organization_id = ' || p_org_id || '
                      AND rti.po_header_id = h.po_header_id(+)
                      AND rti.po_line_id = l.po_line_id(+)
                      AND rti.po_release_id = r.po_release_id(+)
                      AND rti.to_organization_id = mif.organization_id
                      AND rti.item_id = mif.inventory_item_id
                      and rti.interface_transaction_id = pie.interface_transaction_id(+)
                      AND destination_type_code = ''INVENTORY''
                      AND TO_CHAR( rti.transaction_date,''YYYYDDD'') <= 
                          '|| l_schedule_close ;

        Run_sql( g_title, g_text, 'N', NULL, 1 );

    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_schedule_close_date=' || p_schedule_close_date );

END Display_Rti_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_WMTI_Info 
-- DESCRIPTION:
--        Resolution recommended
--        Identify Pending Shop Floor Move Transactions with a transaction date
--        before the scheduled period close date.
-- Input:
--        p_org_id
--        p_schedule_close_date 
--        p_period_id
-- Return-Code:
--        None
-- USAGE:
--        Display_WMTI_Info 
-- USAGE-EXAMPLES: 
--        Display_WMTI_Info( 207 , 31-jul-2003, 1234 ) 
------------------------------------------------------------------------------
PROCEDURE Display_WMTI_Info( p_org_id IN NUMBER
            , p_period_id IN org_acct_periods.acct_period_id%TYPE
           , p_schedule_close_date IN org_acct_periods.schedule_close_date%TYPE)
IS
    l_schedule_close  NUMBER;  -- Intentionally using type NUMBER
    l_proc VARCHAR2(30) := 'Display_WMTI_Info';
BEGIN -- Display_WMTI_Info

    SectionPrintBig( 'Pending Shop Floor Move transactions (WIP_MOVE_TXN_INTERFACE)' );
    BRPrint;

    -- Intentionally using YYYYDDD as TRUNC() can cause ORA-1840
    l_schedule_close := TO_CHAR( p_schedule_close_date, 'YYYYDDD'); 

    SELECT COUNT(*) 
      INTO v_rc
      FROM wip_move_txn_interface  
     WHERE organization_id = p_org_id  
       AND (acct_period_id = p_period_id 
            OR (acct_period_id IS NULL 
                AND
                TRUNC( transaction_date ) <= TRUNC( p_schedule_close_date )
               )
           );

    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
        RETURN; -- exit procedure
    END IF;
 
    Tab1Print( 'There are ' || v_rc || ' transactions' );

    BRPrint;
    WarningPrint( 'Pending Shop Floor Move transactions exist.<BR>
                   Resolution of pending Shop Floor Move transactions is recommended' );
    ActionWarningLink( 'Resubmit transactions using the "Pending Move Transactions" form.<BR>
( E.g. WIP : Move Transactions > Pending Move Transactions<BR>
Note ', '242927.1', ' ( 11i - Resolving Period Close Pending Transaction) will give detailed information<BR>
See following information for transaction details' );

-------------------------------------------------------------------------------
    g_title := 'Values for Process Phase and Process Status';
    g_text := 'SELECT DISTINCT process_phase_meaning 
                      ||'' (''|| process_phase ||'')'' "Process Phase"
                    , process_status_meaning 
                      ||'' (''|| process_status ||'')'' "Process Status"
                    , COUNT(*) count
                 FROM wip_move_txn_interface_v
                WHERE organization_id = ' || p_org_id || '
                      AND (acct_period_id = ' || p_period_id || '
                           OR (acct_period_id IS NULL
                               AND
                               TO_CHAR( transaction_date,''YYYYDDD'') <=
                               ' || l_schedule_close || '
                               )
                          )
                GROUP BY process_phase_meaning ||'' (''|| process_phase ||'')''
                    , process_status_meaning ||'' (''|| process_status ||'')''';

    Run_sql( g_title, g_text, 'N', NULL, 1 );

    IF ( :v_detail = 'Y' )
    THEN
        g_title := 'Pending Shop Floor Move Transactions';
        g_text := 'SELECT wmti.transaction_id "Txn ID"
                        , group_id "Group ID"
                        , process_phase_meaning
                          ||'' (''|| process_phase ||'')'' "Process Phase"
                        , process_status_meaning
                          ||'' (''|| process_status ||'')'' "Process Status"
                        , mif.item_number 
                          ||'' (''|| primary_item_id ||'')''
                          "Primary Item (ID)" -- Assembly_id
                        , entity_type "Entity Type"
                        , wip_entity_name "WIP Entity|Name"
                        , wip_entity_id "WIP Entity|(ID)"
                        , transaction_type_meaning
                          ||'' (''|| transaction_type ||'')'' "Txn Type (ID)"
                        , transaction_date "Txn Date"
                        , transaction_quantity "Txn Qty"
                        , transaction_uom "Txn UoM"
                        , primary_quantity "Primary|Qty"
                        , primary_uom "Primary|UoM"
                        , source_code "Source|Code"
                        , source_line_id "Source|Line ID"
                        , repetitive_schedule_id "Repetitive|Schedule ID"
                        , fm_operation_seq_num "From Operation|Seq #"
                        , fm_intraoperation_step_type "From IntraOper|Step Type"
                        , to_operation_seq_num "To Operation|Seq #"
                        , to_intraoperation_step_type "To IntraOper|Step Type"
                        , overcompletion_transaction_qty "Overcompletion|Txn Qty"
                        , scrap_account_id "Scrap Account|ID"
                        , wmti.request_id "Txn Request|ID"
                        , error_column "Error|Column"
                        , error_message "Error|Message"
                     FROM wip_move_txn_interface_v wmti
                        , wip_txn_interface_errors wtie
                        , mtl_item_flexfields mif
                    WHERE wmti.organization_id = ' || p_org_id || '
                      AND (wmti.acct_period_id = ' || p_period_id || '
                           OR (wmti.acct_period_id IS NULL
                               AND
                               TO_CHAR( wmti.transaction_date,''YYYYDDD'') <= 
                               ' || l_schedule_close || '
                               )
                          )
                      AND wtie.transaction_id(+) = wmti.transaction_id
                      AND wmti.organization_id = mif.organization_id
                      AND NVL( wmti.primary_item_id, -1) = mif.inventory_item_id(+)
                    ORDER BY wmti.transaction_id' ;

        Run_Sql( g_title, g_text, 'N', NULL, 1 );

    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_org_id=' || p_org_id || ' / p_period_id=' || p_period_id || ' / p_schedule_close_date=' || p_schedule_close_date );

END Display_WMTI_Info;

------------------------------------------------------------------------------
-- PROCEDURE: Display_Input_Parameters
-- DESCRIPTION:
--        Display an HTML table of the user supplied input parameters
-- Input:
--        None
-- Return-Code:
--        None
-- USAGE:
--        Display_Input_Parameters
-- USAGE-EXAMPLES:
--        Display_Input_Parameters
------------------------------------------------------------------------------
PROCEDURE Display_Input_Parameters
IS
    l_proc VARCHAR2(30) := 'Display_Input_Parameters';
    l_responsibility_name fnd_responsibility_tl.responsibility_name%TYPE;
BEGIN -- Display_Input_Parameters

    SectionPrintBig( 'Input Parameters' );
 
    -- Get responsibility_name from p_resp_id

    SELECT responsibility_name
      INTO l_responsibility_name
      FROM fnd_responsibility_vl
     WHERE responsibility_id = p_respid;
 
    Start_Table( 'Input Parameters');
 
    Show_Table_Header( V2T( 'Parameter','Value (Id)'));
    Show_Table_Row( V2T( 'Application Username',p_username));

    Show_Table_Row( V2T( 'Responsibility', l_responsibility_name || ' (' || p_respid ||')' ));
    g_text := INV_Get_Org_Name( p_organization_id ) || ' = ' || INV_Get_Org_Code( p_organization_id ) || ' (' || p_organization_id || ')';
    Show_Table_Row( V2T( 'Organization', g_text ) );
 
    -- Get INV_Accounting_Period_ID FROM p_period_name 
    g_text := g_period_name ||' ('|| INV_Get_Acct_Period_ID( g_period_name , p_organization_id ) ||')';

    Show_Table_Row( V2T( 'Inventory Period', g_text ) );
    
    -- Detailed or Summary information requested ?
    IF :v_detail = 'Y' 
    THEN g_text := 'Detail';
    ELSE g_text := 'Summary';
    END IF;
    Show_Table_Row( V2T( 'Information Level', g_text ) );
 
    End_Table;
 
    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc || ' p_respid=' || p_respid);
 
END Display_Input_Parameters;

------------------------------------------------------------------------------
-- PROCEDURE: MMT_Txn_Not_In_GL_Batches
-- DESCRIPTION:
--        Display number of MMT-Transactions not in GL Batches
--        Processing Recommended
-- Input:
--        p_org_id
--        p_period_id
-- Return-Code:
--        None
-- USAGE:
--        MMT_Txn_Not_In_GL_Batches( org_id, period_id )
-- USAGE-EXAMPLES:
--        MMT_Txn_Not_In_GL_Batches( 207 , 1234 )
------------------------------------------------------------------------------
PROCEDURE MMT_Txn_Not_In_GL_Batches( p_org_id IN NUMBER
                           , p_period_id IN org_acct_periods.acct_period_id%TYPE)
IS
    l_proc VARCHAR2(30) := 'MMT_Txn_Not_In_GL_Batches';
BEGIN -- MMT_Txn_Not_In_GL_Batches

    SectionPrintBig( 'Material Transactions not in GL Batches' );
    BRPrint;

    SELECT COUNT( mmt.transaction_id )
      INTO v_rc
      FROM mtl_material_transactions mmt
     WHERE mmt.organization_id = p_org_id
       AND mmt.acct_period_id = p_period_id
       AND EXISTS
	    (SELECT NULL
               FROM mtl_transaction_accounts mta
	      WHERE mta.transaction_id = mmt.transaction_id
	        AND mta.gl_batch_id = -1);

    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
    ELSE
        NoticePrint( 'There are ' || v_rc || ' material transactions that have not yet been transfered to GL.<BR>
                      Although GL-Transfer is automatically run during the Period Close process,<BR>
                      it is possible to run GL-Transfer before that, 
                      thus reducing the runtime of the Period Close process.<BR>For details see the Inventory User''s Guide' );
    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id||' / p_period_id='||p_period_id );

END MMT_Txn_Not_In_GL_Batches;

------------------------------------------------------------------------------
-- PROCEDURE: WIP_Txn_Not_In_GL_Batches
-- DESCRIPTION:
--        Display number of WIP-Transactions not in GL Batches
-- Input:
--        p_org_id
--        p_period_id
-- Return-Code:
--        None
-- USAGE:
--        WIP_Txn_Not_In_GL_Batches( org_id, period_id )
-- USAGE-EXAMPLES:
--        WIP_Txn_Not_In_GL_Batches( 207 , 1234 )
------------------------------------------------------------------------------
PROCEDURE WIP_Txn_Not_In_GL_Batches( p_org_id IN NUMBER
                           , p_period_id IN org_acct_periods.acct_period_id%TYPE)
IS
    l_proc VARCHAR2(30) := 'WIP_Txn_Not_In_GL_Batches';
BEGIN -- WIP_Txn_Not_In_GL_Batches

    SectionPrintBig( 'WIP Transactions not in GL Batches' );
    BRPrint;

    SELECT COUNT( wt.transaction_id )
      INTO v_rc
      FROM wip_transactions wt
     WHERE wt.organization_id = p_org_id
       AND wt.acct_period_id = p_period_id
       AND EXISTS
	    (SELECT NULL
               FROM wip_transaction_accounts wta
	      WHERE wta.transaction_id = wt.transaction_id
	        AND wta.gl_batch_id = -1);

    IF v_rc < 1 THEN
        Tab1Print( 'No transactions found' );
    ELSE
    NoticePrint( 'There are ' || v_rc || ' WIP transactions that have not yet been transfered to GL.<BR>
              Although GL-Transfer is automatically run during the Period Close process,<BR>
              it is possible to run GL-Transfer before that, 
              thus reducing the runtime of the Period Close process.' );
    END IF;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id||' / p_period_id='||p_period_id );

END WIP_Txn_Not_In_GL_Batches;

------------------------------------------------------------------------------
-- PROCEDURE: ShowReference
-- DESCRIPTION:
--      Display related Documentation
-- Input: None
-- Return-Code:
--        None
-- USAGE:
--        ShowReference
-- USAGE-EXAMPLES:
--        ShowReference
------------------------------------------------------------------------------
PROCEDURE ShowReference IS
    l_proc VARCHAR2(30) := 'ShowReference';
BEGIN --ShowReference

    SectionPrint ('References');
    Show_Link ('http://metalink.oracle.com/metalink/plsql/ml2_documents.showDocument?p_database_id=NOT&p_id=66957.1',
               'Oracle Inventory Users Guide, Release 11i');
    BRPrint;
    Show_Link ('http://metalink.oracle.com/metalink/plsql/ml2_documents.showDocument?p_database_id=NOT&p_id=66988.1',
               'Oracle Cost Management Users Guide, Release 11i');


    BRPrint; -- gsm sehr gut ! published externally
    Show_Link ('http://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=242927.1',
               'Note 242927.1 : 11i - Resolving Period Close Pending Transaction');

    BRPrint;
    Show_Link ('http://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=246816.1',
               'Note 246816.1 : Pending Material Transactions Diagnostic');

    BRPrint; -- published externally
    Show_Link ('http://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=110424.1',
               'Note 110424.1 : Unprocessed Transactions/Closing INV Accounting Period FAQ');

    BRPrint; -- published externally
    Show_Link ('http://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=1017229.102',
               'Note 1017229.102 : Where to Re-Submit Uncosted Records in Release 11I');


    BRPrint; -- published externally
    Show_Link ('http://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=105647.1',
               'Note 105647.1 : WIP and COST Frequently Asked Questions');


    BRPrint; -- published externally
    Show_Link ('http://metalink.oracle.com/metalink/plsql/ml2_documents.showNOT?p_id=70302.1',
               'Note 70302.1 : Steps Taken in Performing Period-End Processing for Oracle Inventory');

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc );

END ShowReference;

-- ****************************************************************************
-- ****************************************************************************
--
-- Main program starts here
--
-- ****************************************************************************
-- ****************************************************************************

BEGIN  -- begin (block 2) 

    p_username := NVL( RTRIM( LTRIM( UPPER(:v_username))), 'NULL_username');
    p_respid := NVL( &v_respid,-10);
    p_organization_id := INV_Get_Org_ID( '&v_org' );
    g_period_name := NVL( '&v_period_name',-1);
    
    IF :error_flag = 'Y' THEN GOTO FINISH; END IF;

    Show_Header( '206576.1', '&v_testlongname' );

    BEGIN
        Set_Client(p_username,p_respid);
        EXCEPTION WHEN OTHERS THEN RAISE e_BadResponsibility;
    END;

    -- -------------------- Test Execution Section -----------------------

    Display_Input_Parameters;

    BRPrint; BRPrint;
    Display_Apps_Information;

    BRPrint; BRPrint;
    INV_Display_Patchset_Level;

    -- Get ID, SchedCloseDate, StartDate of choosen period
    SELECT acct_period_id, schedule_close_date, period_start_date
      INTO l_period_id, l_schedule_close_date, l_period_start_date
      FROM org_acct_periods
     WHERE organization_id = :v_org_id
       AND period_name='&v_period_name';

    BRPrint; BRPrint;
    -- Display information about current and previous/next period ( if open )
    -- # of open periods, earliest open period
    INV_Display_Period_Info( p_organization_id, l_period_id, 'Y' );

    v_rc := Count_INV_Periods( p_organization_id, 'Y', 'N' );
    BRPrint;
    Tab0Print( 'There are '||v_rc||' open Inventory periods' );
    If v_rc > 0 THEN
        -- Get earliest open period information
        SELECT period_name, period_start_date, schedule_close_date
          INTO l_1_period_name, l_1_period_start_date, l_1_schedule_close_date
          FROM org_acct_periods
         WHERE organization_id= p_organization_id
           AND period_start_date =
               (SELECT MIN(period_start_date)
                  FROM org_acct_periods
                 WHERE open_flag = 'Y'
                   AND organization_id = p_organization_id )
           AND rownum = 1;
        BRPrint;
        Tab0Print( 'The earliest open period is ' || l_1_period_name );
        Tab1Print( 'Start Date = ' || l_1_period_start_date );
        Tab1Print( 'Scheduled Close Date = ' || l_1_schedule_close_date);
    END IF;

    -- Display Organization Info
    BRPrint; BRPrint;
    v_rc := Display_Inv_Org_Info( :v_org_id );

    -- Unprocessed Material Transactions MMTT
    BRPrint; BRPrint;
    Display_MMTT_Info( :v_org_id, l_period_id );

    -- Uncosted Material Transactions MMT
    BRPrint; BRPrint;
    Display_MMT_Info( :v_org_id, l_period_id );

    -- Pending WIP Costing Transactions (WCTI = WIP_COST_TXN_INTERFACE)
    BRPrint; BRPrint;
    Display_WCTI_Info( :v_org_id, l_period_id );

    -- Uncosted WSM Transactions (WSMT = WSM_SPLIT_MERGE_TRANSACTIONS)
    BRPrint; BRPrint;
    Display_WSMT_Info( :v_org_id, l_schedule_close_date );

    -- Pending WSM Interface Transactions
    BRPrint; BRPrint;
    Display_WSMTI_Info( :v_org_id, l_schedule_close_date );

    -- Pending Receiving Interface transactions 
    BRPrint; BRPrint;
    Display_RTI_Info( :v_org_id, l_schedule_close_date );

    -- Material Interface transactions MTI
    BRPrint; BRPrint;
    Display_MTI_Info( :v_org_id, l_period_id, l_schedule_close_date );

    -- Pending Shop Floor WMTI
    BRPrint; BRPrint;
    Display_WMTI_Info( :v_org_id, l_period_id, l_schedule_close_date );

    -- Unprocessed Shipping Transactions WDD
    BRPrint; BRPrint;
    Display_WDD_Info( :v_org_id, l_period_id, l_period_start_date, l_schedule_close_date );

    BRPrint; BRPrint;
    MMT_Txn_Not_In_GL_Batches( :v_org_id, l_period_id );

    BRPrint; BRPrint;
    WIP_Txn_Not_In_GL_Batches( :v_org_id, l_period_id );

    BRPrint; BRPrint;
    SectionPrintBig( 'Transaction interface managers' );
    -- Display info about Setup/config of the Interface-Transaction-managers
    INV_Txn_Manager_Config;
    INV_Txn_Manager_Status( 'Y', 'Y', 'Y', 'Y');
 
    BRPrint; BRPrint;
    INV_Display_Debug_Trace_PO;

    BRPrint; BRPrint;
    Display_Profiles( 401, null );
 
    BRPrint; BRPrint;
    ShowReference;

    --<<FINISH>>
    --  -------------------- Feedback ---------------------------- 
    BRPrint;
    Show_Footer( '&v_testlongname', '&v_headerinfo');

    <<FINISH>>
    BRPrint;
    
  -- -------------------- test Exception Section ------------------------- 
  EXCEPTION -- block 2
    WHEN OTHERS THEN -- exception section (block 2) for INV API and template
    BRPrint;
    ErrorPrint(sqlerrm ||' occurred in Test');
    ActionErrorPrint('Please report the above error to Oracle Support Services.');
    BRPrint;
    Show_Footer('&v_testlongname', '&v_headerinfo');
    BRPrint;
  END;  -- block 2, test code

EXCEPTION -- block 1
      WHEN e_Terminate THEN
        Show_Footer('&v_testlongname', '&v_headerinfo');
        BRPrint;
      WHEN OTHERS THEN   -- exceptions (block 2) for INV API and template code
        BRPrint;
        ErrorPrint(sqlerrm ||' occurred in test');
        ActionErrorPrint('Please report the above error to Oracle Support Services.');
        BRPrint;
        Show_Footer('&v_testlongname', '&v_headerinfo');
        BRPrint;
end;  -- end (block 1), API and template code

EXCEPTION WHEN OTHERS THEN   -- exceptions (block 0) for API and template code
  BRPrint;
  Errorprint(sqlerrm ||' occurred in test');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('&v_testlongname', '&v_headerinfo');
  BRPrint;
END;  -- block 0
/


REM  ==============SQL PLUS Environment setup===================
SPOOL OFF

PROMPT
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================
SET TERM ON
SET FEED ON
SET HEADING ON
PROMPT Please exit the sql-session before re-running this test.
