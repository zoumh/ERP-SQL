--
--   $ Header: Do not insert version information here. Use INV_Api_Info() instead
--   =========================================================================
--   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
--   Oracle Support Services.  All rights reserved.
--   =========================================================================
--   PURPOSE:           Provide common function/procedures for Oracle Inventory Scripting
--   PRODUCT:           Inventory (INV) 
--   PRODUCT VERSIONS:  11.5.X
--   PLATFORM:          Generic
--   PARAMETERS:        N/A
--   =========================================================================


--   =========================================================================
--   USAGE:             API only, included in others as: @@INVApiHtml.sql 
--                      AFTER CoreApiHtml
--                      If you want to use/include the INVApi, you must have defined a 
--                      global variable g_text varchar2( 2048 ) in your MAIN-CODE
--                      See INVCheckSetup115h.sql for an example
--   EXAMPLE:           variable g_text varchar2(4000)
--                      @@CoreApiHtml.sql
--                      @@INVApiHtml.sql
--                      ... rest of code ...
--   OUTPUT:            See the description for each function/procedure below
--   =========================================================================


--   =========================================================================
--   CHANGE HISTORY:
--     27-Aug-2002 gschmidt        Changed Display_Transaction_Types() to include 
--                                 additional columns:
--                                              transaction_type_id 
--                                              transaction_action_id
--                                              transaction_source_type_id
--   
--     28-Aug-2002 gschmidt        Added new function Count_INV_Periods
--      7-Oct-2002 gschmidt        Implemented Feedback from 1st round Final QA
--     11-Oct-2002 gschmidt        Added new procedure INV_Get_Org_Info
--     15-Oct-2002 gschmidt        Incorporated changes to Fmt_By_Cnt and Fmt_By_Cnt_Sub
--     23-Oct-2002 rcoleman        Added function INV_Api_Info to return version info
--     27-Nov-2002 rcoleman        Added new functions
--                                 Added begin/declare section to allow defintion of
--                                 global variables and cursors. This requires the
--                                 addition of a new exception/end statement to 
--                                 existing scripts
--     13-Dec-2002 gschmidt        Implemented changes on FQA for ICS 11-Dec-02
--     20-May-2003 gschmidt        Added :
--                                 * INV_Get_Org_Name()
--                                 * INV_Seeded_MSI_Triggers()
--                                 * INV_Custom_MSI_Triggers()
--                                 * e_BadItem EXCEPTION;
--                                 Changed :
--                                 function Display_Inv_Org_Info()
--                                 to also show wms_enabled_flag
--      11-Jul-2003 gschmidt       Changed :
--                                 * table_alias => table_alias to
--                                   p_table_alias => table_alias
--                                   as CoreApiHtml 1.29 requires this.
--                                 * Display_Inv_Org_Info()
--                                   to also show eam_enabled_flag
--                                 * Display_Apps_Information()
--                                   to not report number of retrieved records
--                                 Added :
--                                 * INV_Get_Acct_Period_ID()
--                                 * e_BadPeriod EXCEPTION;
--                                 * INV_Display_Invalid_Objects()
--                                 * INV_Display_Debug_Trace_PO()
--                                 * INV_Display_utl_file_dir()
--      22-Jul-2003 gschmidt       Changed :
--                                 * INV_Display_utl_file_dir()
--                                   also display "max_dump_file_size"
--                                 * Consistent use of Exception_ErrorPrint()
--                                 Added :
--                                 * INV_Get_Item_Id()
--                                 * INV_Display_Item_Desc()
--      06-Aug-2003 gschmidt       Changed :
--                                 * INV_Display_Install_Status() 
--                                   does not report # of records retrieved
--                                 * INV_Display_Debug_Trace_PO() 
--                                   added RCV_DEBUG_MODE,RCV_TP_MODE,MRP_TRACE
--                                 * is_concurrent_process_active()
--                                   Corrected exception hanlding
--                                 Added :
--                                 * INV_Display_Period_Info()
--                                 * INV_Display_Stock_locators()
--      14-Aug-2003 gschmidt       Added :
--                                 * INV_Txn_Manager_Config()
--      19-Aug-2003 gschmidt       Changed :
--                                 * INV_Display_Period_Info()
--      26-Aug-2003 gschmidt       Changed :
--                                 * Display_Inv_Org_Info () for ORA-1722
--      27-Aug-2003 gschmidt       Added :
--                                 * INV_Txn_Manager_Status ()
--      15-Oct-2003 gschmidt       Added :
--                                 * INV_Display_Patchset_Level ()
--      23-OCT-2003 mcasalgr       Reimplemented INV_Api_Info so that Header
--                                 string can be extracted from text file
--      04-NOV-2003 gschmidt       Move special code to INVCheckSetup due to
--                                 PLS-00123: program too large: 
--                                 Following function/procs were moved:
--                                     * Display_Org_Access_Defs
--                                     * Display_Transaction_Reasons
--                                     * Count_Transaction_Reasons
--                                     * Display_Transaction_Types
--                                     * Count_Transaction_Types
--                                     * Count_P_O_With_No_Value
--      05-NOV-2003 gschmidt       * Include WSM in patchset level
--                                 * Display WSM_Enabled and consigned Flag
--                                           in Display_Inv_Org_Info()
--      25-NOV-2003 gschmidt       * Implement FB from FQA PeriodClose
--                                   Change warning in INV_Txn_Manager_Status()
--                                   Change INV_Display_Period_Info() to not
--                                           display hours/minutes
--   =========================================================================

/*
===============================================================================
= List of implemented Functions/Procedures
===============================================================================
PROCEDURE: Display_Apps_Information
        Display Basic Apps Information. Esp. check whether it is MULTIORG !

PROCEDURE: INV_Display_Install_Status
        Display Installation-Status of INV-related products
        INV,BOM,ENG,ONT,WIP,PO,MRP,WMS

PROCEDURE: INV_Display_Patchset_Level
        Display Patchset Level of INV-related products
        INV,BOM,ENG,ONT,WIP,PO,MRP,WMS,EAM

FUNCTION: INV_Display_invalid_Objects
        Display invalid Inventory DB Objects like views/packages etc.

PROCEDURE: INV_Display_Debug_Trace_PO()
        Display all profiletopions that have to do with Debugging/Tracing

PROCEDURE: Exception_ErrorPrint
        Display a standard Exception message from an Exception block

PROCEDURE: SectionPrintBig
        Display a Large Font Section Heading using a standard API call

PROCEDURE: INV_Display_Dep_Install_Status
        Display an HTML table of Inventory related products
        These are those products that either Inventory depends on
        and/or that depend on Invenotry

PROCEDURE: Parse_Header
        Parse an RCS Header for information

PROCEDURE: INV_Display_Java_Versions
        Display JAVA Class file versions 

PROCEDURE: INV_Display_Package_Versions
        Display package version information for all packages matching 
        p_matchstring

FUNCTION: Display_Subinventories
        Display SubInventory Information of the given Organization ID
        If NULL is passed as Organization ID, then the subinventory info
        for all organizations is displayed.

FUNCTION: Count_Subinventories
        Count SubInventory Information of the given Organization ID
        If NULL is passed as Organization ID, then the subinventory info
        for all organizations is counted.

FUNCTION: INV_Display_Stock_Locators
        Display all Stock Locator Information of the given Organization ID
        Display Information for a specific Stock Locator

FUNCTION: Count_INV_Periods
        Count Inventory Periods ( Open, Closed, Pending )

FUNCTION: INV_Get_Acct_Period_ID
        Return the acct_period_id for given period_name and OrgID

PROCEDURE: INV_Display_Period_Info()
	Display Information for 1 or many Inventory periods
        or for 1 and adjactent periods.

PROCEDURE: Display_Operating_Units
        Display Operating_Units in a MultiOrg Installation

FUNCTION: Display_UOMs
        Display Unit_of_Measures

FUNCTION: Count_UOMs
        Count Unit_of_Measures

FUNCTION: Fmt_By_Cnt_Sub
        Format a string based on a count (internal helper function)

FUNCTION: Fmt_By_Cnt
        Format a string based on a count

FUNCTION: INV_Api_Info
        Return information about this API

FUNCTION: INV_Display_SQL
        Inventory interface to the standard Display_SQL API

FUNCTION: is_wms_installed
        Detect if WMS is installed

FUNCTION: INV_Display_Subinventory_Info
        Display an HTML table of Subinventory Information

FUNCTION: INV_Display_Txn_Temp_Info
        Display an HTML table of Txn_Temp Information

==============================================================================
Inventory Organization related functions/procedures
==============================================================================

    FUNCTION: Display_Inv_Org_Info
              Display Inventory Organization Information of the given OrgID
              If no OrgID is paased, then info for ALL Orgs displayed

    FUNCTION: INV_Display_Organization_Info
              Display an HTML table of Organization Information

    FUNCTION: INV_Get_Org_ID
              Return the Organization_ID for given org_code

    FUNCTION: INV_Get_Org_Code
              Return the Organization_code for given org_id

    FUNCTION: INV_Get_Org_Name
              Return the Organization_name for given org_id

    PROCEDURE: INV_Get_Org_Info
               Get Inventory-Organization-ID and Inventory-Organization-Name

==============================================================================
Trigger related functions/procedures
==============================================================================

    FUNCTION: INV_Seeded_MSI_Triggers
              Display seeded DB-Triggers on tables 
              MTL_SYSTEM_ITEMS_B and MTL_SYSTEM_ITEMS_TL

    FUNCTION: INV_Custom_MSI_Triggers
              Display custom DB-Triggers on tables 
              MTL_SYSTEM_ITEMS_B and MTL_SYSTEM_ITEMS_TL

==============================================================================
Flexfield ( KFF / DFF ) related functions/procedures
==============================================================================

    FUNCTION: Display_Item_Status
              Display Item_Status

    FUNCTION: Count_Item_Status
              Count mtl_item_status

    FUNCTION: Get_KFF_Name
              Return the KFF Name for the indicated flex code

    PROCEDURE: Flex_ErrorPrint
               Display a flex error message

    PROCEDURE: INV_Display_KFF
               Display Key Flexfield information for the specified 
               application_id/flex code

    PROCEDURE: Display_KFF_Header
               Display an HTML table showing the KFF registration information

    PROCEDURE: Display_KFF_Structure
               Display an HTML table showing the KFF structures associated 

    PROCEDURE: Display_KFF_Segments
               Display an HTML table showing the KFF segments and value set 
               associated with p_id_flex_code and optionally, structure 
               p_id_flex_num

    PROCEDURE: INV_Validate_MKTS_KFF
               Validate and Display Sales Order Key Flexfield

    PROCEDURE: INV_Validate_MCAT_KFF
               Validate and Display Item Categories Key Flexfield

    PROCEDURE: INV_Validate_MDSP_KFF
               Validate and Display Account Alias Key Flexfield

    PROCEDURE: INV_Validate_MTLL_KFF
               Validate and Display Stock Locators Key Flexfield

    PROCEDURE: INV_Validate_MSTK_KFF
               Validate and System Items Alias Key Flexfield

==============================================================================
Item related functions/procedures
==============================================================================

    FUNCTION: INV_Display_Item_Info
              Display an HTML table of Item Master Information

    FUNCTION: Display_Items_Assigned
              Display or Count Items_Assigned to the given Organization_ID

    FUNCTION: INV_Display_Onhand_Qty_Info
              Display an HTML table of Onhand_Qty Information

    FUNCTION: INV_Display_MO_Detail_Info
              Display an HTML table of MO_Detail Information

    FUNCTION: INV_Get_Item_Id
              Return the Inventory_item_id for a given item_number

    FUNCTION: INV_Display_Item_Desc
              Display item_number ( mtl_item_flexfields ) and description
              and long_description ( mtl_system_items_tl ) in all
              the installed languages.

==============================================================================
Concurrent Manager related functions/procedures
==============================================================================

        FUNCTION: Display_Active_Concurrent_Managers
                Display or Count active concurrent managers
                Active does not necessarily mean, that a CM is just running
                a request, but that the CM is able to process requests.

        FUNCTION: Display_Inactive_ConcMgr
                Display or Count inactive concurrent managers.
                Inactive means, that a CM has not been started or is disabled

        FUNCTION: Display_Enabled_ConcMgr
                Display all defined concurrent managers
         
        FUNCTION: Display_Disabled_ConcMgr
                Display all Disabled concurrent managers


==============================================================================
Concurrent Program related functions/procedures
==============================================================================
        PROCEDURE: Display_Conc_Progs_Status
                Display program_name and enabled_status of Concurrent Programs

        PROCEDURE: is_concurrent_process_active
                Is Concurrent process active ?

        PROCEDURE: INV_Display_Interface_Managers
        Display Information about the Inventory controlled Interface Managers

        PROCEDURE: INV_Txn_Manager_Config
        Display Setup/Cnfig Information about the Inventory controlled 
            Transaction/Interface Managers

        PROCEDURE: INV_Txn_Manager_Status
        Display whether Transaction/Interface Managers are running/pending

===============================================================================
= List of Functions/Procedures __NOT__ yet implemented
===============================================================================
        ----------------------------------------------------------------------
        -- FUNCTION: Check_Concurrent_Request
        -- DESCRIPTION: Check whether the concurrent request id has
        --                completed successful.
        --              If concurrent request id is 0, no checking is performed.
        --
        -- Input: p_req_id ( FND_CONCURRENT_REQUESTS.REQUEST_ID )
        --        p_prog_name ( FND_CONCURRENT_PROGRAM.CONCURRENT_PROGRAM_NAME )
        --              If Concurrent ProgName is NOT NULL, e.g. INVIRSLO )
        --              then a check is performed, if the given req-id is
        --              really for Concurrent ProgName
        -- Return-Code: 0: request-id was completed sucessfully
        --              1: request-id is 0: Do not perform checking
        --              2: request-id was completed sucessfully HOWEVER,
        --                      it is not of the given Concurrent ProgName
        --             -1: request-id doesnot exist
        --             -2: request-id exist but did not finish successfully
        ----------------------------------------------------------------------
        function Check_Concurrent_Request( p_req_id IN number,
                                           p_prog_name IN varchar2 ) is

        ============================================================
        Inventory Accounting Periods related functions/procedures
        ============================================================
        ----------------------------------------------------------------------
        -- PROCEDURE: INV_Get_Acct_Period_Status
        -- DESCRIPTION: get the status of given Accounting Period
        -- Input: Organization ID ( ORG_ACCT_PERIODS.ORGANIZATION_ID )
        --              e.g. null, 204
        --        Accounting_Period ID ( ORG_ACCT_PERIODS.ACCT_PERIOD_ID )
        --              e.g. null, 1901
        -- Output: p_open_flag ( ORG_ACCT_PERIODS.OPEN_FLAG )
        --         RC: 0 = OK
        --            -1 = Given Period not found
        --            -2 = Other exception thrown
        ----------------------------------------------------------------------
        procedure INV_Get_Acct_Period_Status( p_org_id IN number,
                                              p_acct_period_id IN number,
                                              p_open_flag OUT varchar2,
                                              p_rc out number ) is

        END-OF-DESCRIPTION
*/

begin

    NULL; -- noop 

declare

    -- CONSTANTS
    QUOTE constant varchar2(1)  := chr(39); -- single quote (')
    v_NL  constant varchar2(1)  := chr(10); -- newline
    v_CR  constant varchar2(1)  := chr(13); -- CR
    v_BS  constant varchar2(1)  := chr(92); -- backslash (\)
    v_AMP constant varchar2(1)  := chr(38); -- ampersand (&)

    -- INV API global variables
    g_tf BOOLEAN;   -- capture returned true/false value
    v_rc NUMBER;    -- capture returned code (number) value
    g_text varchar2(4500); -- Attn 4096 is too small . GSM
    g_title varchar2(100); -- Used for SQL-Result-Title

    g_kff_action_msg VARCHAR2(200) := 'Refer to the Appendix B in the Inventory User''s Guide and the Oracle Applications Flexfields Guide for additional information on Key Flexfield setup and usage';

    -- Standard Exceptions For Exception Handling
    e_Terminate EXCEPTION;
    e_BadOrg EXCEPTION;
    e_BadResponsibility EXCEPTION;
    e_BadUsername EXCEPTION;
    e_BadItem EXCEPTION;
    e_BadPeriod EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_Terminate, -25000);
    PRAGMA EXCEPTION_INIT(e_BadOrg, -25001);
    PRAGMA EXCEPTION_INIT(e_BadResponsibility, -25002);
    PRAGMA EXCEPTION_INIT(e_BadUsername, -25003);
    PRAGMA EXCEPTION_INIT(e_BadItem, -25004);
    PRAGMA EXCEPTION_INIT(e_BadPeriod, -25005);

    -- Key Flexfield Structure Cursor
    cursor c_KFF_struct(
                        p_application_id NUMBER, 
                        p_id_flex_code fnd_id_flex_structures_vl.id_flex_code%TYPE,
                        p_id_flex_num fnd_id_flex_structures_vl.id_flex_num%TYPE
                       ) is
        SELECT 
                f.APPLICATION_ID,
                f.ID_FLEX_CODE,
                f.ID_FLEX_NUM,
                f.ID_FLEX_STRUCTURE_CODE,
                f.LAST_UPDATE_DATE,
                f.LAST_UPDATED_BY,
                f.CONCATENATED_SEGMENT_DELIMITER,
                f.CROSS_SEGMENT_VALIDATION_FLAG,
                f.DYNAMIC_INSERTS_ALLOWED_FLAG,
                f.ENABLED_FLAG,
                f.FREEZE_FLEX_DEFINITION_FLAG,
                f.FREEZE_STRUCTURED_HIER_FLAG,
                f.SHORTHAND_ENABLED_FLAG,
                f.SHORTHAND_LENGTH,
                f.ID_FLEX_STRUCTURE_NAME,
                f.DESCRIPTION
        FROM 
                fnd_id_flex_structures_vl f
        WHERE ID_FLEX_CODE = p_id_flex_code 
         AND f.application_id = p_application_id
         AND f.ID_FLEX_NUM = nvl(p_id_flex_num,f.id_flex_num)
         ORDER BY f.application_id, f.id_flex_code;

    -- Key Flexfield Segment Cursor
    cursor c_KFF_seg(
                     p_application_id NUMBER, 
                     p_id_flex_code fnd_id_flexs.id_flex_code%TYPE,
                     p_id_flex_num fnd_id_flex_structures_vl.id_flex_num%TYPE
                     ) is
            SELECT 
              --s.RUNTIME_PROPERTY_FUNCTION,
              s.APPLICATION_ID,
              s.ID_FLEX_CODE,
              s.ID_FLEX_NUM,
              s.APPLICATION_COLUMN_NAME,
              s.SEGMENT_NAME,
              s.LAST_UPDATE_DATE,
              decode(nvl(u1.user_name,'?'),'?',to_char(s.last_updated_by), 
                    (u1.user_name || ' (' || s.LAST_UPDATED_BY || ')')) LAST_UPDATED_BY,
              s.SEGMENT_NUM,
              s.APPLICATION_COLUMN_INDEX_FLAG,
              s.ENABLED_FLAG,
              s.REQUIRED_FLAG,
              s.DISPLAY_FLAG,
              s.DISPLAY_SIZE,
              s.SECURITY_ENABLED_FLAG,
              s.MAXIMUM_DESCRIPTION_LEN,
              s.CONCATENATION_DESCRIPTION_LEN,
              s.FLEX_VALUE_SET_ID,
              s.RANGE_CODE,
              s.DEFAULT_TYPE,
              s.DEFAULT_VALUE,
              s.FORM_LEFT_PROMPT,
              s.FORM_ABOVE_PROMPT,
              s.DESCRIPTION,
              'Value Set->',
              vs.FLEX_VALUE_SET_NAME VS_FLEX_VALUE_SET_NAME,
              vs.LAST_UPDATE_DATE VS_LAST_UPDATE_DATE,
              decode(nvl(u2.user_name,'?'),'?',to_char(vs.last_updated_by), 
                    (u2.user_name || ' (' || vs.LAST_UPDATED_BY || ')')) VS_LAST_UPDATED_BY,
              vs.VALIDATION_TYPE VS_VALIDATION_TYPE,
              l.MEANING VS_VALIDATION_TYPE_MEANING,
              vs.PROTECTED_FLAG VS_PROTECTED_FLAG,
              vs.SECURITY_ENABLED_FLAG VS_SECURITY_ENABLED_FLAG,
              vs.LONGLIST_FLAG VS_LONGLIST_FLAG,
              vs.FORMAT_TYPE VS_FORMAT_TYPE,
              lf.MEANING VS_FORMAT_TYPE_MEANING,
              vs.MAXIMUM_SIZE VS_MAXIMUM_SIZE,
              vs.ALPHANUMERIC_ALLOWED_FLAG VS_ALPHANUMERIC_ALLOWED_FLAG,
              vs.UPPERCASE_ONLY_FLAG VS_UPPERCASE_ONLY_FLAG,
              vs.NUMERIC_MODE_ENABLED_FLAG  VS_NUMERIC_MODE_ENABLED_FLAG,
              vs.DESCRIPTION VS_DESCRIPTION,
              vs.DEPENDANT_DEFAULT_VALUE VS_DEPENDANT_DEFAULT_VALUE,
              vs.DEPENDANT_DEFAULT_MEANING VS_DEPENDANT_DEFAULT_MEANING,
              vs.PARENT_FLEX_VALUE_SET_ID VS_PARENT_FLEX_VALUE_SET_ID,
              vs.MINIMUM_VALUE VS_MINIMUM_VALUE,
              vs.MAXIMUM_VALUE VS_MAXIMUM_VALUE,
              vs.NUMBER_PRECISION VS_NUMBER_PRECISION
            FROM 
              fnd_id_flex_segments_vl s,
              fnd_flex_value_sets vs,
              fnd_lookups l,
              fnd_lookups lf,
              fnd_user u1,
              fnd_user u2
            WHERE 
              s.flex_value_set_id = vs.flex_value_set_id(+)  and
              'SEG_VAL_TYPES' = l.lookup_type(+) and
              vs.validation_type = l.lookup_code(+) and
              'FIELD_TYPE' = lf.lookup_type(+) and
              vs.format_type = lf.lookup_code(+) and
              s.id_flex_num =  p_id_flex_num and 
              s.last_updated_by = u1.user_id(+) and
              vs.last_updated_by = u2.user_id(+) and 
              s.ID_FLEX_CODE = p_id_flex_code AND 
              s.application_id = p_application_id
            ORDER BY 
              s.application_id,
              s.id_flex_num,
              s.segment_num;

------------------------------------------------------------------------------
-- FUNCTION: INV_Api_Info
-- DESCRIPTION:
--      Return INV Api Info


function INV_Api_Info (p_which in varchar2) return varchar2 is 

   l_header varchar2(100) := '$Header: INVApiIHtml.sql 1.28 24-NOV-2003 support $';
   
   /* points to first chars - makes call to instr easier to read */
   FIRSTS number := 1;
   /* position of chars AFTER spaces */
   SPACE1 number := instr(l_header, ' ', FIRSTS, 1) + 1;
   SPACE2 number := instr(l_header, ' ', FIRSTS, 2) + 1;
   SPACE3 number := instr(l_header, ' ', FIRSTS, 3) + 1;
   SPACE4 number := instr(l_header, ' ', FIRSTS, 4) + 1;
   
begin
    if UPPER(p_which) = 'NAME' then
        /* name is between space 1 and 2 */
        return substr( l_header, SPACE1 , SPACE2 - SPACE1 -1);
    elsif UPPER(p_which) = 'VERSION' then
        /* version is between the 2nd and 3rd space */
        return substr( l_header, SPACE2 , SPACE3 - SPACE2 -1);
    elsif UPPER(p_which) = 'DATE' then
        /* date is between the 3rd and 4th space */
        return substr( l_header, SPACE3 , SPACE4 - SPACE3 -1);
    else 
        return l_header;
    end if;
end INV_Api_Info;


------------------------------------------------------------------------------
-- PROCEDURE: Exception_ErrorPrint
-- DESCRIPTION: Display a standard Exception message from an Exception block
--
-- Input: p_procedure: the current procedure/function name
-- Input: p_msg: additional message to display
--
-- Return: none
--
-- Examples:
--
--      FUNCTION xyz 
--      l_proc VARCHAR2(30) := 'xyz';
--      IS
--      BEGIN
--      ...
--      EXCEPTION WHEN OTHERS THEN
--          Exception_ErrorPrint(l_proc);
--      END xyz;
--          
------------------------------------------------------------------------------
PROCEDURE Exception_ErrorPrint (p_procedure in VARCHAR2, p_msg in VARCHAR2 DEFAULT NULL) IS
    l_proc VARCHAR2(30) := 'Exception_ErrorPrint';
BEGIN
    -- This exception is not expected to occur
    ErrorPrint( 'Unexpected Exception Raised in ' || p_procedure );
    IF p_msg IS NOT NULL THEN 
        ErrorPrint(p_msg); 
    END IF;
    ErrorPrint( SQLCODE );
    ErrorPrint( SQLERRM );
    ActionErrorPrint( 'Please verify that the database is running and connection is made to the APPS-user' );

END Exception_ErrorPrint;

------------------------------------------------------------------------------
-- FUNCTION: Count_INV_Periods
-- DESCRIPTION:
--      Count Inventory Periods ( Open, Closed, Pending ) 
-- Input:
--      p_org_id = ORG_ACCT_PERIODS.ORGANIZATION_ID
--              p_org_id MUST be a valid ORG_ID. No check is performed
--                You must NOT pass NULL
--      p_open_flag = Y or N or P or null
--                Y=period open
--                N=period closed
--                P=period close is processing
--                If null is passed, ALL periods, regardless of their
--                        status, are counted
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
--                      done in the calling procedure.
-- Return-Code:
--      Success: Number of Inventory Periods
--      Failure: -2 Unexpected Exception
-- USAGE:
--      Count_INV_Periods( p_org_id, p_open_flag, p_display_message_flag )
-- USAGE-EXAMPLES:
--      count:=Count_INV_Periods( 207, 'Y', 'Y' );
--              Count open INV-Periods for ORG_ID 207 and display message
--      count:=Count_INV_Periods( 207, 'Y', 'N' );
--              Count open INV-Periods for ORG_ID 207 , dont display message
--      count:=Count_INV_Periods( 207, 'N', 'Y' );
--              Count closed INV-Periods for ORG_ID 207 , display message
--      count:=Count_INV_Periods( 207, 'N', 'N' );
--              Count closed INV-Periods for ORG_ID 207 , don't display message
--      count:=Count_INV_Periods( 207, 'P', 'N' );
--              Count pending INV-Periods for ORG_ID 207 , don't display message
------------------------------------------------------------------------------
function Count_INV_Periods ( p_org_id IN number ,
                             p_open_flag IN varchar2 ,
                             p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Count_INV_Periods';
    l_number number;
    l_title varchar2(80);
begin -- Count_INV_Periods

    SELECT count(*)
      INTO l_number
      FROM org_acct_periods
     WHERE organization_id = p_org_id 
       AND open_flag = nvl( p_open_flag, open_flag );

    if p_display_message_flag = 'Y' then
        if p_open_flag = 'Y' then
            g_text := ' open Inventory Periods defined';
        elsif p_open_flag = 'N' then
            g_text := ' closed Inventory Periods defined';
        elsif p_open_flag = 'P' then
            g_text := ' pending Inventory Periods defined';
        else
            g_text := ' Inventory Periods';
        end if;
        Tab3Print( 'There are ' || l_number || g_text );
    end if;

    return l_number;

    exception when OTHERS then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id );
        return -2;

end Count_INV_Periods;

------------------------------------------------------------------------------
-- FUNCTION: INV_Get_Org_Name
-- DESCRIPTION:
--      Return the Organization_Name for given org_id
-- Input:
--      p_org_id ( MTL_PARAMETERS.ORGANIZATION_ID )
-- Return-Code:
--      Success: Organization_name
--      Failure: ERROR_IN_INV_Get_Org_Name
-- USAGE:
--         INV_Get_Org_Name( p_org_id )
-- USAGE-EXAMPLES: 
--         l_org_name:=INV_Get_Org_Name( 207 )
--                Get Organization Name for Organization_ID 207
------------------------------------------------------------------------------
FUNCTION INV_Get_Org_Name ( p_org_id IN number )
RETURN VARCHAR2 IS
    l_proc VARCHAR2(30) := 'INV_Get_Org_Name';
    l_number NUMBER;
    l_org_name hr_organization_units.name%TYPE;
BEGIN -- INV_Get_Org_Name

    ---------------------------------------------------------------------
    -- Get ORGANIZATION_NAME 
    ---------------------------------------------------------------------
    SELECT hou.NAME
      INTO l_org_name
      FROM HR_ORGANIZATION_UNITS hou
     WHERE hou.ORGANIZATION_ID = p_org_id ;

    RETURN l_org_name;

    EXCEPTION 
        WHEN NO_DATA_FOUND THEN
            ErrorPrint( 'The given Organization ID ' || p_org_id || ' is invalid.');
            ActionErrorPrint( 'Please rerun Test and enter a valid Organization ID');
            RETURN 'INVALID_ORG_ID_IN_INV_Get_Org_Name';

        WHEN OTHERS THEN
            -- This exception is not expected to occur....
            RETURN 'ERROR_IN_INV_Get_Org_Name';

END INV_Get_Org_Name;


------------------------------------------------------------------------------
-- FUNCTION: INV_Get_Org_ID
-- DESCRIPTION:
--      Return the Organization_ID for given org_code
-- Input:
--      p_org_code ( MTL_PARAMETERS.ORGANIZATION_code )
-- Return-Code:
--      Sucess: Organization_ID
--      Warning:  0 Unknown Org-Code, defaults to "NoLimit"
--      Failure: -2 Unexpected Exception
-- USAGE:
--      INV_Get_Org_ID( p_org_code )
-- USAGE-EXAMPLES: 
--      l_org_id:=INV_Get_Org_ID( 'M1' )
--                Get Organization ID for Organization_Code M1
------------------------------------------------------------------------------
function INV_Get_Org_ID ( p_org_code IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'INV_Get_Org_ID';
    l_number number;
    l_org_id MTL_PARAMETERS.ORGANIZATION_ID%TYPE;
begin -- INV_Get_Org_ID

    SELECT organization_id
      INTO l_org_id
      FROM mtl_parameters mp
     WHERE organization_code = p_org_code;

    return l_org_id;

    exception
        when NO_DATA_FOUND then
            WarningPrint( 'The given Organization Short Name ' || p_org_code || ' is invalid.');
            ActionWarningPrint( 'Script will retrieve information for all Organizations');
            return 0;

        when OTHERS then
            -- This exception is not expected to occur
            Exception_ErrorPrint( l_proc, 'p_org_code='||p_org_code );
            return -2;

end INV_Get_Org_ID;

------------------------------------------------------------------------------
-- FUNCTION: INV_Get_Org_Code
-- DESCRIPTION:
--      Return the Organization_code for given org_id
-- Input:
--      p_org_id ( MTL_PARAMETERS.ORGANIZATION_ID )
-- Return-Code:
--      Success: Organization_Code
--      Failure: ERR
-- USAGE:
--         INV_Get_Org_Code( p_org_id )
-- USAGE-EXAMPLES: 
--         l_org_code:=INV_Get_Org_Code( 207 )
--                Get Organization Code for Organization_ID 207
------------------------------------------------------------------------------
function INV_Get_Org_Code ( p_org_id IN number )
return varchar2 is
    l_proc VARCHAR2(30) := 'INV_Get_Org_Code';
    l_number number;
    l_org_code MTL_PARAMETERS.ORGANIZATION_CODE%TYPE;
begin -- INV_Get_Org_Code

    select organization_code
      INTO l_org_code
      FROM MTL_PARAMETERS mp
     WHERE ORGANIZATION_ID = p_org_id;

    return l_org_code;

    exception when OTHERS then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id);
        return 'ERR';

end INV_Get_Org_Code;


------------------------------------------------------------------------------
-- FUNCTION: Display_Item_Status
-- DESCRIPTION:
--      Display Item_Status
-- Input:
--      p_activ_inactive_flag ( 'A' or 'I' )
--              If 'A' only active Transaction_Reasons are displayed/counted
--              If 'I' only inactive Transaction_Reasons are displayed/counted
--                        In addition, retrieve the column "disable_date"
--              If null display/count active and inactive Transaction_Reasons
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
--                      done in the calling procedure.
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--         Display_Item_Status( p_activ_inactive_flag,
--                              p_display_message_flag )
-- USAGE-EXAMPLES: 
--         count:=Display_Item_Status( null, 'Y' );
--                Display Transaction_Reasons and Display Message
--         count:=Display_Item_Status( 'A', 'N' );
--                Display Transaction_Reasons and dont Display Message
--         count:=Display_Item_Status( 'I', 'N' );
--                Display Transaction_Reasons and dont Display Message
------------------------------------------------------------------------------
function Display_Item_Status ( p_activ_inactive_flag IN varchar2 ,
                               p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Display_Item_Status';
    l_number number;
    l_title varchar2(80);
    l_act_inact varchar2(80);
begin -- Display_Item_Status

    if p_activ_inactive_flag = 'A'
    then
        ---- Display Active Item Status ----
        ---- There is no MLS-View like mtl_item_status_vl
        l_act_inact := ' active ';
        l_title := 'Active Item Status';
        g_text := 'SELECT inventory_item_status_code "Item Status", description
                      FROM mtl_item_status
                     WHERE disable_date is null OR disable_date > sysdate
                     ORDER BY inventory_item_status_code';
    elsif p_activ_inactive_flag = 'I'
    then
        ---- Display Inactive Item Status ----
        ---- There is no MLS-View like mtl_item_status_vl
        l_act_inact := ' inactive ';
        l_title := 'Inactive Item Status';
        g_text := 'SELECT inventory_item_status_code "Item Status",
                           description, disable_date "Disable Date"
                      FROM mtl_item_status
                     WHERE disable_date is not null AND disable_date <= sysdate
                     ORDER BY inventory_item_status_code';
    else
        ---- Display Active and Inactive Item Statuses ----
        l_act_inact := ' ';
        l_title := 'Item Status';
        g_text := 'SELECT inventory_item_status_code "Item Status",
                           description, disable_date "Disable Date"
                      FROM mtl_item_status
                     ORDER BY inventory_item_status_code';
    end if;

    l_number := Run_SQL( l_title , g_text );

    if p_display_message_flag = 'Y' then
        if l_number = 0 then
            g_text := 'There are no'|| l_act_inact ||'Item Statuses defined';
            ErrorPrint( g_text );
            ActionErrorPrint('Refer to the Inventory User''s Guide on defining Item Statuses');
        else
            g_text := 'There are '||l_number||l_act_inact||'Item Statuses defined';
            Tab1Print( g_text );
        end if;
    end if;

    return l_number;

    exception when OTHERS then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_activ_inactive_flag='||p_activ_inactive_flag );
        return -2;

end Display_Item_Status;


------------------------------------------------------------------------------
-- FUNCTION: Count_Item_Status
-- DESCRIPTION:
--      Count mtl_item_status
-- Input:
--      p_activ_inactive_flag ( 'A' or 'I' )
--              If 'A' only active Items Statuses are displayed/counted
--              If 'I' only inactive Items Statuses are displayed/counted
--                        In addition, retrieve the column "disable_date"
--              If null display/count active and inactive Items Statuses
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
--                      done in the calling procedure.
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--         Count_Item_Status( p_activ_inactive_flag, p_display_message_flag )
-- USAGE-EXAMPLES: 
--         count:=Count_Item_Status( null, 'Y' );
--                Count ALL Items Statuses and Display Message
--         count:=Count_Item_Status( null, 'N' );
--                Count ALL Items Statuses and dont Display Message
--         count:=Count_Item_Status( 'A', 'N' );
--                Count active Items Statuses and dont Display Message
--         count:=Count_Item_Status( 'I', 'N' );
--                Count inactive Items Statuses and dont Display Message
------------------------------------------------------------------------------
function Count_Item_Status ( p_activ_inactive_flag IN varchar2 ,
                             p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Count_Item_Status';
    l_number number;
    l_title varchar2(80);
    l_act_inact varchar2(80);
begin -- Count_Item_Status

    if p_activ_inactive_flag = 'A'
    then
        ---- Count Active Items Statuses ----
        ---- There is no MLS-View like mtl_item_status_vl
        l_act_inact := ' active ';
        SELECT count(*)
          INTO l_number
          FROM mtl_item_status
         WHERE disable_date is null OR disable_date > sysdate ;
    elsif p_activ_inactive_flag = 'I'
    then
        ---- Count Inactive Items Statuses ----
        ---- There is no MLS-View like mtl_item_status_vl
        l_act_inact := ' inactive ';
        SELECT count(*)
          INTO l_number
          FROM mtl_item_status
         WHERE disable_date is not null AND disable_date <= sysdate ;
    else
        ---- Count Active and Inactive Items Statuses ----
        l_act_inact := ' ';
        SELECT count(*)
          INTO l_number
          FROM mtl_item_status;
    end if;

    if p_display_message_flag = 'Y' then
        if l_number = 0 then
            g_text := 'There are no'|| l_act_inact ||'Item Statuses defined';
            ErrorPrint( g_text );
            ActionErrorPrint('Refer to the Inventory User''s Guide on defining Item Statuses');
        else
            g_text := 'There are '||l_number||l_act_inact||'Item Statuses defined';
            Tab1Print( g_text );
        end if;
    end if;

    return l_number;

    exception when OTHERS then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_activ_inactive_flag='||p_activ_inactive_flag );
        return -2;

end Count_Item_Status;


------------------------------------------------------------------------------
-- PROCEDURE: Display_Operating_Units
-- DESCRIPTION:
--      Display Operating_Units in a MultiOrg Installation
-- Input: None
-- Return-Code: None
-- USAGE: Display_Operating_Units
-- USAGE-EXAMPLES: Display_Operating_Units
------------------------------------------------------------------------------
procedure Display_Operating_Units is
    l_proc VARCHAR2(30) := 'Display_Operating_Units';
begin -- Display_Operating_Units

    g_text := 'Existing Operating Units';
    Run_SQL( g_text,
    'SELECT organization_id "Org ID", name, date_from "Date from", date_to "Date to"
       FROM hr_operating_units
      ORDER by organization_id' );

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc );
        return ;

end Display_Operating_Units;

------------------------------------------------------------------------------
-- PROCEDURE: Display_Apps_Information
-- DESCRIPTION:
--      Display Basic Apps Information
--      Esp. check whether it is MULTIORG ! 
-- Input: None
-- Return-Code: None
-- USAGE: Display_Apps_Information
-- USAGE-EXAMPLES: Display_Apps_Information
------------------------------------------------------------------------------
procedure Display_Apps_Information is
    l_proc VARCHAR2(30) := 'Display_Apps_Information';
    l_multi_org_flag fnd_product_groups.multi_org_flag%type;
begin -- Display_Apps_Information

    g_text := 'Application Information';
    Run_SQL( g_text,
    'SELECT decode( multi_org_flag, ''N'',''No'',
                                    ''Y'',''Yes'',
                    multi_org_flag ) "Multi Org",
            decode( multi_currency_flag, ''N'',''No'',
                                         ''Y'',''Yes'',
                    multi_currency_flag ) "Multi Currency",
            product_group_name "Product Group Name"
       FROM fnd_product_groups' ,'N' );

    SELECT multi_org_flag
      INTO l_multi_org_flag
      FROM fnd_product_groups;

    if upper(l_multi_org_flag) <> 'Y' then
        WarningPrint( 'The Installation is not Multi-org Enabled' );
        ActionWarningPrint( 'Please see MetaLink for DocID: 202127.1' );
        Show_Link( 'http://metalink.oracle.com/metalink/plsql/ml2_documents.showDocument?p_database_id=NOT&p_id=202127.1', 'Release 11i Use of Multiple Organizations in Oracle Applications');
    end if;

    exception when OTHERS then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc );
        return;

end Display_Apps_Information;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Patchset_Level
-- DESCRIPTION:
--      Display Patchset-Level of INV-related products
--      INV,BOM,ENG,ONT,WIP,PO,MRP,WMS
--        fpi.product_version is INTENTIONALLY not displayed, 
--        as this shows 11.5.0 even if this is a 11.5.7 ( or below version )
--        This might be missleading.
--        fpi.patch_level is INTENTIONALLY displayed,
--        as from 11.5.7 onwards it clearly shows Patch-Level.
--
-- Input: None
-- Return-Code: None
-- USAGE: INV_Display_Patchset_Level
-- USAGE-EXAMPLES: INV_Display_Patchset_Level
------------------------------------------------------------------------------
PROCEDURE INV_Display_Patchset_Level IS
    l_proc VARCHAR2(30) := 'INV_Display_Patchset_Level';
BEGIN -- INV_Display_Patchset_Level

    g_text := 'Inventory Related Product Patchset Level' ;
    Run_SQL( g_text,
    'SELECT fa.application_name 
            || '' ( '' || application_short_name || '' ) '' "Application"
          , fpi.patch_level "Patch Level"
       FROM fnd_product_installations fpi, fnd_application_vl fa
      WHERE fpi.application_id = fa.application_id
        AND fa.application_short_name
            IN (''INV'',''BOM'',''EAM'',''ENG'',''ONT'',''WIP'',''PO'',''MRP'',''WMS'', ''WSM'')
      ORDER BY fa.application_name' ,'N' );

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc );
        RETURN ;

END INV_Display_Patchset_Level;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Install_Status
-- DESCRIPTION:
--      Display Installation-Status and Patchset-Level of INV-related products
--      INV,BOM,ENG,ONT,WIP,PO,MRP,WMS
--        fpi.product_version is INTENTIONALLY not displayed, 
--        as this shows 11.5.0 even if this is a 11.5.7 ( or below version )
--        This might be missleading.
--        fpi.patch_level is INTENTIONALLY displayed,
--        as from 11.5.7 onwards it clearly shows Patch-Level.
--
-- Input: None
-- Return-Code: None
-- USAGE: INV_Display_Install_Status
-- USAGE-EXAMPLES: INV_Display_Install_Status;
------------------------------------------------------------------------------
procedure INV_Display_Install_Status is
    l_proc VARCHAR2(30) := 'INV_Display_Install_Status';
begin -- INV_Display_Install_Status

    g_text := 'Inventory Related Product Installation Status' ;
    Run_SQL( g_text,
    'SELECT fa.application_name Application, fl.meaning status, 
            fpi.patch_level "Patch Level"
       FROM fnd_product_installations fpi, fnd_application_vl fa,
            fnd_lookup_values_vl fl
      WHERE fpi.application_id = fa.application_id
        and fl.lookup_type = ''FND_PRODUCT_STATUS''
        and nvl(fpi.status,''N'') = fl.lookup_code
        and fa.application_short_name
            in (''INV'',''BOM'',''EAM'',''ENG'',''ONT'',''WIP'',''PO'',''MRP'',''WMS'')
      ORDER BY fa.application_name' ,'N' );

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc );
        return ;

end INV_Display_Install_Status;

------------------------------------------------------------------------------
-- FUNCTION: Display_UOMs
-- DESCRIPTION: 
--        Display Unit_of_Measures
-- Input:  
--        p_activ_inactive_flag ( 'A' or 'I' )
--              If 'A' only active UOMs are displayed
--              If 'I' only inactive UOMs are displayed
--                        In addition, retrieve the column "disable_date"
--              If null display/count active and inactive UOMs
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
--                      done in the calling procedure.
-- Return-Code:
--      Success: number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--                Display_UOMs( ACTIVE_INACTIVE_FLAG , p_display_message_flag )
-- USAGE-EXAMPLES:
--              count:=Display_UOMs( 'A' , 'Y' );
--                      Display Active UOMs and display message
--
--              count:=Display_UOMs( 'I' , 'Y' );
--                      Display Inactive UOMs and display message
--
--              count:=Display_UOMs( null , 'Y' );
--                      Display of Active and Inactive UOMs and display message.
--
--              count:=Display_UOMs( 'A' , 'N' );
--                      Display Active UOMs and dont display message
--
--              count:=Display_UOMs( 'I' , 'N' );
--                      Display Inactive UOMs and dont display message
--
--              count:=Display_UOMs( null , 'N' );
--                      Display Active and Inactive UOMs and dont display messag
------------------------------------------------------------------------------

function Display_UOMs ( p_activ_inactive IN varchar2 ,
                        p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Display_UOMs';
    l_number number;
    l_title varchar2(80);
begin -- Display_UOMs

        ---- Display UOMs ----
        g_text := 'SELECT uom_class "UoM Class",
                          unit_of_measure "Unit of Measure",
                          uom_code "UoM Code",
                          decode( base_uom_flag, 
                                       ''Y'', ''Yes'', 
                                       ''No'') "Base UoM"';
        if p_activ_inactive = 'A'
        then
            ---- Display Active UOMs ----
            l_title := 'Active Units of Measure';
            g_text := g_text || ' FROM MTL_UNITS_OF_MEASURE_VL
                                    WHERE disable_date is null
                                        OR disable_date > sysdate';
        elsif p_activ_inactive = 'I'
        then
            ---- Display Inactive UOMs ----
            l_title := 'Inactive Units of Measure';
            g_text := g_text || ' , disable_date "Disable Date"
                                    FROM MTL_UNITS_OF_MEASURE_VL
                                    WHERE disable_date is not null
                                        AND disable_date <= sysdate';
        else
            ---- Display Active and Inactive UOMs ----
            l_title := 'Units of Measure';
            g_text := g_text || ' FROM MTL_UNITS_OF_MEASURE_VL';
        end if;
 
        g_text := g_text || ' ORDER BY uom_class, unit_of_measure ';
        l_number := Run_SQL( l_title , g_text );

    if p_display_message_flag = 'Y' then
        Tab1Print( 'There are '||l_number|| ' ' || l_title || ' defined' );
    end if;

    return l_number;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_activ_inactive='||p_activ_inactive );
        return -2;

end Display_UOMs;

------------------------------------------------------------------------------
-- FUNCTION: Count_UOMs
-- DESCRIPTION:
--      Count Unit_of_Measures
-- Input:
--        p_activ_inactive_flag ( 'A' or 'I' )
--              If 'A' only active Units of Measure are counted
--              If 'I' only inactive Units of Measure are counted
--                        In addition, retrieve the column "disable_date"
--              If null display/count active and inactive Units of Measure
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
--                      done in the calling procedure.
-- Return-Code:
--      Success: number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--         Count_UOMs( p_activ_inactive_flag, p_display_message_flag )
-- USAGE-EXAMPLES: 
--         count:=Count_UOMs( null, 'Y' );
--                Count ALL Units-of-Measure and Display Message
--         count:=Count_UOMs( null, 'N' );
--                Count ALL Units-of-Measure and dont Display Message
--         count:=Count_UOMs( 'A', 'N' );
--                Count active Units-of-Measure and dont Display Message
--         count:=Count_UOMs( 'I', 'N' );
--                Count inactive Units-of-Measure and dont Display Message
------------------------------------------------------------------------------
function Count_UOMs ( p_activ_inactive_flag IN varchar2 ,
                      p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Count_UOMs';
    l_number number;
    l_title varchar2(80);
begin -- Count_UOMs

    if p_activ_inactive_flag = 'A'
    then
        ---- Count Active Units of Measure ----
        l_title := 'Active Units of Measure';
        SELECT count(*)
          INTO l_number
          FROM mtl_units_of_measure_vl
         WHERE disable_date is null OR disable_date > sysdate ;
    elsif p_activ_inactive_flag = 'I'
    then
        ---- Count Inactive Units of Measure ----
        l_title := 'Inactive Units of Measure';
        SELECT count(*)
          INTO l_number
          FROM mtl_units_of_measure_vl
         WHERE disable_date is not null AND disable_date <= sysdate ;
    else
        ---- Count Active and Inactive Units of Measure ----
        l_title := 'Units of Measure';
        SELECT count(*)
          INTO l_number
          FROM mtl_units_of_measure_vl;
    end if;

    if p_display_message_flag = 'Y' then
        Tab1Print( 'There are '||l_number|| ' ' || l_title || ' defined' );
    end if;

    return l_number;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_activ_inactive_flag='||p_activ_inactive_flag );
        return -2;

end Count_UOMs;

------------------------------------------------------------------------------
-- FUNCTION: Display_Items_Assigned
-- DESCRIPTION
--      Display_Items_Assigned to the given Organization_ID
-- Input:  p_org_id ( MTL_PARAMETERS.ORGANIZATION_ID )
--                If p_org_id is null, then ALL organizations are used
--      p_count_only_flag ( 'Y' or 'N' )
--              If 'Y' only counts are returned
--              If 'N' display info and return count
-- Return-Code:
--      Success: number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE
--      Display_Items_Assigned( p_org_id , p_count_only_flag );
-- USAGE-EXAMPLES:
--      p_rc:=Display_Items_Assigned( null, 'Y' );
--                Count only number of assigned Items for ALL Organizations
--      p_rc:=Display_Items_Assigned( 207, 'N' );
--              Display Subinventory info for OrganizationID=207
------------------------------------------------------------------------------

function Display_Items_Assigned ( p_org_id IN number  ,
                                  p_count_only_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Display_Items_Assigned';
    l_number number;
begin -- Display_Items_Assigned

    if p_count_only_flag = 'Y'
    then
        SELECT count(*)
          INTO l_number
          FROM mtl_system_items_b
         WHERE organization_id = nvl( p_org_id, organization_id ) ;
    else
        g_text := 'Items Assigned to Organization ' || p_org_id ;
        l_number := Run_SQL( g_text,
        'SELECT secondary_inventory_name "Inventory Name", description,
                reservable_type "Reservable Type",
                locator_type "Locator type",
                availability_type "Availability Type",
                inventory_atp_code "Inventory ATP Code",
                decode( asset_inventory, 1, ''Yes'',
                                         2, ''No'',
                        asset_inventory ) "Asset Inventory ?",
                decode( quantity_tracked, 1, ''Yes'',
                                          2, ''No'',
                        quantity_tracked ) "Quantity Tracked ?",
                disable_date "Disable Date"
          FROM mtl_secondary_inventories 
         WHERE organization_id = ' || p_org_id || '
         ORDER BY secondary_inventory_name' );
    end if;

    return l_number;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id );
        return -2;

end Display_Items_Assigned; 

------------------------------------------------------------------------------
-- FUNCTION: Display_Subinventories
-- DESCRIPTION
--      Display Subinventory Information of the given Organization ID.
--      If NULL is passed as Organization ID, then the subinventory info
--      for all organizations is displayed.
-- Input:
--      p_org_id ( MTL_PARAMETERS.ORGANIZATION_ID )
--          If NULL is passed, Subinventory info of all Organizations is
--          displayed.
--          Output is ordered by org_id, sub_inv_name
--      p_display_message_flag ( 'Y' or 'N' )
--          If 'Y' messages are displayed
--          If 'N' no messages are displayed. The message handling must be
--          the calling code.
--      p_indent( number ) 0,1,2,3 DEFAULT=0=no indentation
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--      Display_Subinventories( p_org_id, p_display_message_flag );
--      Display_Subinventories( p_org_id, p_display_message_flag, p_indent );
-- USAGE-EXAMPLES:
--      Display_Subinventories( null, 'Y' );
--              Display number of Subinventory for ALL Organizations indent=0
--      Display_Subinventories( null, 'Y' , 3 );
--              Display number of Subinventory for ALL Orgs indentation=3
--      Display_Subinventories( 207, 'N' );
--              Display Subinventory info for OrganizationID=207 indentation=0
------------------------------------------------------------------------------
function Display_Subinventories ( p_org_id IN number  ,
                                  p_display_message_flag IN varchar2 ,
                                  p_indent IN NUMBER DEFAULT 0 )
return number is
    l_proc VARCHAR2(30) := 'Display_Subinventories';
    l_number number;
    l_title varchar2(80);
    l_org_code MTL_PARAMETERS.ORGANIZATION_CODE%TYPE;
begin -- Display_Subinventories

    if p_org_id is null then
        l_title := 'Subinventory Information for all Organizations' ;
        g_text := 'SELECT mp.organization_code "Org Code" , ' ;
    else
        l_org_code := INV_Get_Org_Code( p_org_id );
        l_title := 'Subinventory Information for Organization '||l_org_code;
        g_text := 'SELECT ';
    end if;

    g_text := g_text || 'msi.secondary_inventory_name "Name",
                         msi.description,
                         DECODE( msi.reservable_type, 1, ''Yes'',
                                                      2, ''No'',
                                 msi.reservable_type) "Reservable Type",
                         mllt.meaning "Locator Type",
                         mlat.meaning "Availability Type",
                         mlatp.meaning "ATP Code",
                         DECODE( msi.asset_inventory, 1, ''Yes'',
                                                      2, ''No'',
                                 msi.asset_inventory ) "Asset Inventory ?",
                         DECODE( msi.quantity_tracked, 1, ''Yes'',
                                                       2, ''No'',
                                 msi.quantity_tracked ) "Quantity Tracked ?",
                         msi.disable_date "Disable Date"
                        FROM mtl_parameters mp, mtl_secondary_inventories msi, 
                             mfg_lookups mllt, mfg_lookups mlat, mfg_lookups mlatp 
          WHERE ';

        if p_org_id is not null then
             g_text:=g_text|| ' mp.organization_id ='||p_org_id||' AND ' ;
        end if;
        g_text:=g_text||' mp.organization_id = msi.organization_id AND ';

        g_text:=g_text||
                '     nvl( msi.locator_type,-99) = mllt.lookup_code(+)'||
                ' AND mllt.lookup_type=''MTL_LOCATION_CONTROL'' '||
                ' AND nvl( msi.availability_type,-99) = mlat.lookup_code(+)'||
                ' AND mlat.LOOKUP_TYPE=''MTL_AVAILABILITY'' '||
                ' AND nvl( msi.availability_type,-99) = mlatp.lookup_code(+)'||
                ' AND mlatp.LOOKUP_TYPE=''MTL_ATP_CODE'' ';

        if p_org_id is null then
            g_text := g_text || ' ORDER BY msi.organization_id, msi.secondary_inventory_name' ; 
        else
            g_text := g_text || ' ORDER BY msi.secondary_inventory_name' ; 
        end if;

    l_number := Run_SQL( l_title, g_text, 'N', NULL, p_indent );

    IF p_display_message_flag = 'Y' AND p_org_id IS NOT NULL THEN
        Tab3Print( 'There are '||l_number|| ' Subinventories defined for Organization ' || l_org_code );
        if l_number = 0 then
            ErrorPrint( 'There must be at least one Subinventory defined');
            ActionErrorPrint('Refer to the Oracle Inventory User''s Guide for Information on defining Subinventories');
        end if;
    end if;

    return l_number;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id );
        return -2;

end Display_Subinventories;

------------------------------------------------------------------------------
-- FUNCTION: Count_Subinventories
-- DESCRIPTION
--      Count Subinventory Information of the given Organization ID
--      If NULL is passed as Organization ID, then the subinventory info
--      for all organizations is counted.
-- Input:
--      p_org_id ( MTL_PARAMETERS.ORGANIZATION_ID )
--              If NULL is passed, Subinventory info of all
--                        Organizations is displayed.
--                        Output is ordered by org_id, sub_inv_name
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--      Count_Subinventories( p_org_id, p_display_message_flag );
-- USAGE-EXAMPLES:
--      Count_Subinventories( null, 'Y' );
--              Count Subinventories for ALL Organizations and display message
--      Count_Subinventories( 207, 'Y' );
--              Count Subinventories for OrganizationID=207 and display messag
--      Count_Subinventories( 207, 'N' );
--              Count Subinventories for OrganizationID=207, dont display mess
------------------------------------------------------------------------------
function Count_Subinventories ( p_org_id IN number  ,
                                p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Count_Subinventories';
    l_number number;
    l_title varchar2(80);
begin -- Count_Subinventories

    SELECT count(*)
      INTO l_number
      FROM mtl_secondary_inventories
     WHERE organization_id = nvl( p_org_id, organization_id ) ;

    if p_display_message_flag = 'Y' then
        if p_org_id is null then
            Tab3Print( 'There are '||l_number||' Subinventories defined for all Organizations' );
            if l_number = 0 then
                Errorprint( 'There must be at least one Subinventory defined in each organization');
                ActionErrorPrint('Refer to the Oracle Inventory User''s Guide for Information on defining Subinventories');
            end if;
        else
            Tab3Print( 'There are '||l_number||' Subinventories defined' ); 
            if l_number = 0 then
                Errorprint( 'There must be at least one Subinventory defined');
                ActionErrorPrint('Refer to the Oracle Inventory User''s Guide for Information on defining Subinventories');
            end if;
        end if;
    end if;

    return l_number;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id );
        return -2;

end Count_Subinventories;


------------------------------------------------------------------------------
-- FUNCTION: INV_Display_Stock_Locators
-- DESCRIPTION
--      Display Stock Locator Information of the given Organization ID
-- Input:
--      p_org_id ( mtl_parameters.organization_id ).
--      p_loc_id ( mtl_item_locations_kfv.inventory_location_id ).
--            If p_loc_id IS NOT NULL, then p_activ_inactive_flag is NOT taken
--                  into account.
--            If p_loc_id IS NULL, then p_activ_inactive_flag is taken
--      p_activ_inactive_flag = 'I' , 'A' , NULL
--          p_activ_inactive_flag is for future use
--      p_indent = 0,1,2 ( IndentationLevel )
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--      INV_Display_Stock_Locators( p_org_id , p_loc_id , 'A', 1 );
-- USAGE-EXAMPLES:
--      rc:=INV_Display_Stock_Locators( 207, NULL, 'I', 0);
--          Display Inactive StockLocator for OrganizationID=207, No indentLevel
--      rc:=INV_Display_Stock_Locators( 207, NULL, 'A', 1);
--          Display Active StockLocator for OrganizationID=207, 1 IndentLevel
--      rc:=INV_Display_Stock_Locators( 207, 1212, 'A', 2);
--          Display StockLocator 1212 for OrganizationID=207, 2 IndentLevel
------------------------------------------------------------------------------
FUNCTION INV_Display_Stock_Locators( p_org_id IN NUMBER,
                                     p_loc_id IN NUMBER,
                                     p_activ_inactive_flag IN VARCHAR2, --future
                                     p_indent IN NUMBER )
RETURN NUMBER IS
    l_proc VARCHAR2(30) := 'INV_Display_Stock_Locators';
    l_number NUMBER;
    l_title VARCHAR2(80);
BEGIN -- INV_Display_Stock_Locators

    -- g_text := 'SELECT mil.concatenated_segments
    --                ||'' (''||mil.inventory_location_id||'')''  "Locator" 

    g_text := 'SELECT mil.concatenated_segments "Locator"
                    , mil.inventory_location_id "Locator|Id"
                    , mil.description
                    , mil.subinventory_code "SubInventory"
                    , mif.item_number "Item"
                    , mil.inventory_item_id "Item Id"
                    , mil.enabled_flag "Enabled"
                    , mil.disable_date "Disable Date"
                    , mil.start_date_active "Start Date"
                    , mil.end_date_active "End Date"' ;
   -- Need to check existence of later introduced column EMPTY_FLAG
    IF Column_Exists('MTL_ITEM_LOCATIONS_KFV', 'EMPTY_FLAG') = 'Y'
    THEN
        g_text := g_text || ' ,DECODE( mil.empty_flag, ''Y'', ''Yes'',
                                                       ''N'', ''No'',
                                       mil.empty_flag )  "Empty"';
    END IF;
   -- Need to check existence of later introduced column MIXED_ITEMS_FLAG
    IF Column_Exists('MTL_ITEM_LOCATIONS_KFV', 'MIXED_ITEMS_FLAG') = 'Y'
    THEN
        g_text := g_text || ' ,DECODE( mil.mixed_items_flag, ''Y'', ''Yes'',
                                                             ''N'', ''No'',
                                       mil.mixed_items_flag ) "Mixed|Items"';
    END IF;
    g_text := g_text || '
                 FROM mtl_item_locations_kfv mil
                    , mtl_item_flexfields mif
                WHERE mil.organization_id = mif.organization_id(+)
                  AND mil.inventory_item_id = mif.inventory_item_id(+)
                  AND mil.organization_id = ' || p_org_id ;

    IF p_loc_id IS NULL
    THEN
        l_title := 'Information for All Stock Locators in Organization ' || INV_Get_Org_Code( p_org_id)||' ('||p_org_id||')';
    ELSE
        l_title := 'Information for Stock Locator ' ||p_loc_id||' in Organization ' || INV_Get_Org_Code( p_org_id)||' ('||p_org_id||')';
        g_text := g_text || ' AND inventory_location_id = ' || p_loc_id; 
    END IF;
    g_text := g_text || ' ORDER BY mil.inventory_location_id, mil.organization_id';
    
/****************************************************************************
    IF p_activ_inactive_flag = 'A' THEN
        ---- Display Active Stock Locators
        l_title := 'Active Stock Locators';
        g_text := 'SELECT inventory_location_id "Locator|Id"
                        , organization_id "Organization|Id"
                        , description
                        , concatenated_segments
                        , subinventory_code "SubInventory"
                        , enabled_flag "Enabled"
                        , disable_date "Disable Date"
                        , start_date_active "Start Date"
                        , end_date_active "End Date"
                      FROM mtl_item_locations_kfv
                     WHERE ( end_date_active IS NULL
                          OR end_date_active > sysdate )
                       AND ( disable_date IS NULL OR disable_date IS NULL )
                       AND ( enabled_flag IS NULL OR disable_date IS NULL )
                     ORDER BY inventory_location_id, organization_id';
    ELSIF p_activ_inactive_flag = 'I'
    THEN
        ---- Display Inactive Stock Locators
        l_title := 'Inactive Stock Locators';
        g_text := 'SELECT inventory_location_id "Locator|Id"
                        , organization_id "Organization|Id"
                        , description
                        , concatenated_segments
                        , subinventory_code "SubInventory"
                        , enabled_flag "Enabled"
                        , disable_date "Disable Date"
                        , start_date_active "Start Date"
                        , end_date_active "End Date"
                      FROM mtl_item_locations_kfv
                     WHERE ( end_date_active IS NOT NULL
                          OR end_date_active <= sysdate )
                       OR ( disable_date IS NOT NULL 
                          OR disable_date <= SYSDATE )
                       OR ( enabled_flag IS NOT NULL )
                     ORDER BY inventory_location_id, organization_id';
    else
        ---- Display Active and Inactive Stock Locators ----
        l_title := 'Stock Locators';
        g_text := 'SELECT inventory_location_id "Locator|Id"
                        , organization_id "Organization|Id"
                        , description
                        , concatenated_segments
                        , subinventory_code "SubInventory"
                        , enabled_flag "Enabled"
                        , disable_date "Disable Date"
                        , start_date_active "Start Date"
                        , end_date_active "End Date"
                     FROM mtl_item_locations_kfv';
    END IF;
*****************************************************************************/

    l_number := Run_SQL( l_title , g_text, 'N', 0, p_indent );

    RETURN l_number;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id );
        RETURN -2;

END INV_Display_Stock_Locators;

------------------------------------------------------------------------------
-- FUNCTION: Display_Inv_Org_Info
-- DESCRIPTION:
--      Display Inventory Organization Information of the given Organization ID
--      If no Organization ID is passed, then info for  ALL  Organizations
--      displayed
-- Input:
--         p_org_id ( MTL_PARAMETERS.ORGANIZATION_ID )
--              or NULL. If NULL is passed, all Organizations are displayed.
--
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
--
-- USAGE-EXAMPLES:
--              Display_Inv_Org_Info( null );
--                      Display info for ALL Inventory Organizations
--              Display_Inv_Org_Info( 207 );
--                      Display info for Inventory OrganizationID=207
------------------------------------------------------------------------------
function Display_Inv_Org_Info ( p_org_id IN number ) return number is
    l_proc VARCHAR2(30) := 'Display_Inv_Org_Info';
    l_number number;
begin -- Display_Inv_Org_Info

    g_text := 'SELECT mp.organization_code "Org|Code"
           ,mp.organization_id "Organization|ID"
           ,mpm.organization_code "Master|Org|Code"
           ,mp.master_organization_id "Master|Organization|ID"
           ,mpc.organization_code "Cost|Org|Code"
           ,mp.cost_organization_id "Cost|Organization|ID"
           ,nvl(sob.short_name,''null'') "Set of Books"
           ,nvl(ood.set_of_books_id,0) "Set of Books|ID"
           ,ou.name "Operating Unit Name"
           ,ood.operating_unit "Operating|Unit"
           ,mp.calendar_code "Calendar"
           ,DECODE( mp.negative_inv_receipt_code,1,''Yes'',
                                       ''No'') "Negative|Balances|Allowed"
           ,DECODE( mp.serial_number_generation, 1, ''At organization level'',
                                                 2, ''At item level'',
                                                 3, ''User Defined'',
                    mp.serial_number_generation ) "Serial Number|Generation"
           ,DECODE( mp.lot_number_uniqueness, 1, ''Unique for item'',
                                              2, ''No uniqueness control'',
                    mp.lot_number_uniqueness) "Lot Number Uniqueness"
           ,DECODE( mp.lot_number_generation, 1, ''At organization level'',
                                           2, ''At item level'',
                                           3, ''User Defined'',
                    mp.lot_number_generation ) "Lot Number Generation"
           ,DECODE( mp.serial_number_type, 1, ''Unique within inventory items'',
                                           2, ''Unique within organization'',
                                           3, ''Unique across organizations'',
                    mp.serial_number_type ) "Serial Number Type"
           ,DECODE( mp.stock_locator_control_code, 1, ''No locator control'' ,
                                                   2, ''Prespecified locator control'' ,
                                                   3, ''Dynamic entry locator control'' ,
                                                   4, ''Determined at subinventory level'' ,
                                                   5, ''Determined at item level'' ,
                   mp.stock_locator_control_code ) "Locator|Control Code"
           ,DECODE( mp.primary_cost_method, 1, ''Standard'',
                                            2, ''Average'',
                                            3, ''Periodic Average'',
                                            4, ''Periodic Incremental LIFO'',
                                            5, ''FIFO'',
                                            6, ''LIFO'',
                    mp.primary_cost_method) "Primary Cost|Method"
           ,nvl(cost_type,''null'') "Avg.Rates|Cost Type"
           ,mp.avg_rates_cost_type_id "Avg.Rates|Cost Type ID"
           ,DECODE( mp.wms_enabled_flag, ''Y'', ''Yes'', 
                                         ''N'', ''No'',
                    mp.wms_enabled_flag )  "WMS|Enabled"
           ,DECODE( mp.wsm_enabled_flag, ''Y'', ''Yes'', 
                                         ''N'', ''No'',
                    mp.wsm_enabled_flag )  "WSM|Enabled"';

   -- Need to check existence of later introduced column EAM_ENABLED_FLAG
    IF Column_Exists('MTL_PARAMETERS', 'EAM_ENABLED_FLAG') = 'Y'
    THEN
        g_text := g_text || ' ,DECODE( mp.eam_enabled_flag, ''Y'', ''Yes'',
                                                              ''N'', ''No'',
                                       mp.eam_enabled_flag )  "EAM|Enabled"';
    END IF;

   -- Need to check existence of later introduced column CONSIGNED_FLAG
    IF Column_Exists('MTL_PARAMETERS', 'CONSIGNED_FLAG') = 'Y'
    THEN
        g_text := g_text || ' ,DECODE( mp.consigned_flag, ''Y'', ''Yes'',
                                                          ''N'', ''No'',
                                       mp.consigned_flag )  "Consigned|VMI Stock"';
    END IF;

    g_text := g_text || '
      FROM mtl_parameters mp ,mtl_parameters mpc ,mtl_parameters mpm
          ,cst_cost_types ct
          ,org_organization_definitions ood
          ,gl_sets_of_books sob
          ,hr_operating_units ou ' ;

    if p_org_id is null
    then
        g_text:=g_text||' WHERE mp.cost_organization_id=mpc.organization_id';
    else
        g_text:=g_text||' WHERE mp.organization_id=' || p_org_id ;
        g_text:=g_text||'   AND mp.cost_organization_id=mpc.organization_id';
    end if ;
    
    -- to prevent ORA-1722 in  8174 on mfg_lookups.lookup_code(+) use DECODE()
    -- See OSS377796 , bug 1517098
    g_text:=g_text||'
      AND mp.master_organization_id = mpm.organization_id
      AND mp.avg_rates_cost_type_id = ct.cost_type_id(+)
      AND mp.organization_id = ood.organization_id
      AND ood.set_of_books_id = sob.set_of_books_id(+)
      AND ood.operating_unit = ou.organization_id(+)
      ORDER BY mp.organization_code';

    l_number := Run_SQL( 'Organization Information', g_text, 'N', NULL, 0 );

    return l_number;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id );
        Tab0Print( g_text );
        return -2;

end Display_Inv_Org_Info;

------------------------------------------------------------------------------
-- FUNCTION: Display_Active_Concurrent_Managers
-- DESCRIPTION:
--        Display active concurrent managers
--      Active does not necessarily mean, that a CM is just running
--        a request, but that the CM is able to process requests
-- Input:
--      p_count_only_flag ( 'Y' or 'N' )
--              If 'Y' only count active ConcMgrs
--              If 'N' display active ConcMgrs
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be 
--                        done in the calling procedure.
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--      count:=Display_Active_ConcMgr( COUNT_ONLY_FLAG, DISPLAY_MESSAGE_FLAG );
-- USAGE-EXAMPLES:
--      count:=Display_Active_ConcMgr( 'Y' , 'Y' );
--                      Count Number of Active ConcMgrs and Display Message
--      count:=Display_Active_ConcMgr( 'Y' , 'N' );
--                      Count Number of Active ConcMgrs and dont Display Message
--      count:=Display_Active_ConcMgr( 'N' , 'Y' );
--                      Display Active ConcMgrs and Display Message
--      count:=Display_Active_ConcMgr( 'N' , 'N' );
--                      Display Active ConcMgrs and dont Display Message
------------------------------------------------------------------------------
function Display_Active_ConcMgr ( p_count_only_flag IN varchar2 ,
                                  p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Display_Active_ConcMgr';
    l_rowcnt number;
begin -- Display_Active_ConcMgr

    if p_count_only_flag = 'Y'
    then
        SELECT count(*)
          INTO l_rowcnt
          FROM fnd_concurrent_queues_vl fcq,
               fnd_application_vl fa,
               fnd_concurrent_processors fcp
         WHERE running_processes > 0
           and fa.application_id = fcq.application_id
           and fcq.application_id = fcp.application_id
           and fcq.concurrent_processor_id = fcp.concurrent_processor_id;
    else
        l_rowcnt := Run_SQL( 'Active Concurrent Managers',
        'SELECT fa.application_name application ,
                fcp.concurrent_processor_name Name,
                fcq.user_concurrent_queue_name Manager,
                nvl(fcq.target_node,''n/a'') Node,
                fcq.running_processes Actual,
                fcq.max_processes Target
           FROM fnd_concurrent_queues_vl fcq,
                fnd_application_vl fa,
                fnd_concurrent_processors fcp
          WHERE running_processes > 0
            AND fa.application_id = fcq.application_id
            AND fcq.application_id = fcp.application_id
            AND fcq.concurrent_processor_id = fcp.concurrent_processor_id
          ORDER BY fcp.application_id , fcp.concurrent_processor_id,
                 fcp.concurrent_processor_name' );
    end if;

    if p_display_message_flag = 'Y' then
        BRPrint;
        if l_rowcnt = 0  then
            g_text := 'There are no Active Concurrent Managers';
            WarningPrint( g_text );
            ActionWarningPrint( 'Refer to the Oracle System Administrator Guide for information on setting up and running Concurrent Managers' );
        else
            g_text := 'There are ' ||l_rowcnt|| ' Active Concurrent Managers';
            Tab1Print( g_text );
        end if;
    end if;

    return l_rowcnt;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_count_only_flag='||p_count_only_flag );
        return -2;

end Display_Active_ConcMgr;

------------------------------------------------------------------------------
-- FUNCTION: Display_Inactive_ConcMgr
-- DESCRIPTION:
--        Display inactive concurrent managers
--      Inactive means, that a CM has not been started or is disabled
-- Input:
--      p_count_only_flag ( 'Y' or 'N' )
--              If 'Y' only count active ConcMgrs
--              If 'N' display active ConcMgrs
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
--                      done in the calling procedure.
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE:
--      count:=Display_Inactive_ConcMgr( COUNT_ONLY_FLAG, DISPLAY_MESSAGE_FLAG);
-- USAGE-EXAMPLES:
--      count:=Display_Inactive_ConcMgr( 'Y' , 'Y' );
--                      Count Number of Inactive ConcMgrs and display Message
--      count:=Display_Inactive_ConcMgr( 'Y' , 'N' );
--                      Count Number of Inactive ConcMgrs, dont display Message
--      count:=Display_Inactive_ConcMgr( 'N' , 'Y' );
--                      Display Inactive ConcMgrs and display Message
--      count:=Display_Inactive_ConcMgr( 'N' , 'N' );
--                      Display Inactive ConcMgrs and dont display Message
------------------------------------------------------------------------------
function Display_Inactive_ConcMgr ( p_count_only_flag IN varchar2 ,
                                    p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Display_Inactive_ConcMgr';
    l_rowcnt number;
begin -- Display_Inactive_ConcMgr

    if p_count_only_flag = 'Y'
    then
        SELECT count(*)
          INTO l_rowcnt
          FROM fnd_concurrent_queues_vl fcq,
               fnd_application_vl fa,
               fnd_concurrent_processors fcp
         WHERE running_processes = 0
           and fa.application_id = fcq.application_id
           and fcq.application_id = fcp.application_id
           and fcq.concurrent_processor_id = fcp.concurrent_processor_id;
    else
        l_rowcnt := Run_SQL( 'Inactive Concurrent Managers',
        'SELECT fa.application_name application,
                fcp.concurrent_processor_name Manager,
                fcq.user_concurrent_queue_name Name,
                nvl(fcq.target_node,''n/a'') Node,
                fcq.running_processes Actual,
                fcq.max_processes Target
           FROM fnd_concurrent_queues_vl fcq, fnd_application_vl fa,
                fnd_concurrent_processors fcp
          WHERE running_Processes = 0
            and fa.application_id = fcq.application_id
            and fcq.application_id = fcp.application_id
            and fcq.concurrent_processor_id = fcp.concurrent_processor_id
          ORDER BY fa.application_name, fcq.concurrent_queue_id' );
    end if;

    if p_display_message_flag = 'Y' then
        BRPrint;
        if l_rowcnt = 0  then
            g_text := 'There are no Inactive Concurrent Managers';
            Tab1Print( g_text );
        else
           g_text := 'There are ' ||l_rowcnt|| ' Inactive Concurrent Managers';
           WarningPrint( g_text );
           ActionWarningPrint( 'Refer to the appropriate User Guide and Oracle System Administrator Guide for information on setting up and running Concurrent Managers' );
        end if;
    end if;

    return l_rowcnt;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_count_only_flag='||p_count_only_flag );
        return -2;

end Display_Inactive_ConcMgr;

------------------------------------------------------------------------------
-- FUNCTION: Display_Enabled_ConcMgr
-- DESCRIPTION: Display all enabled concurrent managers 
-- Input: None
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
------------------------------------------------------------------------------
function Display_Enabled_ConcMgr return number is
    l_proc VARCHAR2(30) := 'Display_Enabled_ConcMgr';
    l_rowcnt number;
begin -- Display_Enabled_ConcMgr

    l_rowcnt := Run_SQL( 'Enabled Concurrent Managers',
    'SELECT fa.application_name Application,
            fcq.user_concurrent_queue_name Manager,
            nvl(fcq.target_node,''n/a'') Node,
            fcq.running_processes Actual,
            fcq.max_processes Target
     FROM fnd_concurrent_queues_vl fcq,
          fnd_application_vl fa
     WHERE fa.application_id = fcq.application_id
       AND fcq.enabled_flag = ''Y''
     ORDER BY fcq.application_id , fcq.concurrent_queue_id' );

    return l_rowcnt;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc );
        return -2;

end Display_Enabled_ConcMgr;

------------------------------------------------------------------------------
-- FUNCTION: Display_Disabled_ConcMgr
-- DESCRIPTION: Display all Disabled concurrent managers 
-- Input: None
-- Return-Code:
--      Success: Number of retrieved rows
--      Failure: -2 Unexpected Exception
------------------------------------------------------------------------------
function Display_Disabled_ConcMgr return number is
    l_proc VARCHAR2(30) := 'Display_Disabled_ConcMgr';
    l_rowcnt number;
begin -- Display_Disabled_ConcMgr

    l_rowcnt := Run_SQL( 'Disabled Concurrent Managers',
    'SELECT fa.application_name Application,
            fcq.user_concurrent_queue_name Manager,
            nvl(fcq.target_node,''n/a'') Node,
            fcq.running_processes Actual,
            fcq.max_processes Target
     FROM fnd_concurrent_queues_vl fcq,
          fnd_application_vl fa
     WHERE fa.application_id = fcq.application_id
       and fcq.enabled_flag = ''N''
     ORDER BY fcq.application_id , fcq.concurrent_queue_id' );

    return l_rowcnt;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc );
        return -2;

end Display_Disabled_ConcMgr;

------------------------------------------------------------------------------
-- FUNCTION: Display_Conc_Progs_Status
-- DESCRIPTION: Display program_name and enabled_status of all Conc_Prgs
--              of the given Application ID
--              If no Application ID is paased, than ALL the
--              the Enabled-Status of ALL Concurrent_Programs is displayed
--              If no ENABLED_FLAG is given the conc.progs according to 
--              APPLICATION_ID are displayed.
-- Input:  Application ID ( FND_CONCURRENT_PROGRAMS_VL.APPLICATION_ID )
--         p_enabled_flag ( FND_CONCURRENT_PROGRAMS_VL.ENABLED_FLAG )
--                Must be null, Y or N. UPPERCASE !
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
--                      done in the calling procedure.
-- Return-Code:
--      Success: number of retrieved rows
--      Failure: -2 Unexpected Exception
-- USAGE
--      Display_Conc_Progs_Status( p_application_id, p_enabled_flag 
--                                 p_display_message_flag )
-- USAGE-EXAMPLES:
--      p_rec:=Display_Conc_Progs_Status( null, null, 'N' );
--          Display Enabled/Disabled info of ALL Conc.Progs, dont display messag
--
--      p_rec:=Display_Conc_Progs_Status(  401, null, 'N' );
--          Display Enabled/Disabled info of Inventory(401) Conc.Progs
--
--      p_rec:=Display_Conc_Progs_Status( null, 'Y' , 'N' );
--          Display info of ALL Enabled Conc.Progs. Dont display message.
--
--      p_rec:=Display_Conc_Progs_Status( null, 'N' , 'Y' );
--          Display info of ALL Disabled Conc.Progs. Display message.
--
--      p_rec:=Display_Conc_Progs_Status(  401, 'Y' , 'N' );
--          Display info of ALL Enabled Inventory Conc.Progs
--
--      p_rec:=Display_Conc_Progs_Status(  401, 'N' , 'Y' );
--          Display info of ALL Disabled Inventory Conc.Progs. Display message.
------------------------------------------------------------------------------
function Display_Conc_Progs_Status ( p_application_id IN varchar2 ,
                                     p_enabled_flag IN varchar2 ,
                                     p_display_message_flag IN varchar2 )
return number is
    l_proc VARCHAR2(30) := 'Display_Conc_Progs_Status';
    l_rowcnt number;
    l_title varchar2(80);
    l_appname varchar2(40);
begin -- Display_Conc_Progs_Status


    -- I intentionally assemble the select as it seems to be MORE performant
    -- than using nvl()to check for NULLs e.g.
    -- WHERE APPLICATION_ID=' || nvl(p_application_id, 'APPLICATION_ID') || '

    g_text := 'SELECT fa.application_id "Appl. ID",
                       fa.application_short_name "Appl. Shortname",
                       fcp.user_concurrent_program_name "Program Name",
                       fcp.concurrent_program_name "Program Short Name",
                       fcp.enabled_flag "Enabled ?"
                  FROM fnd_concurrent_programs_vl fcp, fnd_application_vl fa
                 WHERE fcp.application_id = fa.application_id ';

    l_title := 'Concurrent Program Enabled Status';
    if p_application_id is not null
    then
        g_text := g_text || ' AND fa.application_id =' || p_application_id;
        SELECT substr( APPLICATION_NAME, 1, 30 )
          INTO l_appname
          FROM fnd_application_vl
         WHERE application_id = p_application_id;

        l_title := l_title || ' for ' || l_appname;
    end if;

    if p_enabled_flag is not null
    then
        g_text := g_text ||' AND fcp.enabled_flag = ''' || p_enabled_flag || '''';
    end if;

    g_text := g_text || ' ORDER BY fcp.application_id, fcp.concurrent_program_name';
    -- SectionPrint( g_text );

    l_rowcnt := Run_SQL( l_title , g_text );

    if p_display_message_flag = 'Y' then
        g_text := 'There are ' || l_rowcnt;
        if p_enabled_flag = 'Y'
        then
            g_text := g_text || ' enabled Concurrent Programs';
        else
            g_text := g_text || ' disabled Concurrent Programs';
        end if;
        if p_application_id is not null then
            g_text := g_text||' for Application ' || l_appname;
        end if;
        Tab1Print( g_text );
    end if;

    return l_rowcnt;

    exception when others then
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_application_id='||p_application_id );
        return -2;

end Display_Conc_Progs_Status;

------------------------------------------------------------------------------
-- PROCEDURE: is_concurrent_process_active
-- DESCRIPTION: is_concurrent_process_active
-- Input: p_process: program_name to check (e.g. INCTCW)
-- Return-Code: p_status: variable to return the status of the process
--              p_tf: return TRUE if Active, FALSE if Inactive
------------------------------------------------------------------------------
PROCEDURE is_concurrent_process_active( p_process IN VARCHAR2,
                                        l_status IN OUT VARCHAR2,
                                        l_tf IN OUT BOOLEAN) IS
    l_active NUMBER := 0;
    l_proc VARCHAR2(30) := 'is_concurrent_process_active';

BEGIN -- is_concurrent_process_active
    l_status := 'Inactive';
    l_tf := FALSE;

    SELECT 1
      INTO l_active
      FROM fnd_concurrent_requests r, fnd_concurrent_programs p
     WHERE p.concurrent_program_name = p_process 
       AND p.concurrent_program_id = r.concurrent_program_id 
       AND p.application_id = r.program_application_id
       AND r.phase_code in ( 'P', 'R' );

    IF l_active = 1 THEN
        l_tf := TRUE;
        l_status := 'Active';
    END IF;

    EXCEPTION 
        WHEN NO_DATA_FOUND THEN
            l_status := 'Inactive';
            l_tf := FALSE;
            RETURN;

        WHEN TOO_MANY_ROWS THEN
            l_status := 'Active';
            l_tf := TRUE;
            RETURN;

        WHEN OTHERS THEN
            -- This exception is not expected to occur
            Exception_ErrorPrint( l_proc, 'p_process='||p_process );
            RETURN;

END is_concurrent_process_active;


------------------------------------------------------------------------------
-- FUNCTION: INV_Get_Conc_Proc_Info
-- DESCRIPTION: Get information from fnd_concurrent_process
--              wthere a certain conc.Program is running/pending etc.
-- Input: p_process: program_name to check (e.g. INCTCW)
--        p_limited_phase_code: e.g. NULL or RP (Running or Pending)
-- Return-Code: p_status: variable to return the status of the process
--              p_tf: return TRUE if Active, FALSE if Inactive
-- Input:  Conc.Prog.Shortname ( FND_CONCURRENT_PROGRAMS_VL.APPLICATION_ID )
--         p_limited_phase_code:
--                RP: Only Reuqests in status Running/Pending
--                0: Do not take into account Phase_Code
--     Max Rows - Limit the output to this many rows.  0 indicate
--                unlimited rows
-- Return-Code:
--      Number of records found in fnd_concurrent_requests for conc.ProgramName
--      Failure: -1 p_prog_name is not a ConcurrentProgram
--      Failure: -2 Unexpected Exception
-- USAGE
--      INV_Get_Conc_Proc_Info( p_prog_name, 'RP', p_max_rows, p_indent );
--      INV_Get_Conc_Proc_Info( p_prog_name, NULL, p_max_rows , p_indent);
-- USAGE-EXAMPLES:
--      l_number:=INV_Get_Conc_Proc_Info( ?, ?, 30, 1 );
--      l_number:=INV_Get_Conc_Proc_Info( ?, ?, 0, 0 );
--          ?
------------------------------------------------------------------------------
FUNCTION INV_Display_Conc_Proc_Info( p_prog_name IN VARCHAR2
                                   , p_limited_phase_code IN VARCHAR2 
                                   , p_max_rows IN NUMBER 
                                   , p_indent IN NUMBER )
RETURN NUMBER IS
    l_proc  VARCHAR2(30) := 'INV_Get_Conc_Proc_Info';
    l_title VARCHAR2(300);
    l_prog_user_name fnd_concurrent_programs_vl.user_concurrent_program_name%TYPE;
BEGIN -- INV_Display_Conc_Proc_Info

    BEGIN
    SELECT ptl.user_concurrent_program_name
      INTO l_prog_user_name
      FROM fnd_concurrent_programs_vl ptl,
           fnd_concurrent_programs prog
     WHERE prog.concurrent_program_name = p_prog_name
       AND prog.concurrent_program_id=ptl.concurrent_program_id
       AND prog.application_id=ptl.application_id;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
        -- if this exception is raised, the calling code is wrong.
        ErrorPrint( SQLCODE );
        ErrorPrint( SQLERRM );
        ErrorPrint( 'Error in INVApiHtml   INV_Display_Conc_Proc_Info' );
        ErrorPrint( 'p_prog_name=' || p_prog_name );
        ActionErrorPrint('Please report this error to Oracle Support Services
                          Stating which test and version you have run' );
        RETURN -1;
    END;

    -- I intentionally display also "Concurrent Program Name"
    g_text := 'SELECT request_id "Request"
                    , fcp.concurrent_program_name "Concurrent Program"
                    , DECODE( phase_code, ''C'', ''Completed'',
                                          ''I'', ''Inactive'',
                                          ''P'', ''Pending'',
                                          ''R'', ''Running'',
                              phase_code ) "Phase"
                    , DECODE( status_code, ''A'', ''Waiting'',
                                           ''B'', ''Resuming'',
                                           ''C'', ''Normal'',
                                           ''D'', ''Cancelled'',
                                           ''E'', ''Error'',
                                           ''G'', ''Warning'',
                                           ''H'', ''On Hold'',
                                           ''I'', '' Normal'',
                                           ''M'', ''No Manager'',
                                           ''P'', ''Scheduled'',
                                           ''Q'', ''Standby'',
                                           ''R'', ''  Normal'',
                                           ''S'', ''Suspended'',
                                           ''T'', ''Terminating'',
                                           ''U'', ''Disabled'',
                                           ''W'', ''Paused'',
                                           ''X'', ''Terminated'',
                                           ''Z'', ''Waiting'',
                              status_code ) "Status"
                    , hold_flag "Hold"
                    , request_date "Request Date"
                    , requested_start_date "Requested Start|Date"
                    , resubmitted "Resubmitted" 
                    , resubmit_interval "Resubmit|Interval" 
                    , resubmit_interval_unit_code "Resubmit Interval|Unit Code" 
                    , resubmit_time "Resubmit|Time" 
                    , completion_text "Completion Text" 
                 FROM fnd_concurrent_requests fcr, fnd_concurrent_programs fcp
                WHERE fcp.concurrent_program_name = '''||p_prog_name||'''
                  AND fcp.concurrent_program_id = fcr.concurrent_program_id
                  AND fcp.application_id= fcr.program_application_id';

    l_title := 'Concurrent Requests for '''||l_prog_user_name||'''';
    IF p_max_rows >0 THEN
        l_title := l_title || ' (max. latest ' || p_max_rows || ' requests)';
    END IF;
    IF p_limited_phase_code = 'RP' THEN
        g_text := g_text || ' AND fcr.phase_code in ( ''R'', ''P'' )';
        l_title := l_title || ' in phase running or pending' ;
    END IF;

    g_text := g_text || ' ORDER BY fcr.request_id DESC';

    RETURN( Run_SQL( l_title, g_text, 'N', p_max_rows, p_indent  ));

    EXCEPTION 
        WHEN OTHERS THEN
            -- This exception is not expected to occur
            Exception_ErrorPrint( l_proc, 'p_prog_name='||p_prog_name );
            RETURN -2;

END INV_Display_Conc_Proc_Info;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Get_Org_Info
-- DESCRIPTION:
--      Get OrgID and OrgName for given Org-Code ( e.g. M1 )
-- Input:
--      p_org_code ( Organization Short name MTL_PARAMETERS.ORGANIZATION_CODE )
--              e.g. "M1" in a vision installation
--              If null display active and inactive Access Definitions
--      p_display_message_flag ( 'Y' or 'N' )
--              If 'Y' messages are displayed
--              If 'N' no messages are displayed. The message handling must be
--                      done in the calling procedure.
--                      If OTHER-Exception is thrown, a message is ALWAYS echoed
-- Output:
--      p_org_id ( Organization Short name MTL_PARAMETERS.ORGANIZATION_CODE )
--              e.g. "M1" in a vision installation
--      p_org_name ( HR_ORGANIZATION_UNITS.NAME )
--      p_rc Return-Code:
--           Success:  0: row retrieved
--           Failure: -1: no rows retrieved: 
--                       No organization exists for given Organization Shortname
--                    -2: Unexpected Exception
------------------------------------------------------------------------------
procedure INV_Get_Org_Info( p_org_code IN mtl_parameters.organization_code%type,
                            p_display_message_flag IN varchar2 ,
                            p_org_id OUT hr_organization_units.organization_id%type,
                            p_org_name OUT hr_organization_units.name%type,
                            p_rc OUT number )  is
    l_proc VARCHAR2(30) := 'INV_Get_Org_Info';
begin -- INV_Get_Org_Info

    p_rc := 0;

    SELECT hou.organization_id, hou.name
      INTO p_org_id, p_org_name
      FROM hr_organization_units hou , mtl_parameters mp
     WHERE mp.organization_id = hou.organization_iD
       AND mp.organization_code = p_org_code;

    exception
        when NO_DATA_FOUND then
        -- Invalid ORG-Code
        p_rc := -1;
        if p_display_message_flag = 'Y' then
            g_text := 'The given Organization Short Name ' || p_org_code || ' is invalid';
            ErrorPrint( g_text );
            g_text := 'Please enter a valid Organization Short Name';
            ActionErrorPrint( g_text );
        end if;
        return ;

        when OTHERS then
        -- This exception is not expected to occur
        p_rc := -2;
        Exception_ErrorPrint( l_proc, 'p_org_code='||p_org_code );
        return ;

end INV_Get_Org_Info;

------------------------------------------------------------------------------
-- FUNCTION: Fmt_By_Cnt_Sub
-- DESCRIPTION: Perform the format string substitution base on p_count
-- Input: p_count: a record count
-- Input: p_text: the string to format
-- Input: p_entity: the name of the thing a count is being displayed for (optional)
-- Return: return the formatted string
--
-- Evaluate p_text where p_text is '<TEXT0|TEXT1|TEXT2>' or '<TEXT>'
-- where TEXT0 is text to display when p_count=0
-- where TEXT1 is text to display when p_count=1
-- where TEXT2 is text to display when p_count>1
-- where TEXT  is text to display.  In all cases:
-- if TEXT|TEXT0|TEXT1|TEXT2 is the exact string '[count]',
--                    p_count is substituted for '[count]'
-- if TEXT|TEXT0|TEXT1|TEXT2 is the exact string '[entity]',
--                    p_entity is substituted for '[entity]'
--
-- This is a helper function called by Fmt_By_Cnt(), call Fmt_By_Cnt() instead
--
------------------------------------------------------------------------------
FUNCTION Fmt_By_Cnt_Sub ( p_count IN NUMBER, 
                          p_text IN VARCHAR2, 
                          p_entity IN VARCHAR2 default NULL) 
RETURN VARCHAR2 IS
        p_none VARCHAR2(5000) := NULL;
        p_one VARCHAR2(5000) := NULL;
        p_many VARCHAR2(5000) := NULL;
        p_ind0 NUMBER := 0;
        p_ind1 NUMBER := 0;
        p_ind2 NUMBER := 0;
        p_ind3 NUMBER := 0;
        l_count NUMBER := 0;
        l_null_entity VARCHAR(50) := '<entity>';
        l_null_count VARCHAR(50) := '<undefined>';
BEGIN
        -- return if p_text is null
        if p_text is null then return NULL; end if;

        -- force l_count to 0 if p_count is undefined (NULL)
        l_count := p_count + 0;

        -- determine locations formatting characters
        p_ind0 := instr(p_text, '<', 1);
        p_ind1 := instr(p_text, '|', 1);
        p_ind2 := instr(p_text, '|', 1, 2);
        p_ind3 := instr(p_text, '>', 1);

        -- if '<' or '>' are missing, just return original string
        -- since these might be legitimate less/greater than symbols
        -- we cannot make this determination
        if p_ind0 = 0 or p_ind3 = 0 then return p_text; end if;

        -- determine the text to display when "p_count=0" 
        p_ind0 := p_ind0 + 1;
        p_none := substr(p_text,p_ind0,p_ind1-p_ind0);

        -- special case (shortcut) where p_text = '<[count]>' or p_text = '<[entity]>'
        --if p_ind1 = 0 or p_ind1 > p_ind3 then 
        if p_text = '<[count]>' then
            Tab3Print('SHORTCUT <[count]>' || '"' || p_text || '"');
            Tab3Print('<[count]> replaced with ' || replace(p_text,'<[count]>', (l_count||'')));
            return replace(p_text,'<[count]>', (l_count||''));
        end if;
        if p_text = '<[entity]>' then
            Tab3Print('SHORTCUT <[entity]>' || '"' || p_text || '"');
            return replace(p_text,'<[entity]>', nvl(p_entity,l_null_entity));
        end if;

        -- determine the text to display when "p_count=1" 
        p_ind1 := p_ind1 + 1;
        p_one := substr(p_text,p_ind1,p_ind2-p_ind1);

        -- determine the text to display when "p_count>=1"
        p_ind2:= p_ind2 + 1;
        p_many := substr(p_text,p_ind2,p_ind3-p_ind2);

        -- return appropriate value, replacing any '[count]' string with l_count
        -- negative values are handled since we are taking absolute value abs(count)
        if l_count = 0 then return replace(p_none,'[count]',(l_count||'')); end if;
        if abs(l_count) = 1 then return replace(p_one,'[count]',(l_count||'')); end if;
        if abs(l_count) > 1 then return replace(p_many,'[count]',(l_count||'')); end if;

        return p_text;

        EXCEPTION WHEN OTHERS THEN 
            --Tab0Print ('ERROR IN FMT_BY_SUB_CNT');
            RETURN null;

END Fmt_By_Cnt_Sub;

------------------------------------------------------------------------------
-- FUNCTION: Fmt_By_Cnt
-- DESCRIPTION: Format a string based on a record count
--
-- Input: p_count: a record count
-- Input: p_text: the string to format
-- Input: p_entity: the thing being counted
--
-- Return: return the formatted string
--
-- Evaluate p_text based on the count passed in p_count
-- where p_text is a string containing plain text and format tag(s)
-- and p_entity contains an optional name for the thing being counted
--
-- Note: A negative p_count value is allowed. In this case, the absolute 
--       value of p_count is used only to determine which <TEXT> to display 
--
-- A NULL values is returned if p_count, p_text is null or p_entity is null
-- and the exact string [entity] exists in p_text. A NULL value is also
-- return if any exception condition occurs
--
-- The Format string's syntax is:
--     '<TEXT0|TEXT1|TEXT2>' or '<TEXT>'
--        where TEXT0 is text to display when p_count=0
--        where TEXT1 is text to display when p_count=1
--        where TEXT2 is text to display when p_count>1
--        where TEXT  is text to display regardless of p_count's value
--In all cases:
--     if TEXT|TEXT0|TEXT1|TEXT2 is the exact string '[count]',
--           p_count is substituted for '[count]'
--     if TEXT|TEXT0|TEXT1|TEXT2 is the exact string '[entity]',
--           p_entity is substituted for '[entity]'
--
-- Examples:
--      Fmt_By_Cnt(0,'There <are|is|are> <no|[count]|[count]> subinventor<ies|y|ies> defined');
--      returns 'There are no subinventories defined'
--
--      Fmt_By_Cnt(1,'There <are|is|are> <no|[count]|[count]> subinventor<ies|y|ies> defined');
--      returns 'There is 1 subinventory defined'
--
--      Fmt_By_Cnt(2,'There <are|is|are> <no|[count]|[count]> subinventor<ies|y|ies> defined');
--      returns 'There are 2 subinventories defined'
--
--      Fmt_By_Cnt(25,'Subinventory Count=<[count]>');
--      returns 'Subinventory Count=25'
--
--      Fmt_By_Cnt(432,'There <are|is|are> <[count]> <[entity]><s||s> defined', 'Inventory Item');
--      returns 'There are 432 Inventory Items defined'
--
------------------------------------------------------------------------------
FUNCTION Fmt_By_Cnt ( p_count IN NUMBER, 
                      p_text IN VARCHAR2, 
                      p_entity IN VARCHAR2 default NULL) 
RETURN VARCHAR2 IS
        p_ind0 NUMBER;
        p_ind1 NUMBER;
        p_len NUMBER;
        p_newtext VARCHAR2(10000) := NULL;
        p_subtext VARCHAR2(10000) := NULL;
BEGIN
        if p_text is NULL or p_count is null then 
           return NULL; 
        end if;

        p_ind0 := instr(p_text, '<', 1);
        p_ind1 := instr(p_text, '>', 1);
        p_len := length(p_text);

        if (p_ind0 = 0 or p_ind1 = 0 or p_ind0 >= p_ind1) then 
            return p_text; 
        end if;

        if p_entity is null and instr(p_text,'[entity]') > 0 then
            return null;
        end if;

        p_newtext := substr(p_text, 1, p_ind0-1);
        p_subtext := Fmt_By_Cnt_Sub(p_count, substr(p_text,p_ind0,p_ind1-p_ind0+1), p_entity);
        if p_subtext is null then return null; end if;
        p_newtext := p_newtext || p_subtext;

        return (p_newtext || Fmt_By_Cnt(p_count, substr(p_text,p_ind1+1), p_entity));

        EXCEPTION WHEN OTHERS THEN RETURN null;

END Fmt_By_Cnt;
------------------------------------------------------------------------------
-- PROCEDURE: SectionPrintBig
-- DESCRIPTION: Display a Large Font Section Heading using a standard API call
--
-- Input: p_procedure: the current procedure/function name
-- Input: p_msg: additional message to display
--
-- Return: none
--
-- Examples:
--
--      SectionPrintBig('This is a Big Heading');
--          
------------------------------------------------------------------------------
procedure SectionPrintBig (p_title in VARCHAR2) is
    l_proc VARCHAR2(30) := 'SectionPrintBig';
    l_sql VARCHAR2(30) := 'select * from dual where 1=0';
begin
    run_sql(p_title,l_sql,'N');
    exception when others then Exception_ErrorPrint(l_proc);
end SectionPrintBig;
------------------------------------------------------------------------------
-- FUNCTION: INV_Display_SQL
-- DESCRIPTION: Inventory interface to the standard Display_SQL API
--
-- In addition to the standard parameters to the standard Display_SQL API
-- call (see CoreApiHtml.sql), the following can be passed.  This scheme
-- allows you to define a standard set of column data to display and then
-- alter what that query displays by providing an additional where clause
-- to restrict the dataset.
--
-- Input: n_table_alias: a table alias name to apply to the passed p_sql_statement
-- Input: n_where_clause: a where clause to apply to the passed p_sql_statement
--        This where clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: n_order_by: a order by clause to apply to the passed p_sql_statement
--        This order by clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: n_include_rownum: If true, wrap the sql statement in a select to generate
--        a 'Rownum' column in the first position as an index for the table output
--        i.e. select rownum, xyz.* ( <p_sql_statement> ) xyz;
--
-- Return: none
--
-- Examples:
--
--      
--  l_sql := 'select 
--           organization_id "Orgization Id"
--           ,inventory_item_id "Item Id"
--           from mtl_system_items';
--  l_cnt := INV_Display_SQL(
--      p_sql_statement => l_sql
--     ,table_alias => 'Item Data for Organization 207'
--     ,display_longs => 'N'
--     ,p_feedback => 'Y'
--     ,p_max_rows => 0
--     ,n_table_alias => 'MSIV'
--     ,n_where_clause => 'where MSIV."Organization Id" = 207'
--     ,n_order_by => 'MSIV."Item Id"'
--     ,n_include_rownum => true
--     );
-- 
--  Output:
--       Rownum   Organization Id   Item Id
--       1        207               234
--       2        207               256
--       ...
--          
------------------------------------------------------------------------------
function INV_Display_SQL (
                 p_sql_statement  varchar2
               , table_alias      varchar2
               , display_longs    varchar2 default 'Y'
               , p_feedback       varchar2 default 'Y'
               , p_max_rows       number   default null
               , p_current_exec   number   default 0
               , n_table_alias    varchar2 default null
               , n_where_clause   varchar2 default null
               , n_order_by       varchar2 default null
               , n_include_rownum boolean default false) return number is
    l_sql_statement VARCHAR2(32000);
    l_proc VARCHAR2(50) := 'INV_Display_SQL';
    dummy NUMBER;
begin

    if n_where_clause is not null then
        l_sql_statement := 'select * from (' ||
                            p_sql_statement ||
                            ') ' || 
                            n_table_alias || 
                            ' ' || 
                            n_where_clause || 
                            ' ' || 
                            n_order_by;
    else
        l_sql_statement := p_sql_statement;
    end if;

    if n_include_rownum = true then
        l_sql_statement := 'select rownum "Rownum",'
            || nvl(n_table_alias,'XYZ' ) 
            || '.* from (' 
            || l_sql_statement
            || ') ' 
            || nvl(n_table_alias,'XYZ');
    end if;

    dummy := Display_SQL ( 
                 p_sql_statement => l_sql_statement
               , p_table_alias => table_alias
               , display_longs => display_longs
               , p_feedback => p_feedback
               , p_max_rows => p_max_rows
               , p_current_exec => p_current_exec
               );
    return dummy;
    exception when others then
        Exception_ErrorPrint(l_proc);
        return 0;
end INV_Display_SQL;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Dep_Install_Status
-- DESCRIPTION: Display an HTML table of Inventory related products
--              These are those products that either Inventory depends on
--              and/or that depend on Invenotry
--
-- Return: none
--
-- Examples:
--
--      INV_Display_Dep_Install_Status;
--          
------------------------------------------------------------------------------
procedure INV_Display_Dep_Install_Status(p_application_id number default 401) is
    l_proc VARCHAR2(30) := 'INV_Display_Dep_Install_Status';
    l_sql  VARCHAR2(4000) := null;
    l_app_name fnd_application_vl.application_name%TYPE;
begin

    l_app_name := '';
    begin
        select application_name into l_app_name from fnd_application_vl
        where application_id = p_application_id and rownum = 1;
        l_app_name := trim(l_app_name) || ' ';
        exception when others then
            l_app_name := '';
    end;

    g_text := l_app_name || 'Related Product Installation Status' ;

    -- Returned products depend on each other to be installed (co-dependent)
    l_sql :=
       '(SELECT fa.application_name Application, fa.application_id "Id",
          ''Mutually Dependent'' "Dependency", fl.meaning status, fpi.patch_level
       FROM fnd_product_installations fpi, fnd_application_vl fa,
            fnd_lookup_values_vl fl, fnd_product_dependencies d
      WHERE fpi.application_id = fa.application_id
        and fl.lookup_type = ''FND_PRODUCT_STATUS''
        and nvl(fpi.status,''N'') = fl.lookup_code
        and fa.application_id = d.required_application_id
        and d.application_id = ' || p_application_id || 
      ' intersect
    SELECT fa.application_name Application,  fa.application_id "Id",
       ''Mutually Dependent'' "Dependency", fl.meaning status, fpi.patch_level
       FROM fnd_product_installations fpi, fnd_application_vl fa,
            fnd_lookup_values_vl fl, fnd_product_dependencies d
      WHERE fpi.application_id = fa.application_id
        and fl.lookup_type = ''FND_PRODUCT_STATUS''
        and nvl(fpi.status,''N'') = fl.lookup_code
        and fa.application_id = d.application_id
        and d.required_application_id = ' || p_application_id || ')';

     l_sql := l_sql || ' union ';

    -- Returend products need to be installed in order for Inventory to operate
    l_sql := l_sql || 
       '(SELECT fa.application_name Application,  fa.application_id "Id",
        ''Required By Inventory'' "Dependency", fl.meaning status, fpi.patch_level
       FROM fnd_product_installations fpi, fnd_application_vl fa,
            fnd_lookup_values_vl fl, fnd_product_dependencies d
      WHERE fpi.application_id = fa.application_id
        and fl.lookup_type = ''FND_PRODUCT_STATUS''
        and nvl(fpi.status,''N'') = fl.lookup_code
        and fa.application_id = d.required_application_id
        and d.application_id = ' || p_application_id || 
      ' minus
    SELECT fa.application_name Application,  fa.application_id "Id",
       ''Required By Inventory'' "Dependency", fl.meaning status, fpi.patch_level
       FROM fnd_product_installations fpi, fnd_application_vl fa,
            fnd_lookup_values_vl fl, fnd_product_dependencies d
      WHERE fpi.application_id = fa.application_id
        and fl.lookup_type = ''FND_PRODUCT_STATUS''
        and nvl(fpi.status,''N'') = fl.lookup_code
        and fa.application_id = d.application_id
        and d.required_application_id = ' || p_application_id || ')';


     l_sql := l_sql || ' union ';

    -- Returned products required Inventory to be installed
    l_sql := l_sql || 
      '(SELECT fa.application_name Application,  fa.application_id "Id",
        ''Inventory Is Required'' "Dependency", fl.meaning status, fpi.patch_level
       FROM fnd_product_installations fpi, fnd_application_vl fa,
            fnd_lookup_values_vl fl, fnd_product_dependencies d
      WHERE fpi.application_id = fa.application_id
        and fl.lookup_type = ''FND_PRODUCT_STATUS''
        and nvl(fpi.status,''N'') = fl.lookup_code
        and fa.application_id = d.application_id
        and d.required_application_id = ' || p_application_id ||
        ' minus
    SELECT fa.application_name Application,  fa.application_id "Id",
     ''Inventory Is Required'' "Dependency", fl.meaning status, fpi.patch_level
       FROM fnd_product_installations fpi, fnd_application_vl fa,
            fnd_lookup_values_vl fl, fnd_product_dependencies d
      WHERE fpi.application_id = fa.application_id
        and fl.lookup_type = ''FND_PRODUCT_STATUS''
        and nvl(fpi.status,''N'') = fl.lookup_code
        and fa.application_id = d.required_application_id
        and d.application_id = ' || p_application_id || ')' ;

    l_sql := l_sql || ' order by 1';

    run_sql(g_text, l_sql, 'N');

    exception when others then
        Exception_ErrorPrint(l_proc);
end INV_Display_Dep_Install_Status;
------------------------------------------------------------------------------
-- FUNCTION: Get_KFF_Name
-- DESCRIPTION: Return the KFF Name for the indicated flex code
--
-- Input: p_application_id: The application id for the flexfield
-- Input: p_id_flex_code: The flex field code (e.g. "MCAT")
--
-- Return: id_flex_name - the flexfield descriptive name
--
-- Examples:
--
--      l_name := Get_KFF_Name(401, 'MCAT');    -- returned value is 'Item Category'
--          
------------------------------------------------------------------------------
function Get_KFF_Name  (p_application_id in NUMBER, p_id_flex_code in VARCHAR2) return VARCHAR2 is
    l_proc VARCHAR2(30) := 'Get_KFF_Name';
    l_id_flex_name fnd_id_flexs.id_flex_name%TYPE;
begin
    l_id_flex_name := NULL;

    SELECT id_flex_name
      INTO l_id_flex_name
      FROM fnd_id_flexs
     WHERE id_flex_code = p_id_flex_code
       AND application_id = p_application_id;

    return l_id_flex_name;

    EXCEPTION WHEN OTHERS THEN
        Exception_ErrorPrint(l_proc, ' p_id_flex_code='||p_id_flex_code || ' / p_application_id=' || p_application_id );

end Get_KFF_Name;
------------------------------------------------------------------------------
-- PROCEDURE: Display_KFF_Header
-- DESCRIPTION: Display an HTML table showing the KFF registration information
--
-- Input: p_application_id: The application id for the flexfield
-- Input: p_id_flex_code: The flex field code (e.g. "MCAT")
--
-- Return: None
--
-- Examples:
--
--      Display_KFF_Header(401, 'MCAT');
--          
------------------------------------------------------------------------------
procedure Display_KFF_Header (p_application_id in NUMBER, p_id_flex_code in VARCHAR2) is
    l_proc VARCHAR2(30) := 'Display_KFF_Header';
    l_id_flex_name fnd_id_flexs.id_flex_name%TYPE;
begin
    g_text := 'SELECT  
                APPLICATION_ID "Application Id",
                id_flex_code "Id Flexfield Code", 
                id_flex_name "Id Flexfield Name",
                APPLICATION_TABLE_NAME "Application Table Name",
                DESCRIPTION "Description"
        FROM fnd_id_flexs f
        WHERE ID_FLEX_CODE = ' ||
        QUOTE || p_id_flex_code || QUOTE ||
        ' AND application_id = ' || p_application_id;

    l_id_flex_name := Get_KFF_Name(p_application_id, p_id_flex_code);

    Tab0Print('Registration Information');

    run_sql( NULL, g_text, 'N');
    
    EXCEPTION WHEN OTHERS THEN
        Exception_ErrorPrint(l_proc, ' p_id_flex_code='||p_id_flex_code || ' / p_application_id=' || p_application_id );
        Tab0Print( g_text ); 

end Display_KFF_Header;
------------------------------------------------------------------------------
-- PROCEDURE: Display_KFF_Structure
-- DESCRIPTION: Display an HTML table showing the KFF structures associated 
--              with p_id_flex_code and optionally, structure p_id_flex_num
--
-- Input: p_application_id: The application id for the flexfield
-- Input: p_id_flex_code: The flex field code (e.g. "MCAT")
-- Input: p_id_flex_num: The (optional) flex number for a structure (e.g. 101)
--
-- Return: None
--
-- Examples:
--
--      Display_KFF_Header(401, 'MCAT', 101);
--          
------------------------------------------------------------------------------
procedure Display_KFF_Structure (p_application_id in NUMBER, 
                                 p_id_flex_code in VARCHAR2, 
                                 p_id_flex_num in NUMBER default 0) is
    l_proc VARCHAR2(30) := 'Display_KFF_Structure';
    l_id_flex_name fnd_id_flexs.id_flex_name%TYPE;
    l_flexnum VARCHAR2(60) := '';
begin

    if p_id_flex_num is not null and p_id_flex_num > 0 then
        l_flexnum := ' AND f.id_flex_num = ' || p_id_flex_num;
    end if;

    g_text := '
        SELECT 
                f.APPLICATION_ID "Application Id",
                f.id_flex_code "Id Flexfield Code",
                f.id_flex_num "Id Flexfield Num",
                f.id_flex_structure_code "Id Flexfield|Structure Code",
                f.LAST_UPDATE_DATE "Last Update Date",
                f.LAST_UPDATED_BY "Last Updated By",
                f.concatenated_segment_delimiter "Concatenated Segment|Delimiter",
                f.cross_segment_validation_flag "Cross Segment|Validation Flag",
                f.dynamic_inserts_allowed_flag "Dynamic Inserts|Allowed Flag",
                f.ENABLED_FLAG "Enabled Flag",
                f.freeze_flex_definition_flag "Freeze Flexfield|Definition Flag",
                f.FREEZE_STRUCTURED_HIER_FLAG "Freeze Structured Hier Flag",
                f.SHORTHAND_ENABLED_FLAG "Shorthand Enabled Flag",
                f.SHORTHAND_LENGTH "Shorthand Length",
                f.id_flex_structure_name "Id Flexfield Structure Name",
                f.DESCRIPTION "Description"
        FROM 
                fnd_id_flex_structures_vl f
        WHERE  f.ID_FLEX_CODE = ' || QUOTE || p_id_flex_code || QUOTE || 
                ' AND f.application_id = ' || p_application_id || l_flexnum ||
                ' ORDER BY f.id_flex_num';

    l_id_flex_name := Get_KFF_Name(p_application_id, p_id_flex_code);

    Tab0Print('Structures');

    Run_Sql( NULL , g_text, 'N');

    EXCEPTION WHEN OTHERS THEN
        Exception_ErrorPrint(l_proc, ' p_id_flex_code='||p_id_flex_code || ' / p_application_id=' || p_application_id );
        Tab0Print( g_text ); 

end Display_KFF_Structure;
------------------------------------------------------------------------------
-- PROCEDURE: Display_KFF_Segments
-- DESCRIPTION: Display an HTML table showing the KFF segments and value set 
--              associated with p_id_flex_code and optionally, structure p_id_flex_num
--
-- Input: p_application_id: The application id for the flexfield
-- Input: p_id_flex_code: The flex field code (e.g. "MCAT")
-- Input: p_id_flex_num: The (optional) flex number for a structure (e.g. 101)
--
-- Return: None
--
-- Examples:
--
--      Display_KFF_Segment(401, 'MCAT');
--          
------------------------------------------------------------------------------
procedure Display_KFF_Segment (p_application_id in NUMBER, p_id_flex_code in VARCHAR2, p_id_flex_num NUMBER) is
    l_proc VARCHAR2(30) := 'Display_KFF_Segment';
    l_flexnum_clause VARCHAR2(80);
    l_id_flex_name fnd_id_flexs.id_flex_name%TYPE;
    --QUOTE constant varchar2(1) :=  chr(39);   -- single quote
begin

    if p_id_flex_num is null or p_id_flex_num = 0 then
       l_flexnum_clause := '';
    else
       l_flexnum_clause := ' s.id_flex_num = ' || p_id_flex_num || ' and ';
    end if;

    g_text := '
            SELECT 
              --s.RUNTIME_PROPERTY_FUNCTION,
              s.APPLICATION_ID "Application Id",
              s.id_flex_code "Id Flexfield Code",
              s.id_flex_num "Id Flexfield Num",
              s.APPLICATION_COLUMN_NAME "Applicaton Column Name",
              s.SEGMENT_NAME "Segment Name",
              s.LAST_UPDATE_DATE "Last Update Date",
              decode(nvl(u1.user_name,''?''),''?'',to_char(s.last_updated_by), 
                    (u1.user_name || '' ('' || s.LAST_UPDATED_BY || '')'')) "Last Updated By",
              s.SEGMENT_NUM "Segment Num",
              s.APPLICATION_COLUMN_INDEX_FLAG "Application Column Index Flag",
              s.ENABLED_FLAG "Enabled Flag",
              s.REQUIRED_FLAG "Required Flag",
              s.DISPLAY_FLAG "Display Flag",
              s.DISPLAY_SIZE "Display Size",
              s.SECURITY_ENABLED_FLAG "Security Enabled Flag",
              s.MAXIMUM_DESCRIPTION_LEN "Maximum Description Len",
              s.CONCATENATION_DESCRIPTION_LEN "Concatenation Description Len",
              s.flex_value_set_id "Flexfield Value Set Id",
              s.RANGE_CODE "Range Code",
              s.DEFAULT_TYPE "Default Type",
              s.DEFAULT_VALUE "Default Value",
              s.FORM_LEFT_PROMPT "Form Left Prompt",
              s.FORM_ABOVE_PROMPT "Form Above Prompt",
              s.DESCRIPTION "Description",
              ''Value Set->'',
              vs.flex_value_set_name "Flexfield Value Set Name",
              vs.LAST_UPDATE_DATE "Last Update Date",
              decode(nvl(u2.user_name,''?''),''?'',to_char(vs.last_updated_by), 
                    (u2.user_name || '' ('' || vs.LAST_UPDATED_BY || '')'')) "Last Updated By",
              vs.VALIDATION_TYPE "Validation Type",
              l.MEANING "Validation Type Meaning",
              vs.PROTECTED_FLAG "Protected Flag",
              vs.SECURITY_ENABLED_FLAG "Security Enabled Flag",
              vs.LONGLIST_FLAG "Longlist Flag",
              vs.FORMAT_TYPE "Format Type",
              lf.MEANING "Format Type Meaning",
              vs.MAXIMUM_SIZE "Maximum Size",
              vs.ALPHANUMERIC_ALLOWED_FLAG "Alphanumeric Allowed Flag",
              vs.UPPERCASE_ONLY_FLAG "Uppercase Only Flag",
              vs.NUMERIC_MODE_ENABLED_FLAG "Numeric Mode Enabled Flag",
              vs.DESCRIPTION "Description",
              vs.DEPENDANT_DEFAULT_VALUE "Dependant Default Value",
              vs.DEPENDANT_DEFAULT_MEANING "Dependant Default Meaning",
              vs.PARENT_FLEX_VALUE_SET_ID "Parent Flexfield Value Set Id",
              vs.MINIMUM_VALUE "Minumum Value",
              vs.MAXIMUM_VALUE "Maximum Value",
              vs.NUMBER_PRECISION "Number Precision"
            FROM 
              fnd_id_flex_segments_vl s,
              fnd_flex_value_sets vs,
              fnd_lookups l,
              fnd_lookups lf,
              fnd_user u1,
              fnd_user u2
            WHERE 
              s.flex_value_set_id = vs.flex_value_set_id(+)  and
              ''SEG_VAL_TYPES'' = l.lookup_type(+) and
              ''FIELD_TYPE'' = lf.lookup_type(+) and
              vs.validation_type = l.lookup_code(+) and
              vs.format_type = lf.lookup_code(+) and ' || 
              l_flexnum_clause ||
              ' s.last_updated_by = u1.user_id(+) and
                 vs.last_updated_by = u2.user_id(+) ' ||
        ' and s.ID_FLEX_CODE = ' || QUOTE || p_id_flex_code || QUOTE || ' AND s.application_id = ' || p_application_id ||
                 ' ORDER BY s.id_flex_num, s.segment_num';

    l_id_flex_name := Get_KFF_Name(p_application_id, p_id_flex_code);

    Tab0Print('Segment and Value Sets');

    Run_Sql( NULL, g_text, 'N');
    
    EXCEPTION WHEN OTHERS THEN
        Exception_ErrorPrint(l_proc, ' p_id_flex_code='||p_id_flex_code || ' / p_application_id=' || p_application_id || ' / p_id_flex_num='||p_id_flex_num);
        Tab0Print( g_text ); 

end Display_KFF_Segment;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_KFF
-- DESCRIPTION: Display Key Flexfield information for the specified application_id/flex code
--
-- Input: p_application_id: application_id associated with the KFF
-- Input: p_id_flex_code: the flexfield code (e.g. MCAT)
--
-- Return: None
------------------------------------------------------------------------------
procedure INV_Display_KFF(p_application_id number, p_id_flex_code VARCHAR2) Is
    l_proc VARCHAR2(30) := 'INV_Display_KFF';
    l_id_flex_name fnd_id_flexs.id_flex_name%TYPE;
begin

    l_id_flex_name := initcap(replace(Get_KFF_Name(p_application_id, p_id_flex_code),'_',' '));
    SectionPrintBig(l_id_flex_name || ' Key Flexfield Definition' );
    BRPrint;
    DIsplay_KFF_Header(p_application_id, p_id_flex_code);
    BRPrint;
    DIsplay_KFF_Structure(p_application_id, p_id_flex_code);
    BRPrint;
    DIsplay_KFF_Segment(p_application_id, p_id_flex_code,0);
    BRPrint;
    
    EXCEPTION WHEN OTHERS THEN
        Exception_ErrorPrint(l_proc, ' p_id_flex_code='||p_id_flex_code || ' / p_application_id=' || p_application_id );
end INV_Display_KFF;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_KFF
-- DESCRIPTION: Display Key Flexfield information for all KFF associated with 
--              the specified application_id
--
-- Input: p_application_id: application_id  
--
-- Return: None
------------------------------------------------------------------------------
procedure INV_Display_KFF(p_application_id number) Is
    l_proc VARCHAR2(30) := 'INV_Display_KFF';
    cursor c_KFF ( p_application_id number) is
        SELECT ID_FLEX_CODE FROM fnd_id_flexs WHERE application_id = p_application_id order by id_flex_code;
    r_kff c_KFF%ROWTYPE;
begin
    for r_kff in c_KFF(p_application_id) LOOP
        INV_Display_KFF(p_application_id, r_kff.id_flex_code);
    end loop;
    EXCEPTION WHEN OTHERS THEN
        Exception_ErrorPrint(l_proc);
end INV_Display_KFF;
------------------------------------------------------------------------------
-- PROCEDURE: Flex_ErrorPrint
-- DESCRIPTION: Display a flex error message
--
-- Input: p_tf: display p_successmsg if false of p_failmsg/p_actionmsg if true
-- Input: p_entity_description_1: Primary entity the message is displayed for
-- Input: p_value_1: Value of p_entity_description_1
-- Input: p_entity_description_1: Secondary entity the message is displayed for
-- Input: p_value_2: Value of p_entity_description_2
-- Input: p_failmsg: Error/Warn/Notice to display on failure
-- Input: p_actionmsg: Action Message to display on failure
-- Input: p_successmsg: Message to display on success (none displayed if null)
-- Input: p_type: type of message (E=Error (default), W=Warn, N=Notice)
--
-- Return: None
--
-- Examples:
--
--        Flex_ErrorPrint((nvl(l_rec.dynamic_inserts_allowed_flag,'N') != 'N'), 
--                         'structure', l_sn, 'flexfield',  l_fn, 
--            'must not allow dynamic inserts', 
--            'Uncheck this option and recompile',
--            'does not allow dynamic inserts',
--            'E');
--
-- Output: if l_rec.dynamic_inserts_allowed_flag = 'Y'
--        ERROR - The structure "INV.Items" for the flexfield "Item Categories" must not allow dynamic inserts'
--        ACTION - Uncheck this option and recompile
-- Output: if l_rec.dynamic_inserts_allowed_flag = 'N'
--        The structure "INV.Items" for the flexfield "Item Categories" does not allow dynamic inserts'
--          
--          
------------------------------------------------------------------------------
procedure Flex_ErrorPrint(
            p_tf BOOLEAN, 
            p_entity_description_1 VARCHAR2,
            p_entity_value_1 in VARCHAR2, 
            p_entity_description_2 in VARCHAR2, 
            p_entity_value_2 in VARCHAR2, 
            p_failmsg in VARCHAR2, 
            p_actionmsg in VARCHAR2, 
            p_successmsg in VARCHAR2 default null,
            p_type in CHAR default 'E'  -- E=Error, W=Warn, N=Notice
) is
    l_proc VARCHAR2(30) := 'Flex_ErrorPrint';
    l_msg VARCHAR(800) := NULL;
begin

    l_msg := 'The ';
    if (p_entity_description_1 is not null) then
        l_msg := l_msg || p_entity_description_1 || ' "' || p_entity_value_1 || '"'; 
    end if;
    if (p_entity_description_2 is not null) then
        if (p_entity_description_1 is not null) then
            l_msg := l_msg || ' for the ';
        end if;
        l_msg := l_msg || p_entity_description_2 || ' "' || p_entity_value_2 || '"'; 
    end if;
    if p_tf = TRUE then
        if p_type = 'W' then
            WarningPrint(l_msg || ' ' || p_failmsg);
            ActionWarningPrint(p_actionmsg);
        elsif p_type = 'N' then
            NoticePrint(l_msg || ' ' || p_failmsg);
        else
            ErrorPrint(l_msg || ' ' || p_failmsg);
            ActionErrorPrint(p_actionmsg);
        end if;
    elsif p_successmsg is not null then
        -- NoticePrint( l_msg || ' ' || p_successmsg);
        l_proc := l_proc; -- NOOP
    end if;
    exception when others then Exception_ErrorPrint(l_proc);
end Flex_ErrorPrint;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Validate_MKTS_KFF
-- DESCRIPTION: Validate and Display Sales Order Key Flexfield
--
--      o Display HTML table of registration data (header)
--      o Display HTML table of structure data 
--      o Display HTML table of segments/value set data
--
--    Validation:
--      o Display Error msg if not enabled
--      o Display Error msg if not frozen
--      o Display Error msg if dynamic inserts not allowed
--      o Display Error msg if segments are not SEGMENT1, SEGMENT2, and SEGMENT3
--      o Display Error msg if segment 1 is not named "Order Number"
--      o Display Error msg if segment 2 is not named "Order Type"
--      o Display Error msg if segment 2 is not named "Order Source"
--      o Display Attention msg any validation type is other than "None"
--      o Display Attention msg any required flag is not 'Y'
--      o Display Error msg if the Right-justify and Zero-fill Numbers flag is set
--      o Display Error msg if the maximum size of segment > 40
--      o Display Attention msg if the format type for "SEGMENT1" is not "Number" and the "Numeric Only" checkbox is not set.
--      o Display Attention msg if the format type for "SEGMENT2" and "SEGMENT3" is not "Char" or the "Numeric Only" checkbox is set.
--
-- Return: None
--
-- Examples:
--
--        INV_Validate_MKTS_KFF;
--          
------------------------------------------------------------------------------
procedure INV_Validate_MKTS_KFF is
    l_proc VARCHAR2(30) := 'INV_Validate_MKTS_KFF';
    l_application_id NUMBER := 401;
    l_id_flex_code fnd_id_flexs.id_flex_code%TYPE := 'MKTS';
    l_sn fnd_id_flex_structures_vl.id_flex_structure_code%TYPE;
    l_rec c_KFF_struct%ROWTYPE;
    l_seg c_KFF_seg%ROWTYPE;
    l_cnt NUMBER;
    l_fn fnd_id_flexs.id_flex_name%TYPE;
    l_segn fnd_id_flex_segments_vl.segment_name%TYPE;
begin

    l_fn := Get_KFF_Name(l_application_id, l_id_flex_code);

    INV_Display_KFF(l_application_id, l_id_flex_code);

    for l_rec in c_KFF_struct(l_application_id, l_id_flex_code, NULL) LOOP

        l_sn := l_rec.id_flex_structure_code;

        Flex_ErrorPrint((nvl(l_rec.enabled_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must be enabled', 
            g_kff_action_msg, 
            'is enabled');
        Flex_ErrorPrint((nvl(l_rec.freeze_flex_definition_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must be frozen', 
            g_kff_action_msg, 
            'is frozen');
        Flex_ErrorPrint((nvl(l_rec.dynamic_inserts_allowed_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must allow dynamic inserts', 
            g_kff_action_msg, 
            'allows dynamic inserts');

        l_cnt := 0;
        for l_seg in c_KFF_seg(l_application_id, l_id_flex_code, l_rec.id_flex_num) LOOP

            l_cnt := l_cnt + 1;
            l_segn := l_seg.segment_name;
            if l_cnt = 1 then
                Flex_ErrorPrint((l_seg.application_column_name != 'SEGMENT1'), 'segment', l_segn, 'structure',  l_sn, 
                    'should use "SEGMENT1" as the first segment', 
                    g_kff_action_msg, 
                    'uses "SEGMENT1" as the first segment');
                Flex_ErrorPrint((l_segn != 'Order Number'), 'segment', l_segn, 'structure',  l_sn, 
                    'should be named "Order Number"', 
                    g_kff_action_msg, 
                    'is named "Order Number"');
            elsif l_cnt = 2 then
                Flex_ErrorPrint((l_seg.application_column_name != 'SEGMENT2'), 'segment', l_segn, 'structure',  l_sn, 
                    'should use "SEGMENT2" as the second segment', 
                    g_kff_action_msg, 
                    'uses "SEGMENT2" as the second segment');
                Flex_ErrorPrint((l_segn != 'Order Type'), 'segment', l_segn, 'structure',  l_sn, 
                    'should be named "Order Type"', 
                    g_kff_action_msg, 
                    'is named "Order Type"');
            elsif l_cnt = 3 then
                Flex_ErrorPrint((l_seg.application_column_name != 'SEGMENT3'), 'segment', l_segn, 'structure',  l_sn, 
                    'should use "SEGMENT3" as the third segment', 
                    g_kff_action_msg, 
                    'uses "SEGMENT3" as the third segment');
                Flex_ErrorPrint((l_segn != 'Order Source'), 'segment', l_segn, 'structure',  l_sn, 
                    'should be named "Order Source"', 
                    g_kff_action_msg, 
                    'is named "Order Source"');
            end if;
            Flex_ErrorPrint((nvl(l_seg.vs_validation_type,'N') != 'N'), 'segment', l_segn, 'structure',  l_sn, 
                'has a validaton type of "' || l_seg.vs_validation_type_meaning || 
                    '". Although this validation type can be used, Oracle recommends a validation type of "None"', 
                g_kff_action_msg, 
                'has a validation type of "None"',
                p_type=>'N');
            Flex_ErrorPrint((nvl(l_seg.required_flag,'N') != 'Y'), 'segment', l_segn, 'structure',  l_sn, 
                'should be defined as required to improve performance', 
                g_kff_action_msg, 
                'is defined as required',
                p_type=>'N');
            Flex_ErrorPrint((nvl(l_seg.vs_numeric_mode_enabled_flag,'N') = 'Y'), 'segment', l_segn, 'structure',  l_sn,
                'should not use the Right-justify and Zero-fill Numbers flag',
                g_kff_action_msg, 
                'does not use the Right-justify and Zero-fill Numbers flag');
            Flex_ErrorPrint((nvl(l_seg.vs_maximum_size,0) > 40 ), 'segment', l_segn, 'structure',  l_sn,
                'must have a maximum size <= 40 ',
                g_kff_action_msg, 
                'has a size of ' || nvl(l_seg.vs_maximum_size,40));
            if ( l_seg.application_column_name = 'SEGMENT1' ) then
                Flex_ErrorPrint((nvl(l_seg.vs_format_type,'C') != 'N' or nvl(l_seg.vs_alphanumeric_allowed_flag,'Y') != 'N'), 
                'segment', l_segn, 'structure',  l_sn,
                'has a format type of "' || nvl(l_seg.vs_format_type_meaning,'"Character"') || '" and an alphanumeric_allowed_flag of "' || 
                nvl(l_seg.vs_alphanumeric_allowed_flag,'Y') || 
                  '".<BR>If Order Management is being used, Oracle recommends that the format type for this segment be "Number" and the "Numeric Only" checkbox be set',
                g_kff_action_msg, 
                'is alphanumeric',
                p_type=>'N');
            end if;    
            if ( l_seg.application_column_name = 'SEGMENT2' or l_seg.application_column_name = 'SEGMENT3' ) then
                Flex_ErrorPrint((nvl(l_seg.vs_format_type,'C') != 'C' or nvl(l_seg.vs_alphanumeric_allowed_flag,'Y') != 'Y'), 
                'segment', l_segn, 'structure',  l_sn,
                'has a format type of "' || l_seg.vs_format_type_meaning || '" and an alphanumeric_allowed_flag of "' || 
                l_seg.vs_alphanumeric_allowed_flag || 
                  '". If Oracle Management is being used, Oracle recommends that the format type for this segment be "Char" and the "Numeric Only" checkbox be unset',
                g_kff_action_msg, 
                'is alphanumeric',
                p_type=>'N');
            end if;    

        end loop;

    end loop;

    exception when others then
        Exception_ErrorPrint(l_proc);
end INV_Validate_MKTS_KFF;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Validate_MCAT_KFF
-- DESCRIPTION: Validate and Display Item Categories Key Flexfield
--
--      o Display HTML table of registration data (header)
--      o Display HTML table of structure data 
--      o Display HTML table of segments/value set data
--
--    Validation:
--      o Display Warning msg if not enabled
--      o Display Warning msg if not frozen
--
-- Return: None
--
-- Examples:
--
--        INV_Validate_MCAT_KFF;
--
------------------------------------------------------------------------------
procedure INV_Validate_MCAT_KFF(p_id_flex_num in NUMBER default 0) is
    l_proc VARCHAR2(30) := 'INV_Validate_MCAT_KFF';
    l_application_id NUMBER := 401;
    l_id_flex_code fnd_id_flexs.id_flex_code%TYPE := 'MCAT';
    l_sn fnd_id_flex_structures_vl.id_flex_structure_code%TYPE;
    l_rec c_KFF_struct%ROWTYPE;
    l_seg c_KFF_seg%ROWTYPE;
    l_cnt NUMBER;
    l_fn fnd_id_flexs.id_flex_name%TYPE;
    l_segn fnd_id_flex_segments_vl.segment_name%TYPE;

    -- Selects the category sets and structure associated with each functional area
    -- The lookup code's HAVE to be hard coded to associate with the application because 
    -- there is no other way to determine which application the functional area
    -- belongs to.  This methodology was extracted from existing PLS application code.
    cursor c_cs ( p_structure_id mtl_category_sets.structure_id%TYPE) is
            SELECT distinct
               nvl(mc.category_set_name,  'None') "Category Set Name",
               mc.category_set_id "Category Set Id",
               mdc.category_set_id "Default Category Set Id",
               mc.structure_id "Structure Id",
               lup.meaning "Functional Area",
               nvl(mdc.functional_area_id,-1)  "Functional Area Id",
               fa.application_short_name "Application Short Name",
               fat.application_name "Application Name",
               fa.application_id "Application Id",
               decode( nvl(fl.meaning,'?'), 
                        '?', fi.status,  
                        fl.meaning || ' (' || fi.status || ')'
                     ) "Status"
             FROM 
               mtl_default_category_sets mdc ,
               mfg_lookups lup,
               fnd_lookups fl,
               fnd_product_installations fi,
               fnd_application_vl fat,
               fnd_application fa,
               mtl_category_sets mc
             WHERE 
               mdc.category_set_id = mc.category_set_id(+)  AND
               lup.lookup_type = 'MTL_FUNCTIONAL_AREAS' AND
               'FND_PRODUCT_STATUS' = fl.lookup_type(+)  AND
               fi.status = fl.lookup_code(+) AND
               mdc.functional_area_id(+) = lup.lookup_code AND
               fa.application_id = fat.application_id AND
               fa.application_id = fi.application_id AND
                (   ( lup.lookup_code = 1 and fa.application_short_name = 'INV' )
                 or ( lup.lookup_code = 2 and fa.application_short_name = 'PO' )
                 or ( lup.lookup_code = 3 and fa.application_short_name = 'MRP' )
                 or ( lup.lookup_code = 4 and fa.application_short_name = 'CS' )
                 or ( lup.lookup_code = 5 and fa.application_short_name = 'BOM' )
                 or ( lup.lookup_code = 6 and fa.application_short_name = 'ENG' )
                 or ( lup.lookup_code = 7 and fa.application_short_name = 'ONT' )
                 or ( lup.lookup_code = 8 and fa.application_short_name = 'WIP' )
                 or ( lup.lookup_code = 9 and fa.application_short_name = 'OFA' )
                 or ( lup.lookup_code = 10 and fa.application_short_name = 'OKS' )
                )
               and fi.status in ( 'I', 'S' )
               and mc.structure_id = p_structure_id;

    r_cs c_cs %ROWTYPE;
    l_flexmsg VARCHAR2(40) := '';

begin

    l_fn := Get_KFF_Name(l_application_id, l_id_flex_code);
    if nvl(p_id_flex_num,0) > 0 then
        l_flexmsg := ' (Id Flex Num=' || p_id_flex_num || ')'; 
    end if;

    INV_Display_KFF(l_application_id, l_id_flex_code);

    for l_rec in c_KFF_struct(l_application_id, l_id_flex_code, p_id_flex_num) LOOP

        l_sn := l_rec.id_flex_structure_code;

        for r_cs in c_cs(l_rec.id_flex_num) LOOP
            Flex_ErrorPrint((nvl(l_rec.enabled_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
                'is defined as the structure for the category set "' ||
                    r_cs."Category Set Name" ||
                    '" for the installed product "' || 
                    r_cs."Application Name" || '" but is not enabled. This may cause errors ' ||
                    'when adding items that are configured for this product', 
                'Enable the "' || l_sn || '" flexfield structure to prevent such errors',
                'is enabled',
                p_type => 'W'
                );
            Flex_ErrorPrint((nvl(l_rec.freeze_flex_definition_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
                'is defined as the structure for the category set "' ||
                    r_cs."Category Set Name" ||
                    '" for the installed product "' || 
                    r_cs."Application Name" || '" but is not frozen. This may cause errors ' ||
                    'when adding items that are configured for this product', 
                'Freeze and compile the "' || l_sn || '" flexfield structure to prevent such errors',
                'is frozen',
                p_type => 'W'
                );
            exit;
        end loop;

        l_cnt := 0;
        for l_seg in c_KFF_seg(l_application_id, l_id_flex_code, l_rec.id_flex_num) LOOP

            l_cnt := l_cnt + 1;
            l_segn := l_seg.segment_name;

        end loop;

    end loop;

    exception when others then
        Exception_ErrorPrint(l_proc);
end INV_Validate_MCAT_KFF;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Validate_MDSP_KFF
-- DESCRIPTION: Validate and Display Account Alias Key Flexfield
--
--      o Display HTML table of registration data (header)
--      o Display HTML table of structure data 
--      o Display HTML table of segments/value set data
--
--    Validation:
--      o Display Error msg if not enabled
--      o Display Error msg if not frozen
--      o Display Error msg if dynamic inserts are allowed
--
-- Return: None
--
-- Examples:
--
--        INV_Validate_MDSP_KFF;
--
------------------------------------------------------------------------------
procedure INV_Validate_MDSP_KFF is
    l_proc VARCHAR2(30) := 'INV_Validate_MDSP_KFF';
    l_application_id NUMBER := 401;
    l_id_flex_code fnd_id_flexs.id_flex_code%TYPE := 'MDSP';
    l_sn fnd_id_flex_structures_vl.id_flex_structure_code%TYPE;
    l_rec c_KFF_struct%ROWTYPE;
    l_seg c_KFF_seg%ROWTYPE;
    l_cnt NUMBER;
    l_fn fnd_id_flexs.id_flex_name%TYPE;
    l_segn fnd_id_flex_segments_vl.segment_name%TYPE;
begin

    l_fn := Get_KFF_Name(l_application_id, l_id_flex_code);

    INV_Display_KFF(l_application_id, l_id_flex_code);

    for l_rec in c_KFF_struct(l_application_id, l_id_flex_code, NULL) LOOP

        l_sn := l_rec.id_flex_structure_code;

        Flex_ErrorPrint((nvl(l_rec.enabled_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must be enabled', 
            g_kff_action_msg,
            'is enabled');
        Flex_ErrorPrint((nvl(l_rec.freeze_flex_definition_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must be frozen', 
            g_kff_action_msg,
            'is frozen');
        Flex_ErrorPrint((nvl(l_rec.dynamic_inserts_allowed_flag,'N') != 'N'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must not allow dynamic inserts', 
            g_kff_action_msg,
            'does not allow dynamic inserts');

        l_cnt := 0;
        for l_seg in c_KFF_seg (l_application_id, l_id_flex_code, l_rec.id_flex_num) LOOP

            l_cnt := l_cnt + 1;
            l_segn := l_seg.segment_name;

        end loop;

    end loop;

    exception when others then
        Exception_ErrorPrint(l_proc);
end INV_Validate_MDSP_KFF;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Validate_MTLL_KFF
-- DESCRIPTION: Validate and Display Stock Locators Key Flexfield
--
--      o Display HTML table of registration data (header)
--      o Display HTML table of structure data 
--      o Display HTML table of segments/value set data
--
--    Validation:
--      o Display Error msg if not enabled
--      o Display Error msg if not frozen
--
-- Return: None
--
-- Examples:
--
--        INV_Validate_MTLL_KFF;
--
------------------------------------------------------------------------------
procedure INV_Validate_MTLL_KFF is
    l_proc VARCHAR2(30) := 'INV_Validate_MTLL_KFF';
    l_application_id NUMBER := 401;
    l_id_flex_code fnd_id_flexs.id_flex_code%TYPE := 'MTLL';
    l_sn fnd_id_flex_structures_vl.id_flex_structure_code%TYPE;
    l_rec c_KFF_struct%ROWTYPE;
    l_seg c_KFF_seg%ROWTYPE;
    l_cnt NUMBER;
    l_fn fnd_id_flexs.id_flex_name%TYPE;
    l_segn fnd_id_flex_segments_vl.segment_name%TYPE;
    --l_kff_action_msg VARCHAR2(400) := 'Refer to the Appendex B in the Inventory Users Guide and the Oracle ' ||
                --'Applications Flexfields Guide for additional information on Key Flexfield setup and usage';
begin

    l_fn := Get_KFF_Name(l_application_id, l_id_flex_code);
    INV_Display_KFF(l_application_id, l_id_flex_code);

    for l_rec in c_KFF_struct(l_application_id,l_id_flex_code, NULL) LOOP

        l_sn := l_rec.id_flex_structure_code;

        Flex_ErrorPrint((nvl(l_rec.enabled_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must be enabled', 
            g_kff_action_msg,
            'is enabled');
        Flex_ErrorPrint((nvl(l_rec.freeze_flex_definition_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must be frozen', 
            g_kff_action_msg,
            'is frozen');
        l_cnt := 0;
        for l_seg in c_KFF_seg(l_application_id,l_id_flex_code,l_rec.id_flex_num) LOOP

            l_cnt := l_cnt + 1;
            l_segn := l_seg.segment_name;

        end loop;

    end loop;

    exception when others then
        Exception_ErrorPrint(l_proc);
end INV_Validate_MTLL_KFF;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Validate_MSTK_KFF
-- DESCRIPTION: Validate and System Items Alias Key Flexfield
--
--      o Display HTML table of registration data (header)
--      o Display HTML table of structure data 
--      o Display HTML table of segments/value set data
--
--    Validation:
--      o Display Error msg if not enabled
--      o Display Error msg if not frozen
--      o Display Error msg if dynamic inserts are allowed
--
-- Return: None
--
-- Examples:
--
--        INV_Validate_MSTK_KFF;
--
------------------------------------------------------------------------------
procedure INV_Validate_MSTK_KFF is
    l_proc VARCHAR2(30) := 'INV_Validate_MSTK_KFF';
    l_application_id NUMBER := 401;
    l_id_flex_code fnd_id_flexs.id_flex_code%TYPE := 'MSTK';
    l_sn fnd_id_flex_structures_vl.id_flex_structure_code%TYPE;
    l_rec c_KFF_struct%ROWTYPE;
    l_seg c_KFF_seg%ROWTYPE;
    l_cnt NUMBER;
    l_fn fnd_id_flexs.id_flex_name%TYPE;
    l_segn fnd_id_flex_segments_vl.segment_name%TYPE;
    --l_kff_action_msg VARCHAR2(400) := 'Refer to the Appendex B in the Inventory Users Guide and the Oracle ' ||
                --'Applications Flexfields Guide for additional information on Key Flexfield setup and usage';
begin

    l_fn := Get_KFF_Name(l_application_id, l_id_flex_code);
    INV_Display_KFF(l_application_id, l_id_flex_code);

    for l_rec in c_KFF_struct(l_application_id, l_id_flex_code, NULL) LOOP

        l_sn := l_rec.id_flex_structure_code;

        Flex_ErrorPrint((nvl(l_rec.enabled_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must be enabled', 
            g_kff_action_msg,
            'is enabled');
        Flex_ErrorPrint((nvl(l_rec.freeze_flex_definition_flag,'N') != 'Y'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must be frozen', 
            g_kff_action_msg,
            'is frozen');
        Flex_ErrorPrint((nvl(l_rec.dynamic_inserts_allowed_flag,'N') != 'N'), 'structure', l_sn, 'flexfield',  l_fn, 
            'must not allow dynamic inserts', 
            g_kff_action_msg,
            'does not allow dynamic inserts');

        l_cnt := 0;
        for l_seg in c_KFF_seg(l_application_id, l_id_flex_code,l_rec.id_flex_num) LOOP

            l_cnt := l_cnt + 1;
            l_segn := l_seg.segment_name;

        end loop;

    end loop;

    exception when others then
        Exception_ErrorPrint(l_proc);
end INV_Validate_MSTK_KFF;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Interface_Managers
-- DESCRIPTION: Display Information about the Inventory controlled Interface Managers
--
-- Return: None
--
-- Examples:
--
--        INV_Display_Interface_Managers;
--
------------------------------------------------------------------------------
procedure INV_Display_Interface_Managers is
    l_proc VARCHAR2(30) := 'Display_Interface_Managers';
    l_sql  VARCHAR2(1000) := null;
begin
    g_text := 'Interface Managers' ;

    l_sql :=
    '(SELECT 
    distinct  p.concurrent_program_name "Program Name",
    p.user_concurrent_program_name "User Program Name",
    decode(r.phase_code,
        ''R'',  ('' Active ('' || r.phase_code || '' )''),
        ''P'',  ('' Active ('' || r.phase_code || '' )''),
        ''Inactive'') "Status"
    FROM 
    fnd_concurrent_requests r,
    fnd_concurrent_programs_vl p
    WHERE 
    p.concurrent_program_name in (''INCTCM'',''CMCTCM'', ''WICTMS'', ''WSCMTM'') and
    p.concurrent_program_id = r.concurrent_program_id(+) and
    r.phase_code in (''R'', ''P''))
    UNION     
    (SELECT 
    distinct p.concurrent_program_name "Program Name",
    p.user_concurrent_program_name "User Program Name",
    ''Inactive'' "Status"
    FROM 
    fnd_concurrent_requests r,
    fnd_concurrent_programs_vl p
    WHERE 
    p.concurrent_program_name in (''INCTCM'',''CMCTCM'', ''WICTMS'', ''WSCMTM'') and
    p.concurrent_program_id = r.concurrent_program_id(+) and
    r.phase_code is null) 
    order by 1';

    run_sql(g_text, l_sql, 'N');

    exception when others then
        Exception_ErrorPrint(l_proc);
end INV_Display_Interface_Managers;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Txn_Manager_Config
-- DESCRIPTION:
--      Display Setup Configuration of the INV-related Transaction Interface
--      Managers
-- Input:
--        NONE
-- Return-Code:
--        None
-- USAGE:
--        INV_Txn_Manager_Config
-- USAGE-EXAMPLES:
--        INV_Txn_Manager_Config
------------------------------------------------------------------------------
PROCEDURE INV_Txn_Manager_Config IS
    l_proc VARCHAR2(30) := 'INV_Txn_Manager_Config';
BEGIN -- INV_Txn_Manager_Config

    g_text :=
        'SELECT PROCESS_TYPE "Manager"
              , PROCESS_NAME "Internal|Name"
              , WORKER_ROWS "Worker|Rows"
              , TIMEOUT_HOURS
                || '':'' || TIMEOUT_MINUTES "Timeout|Hrs:Min"
              , PROCESS_HOURS||'':''||PROCESS_MINUTES||'':''||PROCESS_SECONDS "Process Interval|H:M:S"
              , MANAGER_PRIORITY "Manager|Priority"
              , WORKER_PRIORITY "Worker|Priority"
              , PROCESSING_TIMEOUT "Processing|Timeout"
              --, PROCESS_CODE
              --, PROCESS_APP_SHORT_NAME
              --, LAST_UPDATE_DATE
              --, LAST_UPDATED_BY
              --, LAST_UPDATE_LOGIN
           FROM MTL_INTERFACE_PROC_CONTROLS_V
          ORDER BY PROCESS_TYPE';

    Run_SQL( 'Inventory Interface Managers Setup' , g_text, 'N' );

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc );
 
END INV_Txn_Manager_Config;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Txn_Manager_Status
-- DESCRIPTION:
--      Show status ( active/inactive ) of the Transaction Interface Managers
--        List most recent Conc.Requests of a given Manager ,
--      so users can easily find log/outfiles.
-- Input:
--        display_costmanager: Y/N
--        display_lotmanager: Y/N
--        display_procmanager: Y/N
--        display_wipmanager: Y/N
-- Return-Code:
--        None
-- USAGE:
--        INV_Txn_Manager_Status( display_costmanager, display_lotmanager,
--                                display_procmanager, display_wipmanager )
-- USAGE-EXAMPLES:
--        INV_Txn_Manager_Status( 'N', 'N', 'Y', 'Y' );
--            Display info about Material Txn Mgr
--        INV_Txn_Manager_Status( 'Y', 'N', 'N', 'Y' );
--            Display info about CostManager and WIP Move Transaction Manager
------------------------------------------------------------------------------
PROCEDURE INV_Txn_Manager_Status ( p_costmgr IN VARCHAR2, p_lotmgr IN VARCHAR2
                                 , p_procmgr IN VARCHAR2, p_wipmgr IN VARCHAR2 )
IS
    l_proc VARCHAR2(30) := 'INV_Txn_Manager_Status';
    l_status VARCHAR(20);
    l_active BOOLEAN;
BEGIN -- INV_Txn_Manager_Status

    --SectionPrintBig( 'Interface Managers Status' );
 
    IF p_costmgr = 'Y' THEN
        BRPrint;
        -- CMCTCM = Cost Manager
        SectionPrint( 'Cost Manager' );
        v_rc := INV_Display_Conc_Proc_Info( 'CMCTCM',  'RP', 0, 1);
        IF v_rc < 1 THEN
            Tab2Print( 'There are no running or pending Cost Manager requests');
        END IF;
        -- Display the latest 5 concurrent requests of Cost Manager
        v_rc := INV_Display_Conc_Proc_Info( 'CMCTCM',  NULL, 5, 1);
        is_concurrent_process_active( 'CMCTCM', l_status, l_active  );
        IF l_active = TRUE THEN
            BRPrint;
            Tab1Print( 'Cost Manager is '|| l_status );
        ELSE
            BRPrint;
            WarningPrint( 'Cost Manager is '|| l_status ||'. Transactions will not be costed.');
            ActionWarningPrint( 'Start the Cost Manager.<BR>
    Please Refer to the Inventory User''s Guide on Starting Transaction Managers');
        END IF;
    END IF; -- p_costmgr
 
    IF p_lotmgr = 'Y' THEN
        BRPrint;
        -- WSCMTM = "Lot Move Transactions Manager" = "Lot Move Transaction"
        SectionPrint( 'Lot Move Transactions Manager' );
        v_rc := INV_Display_Conc_Proc_Info( 'WSCMTM',  'RP', 0, 1);
        IF v_rc < 1 THEN
            Tab2Print( 'There are no running or pending Lot Move Transactions Manager requests');
        END IF;
        v_rc := INV_Display_Conc_Proc_Info( 'WSCMTM',  NULL, 5, 1);
        is_concurrent_process_active( 'WSCMTM', l_status, l_active  );
        IF l_active = TRUE THEN
            BRPrint;
            Tab1Print( 'Lot Move Transactions Manager is '|| l_status );
        ELSE
            BRPrint;
            WarningPrint( 'Lot Move Transactions Manager (WSCMTM) is '|| l_status || '.<BR>
                           Lot Moves for Oracle Shop Floor Management will not be processed' ) ;
            ActionWarningPrint( 'Start the Lot Move Transactions Manager.<BR>
    Please Refer to the Inventory User''s Guide on Starting Transaction Managers');
        END IF;
    END IF; -- p_lotmgr
 
    IF p_procmgr = 'Y' THEN
        BRPrint;
        -- INCTCM = "Process transaction interface" = "Material transaction"
        -- ATTENTION: INV-Form "Interface Managers" Shows "Material transaction"
        --        while Con.Req.Form shows the same as Process transaction interface
        SectionPrint( 'Process transaction interface Manager ( Material transaction Manager )' );
        v_rc := INV_Display_Conc_Proc_Info( 'INCTCM',  'RP', 0, 1);
        IF v_rc < 1 THEN
            Tab2Print( 'There are no running or pending Material Manager requests');
        END IF;
        v_rc := INV_Display_Conc_Proc_Info( 'INCTCM',  NULL, 5, 1);
        is_concurrent_process_active( 'INCTCM', l_status, l_active  );
        BRPrint;
        IF l_active = TRUE THEN
            Tab1Print( 'Process transaction interface Manager ( Material Manager ) is '|| l_status );
        ELSE
            WarningPrint( 'Process transaction interface Manager ( Material Manager ) is '|| l_status || '.<BR>
                           Material Transactions will not be processed' );
            ActionWarningPrint( 'Start Material Transactions Manager.<BR>
    Please Refer to the Inventory User''s Guide on Starting Transaction Managers');
        END IF;
    END IF; -- p_procmgr
 
    IF p_wipmgr = 'Y' THEN
        BRPrint;
        -- WICTMS = "WIP Move Transaction Manager" = "Move transaction"
        SectionPrint( 'WIP Move Transaction Manager' );
        v_rc := INV_Display_Conc_Proc_Info( 'WICTMS',  'RP', 0, 1);
        IF v_rc < 1 THEN
            Tab2Print( 'There are no running or pending WIP Move Transaction Manager requests' );
        END IF;
        v_rc := INV_Display_Conc_Proc_Info( 'WICTMS',  NULL, 5, 1);
        is_concurrent_process_active( 'WICTMS', l_status, l_active  );
        BRPrint;
        IF l_active = TRUE THEN
            Tab1Print( 'WIP Move Transaction Manager is '|| l_status );
        ELSE
            WarningPrint( 'WIP Move Transaction Manager is '||l_status|| '.<BR>
                           WIP Transactions will not be processed' );
            ActionWarningPrint( 'Start the WIP Move Transaction Manager.<BR>
    Please Refer to the Inventory User''s Guide on Starting Transaction Managers');
        END IF;
    END IF; -- p_wipmgr
 
    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint(l_proc );
 
END INV_Txn_Manager_Status;

------------------------------------------------------------------------------
-- FUNCTION: is_wms_installed
-- DESCRIPTION: Detect if WMS is installed
--
-- Return: 
--      TRUE if WMS is installed
--      FALSE if WMS is not installed
--
-- Examples:
--
--        if is_wms_installed then 
--              ...
--        end if;
--
------------------------------------------------------------------------------
function is_wms_installed ( p_org_id in NUMBER ) return boolean is
    l_proc VARCHAR2(30) := 'is_wms_installed';
    l_wms_installed       BOOLEAN := FALSE;
    l_return_status       VARCHAR2(240);
    l_msg_count           NUMBER;
    l_msg_data            VARCHAR2(240);
begin
    l_wms_installed := wms_install.check_install(
                    x_return_status       => l_return_status,
                    x_msg_count           => l_msg_count,
                    x_msg_data            => l_msg_data,
                    p_organization_id     => p_org_id);
    return l_wms_installed;
    exception when others then
        return l_wms_installed;
end is_wms_installed;
------------------------------------------------------------------------------
-- FUNCTION: INV_Display_Organization_Info
-- DESCRIPTION: Display an HTML table of Organization Information
--
-- Input: p_title: a table alias name to apply to the passed p_sql_statement
-- Input: p_display_longs: display values for any long variables
-- Input: p_feedback: display a count of the number of rows retrieved
-- Input: p_max_rows: limit number of rows displayed to this. 
-- Input: p_table_alias: a table alias name to assign to the passed p_sql_statement
-- Input: p_where_clause: a where clause to apply to the passed p_sql_statement
--        This where clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_order_by: a order by clause to apply to the passed p_sql_statement
--        This order by clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_include_rownum: If true, wrap the sql statement in a select to generate
--        a 'Rownum' column in the first position as an index for the table output
--        i.e. select rownum, xyz.* ( <p_sql_statement> ) xyz;
--
-- Return: Number of rows retrieved
--
-- Examples:
--      
--  l_cnt := INV_Display_SQL(
--     ,p_title => 'Organization Information (M1)'
--     ,p_display_longs => 'N'
--     ,p_feedback => 'Y'
--     ,p_max_rows => 0
--     ,n_table_alias => 'MPV'
--     ,n_where_clause => 'where MPV."Organization Id" in (204,207)'
--     ,n_order_by => 'MPV."Org Code"'
--     ,n_include_rownum => true
--     );
-- 
--  Output:
--       Organization Information (M1)
--       Rownum   Org Code   Master Org Code ...
--       1        M1         V1              ...
--       2        V1         V1              ...
--
------------------------------------------------------------------------------
function INV_Display_Organization_Info( 
                 p_title          varchar2 default 'Organization Information'
               , p_display_longs  varchar2 default 'Y'
               , p_feedback       varchar2 default 'Y'
               , p_max_rows       number   default null
               , p_current_exec   number   default 0
               , p_table_alias    varchar2 default 'MPV'
               , p_where_clause   varchar2 default null
               , p_order_by       varchar2 default null
               , p_include_rownum boolean default false) return number is
    l_proc VARCHAR2(30) := 'INV_Display_Organization_Info';
    l_cnt NUMBER;
    l_wms_column_sql VARCHAR2(100) := '';


    --
    -- NOTE: The decodes in this select are here to increase performance
    --
    l_Parameters_Select VARCHAR2(4000) := '
         select 
     mp.organization_code "Org Code", 
     mpm.organization_code "Master Org Code", 
     mpc.organization_code "Cost Org Code", 
     mp.organization_id "Organization|Id", 
     mp.master_organization_id "Master Organization|Id", 
     mp.cost_organization_id "Cost Organization|Id", 
     nvl(sob.short_name,''null'') "Set Of Books Name", 
     nvl(ood.set_of_books_id,0) "Set Of Books Id", 
     ou.name "Operating Unit Name", 
     ood.operating_unit "Operating Unit Id", 
     mp.calendar_code "Calendar", 
     decode(nvl(mp.primary_cost_method,-1),
              ''1'',''Standard'',
              ''2'', ''Average'', 
              ''3'', ''Periodic Average'', 
              ''4'', ''Periodic Incremental LIFO'', 
              ''5'', ''LIFO'', 
              ''6'', ''FIFO'', 
              ''-1'',''null'',
              ''Other ('' || nvl(mp.primary_cost_method,-1) || '')'') "Primary Cost Method",
     decode(mp.negative_inv_receipt_code,1,''Yes'',''No'') "Negative|Balances|Allowed", 
     mp.default_cost_group_id "Default Cost Group Id", 
     decode(nvl(mp.serial_number_generation,-1), 
              ''1'',''Org Level'',
              ''2'',''Item Level'', 
              ''-1'',''null'',
              ''Other ('' || nvl(mp.serial_number_generation,-1) || '')'') "Serial Number Generation",
     decode(nvl(mp.lot_number_uniqueness,-1),
              ''1'',''Unique for Item'',
              ''2'',''None'', 
              ''-1'',''null'',
              ''Other ('' || nvl(mp.lot_number_uniqueness,-1) || '')'') "Lot Number Uniqueness",
     decode(nvl(mp.lot_number_generation,-1),
              ''1'',''Org Level'',
              ''2'',''Item Level'',
              ''3'',''User Defined'', 
              ''-1'',''null'',
              ''Other ('' ||  nvl(mp.lot_number_generation,-1) || '')'') "Lot Number Generation", 
     decode(nvl(mp.serial_number_type,-1),
              ''1'',''Unique within Inventory Items'',
              ''2'',''Unique within Organization'',
              ''3'',''Unique across Organizations'', 
              ''-1'',''null'',
              ''Other ('' || nvl(mp.serial_number_type,-1) || '')'') "Serial Number Type",
     decode(nvl(mp.stock_locator_control_code,-1),
              ''1'',''None'',
              ''2'',''Prespecified'',
              ''3'',''Dynamic'',
              ''4'',''Determined at Subinventory Level'',
              ''5'',''Determined at Item Level'',
              ''-1'',''null'',
              ''Other ('' || nvl(mp.stock_locator_control_code,-1) || '')'') "Stock Locator Control Code", 
     nvl(ct.cost_type,''null'') "Avg Rates Cost Type", 
     mp.avg_rates_cost_type_id "Avg Rates Cost Type Id"';

    l_Parameters_FromWhere VARCHAR2(800) := '
     FROM 
       mtl_parameters mp,
       mtl_parameters mpc,
       mtl_parameters mpm,
       cst_cost_types ct,
       org_organization_definitions ood,
       gl_sets_of_books sob,
       hr_operating_units ou
     WHERE 
       mp.cost_organization_id = mpc.organization_id  and
       mp.master_organization_id = mpm.organization_id  and
       ( mp.organization_id = ct.organization_id(+) and mp.avg_rates_cost_type_id = ct.cost_type_id(+) ) and
         mp.organization_id = ood.organization_id  and
           ood.set_of_books_id = sob.set_of_books_id(+)  and
         ood.operating_unit = ou.organization_id(+)
     ORDER BY 
     mp.organization_code';

    l_Parameters_View VARCHAR2(8000);
begin

    select ',decode(nvl(mp.wms_enabled_flag,''N''),''Y'',''Yes'',''No'') "WMS Enabled"'
    into l_wms_column_sql
    from all_tab_columns 
    where column_name = 'WMS_ENABLED_FLAG' and table_name = 'MTL_PARAMETERS';

    l_Parameters_View := l_Parameters_Select ||
            l_wms_column_sql ||
        l_Parameters_FromWhere;

    l_cnt := INV_Display_SQL(
        p_sql_statement => l_Parameters_View
       ,table_alias => p_title
       ,display_longs => p_display_longs
       ,p_feedback => p_feedback
       ,p_max_rows => p_max_rows
       ,n_table_alias => p_table_alias
       ,n_where_clause => p_where_clause
       ,n_order_by => p_order_by
       ,n_include_rownum => p_include_rownum
       );

    return l_cnt;

    exception when others then
        Exception_ErrorPrint(l_proc);
    return -1;
end INV_Display_Organization_Info;
------------------------------------------------------------------------------
-- FUNCTION: INV_Display_Item_Info
-- DESCRIPTION: Display an HTML table of Item Master Information
--
-- Input: p_title: a table alias name to apply to the passed p_sql_statement
-- Input: p_display_longs: display values for any long variables
-- Input: p_feedback: display a count of the number of rows retrieved
-- Input: p_max_rows: limit number of rows displayed to this. 
-- Input: p_table_alias: a table alias name to assign to the passed p_sql_statement
-- Input: p_where_clause: a where clause to apply to the passed p_sql_statement
--        This where clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_order_by: a order by clause to apply to the passed p_sql_statement
--        This order by clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_include_rownum: If true, wrap the sql statement in a select to generate
--        a 'Rownum' column in the first position as an index for the table output
--        i.e. select rownum, xyz.* ( <p_sql_statement> ) xyz;
--
-- Return: Number of rows retrieved
--
-- Examples:
--      
--  l_cnt := INV_Display_SQL(
--     ,p_title => 'Item Information (M1)'
--     ,p_display_longs => 'N'
--     ,p_feedback => 'Y'
--     ,p_max_rows => 0
--     ,n_table_alias => 'MSIV'
--     ,n_where_clause => 'where MSIV."Organization Id" in (207)'
--     ,n_order_by => 'MPV."Item Number"'
--     ,n_include_rownum => true
--     );
-- 
--  Output:
--       Item Information (M1)
--       Rownum   Org Code   Item Number        ...
--       1        M1         AS18957            ...
--       2        M1         AS18966            ...
--
------------------------------------------------------------------------------
function INV_Display_Item_Info( 
                 p_title          varchar2 default 'Item Information'
               , p_display_longs  varchar2 default 'Y'
               , p_feedback       varchar2 default 'Y'
               , p_max_rows       number   default null
               , p_current_exec   number   default 0
               , p_table_alias    varchar2 default 'MSIV'
               , p_where_clause   varchar2 default null
               , p_order_by       varchar2 default null
           , p_include_rownum boolean default false) return number is

    l_proc VARCHAR2(30) := 'INV_Display_Item_Info';
    l_cnt NUMBER;

    l_System_Items_View VARCHAR2(5000) := 
         'SELECT 
     MP.ORGANIZATION_CODE "Org|Code",
     MSI.ITEM_NUMBER "Item_Number",
     MSI.ORGANIZATION_ID "Organization|Id",
     MSI.INVENTORY_ITEM_ID "Item Id",
     MSI.ENABLED_FLAG "Enabled",
     MSI.START_DATE_ACTIVE "Start Date Active",
     MSI.END_DATE_ACTIVE "End date Active",
     MSI.PURCHASING_ITEM_FLAG "Purchasing Item",
     MSI.PURCHASING_ENABLED_FLAG "Purchasing Enabled",
     MSI.SHIPPABLE_ITEM_FLAG "Shippable Item",
     MSI.CUSTOMER_ORDER_FLAG "Customer Order Item",
     MSI.CUSTOMER_ORDER_ENABLED_FLAG "Customer Order Enabled",
     MSI.SO_TRANSACTIONS_FLAG "SO Transactions",
     MSI.INTERNAL_ORDER_FLAG "Internal Order Item",
     MSI.INTERNAL_ORDER_ENABLED_FLAG "Internal Order Enabled",
     MSI.INVOICEABLE_ITEM_FLAG "Invoiceable Item",
     MSI.INVOICE_ENABLED_FLAG "Invoice Enabled",       
     MSI.SERVICE_ITEM_FLAG "Service Item",
     MSI.INVENTORY_ITEM_FLAG "Inventory Item",
     MSI.MTL_TRANSACTIONS_ENABLED_FLAG "Transactions Enabled",
     MSI.INVENTORY_ASSET_FLAG "Asset Item",
     MSI.STOCK_ENABLED_FLAG "Stock Enabled",
     MSI.BOM_ENABLED_FLAG "Bom Enabled",
     MSI.BUILD_IN_WIP_FLAG "Build In WIP",
     decode(to_char(nvl(MSI.REVISION_QTY_CONTROL_CODE,1)),''1'',''N'',''Y'') "Rev Controlled",
     decode(to_char(nvl(MSI.LOT_CONTROL_CODE,1)),''1'',''N'',''Y'') "Lot Controlled",
     decode(nvl(MSI.serial_number_control_code,-1),
              ''1'',''None'',
              ''2'',''Predefined'',
              ''5'',''Dynamic at Inventory Receipt'',
              ''6'',''Dynamic at Sales Order Issue'',
              ''-1'',''null'',
              ''Other''
           ) || ''('' || nvl(MSI.serial_number_control_code,-1) || '')'' "Serial Control",
     decode(to_char(nvl(MSI.RESTRICT_SUBINVENTORIES_CODE,2)),''1'',''Y'',''N'') "Restrict Subinventories",
     decode(to_char(nvl(MSI.RESTRICT_LOCATORS_CODE,2)),''1'',''Y'',''N'') "Restrict Locators",
     decode(nvl(MSI.location_control_code,-1),
              ''1'',''None'',
              ''2'',''Prespecified'',
              ''3'',''Dynamic'',
              ''4'',''Determined at Subinventory Level'',
              ''5'',''Determined at Item Level'',
              ''-1'',''null'',
              ''Other''
           ) || ''('' || nvl(MSI.location_control_code,-1) || '')'' "Location Control",
     decode(nvl(MSI.bom_item_type,-1),
              ''1'',''Model'',
              ''2'',''Option Class'',
              ''3'',''Planning'',
              ''4'',''Standard'',
              ''5'',''Product Family'',
              ''-1'',''null'',
              ''Other''
          ) || ''('' || nvl(MSI.bom_item_type,-1) || '')'' "Bom Item Type",
     MSI.PICK_COMPONENTS_FLAG "Pick Components",
     MSI.REPLENISH_TO_ORDER_FLAG "Replenish To Order",
     MSI.BASE_ITEM_ID "Base Item Id",
     MSI.ATP_COMPONENTS_FLAG "ATP Components",
     MSI.ATP_FLAG "ATP",
     MSI.PRIMARY_UOM_CODE "Primary UOM",
     MSI.INVENTORY_ITEM_STATUS_CODE "Item Status",
     MSI.COSTING_ENABLED_FLAG "Costing Enabled",
     ML4.MEANING || ''('' || nvl(MSI.ITEM_TYPE,''null'') || '')'' "Item_Type Code",
     decode(nvl(MSI.EFFECTIVITY_CONTROL,-1),
              ''1'',''Date'',
              ''2'',''Model/Unit Number'',
              ''-1'',''null'',
              ''Other''
           ) || ''('' || nvl(MSI.EFFECTIVITY_CONTROL,-1) || '')'' "Effectivity Control"
     FROM 
    MTL_ITEM_FLEXFIELDS MSI,
    MTL_PARAMETERS MP,
    FND_COMMON_LOOKUPS ML4  
     WHERE 
       MSI.ORGANIZATION_ID = MP.ORGANIZATION_ID
       AND (ML4.lookup_type(+)=''ITEM_TYPE'' and ML4.lookup_code(+) = MSI.item_type)
    ORDER BY mp.organization_code, msi.item_number, msi.inventory_item_id';

begin
    l_cnt := INV_Display_SQL(
        p_sql_statement => l_System_Items_View
       ,table_alias => p_title
       ,display_longs => p_display_longs
       ,p_feedback => p_feedback
       ,p_max_rows => p_max_rows
       ,n_table_alias => p_table_alias
       ,n_where_clause => p_where_clause
       ,n_order_by => p_order_by
       ,n_include_rownum => p_include_rownum
       );
    return l_cnt;

    exception when others then
        Exception_ErrorPrint(l_proc);
    return -1;

end INV_Display_Item_Info;
------------------------------------------------------------------------------
-- FUNCTION: INV_Display_Subinventory_Info
-- DESCRIPTION: Display an HTML table of Subinventory Information
--
-- Input: p_title: a table alias name to apply to the passed p_sql_statement
-- Input: p_display_longs: display values for any long variables
-- Input: p_feedback: display a count of the number of rows retrieved
-- Input: p_max_rows: limit number of rows displayed to this. 
-- Input: p_table_alias: a table alias name to assign to the passed p_sql_statement
-- Input: p_where_clause: a where clause to apply to the passed p_sql_statement
--        This where clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_order_by: a order by clause to apply to the passed p_sql_statement
--        This order by clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_include_rownum: If true, wrap the sql statement in a select to generate
--        a 'Rownum' column in the first position as an index for the table output
--        i.e. select rownum, xyz.* ( <p_sql_statement> ) xyz;
--
-- Return: Number of rows retrieved
--
-- Examples:
--      
--  l_cnt := INV_Display_SQL(
--     ,p_title => 'Subinventory Information'
--     ,p_display_longs => 'N'
--     ,p_feedback => 'Y'
--     ,p_max_rows => 0
--     ,n_table_alias => 'MSIV'
--     ,n_where_clause => 'where MSIV."Subinventory" in (select subinventory_code from mtl_material_transactions_temp)'
--     ,n_order_by => 'MSIV."Org", MPV."Subinventory"'
--     ,n_include_rownum => true
--     );
-- 
--  Output:
--       Subinventory Information
--       Rownum   Org Code   Org Id   Subinventory ...
--       1        M1         207      Stores       ...
--       2        M2         208      FGI          ...
--
------------------------------------------------------------------------------
function INV_Display_Subinventory_Info( 
                 p_title          varchar2 default 'Subinventory Information'
               , p_display_longs  varchar2 default 'Y'
               , p_feedback       varchar2 default 'Y'
               , p_max_rows       number   default null
               , p_current_exec   number   default 0
               , p_table_alias    varchar2 default 'MSIV'
               , p_where_clause   varchar2 default null
               , p_order_by       varchar2 default null
           , p_include_rownum boolean default false) return number is

    l_proc VARCHAR2(30) := 'INV_Display_Subinventory_Info';
    l_cnt NUMBER;
    l_Secondary_Inventories_View VARCHAR2(4000) := 
         '
            SELECT DISTINCT 
            ORGANIZATION_CODE "Org|Code", 
            MI.ORGANIZATION_ID "Organization|Id", 
            MI.SECONDARY_INVENTORY_NAME "Subinventory", 
                    MI.DISABLE_DATE "Disable Date", 
            ML1.MEANING || ''('' || NVL(MI.INVENTORY_ATP_CODE,-1) || '')'' "ATP Calculation", 
            ML2.MEANING || ''('' || NVL(MI.AVAILABILITY_TYPE,-1) || '')'' "Availability Type", 
            DECODE(MI.RESERVABLE_TYPE,1,''YES'',''NO'') "Reservable", 
            ML3.MEANING || ''('' || NVL(MI.LOCATOR_TYPE,-1) || '')'' "Locator Control Type", 
            MI.PICKING_ORDER "Picking Order", 
            DECODE(MI.QUANTITY_TRACKED,1,''YES'',''NO'') "Qty Tracked", 
            DECODE(MI.ASSET_INVENTORY,1,''YES'',''NO'') "Asset Inventory", 
            ML5.MEANING || ''('' || NVL(MI.SOURCE_TYPE,-1) || '')'' "Source Type", 
            MI.SOURCE_SUBINVENTORY "Source Subinventory ", 
            MI.SOURCE_ORGANIZATION_ID " Source Organization Id", 
            ML4.MEANING || ''('' || NVL(MI.REQUISITION_APPROVAL_TYPE,-1) || '')'' "Requisition Approval", 
            MI.PREPROCESSING_LEAD_TIME "Preprocessing Lead Time", 
            MI.PROCESSING_LEAD_TIME "Processing Lead Time ", 
            MI.POSTPROCESSING_LEAD_TIME "Postprocessing Lead Time ", 
            MI.DEMAND_CLASS "Demand Class", 
            MI.PROJECT_ID "Project Id", 
            MI.TASK_ID "Task Id", 
            MI.SUBINVENTORY_USAGE " Subinventory Usage", 
            MI.NOTIFY_LIST_ID "Notify List Id", 
            MI.PICK_UOM_CODE "Pick UOM Code", 
            DECODE(MI.DEPRECIABLE_FLAG,1,''YES'',''NO'') "Depreciable", 
            MI.LOCATION_ID "Location Id", 
            MI.DEFAULT_COST_GROUP_ID "Default Cost Group Id", 
            MI.STATUS_ID "Status Id", 
            MI.DEFAULT_LOC_STATUS_ID " Default Loc Status Id", 
            MI.LPN_CONTROLLED_FLAG "LPN Controlled Flag", 
            MI.PICK_METHODOLOGY "Pick Methodology", 
            MI.CARTONIZATION_FLAG "Cartonization Flag"
            FROM 
            MTL_SECONDARY_INVENTORIES MI, 
            MTL_PARAMETERS MP, 
            MFG_LOOKUPS ML1, 
            MFG_LOOKUPS ML2, 
            MFG_LOOKUPS ML3, 
            MFG_LOOKUPS ML4, 
            MFG_LOOKUPS ML5 
            WHERE 
                ( mi.inventory_atp_code = ml1.lookup_code and ml1.lookup_type = ''MTL_ATP_CODE'') 
            and ( mi.availability_type = ml2.lookup_code and ml2.lookup_type = ''MTL_AVAILABILITY'') 
            and ( nvl(mi.locator_type,1) = ml3.lookup_code and ml3.lookup_type = ''MTL_LOCATION_CONTROL'') 
            and ( nvl(mi.REQUISITION_APPROVAL_TYPE,2) = ml4.lookup_code and ml4.lookup_type = ''MTL_REQUISITION_APPROVAL'') 
            and ( nvl(mi.SOURCE_TYPE,1) = ml5.lookup_code and ml5.lookup_type = ''MTL_SOURCE_TYPES'') 
            and mi.organization_id = mp.organization_id 
            order by mp.organization_code, mi.secondary_inventory_name';
begin
    l_cnt := INV_Display_SQL(
        p_sql_statement => l_Secondary_Inventories_View
       ,table_alias => p_title
       ,display_longs => p_display_longs
       ,p_feedback => p_feedback
       ,p_max_rows => p_max_rows
       ,n_table_alias => p_table_alias
       ,n_where_clause => p_where_clause
       ,n_order_by => p_order_by
       ,n_include_rownum => p_include_rownum
       );
    return l_cnt;

    exception when others then
        Exception_ErrorPrint(l_proc);
    return -1;
end INV_Display_Subinventory_Info;
------------------------------------------------------------------------------
-- FUNCTION: INV_Display_Onhand_Qty_Info
-- DESCRIPTION: Display an HTML table of Onhand_Qty Information
--
-- Input: p_title: a table alias name to apply to the passed p_sql_statement
-- Input: p_display_longs: display values for any long variables
-- Input: p_feedback: display a count of the number of rows retrieved
-- Input: p_max_rows: limit number of rows displayed to this. 
-- Input: p_table_alias: a table alias name to assign to the passed p_sql_statement
-- Input: p_where_clause: a where clause to apply to the passed p_sql_statement
--        This where clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_order_by: a order by clause to apply to the passed p_sql_statement
--        This order by clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_include_rownum: If true, wrap the sql statement in a select to generate
--        a 'Rownum' column in the first position as an index for the table output
--        i.e. select rownum, xyz.* ( <p_sql_statement> ) xyz;
--
-- Return: Number of rows retrieved
--
-- Examples:
--      
--  l_cnt := INV_Display_SQL(
--     ,p_title => 'Onhand Quantity Information'
--     ,p_display_longs => 'N'
--     ,p_feedback => 'Y'
--     ,p_max_rows => 0
--     ,n_table_alias => 'OHQV'
--     ,n_where_clause => 'where OHQV."Org Id" = 207'
--     ,n_order_by => 'OHQV."Org", MPV."Item _Id"'
--     ,n_include_rownum => true
--     );
-- 
--  Output:
--       Onhand Quantity Information
--       Rownum   Item Id   Org Id   Txn Quantity ...
--       1        234         207      13         ...
--       ...
------------------------------------------------------------------------------
function INV_Display_Onhand_Qty_Info( 
                 p_title          varchar2 default 'Onhand Quantity Information'
               , p_display_longs  varchar2 default 'Y'
               , p_feedback       varchar2 default 'Y'
               , p_max_rows       number   default null
               , p_current_exec   number   default 0
               , p_table_alias    varchar2 default 'MOQV'
               , p_where_clause   varchar2 default null
               , p_order_by       varchar2 default null
           , p_include_rownum boolean default false) return number is

    l_proc VARCHAR2(30) := 'INV_Display_Onhand_Qty_Info';
    l_cnt NUMBER;

    l_Onhand_Qty_View VARCHAR(4000) := '
         SELECT DISTINCT
            moqd.INVENTORY_ITEM_ID "Item Id" ,
            moqd.ORGANIZATION_ID "Organization|Id",
            moqd.TRANSACTION_QUANTITY "Txn Quantity" ,
            moqd.SUBINVENTORY_CODE "Subinventory",
            moqd.COST_GROUP_ID "Cost Group Id",
            moqd.LOCATOR_ID "Locator Id",
            moqd.REVISION "Revision",
            moqd.LOT_NUMBER "Lot_number"
            FROM 
            MTL_ONHAND_QUANTITIES moqd
            ORDER BY 
            moqd.INVENTORY_ITEM_ID,
            moqd.ORGANIZATION_ID,
            NVL(moqd.SUBINVENTORY_CODE,''-1''),
            NVL(moqd.COST_GROUP_ID,-1),
            NVL(moqd.LOCATOR_ID,-1),
            NVL(moqd.REVISION,''-1''),
            NVL(moqd.LOT_NUMBER,''-1'')';
begin
    l_cnt := INV_Display_SQL(
        p_sql_statement => l_Onhand_Qty_View
       ,table_alias => p_title
       ,display_longs => p_display_longs
       ,p_feedback => p_feedback
       ,p_max_rows => p_max_rows
       ,n_table_alias => p_table_alias
       ,n_where_clause => p_where_clause
       ,n_order_by => p_order_by
       ,n_include_rownum => p_include_rownum
       );
    return l_cnt;

    exception when others then
        Exception_ErrorPrint(l_proc);
    return -1;
end INV_Display_Onhand_Qty_Info;
------------------------------------------------------------------------------
-- FUNCTION: INV_Display_MO_Detail_Info
-- DESCRIPTION: Display an HTML table of MO_Detail Information
--
-- Input: p_title: a table alias name to apply to the passed p_sql_statement
-- Input: p_display_longs: display values for any long variables
-- Input: p_feedback: display a count of the number of rows retrieved
-- Input: p_max_rows: limit number of rows displayed to this. 
-- Input: p_table_alias: a table alias name to assign to the passed p_sql_statement
-- Input: p_where_clause: a where clause to apply to the passed p_sql_statement
--        This where clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_order_by: a order by clause to apply to the passed p_sql_statement
--        This order by clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_include_rownum: If true, wrap the sql statement in a select to generate
--        a 'Rownum' column in the first position as an index for the table output
--        i.e. select rownum, xyz.* ( <p_sql_statement> ) xyz;
--
-- Return: Number of rows retrieved
--
-- Examples:
--      
--  l_cnt := INV_Display_SQL(
--     ,p_title => 'Move Order_Detail Information'
--     ,p_display_longs => 'N'
--     ,p_feedback => 'Y'
--     ,p_max_rows => 0
--     ,n_table_alias => 'MODV'
--     ,n_where_clause => 'where MODV."Org Id" = 207'
--     ,n_order_by => 'MODV."Org", MPV."Item _Id"'
--     ,n_include_rownum => true
--     );
-- 
--  Output:
--       Move Order Detail Information
--       Rownum   Source Line Id   Header To Account Id ...
--       1        112414           2342342              ...
--       ...
------------------------------------------------------------------------------
function INV_Display_MO_Detail_Info( 
                 p_title          varchar2 default 'Move Order Detail Information'
               , p_display_longs  varchar2 default 'Y'
               , p_feedback       varchar2 default 'Y'
               , p_max_rows       number   default null
               , p_current_exec   number   default 0
               , p_table_alias    varchar2 default 'MTRV'
               , p_where_clause   varchar2 default null
               , p_order_by       varchar2 default null
           , p_include_rownum boolean default false) return number is

    l_proc VARCHAR2(30) := 'INV_Display_MO_Detail_Info';
    l_cnt NUMBER;

    l_MO_Detail_View VARCHAR2(4000) := '
         SELECT
         MTRL.TXN_SOURCE_LINE_ID "Source Line Id"
        ,MTRH.TO_ACCOUNT_ID "Header To Account Id"
        ,MTRH.HEADER_STATUS "Header Status"
        ,MTRH.SHIP_TO_LOCATION_ID "Header Ship To Location Id"
        ,MTRL.LINE_ID "Line Id"
        ,MTRL.REQUEST_NUMBER "Request Number"
        ,MTRL.MOVE_ORDER_TYPE "Move Order Type"
        ,MTRL.MOVE_ORDER_TYPE_NAME "Order Type Name"
        ,MTRL.TRANSACTION_SOURCE_TYPE_ID "Source Type Id"
        ,MTRL.TRANSACTION_TYPE_ID "Txn Type Id"
        ,MTRL.TRANSACTION_TYPE_NAME "Txn Type Name"
        ,MTRL.TRANSACTION_ACTION_ID "Txn Action Id"
        ,MTRL.LINE_NUMBER "Line Number"
        ,MTRL.ORGANIZATION_ID "Organization|Id"
        ,MTRL.INVENTORY_ITEM_ID "Item Id"
        ,MTRL.REVISION "Revision"
        ,MTRL.FROM_SUBINVENTORY_CODE "From Subinventory"
        ,MTRL.FROM_SUB_LOCATOR_TYPE "From Sub Locator Type"
        ,MTRL.FROM_SUB_ASSET "From Sub Asset"
        ,MTRL.FROM_SUB_QUANTITY_TRACKED "From Sub Qty Tracked"
        ,MTRL.FROM_SUB_MATERIAL_ACCOUNT "From Sub Material Account" 
        ,MTRL.FROM_LOCATOR_ID "From Locator Id"
        ,MTRL.TO_SUBINVENTORY_CODE "To Subinventory"
        ,MTRL.TO_SUB_LOCATOR_TYPE "To Sub Locator Type"
        ,MTRL.TO_SUB_ASSET "To Sub Asset"
        ,MTRL.TO_SUB_QUANTITY_TRACKED "To Sub Qty Tracked"
        ,MTRL.TO_SUB_MATERIAL_ACCOUNT "To Sub Material Account"
        ,MTRL.TO_LOCATOR_ID "To Locator Id"
        ,MTRL.TO_ACCOUNT_ID "Detail To Account Id"
        ,MTRL.SHIP_TO_LOCATION_ID "Detail Ship To Location Id"
        ,MTRL.LOT_NUMBER "Lot Number"
        ,MTRL.SERIAL_NUMBER_START "Serial # Start"
        ,MTRL.SERIAL_NUMBER_END "Serial # End"
        ,MTRL.UOM_CODE "UOM"
        ,MTRL.QUANTITY "Quantity"
        ,MTRL.REQUIRED_QUANTITY "Required Quantity"
        ,MTRL.QUANTITY_DELIVERED "Quantity Delivered"
        ,MTRL.QUANTITY_DETAILED "Quantity Detailed"
        ,MTRL.TRANSACTION_HEADER_ID "Txn Header Id"
        ,MTRL.LINE_STATUS "Line Status"
        ,MTRL.TXN_SOURCE_ID "Txn Source Id"
        ,MTRL.TXN_SOURCE_LINE_DETAIL_ID "Txn Source Line Detail Id"
        ,MTRL.PRIMARY_QUANTITY "Primary Quantity"
        ,MTRL.TO_ORGANIZATION_ID "To Organization|Id"
        ,MTRL.PICK_STRATEGY_ID "Pick Strategy Id"
        ,MTRL.PUT_AWAY_STRATEGY_ID "Put Away Stategy Id"
        ,MTRL.FROM_COST_GROUP_ID "From Cost Group Id"
        ,MTRL.FROM_COST_GROUP_NAME "From Cost Group Name"
        ,MTRL.TO_COST_GROUP_ID "To Cost Group Id"
        ,MTRL.TO_COST_GROUP_NAME "To Cost Group Name"
        ,MTRL.LPN_ID "LPN Id"
        ,MTRL.TO_LPN_ID "To LPN Id"
        ,MTRL.LPN_NUMBER "LPN Number"
        ,MTRL.TO_LPN_NUMBER "To LPN Number"
    FROM 
         MTL_TXN_REQUEST_HEADERS MTRH, 
         MTL_TXN_REQUEST_LINES_v MTRL
    where
        MTRL.header_id = MTRH.header_id
    ORDER BY
    MTRL.TXN_SOURCE_LINE_ID';
begin
    l_cnt := INV_Display_SQL(
        p_sql_statement => l_MO_Detail_View
       ,table_alias => p_title
       ,display_longs => p_display_longs
       ,p_feedback => p_feedback
       ,p_max_rows => p_max_rows
       ,n_table_alias => p_table_alias
       ,n_where_clause => p_where_clause
       ,n_order_by => p_order_by
       ,n_include_rownum => p_include_rownum
       );
    return l_cnt;

    exception when others then
        Exception_ErrorPrint(l_proc);
    return -1;
end INV_Display_MO_Detail_Info;
------------------------------------------------------------------------------
-- FUNCTION: INV_Display_Txn_Temp_Info
-- DESCRIPTION: Display an HTML table of Txn_Temp Information
--
-- Input: p_title: a table alias name to apply to the passed p_sql_statement
-- Input: p_display_longs: display values for any long variables
-- Input: p_feedback: display a count of the number of rows retrieved
-- Input: p_max_rows: limit number of rows displayed to this. 
-- Input: p_table_alias: a table alias name to assign to the passed p_sql_statement
-- Input: p_where_clause: a where clause to apply to the passed p_sql_statement
--        This where clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_order_by: a order by clause to apply to the passed p_sql_statement
--        This order by clause must use the value for the n_table_alias for column
--        qualification or you will receive an exception
-- Input: p_include_rownum: If true, wrap the sql statement in a select to generate
--        a 'Rownum' column in the first position as an index for the table output
--        i.e. select rownum, xyz.* ( <p_sql_statement> ) xyz;
--
-- Return: Number of rows retrieved
--
-- Examples:
--      
--  l_cnt := INV_Display_SQL(
--     ,p_title => 'Pending Transaction Information'
--     ,p_display_longs => 'N'
--     ,p_feedback => 'Y'
--     ,p_max_rows => 0
--     ,n_table_alias => 'MMTTV'
--     ,n_where_clause => 'where MMTTV."Org Id" = 207'
--     ,n_order_by => 'MMTTV."Org", MPV."Item _Id"'
--     ,n_include_rownum => true
--     );
-- 
--  Output:
--       Pending Transaction Information
--       Rownum   Org     Item      Org Id ...
--       1        M1      AS1957    207    ...
--       ...
------------------------------------------------------------------------------
function INV_Display_Txn_Temp_Info( 
                 p_title          varchar2 default 'Transaction Temp Information'
               , p_display_longs  varchar2 default 'Y'
               , p_feedback       varchar2 default 'Y'
               , p_max_rows       number   default null
               , p_current_exec   number   default 0
               , p_table_alias    varchar2 default 'MMTTV'
               , p_where_clause   varchar2 default null
               , p_order_by       varchar2 default null
           , p_include_rownum boolean default false) return number is

    l_proc VARCHAR2(30) := 'INV_Display_Txn_Temp_Info';
    l_cnt NUMBER;

    l_Transactions_Temp_View VARCHAR2(30000) :=
            'SELECT 
              mp.organization_code "Org",
              mif.item_number "Item",
              mmtt.organization_id "Organization|Id",
              mmtt.inventory_item_id "Item Id",
              mmtt.subinventory_code "Subinventory",
              mmtt.locator_id "Locator Id",
              mmtt.revision "Rev",
              mmtt.transaction_date "Txn Date",
              mmtt.acct_period_id "Acct Per Id",
              mmtt.primary_quantity "Primary Qty",
              mmtt.transaction_cost "Transaction Cost",
              mmtt.cost_group_id "Cost Group Id",
              mmtt.org_cost_group_id "Organization|Cost Group Id",
              mmtt.transaction_quantity "Txn Qty",
              mmtt.transaction_temp_id "Txn Temp Id",
              mtt.transaction_type_name "Txn Type",
              mmtt.transaction_type_id "Txn Type Id",
              mmtt.transaction_action_id "Txn Action Id",
              mmtt.reservation_id "Reservation Id",
              mmtt.demand_source_header_id "Demand Src Header Id",
              mmtt.move_order_line_id "Move Order Line Id",
              mmtt.transaction_header_id "Txn Header Id",
              mmtt.trx_source_line_id,
              mmtt.transfer_subinventory "Transfer Subinventory",
              mmtt.process_flag "Process Flag",
              mmtt.lock_flag "Lock Flag",
              mmtt.transaction_mode "Txn Mode",
              mmtt.transaction_status "Txn Status",
              mmtt.error_code "Error Code",
              mmtt.error_explanation "Error Explanation"
            FROM 
              mtl_material_transactions_temp mmtt,
              mtl_item_flexfields mif,
              mtl_transaction_types mtt,
              mtl_parameters mp
            WHERE 
                  mmtt.inventory_item_id = mif.inventory_item_id
              AND mmtt.organization_id = mif.organization_id
              AND nvl(mmtt.transaction_type_id,-1) = mtt.transaction_type_id 
              AND mmtt.organization_id = mp.organization_id
            ORDER BY   
              mp.organization_code, mif.item_number, mmtt.inventory_item_id, 
              mmtt.transaction_date DESC';
begin
    l_cnt := INV_Display_SQL(
        p_sql_statement => l_Transactions_Temp_View
       ,table_alias => p_title
       ,display_longs => p_display_longs
       ,p_feedback => p_feedback
       ,p_max_rows => p_max_rows
       ,n_table_alias => p_table_alias
       ,n_where_clause => p_where_clause
       ,n_order_by => p_order_by
       ,n_include_rownum => p_include_rownum
       );
    return l_cnt;

    exception when others then
        Exception_ErrorPrint(l_proc);
    return -1;
end INV_Display_Txn_Temp_Info;
------------------------------------------------------------------------------
-- PROCEDURE: Parse_Header
-- DESCRIPTION: Parse an RCS Header for information
--
-- Input: p_rcsheader: RCS $Header
-- Input: x_object: Header object name parsed from p_rcsheader
-- Input: x_version: Header version parsed from p_rcsheader
--
-- Return: None
------------------------------------------------------------------------------
procedure Parse_Header(p_rcsheader in varchar2,
                       x_object out varchar2, 
                       x_version out varchar2) is
    l_keyword varchar2(20) := 'Header: ';
    l_startpos number;
    l_header varchar2(2000);
    l_proc varchar2(30) := 'Parse_Header';
begin
    x_object := 'Unknown';
    x_version := 'Unknown';

    -- Look for 'Header: ' keyword in p_rcsheader, if not present, return
    l_startpos := instr(p_rcsheader,l_keyword);
    if l_startpos <= 0 then
        return;
    end if;

    -- set position to skip past 'Header: '
    l_startpos := l_startpos + length(l_keyword);
    l_header := substr(p_rcsheader, l_startpos);

    -- object name is next string past Header keyword
    x_object := substr ( l_header, 1, instr( l_header,' ',1) - 1); 

    -- version follows object name
    x_version := substr(l_header, (instr( l_header,' ')),(instr(l_header,' ',1,2) - instr(l_header,' ',1,1)));

    exception when others then
        Exception_ErrorPrint(l_proc);
end Parse_Header;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Java_Versions
-- DESCRIPTION: Display JAVA Class file versions 
--
-- Input: p_java_class_list: a V2T list of java class(es)
-- Input: p_heading: Heading to display (default="Key Java Class Versions")
--
-- Return: None
------------------------------------------------------------------------------
procedure INV_Display_Java_Versions(p_java_class_list V2T,
                              p_heading in varchar2 default 'Key Java Class Versions') is
    l_proc VARCHAR2(30) := 'INV_Display_Java_Versions';
    v_numlines NUMBER := 4;     -- max lines to read in from buffer
    v_data DBMS_OUTPUT.CHARARR;
    v_name varchar2(2000);
    v_version varchar2(2000);
    v_filename varchar2(2000);
    l_class varchar2(2000);
    l_status all_objects.status%TYPE;
    l_title_default varchar2(30) := 'Key Java Class Versions';
    j number;
begin
   
    -- reinitialize dbms_output buffer
    dbms_output.disable;
    dbms_output.enable(10000);

    SectionPrintBig(nvl(p_heading,l_title_default));
    Start_Table(nvl(p_heading,l_title_default));
    Show_Table_Header(V2T('Java Class','File Name','Version','Status'));

    for i in 1..p_java_class_list.count loop
        l_class := '%' || substr(p_java_class_list(i),instr(p_java_class_list(i),'.',-1)+1);
        begin
            SELECT status into l_status FROM all_objects WHERE object_name like l_class and rownum = 1;
            exception when NO_DATA_FOUND then
                l_status := 'Unknown';
        end;
        v_name := null;
        v_version := null;
        v_filename := null;
        fnd_aolj_util.getClassVersionfromDB(p_java_class_list(i));
        DBMS_OUTPUT.get_lines(v_data, v_numlines);
        for k in 1..v_data.count loop
            j := instr(v_data(k),'>>> Class:');
            if j > 0 then
                v_name := substr(v_data(k),j+10);
            end if;
            j := instr(v_data(k),'$Header');
            if j > 0 then
                Parse_Header(v_data(k),v_filename,v_version);
            end if;
        end loop;
        Show_Table_Row(V2T(p_java_class_list(i), v_filename, v_version, l_status));
    end loop;
    End_Table;
    exception when others then
        End_Table;
        Exception_ErrorPrint(l_proc);
end INV_Display_Java_Versions;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Package_Versions
-- DESCRIPTION: Display package version information for all packages matching p_matchstring
--
-- Input: p_matchstring: a string to match (e.g. INV%)
-- Input: p_title: Title to display as the heading (Default="Package Versions")
--
-- Return: None
------------------------------------------------------------------------------
procedure INV_Display_Package_Versions(p_matchstring varchar2, p_title varchar2 default 'Package Versions') Is
    l_view varchar2(2000) := '
           select 
           x.*,
           substr(x.rcs_info,1,instr(x.rcs_info,'' '')-1) file_name,
           substr(x.rcs_info,
                  instr(x.rcs_info,'' '',1)+1
                  ,(instr(x.rcs_info,'' '',1,2) - instr(x.rcs_info,'' '',1))
                  ) version   
         from (
          select o.name pkg_name,
          decode(o.type#, 7, ''PROCEDURE'', 8, ''FUNCTION'', 9, ''PACKAGE'',
                                11, ''PACKAGE BODY'', 13, ''TYPE'', 14, ''TYPE BODY'',
                                ''UNDEFINED'') type,
          decode(o.status, 0, ''N/A'', 1, ''VALID'', ''INVALID'') status,
          substr(s.source,instr(s.source,''Header:'')+8,instr(s.source,'' $'',-1)-instr(s.source,''Header:'')-8) rcs_info
          from sys.obj$ o, sys.source$ s
          where o.obj# = s.obj#
          and s.line = 2
          and o.type# in (9, 11)) x';
    l_sqltext varchar2(2000);
    l_cnt number;
begin
    l_sqltext := '
            select 
                y.pkg_name "Package Name",
                y.type "Type",
                y.file_name "File Name",
                y.version "Version",
                y.status "Status"
            from 
                (' || l_view || ') y
            where 
                y.pkg_name like ' || QUOTE || p_matchstring || QUOTE ||
            ' order by y.pkg_name, y.type ';
    l_cnt := INV_Display_SQL(
        p_sql_statement => l_sqltext
       ,table_alias => p_title || ' Matching ' || QUOTE || p_matchstring || QUOTE
       ,display_longs => 'N'
       ,p_feedback => 'N'
       ,p_max_rows => 0
       ,n_table_alias => null
       ,n_where_clause => null
       ,n_order_by => null
       ,n_include_rownum => false
       );
end INV_Display_Package_Versions;
------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Package_Versions
-- DESCRIPTION: Display package version information for all packages matching p_matchstring
--
-- Input: p_pkg_list: a V2T list of package names to display
-- Input: p_title: Title to display as the heading (Default="Key Package Versions")
--
-- Return: None
------------------------------------------------------------------------------
procedure INV_Display_Package_Versions(p_pkg_list V2T, p_title varchar2 default 'Key Package Versions') Is
    l_view varchar2(2000) := '
           select 
           x.*,
           substr(x.rcs_info,1,instr(x.rcs_info,'' '')-1) file_name,
           substr(x.rcs_info,
                  instr(x.rcs_info,'' '',1)+1
                  ,(instr(x.rcs_info,'' '',1,2) - instr(x.rcs_info,'' '',1))
                  ) version   
         from (
          select o.name pkg_name,
          decode(o.type#, 7, ''PROCEDURE'', 8, ''FUNCTION'', 9, ''PACKAGE'',
                                11, ''PACKAGE BODY'', 13, ''TYPE'', 14, ''TYPE BODY'',
                                ''UNDEFINED'') type,
          decode(o.status, 0, ''N/A'', 1, ''VALID'', ''INVALID'') status,
          substr(s.source,instr(s.source,''Header:'')+8,instr(s.source,'' $'',-1)-instr(s.source,''Header:'')-8) rcs_info
          from sys.obj$ o, sys.source$ s
          where o.obj# = s.obj#
          and s.line = 2
          and o.type# in (9, 11)) x';
    l_sqltext varchar2(12000);
    l_cnt number;
    l_comma varchar2(1);
begin
    l_sqltext := '
            select 
                y.pkg_name "Package Name",
                y.type "Type",
                y.file_name "File Name",
                y.version "Version",
                y.status "Status"
            from 
                (' || l_view || ') y
            where 
                y.pkg_name in (';

       l_comma := ' ';
       for i in 1..p_pkg_list.count Loop
            l_sqltext := l_sqltext || l_comma || QUOTE || p_pkg_list(i) || QUOTE;
            l_comma := ',';
       end loop;

       l_sqltext := l_sqltext || ') order by y.pkg_name, y.type ';

    l_cnt := INV_Display_SQL(
        p_sql_statement => l_sqltext
       ,table_alias => p_title
       ,display_longs => 'N'
       ,p_feedback => 'N'
       ,p_max_rows => 0
       ,n_table_alias => null
       ,n_where_clause => null
       ,n_order_by => null
       ,n_include_rownum => false
       );
end INV_Display_Package_Versions;

------------------------------------------------------------------------------
-- FUNCTION: INV_Seeded_MSI_Triggers
-- DESCRIPTION:
--     Display the seeded triggers on tables MTL_SYSTEM_ITEMS_B and
--         MTL_SYSTEM_ITEMS_TL exist and are enabled
--     Following 10 Triggers on MSI_B and MSI_TL are seeded up to 11.5.8:
--         MTL_SYSTEM_ITEMS_B_T2_IBE
--         MTL_SYSTEM_ITEMS_B_T3_IBE
--         MTL_SYSTEM_ITEMS_T1
--         MTL_SYSTEM_ITEMS_T1_BOM
--         MTL_SYSTEM_ITEMS_T2_BOM
--         MTL_SYSTEM_ITEMS_T3_BOM
--         MTL_SYSTEM_ITEMS_T4_BOM
--         MTL_SYSTEM_ITEMS_T5_BOM
--         MTL_SYSTEM_ITEMS_T6_BOM
--         MTL_SYSTEM_ITEMS_TL_TA_IBE
-- Input:
--      Apps-Release. This is for future use, in case DEV releases
--                    new triggers only on specific versions of INV.
-- Return-Code:
--      Success: ?
--      Failure: -2 ?
-- USAGE:
--         INV_Seeded_MSI_Triggers( apps_release );
-- USAGE-EXAMPLES: 
--         rc := INV_Seeded_MSI_Triggers( '11.5.8' );
------------------------------------------------------------------------------
FUNCTION INV_Seeded_MSI_Triggers ( p_apps_release IN VARCHAR2 )
RETURN NUMBER IS
    l_proc VARCHAR2(30) := 'INV_Seeded_MSI_Triggers';
    l_number NUMBER;
BEGIN -- INV_Seeded_MSI_Triggers

    g_text := 'SELECT owner, trigger_name "Trigger Name", 
                      trigger_type "Trigger Type",
                      table_owner "Table|Owner",
                      table_name "Table Name",
                      status
                 FROM dba_triggers
                WHERE trigger_name IN ( ''MTL_SYSTEM_ITEMS_T1'' ,
                                        ''MTL_SYSTEM_ITEMS_T1_BOM'' ,
                                        ''MTL_SYSTEM_ITEMS_T2'' ,
                                        ''MTL_SYSTEM_ITEMS_T2_BOM'' ,
                                        ''MTL_SYSTEM_ITEMS_T3_BOM'' ,
                                        ''MTL_SYSTEM_ITEMS_B_T2_IBE'' ,
                                        ''MTL_SYSTEM_ITEMS_B_T3_IBE'' ,
                                        ''MTL_SYSTEM_ITEMS_T4_BOM'' ,
                                        ''MTL_SYSTEM_ITEMS_T5_BOM'' ,
                                        ''MTL_SYSTEM_ITEMS_T6_BOM'' ,
                                        ''MTL_SYSTEM_ITEMS_TL_TA_IBE'' )
                ORDER BY trigger_name' ;

    l_number := Run_SQL( 'Seeded Triggers on MTL_SYSTEM_ITEMS_B and MTL_SYSTEM_ITEMS_TL', 
                         g_text, 'Y', NULL, 1 );

    RETURN l_number;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint(l_proc);
        RETURN -2;

END INV_Seeded_MSI_Triggers;

------------------------------------------------------------------------------
-- FUNCTION: INV_Custom_MSI_Triggers
-- DESCRIPTION:
--     Display the seeded triggers on tables MTL_SYSTEM_ITEMS_B and
--         MTL_SYSTEM_ITEMS_TL exist and are enabled
--     Following 10 Triggers on MSI_B and MSI_TL are seeded up to 11.5.8:
--         MTL_SYSTEM_ITEMS_B_T2_IBE
--         MTL_SYSTEM_ITEMS_B_T3_IBE
--         MTL_SYSTEM_ITEMS_T1
--         MTL_SYSTEM_ITEMS_T1_BOM
--         MTL_SYSTEM_ITEMS_T2_BOM
--         MTL_SYSTEM_ITEMS_T3_BOM
--         MTL_SYSTEM_ITEMS_T4_BOM
--         MTL_SYSTEM_ITEMS_T5_BOM
--         MTL_SYSTEM_ITEMS_T6_BOM
--         MTL_SYSTEM_ITEMS_TL_TA_IBE
-- Input:
--      Apps-Release. This is for future use, in case DEV releases
--                    new triggers only on specific versions of INV.
-- Return-Code:
--      Success: >0 No of custom triggers on MSIB and MSITL
--      Failure: -2 Unexpected Exception
-- USAGE:
--         INV_Custom_MSI_Triggers( apps_release );
-- USAGE-EXAMPLES: 
--         rc := INV_Custom_MSI_Triggers( '11.5.8' );
------------------------------------------------------------------------------
FUNCTION INV_Custom_MSI_Triggers ( p_apps_release IN VARCHAR2 )
RETURN NUMBER IS
    l_proc VARCHAR2(30) := 'INV_Custom_MSI_Triggers';
    l_number NUMBER;
BEGIN -- INV_Custom_MSI_Triggers

    g_text := 'SELECT owner, trigger_name "Trigger Name", 
                      trigger_type "Trigger Type",
                      table_owner "Table|Owner",
                      table_name "Table Name",
                      status
                 FROM dba_triggers
                WHERE table_name in ( ''MTL_SYSTEM_ITEMS_B'',
                                      ''MTL_SYSTEM_ITEMS_TL'' )
                  AND trigger_name NOT IN ( ''MTL_SYSTEM_ITEMS_T1'' ,
                                            ''MTL_SYSTEM_ITEMS_T1_BOM'' ,
                                            ''MTL_SYSTEM_ITEMS_T2'' ,
                                            ''MTL_SYSTEM_ITEMS_T2_BOM'' ,
                                            ''MTL_SYSTEM_ITEMS_T3_BOM'' ,
                                            ''MTL_SYSTEM_ITEMS_B_T2_IBE'' ,
                                            ''MTL_SYSTEM_ITEMS_B_T3_IBE'' ,
                                            ''MTL_SYSTEM_ITEMS_T4_BOM'' ,
                                            ''MTL_SYSTEM_ITEMS_T5_BOM'' ,
                                            ''MTL_SYSTEM_ITEMS_T6_BOM'' ,
                                            ''MTL_SYSTEM_ITEMS_TL_TA_IBE'' )
                ORDER BY trigger_name' ;

    l_number := Run_SQL( 'Custom Triggers on MTL_SYSTEM_ITEMS_B and MTL_SYSTEM_ITEMS_TL', 
                         g_text, 'Y', NULL, 1 );

    RETURN l_number;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint( l_proc, 'p_apps_release='||p_apps_release );
        RETURN -2;

END INV_Custom_MSI_Triggers;


------------------------------------------------------------------------------
-- FUNCTION: INV_Get_Acct_Period_ID
-- DESCRIPTION:
--      Return the Period_ID for given Period_Name and OrgID
-- Input:
--      p_period_name ( org_acct_periods.period_name )
--      p_org_id ( org_acct_periods.organization_id )
-- Return-Code:
--      Sucess: Period_ID
--      Warning:  0 Unknown Period Name
--      Failure: -2 Unexpected Exception
-- USAGE:
--      INV_Get_Acct_Period_ID( p_period_name , p_org_id )
-- USAGE-EXAMPLES: 
--      l_period_id:=INV_Get_Acct_Period_ID( 'Jul-03', 207 )
--                Get Period_ID for Period 'Jul-03' and Organization_ID 207
------------------------------------------------------------------------------
FUNCTION INV_Get_Acct_Period_ID ( p_period_name IN VARCHAR2 ,
                                  p_org_id IN NUMBER )
RETURN NUMBER IS
    l_proc VARCHAR2(30) := 'INV_Get_Acct_Period_ID';
    l_acct_period_id org_acct_periods.acct_period_id%TYPE;
BEGIN -- INV_Get_Acct_Period_ID

    SELECT acct_period_id
      INTO l_acct_period_id
      FROM org_acct_periods
     WHERE organization_id = p_org_id
       AND period_name = p_period_name ;

    RETURN l_acct_period_id;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            WarningPrint( 'The given Period Name ' || p_period_name || ' is invalid for Organization ' || INV_Get_Org_Code( p_org_id ) || '.');
            ActionWarningPrint( 'Please enter a valid Period Name');
            RAISE NO_DATA_FOUND;
            RETURN 0;
        WHEN OTHERS THEN
            -- This exception is not expected to occur
            Exception_ErrorPrint( l_proc, 'p_period_name='||p_period_name );
            RETURN -2;

END INV_Get_Acct_Period_ID;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Period_Info
-- DESCRIPTION:
--      Display Inventory Accounting Period information
--      for 1 specific period or multiple periods, depending on the
--      parameters that  are passed
--      IF p_adjacent='Y' then 3 periods are displayed.
--      Attention: p_adjacent='Y' requires period_id and org_id to be NOT NULL
--          
-- Input:
--        p_period_id ( ID or NULL )
--        p_org_id ( ID or NULL )
--        p_adjacent ( 'Y', 'N' ) 
-- Return-Code:
--        None
-- USAGE:
--        INV_Display_Period_Info( p_period_id, p_org_id, p_adjacent )
-- USAGE-EXAMPLES:
--        INV_Display_Period_Info( 1234, 207, 'Y' )
--            Display period 1234 in org 207 and adjacent periods .
--        INV_Display_Period_Info( 1234, 207, 'N' )
--            Display exactly period 1234 in org 207. No adjacent periods .
------------------------------------------------------------------------------
PROCEDURE INV_Display_Period_Info( p_org_id IN NUMBER
                                  ,p_period_id IN NUMBER 
                                  ,p_adjacent IN VARCHAR2 ) IS
    l_proc VARCHAR2(30) := 'INV_Display_Period_Info';
    l_start_date org_acct_periods.period_start_date%TYPE;
    l_schedule_close_date org_acct_periods.schedule_close_date%TYPE;
BEGIN -- INV_Display_Period_Info

    -- For performance reasons I intentionally do not use NVL,
    -- WHERE organization_id='|| NVL( p_org_id , 'organization_id' ||
    --   AND acct_period_id=' || NVL( p_period_id, 'acct_period_id' ;
    -- but build the select-string
    g_text := 'SELECT period_name "Period|Name"
                    , acct_period_id "Period|Id"
                    , organization_id "Organization|Id"
                    , TO_CHAR( period_start_date, ''DD-MON-YYYY'' ) "Start Date"
                    , TO_CHAR( period_close_date, ''DD-MON-YYYY'' ) "Close Date"
                    , TO_CHAR( schedule_close_date, ''DD-MON-YYYY'' ) "Scheduled|Close Date"
                    , open_flag "Open"
                    , description
                    , period_set_name "GL Period Set|Name"
                    , period_name "GL Period|Name"
                    , period_year "GL Period|Year"
                 FROM org_acct_periods
                WHERE 1 = 1 ' ;

    IF p_org_id IS NOT NULL AND p_adjacent ='N' THEN
        g_text := g_text || ' AND organization_id=' || p_org_id ;
    END IF;
 
    IF p_period_id IS NOT NULL AND p_adjacent ='N' THEN
        g_text := g_text || ' AND acct_period_id=' || p_period_id ;
    END IF;

    -- p_adjacent ='Y' requires p_org_id and p_period_id to be NOT NULL
    IF p_adjacent ='Y' THEN
        SELECT period_start_date, schedule_close_date
          INTO l_start_date, l_schedule_close_date
          FROM org_acct_periods
         WHERE organization_id= p_org_id
           AND acct_period_id= p_period_id ;

        g_text := g_text || ' AND organization_id=' || p_org_id || '
             AND (
                  acct_period_id='||p_period_id||'
                  OR
                  TO_CHAR(period_start_date, ''DD-MON-RR'')='''||TO_CHAR(l_schedule_close_date+1, 'DD-MON-RR' )||'''
                  OR
                  TO_CHAR(schedule_close_date, ''DD-MON-RR'')='''||TO_CHAR(l_start_date-1, 'DD-MON-RR' )||'''
                 )' ;
    END IF;
 
    g_text := g_text || ' ORDER BY organization_id, period_start_date' ;
 
    Run_SQL( 'Period Information', g_text, 'N', NULL, 0 );

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint(l_proc, 'p_org_id='||p_org_id||'/p_period_id='||p_period_id||'/p_adjacent='||p_adjacent);

END INV_Display_Period_Info;

------------------------------------------------------------------------------
-- FUNCTION: INV_Display_Invalid_Objects
-- DESCRIPTION:
--      Display invalid Invetory related Objects
-- Input:
--      None
-- Return-Code:
--      Sucess: Number of INV-related invalid DB-Objects
--      Failure: -2 Unexpected Exception
-- USAGE:
--      INV_Display_Invalid_Objects( )
-- USAGE-EXAMPLES: 
--      l_invalids:=INV_Display_Invalid_Objects( )
------------------------------------------------------------------------------
FUNCTION INV_Display_Invalid_Objects
RETURN NUMBER IS
    l_proc VARCHAR2(30) := 'INV_Display_Invalid_Objects';
BEGIN -- INV_Display_Invalid_Objects

    g_text := 'SELECT owner, object_name "Name", object_type "Type", 
                      status, last_ddl_time "Last Compile Date",
                      created "Creation Date"
                 FROM dba_objects
                WHERE status=''INVALID'' AND
       ( object_name LIKE ''INV%'' OR
         object_name LIKE ''MTL%'' OR
         object_name IN ( ''LOT_SPLIT_DATA_INSERT'' , ''ORG_FREIGHT_TL_PKG'' ,
                          ''PERIOD_SUMMARY_TRANSFER_UTIL'' , ''RMA_UPDATE'' ,
                          ''RMA_UPDATE'' , ''LOT_SPLIT_DATA_INSERT'',
                          ''SERIAL_CHECK'' , ''MISC_TRANSACTIONS_UTIL'',
                          ''USER_PKG_LOT'' )
       )
 ORDER BY object_name, object_type';

    v_rc := Run_SQL( 'Invalid Inventory Database Objects ', g_text, 'N', NULL, 0 );

    BRPrint;
    IF v_rc > 0 THEN
        NoticePrint( 'There are ' || v_rc || ' Invalid Database Objects related to Inventory.<BR>
Please run adadmin on the Database tier ( Option ''2. Compile APPS schema(s)'' to re-compile invalid Database Objects.<BR>
This requires applmgr privileges.' );
    ELSE
        Tab1Print( 'There are no Invalid Database Objects related to Inventory' );
    END IF;

    RETURN v_rc;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint(l_proc);
        RETURN -2;

END INV_Display_Invalid_Objects;

------------------------------------------------------------------------------
-- PROCEDURE: INV_Display_Debug_Trace_PO
-- DESCRIPTION:
--      Display all profiletions that have to do with debugging / tracing
-- Input:
--      None
-- Return-Code:
--      Sucess: Number of INV-related invalid DB-Objects
--      Failure: -2 Unexpected Exception
-- USAGE:
--      INV_Display_Invalid_Objects( )
-- USAGE-EXAMPLES: 
--      l_invalids:=INV_Display_Invalid_Objects( )
------------------------------------------------------------------------------
PROCEDURE INV_Display_Debug_Trace_PO IS
    l_proc VARCHAR2(30) := 'INV_Display_Debug_Trace_PO';
    l_number number;
BEGIN -- INV_Display_Debug_Trace_PO

    g_text := 'SELECT b.user_profile_option_name "Long Name"
                    , a.profile_option_name "Short Name"
                    , decode( c.level_id, 10001, ''Site''
                                        , 10002, ''Application''
                                        , 10003, ''Responsibility''
                                        , 10004, ''User''
                                        , ''Unknown'') "Level"
                    , decode( c.level_id, 10001, ''Site''
                                        , 10002, nvl(h.application_short_name,
                                                     to_char(c.level_value))
                                        , 10003, nvl(g.responsibility_name,
                                                     to_char(c.level_value))
                                        , 10004, nvl(e.user_name,
                                                     to_char(c.level_value))
                                        , ''Unknown'') "Level Value"
                    , c.PROFILE_OPTION_VALUE "Profile Value"
                    , to_char(c.LAST_UPDATE_DATE,''DD-MON-YYYY HH24:MI'') 
                      "Updated Date"
                    , nvl(d.user_name,to_char(c.last_updated_by)) "Updated By"
                 FROM fnd_profile_options a
                    , fnd_profile_options_vl b 
                    , fnd_profile_option_values c
                    , fnd_user d , fnd_user e
                    , fnd_responsibility_vl g
                    , fnd_application h
                WHERE a.profile_option_name = b.profile_option_name
                  AND a.profile_option_id = c.profile_option_id
                  AND a.application_id = c.application_id
                  AND c.last_updated_by = d.user_id (+)
                  AND c.level_value = e.user_id (+)
                  AND c.level_value = g.responsibility_id (+)
                  AND c.level_value = h.application_id (+)
                  AND a.profile_option_name IN (
                      ''AFLOG_ENABLED'' , ''AFLOG_FILENAME'' , ''AFLOG_LEVEL''
                    , ''AFLOG_MODULE'' 
                    , ''CONC_DEBUG'' , ''FND_AS_MSG_LEVEL_THRESHOLD''
                    , ''FLEXFIELDS:VALIDATE_ON_SERVER''
                    , ''FND_APPS_INIT_SQL'' , ''FND_INIT_SQL''
                    , ''INV_DEBUG_FILE'' , ''INV_DEBUG_LEVEL''
                    , ''INV_DEBUG_TRACE'' , ''MRP_DEBUG'' , ''MRP_TRACE''
                    , ''MWA_DEBUG_LEVEL'' , ''MWA_DEBUG_TRACE'' 
                    , ''OE_DEBUG_LEVEL'' , ''OE_DEBUG_LOG_DIRECTORY'' 
                    , ''OE_RPC_DEBUG_FLAGS'' , ''ONT_DEBUG_LEVEL''
                    , ''PO_SET_DEBUG_CONCURRENT_ON'' 
                    , ''PO_SET_DEBUG_WORKFLOW_ON'' , ''RCV_DEBUG_MODE'' 
                    , ''RCV_DEBUG_MODE'' , ''RCV_TP_MODE'' 
                    , ''SO_DEBUG'' , ''SO_DEBUG_TRACE'' 
                    , ''WSH_DEBUG_LOG_DIRECTORY'' , ''WSH_DEBUG_MODE''
                    )
           ORDER BY b.user_profile_option_name, c.level_id ' ;

    l_number := Run_SQL( 'Debug/Trace ProfileOptions ', g_text, 'N', NULL, 0 );

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint(l_proc);

END INV_Display_Debug_Trace_PO;



------------------------------------------------------------------------------
-- FUNCTION: INV_Display_utl_file_dir
-- DESCRIPTION:
--      Display the value of db-Parameter "utl_file_dir"  "max_dump_file_size"
--      This is displayed, so we can compare manually whether
--      values from e.g. INV_DEBUG_FILE is valid/matches utl_file_dir
--      In Addition, I check, whether the length of utl_file_dir is above 128
--      characters, because this might cause failures, because some 
--      packages only accpet 128 chars. 
--      E.g. IBEVWMMB.pls 115.5 / INVVICAB.pls 115.6
-- Input:
--      None
-- Return-Code:
--      Length of DB-Parameter UTL_FILE_DIR
-- USAGE:
--      rc:=INV_Display_utl_file_dir
-- USAGE-EXAMPLES: 
--      rc:=INV_Display_utl_file_dir
------------------------------------------------------------------------------
FUNCTION INV_Display_utl_file_dir RETURN NUMBER IS
    l_proc VARCHAR2(30) := 'INV_Display_utl_file_dir';
    l_length NUMBER ;
BEGIN -- INV_Display_utl_file_dir

    g_text := 'SELECT name, value
                 FROM v$parameter
                WHERE UPPER( name ) IN ( ''UTL_FILE_DIR'' 
                                       , ''MAX_DUMP_FILE_SIZE'' ) ';

    Run_SQL( 'Value of Database Parameter', g_text, 'N', NULL, 0 );

    -- Get the length of UTL_FILE_DIR value to check for length() > 128
    SELECT LENGTH( value ) 
      INTO l_length
      FROM v$parameter
     WHERE UPPER( name ) = 'UTL_FILE_DIR';

-- The DB-Parameter UTL_FILE_DIR contains more than 128 Characters. 
-- This might cause problems when activating DEBUG Functionality
    IF l_length > 128 THEN
        NoticePrint( 
        'The DB-Parameter UTL_FILE_DIR contains more than 128 Characters.
         This might cause problems when activating DEBUG Functionality' );
    END IF;

    RETURN l_length;

    EXCEPTION WHEN OTHERS THEN
        -- This exception is not expected to occur
        Exception_ErrorPrint(l_proc);

END INV_Display_utl_file_dir;

------------------------------------------------------------------------------
-- FUNCTION: INV_Get_Item_ID
-- DESCRIPTION:
--      Return the Inventory Item Id for given Item_number
--      Using mtl_item_flexfields to hanlde multi-segment ItemKFF
-- Input:
--      p_item_number ( mtl_item_flexfields.item_number )
--      p_org_id ( mtl_item_flexfields.organization_id )
-- Return-Code:
--      Sucess: inventory_item_id
--      Failure:  0 Invalid Item_Number
--      Failure: -2 Unexpected Exception
-- USAGE:
--      INV_Get_Item_ID( p_inventory_item_id, p_org_id )
-- USAGE-EXAMPLES: 
--      l_inventory_item_id:=INV_Get_Item_ID( 'A12345', 207 )
--                Get Inventory Item ID for Item_Number 'A12345' in Org 207
------------------------------------------------------------------------------
FUNCTION INV_Get_Item_ID ( p_item_number IN VARCHAR2 , p_org_id IN NUMBER )
RETURN NUMBER IS
    l_proc VARCHAR2(30) := 'INV_Get_Item_ID';
    l_number NUMBER;
    l_inventory_item_id mtl_item_flexfields.inventory_item_id%TYPE;
BEGIN -- INV_Get_Item_ID

    SELECT inventory_item_id
      INTO l_inventory_item_id
      FROM mtl_item_flexfields
     WHERE item_number = p_item_number
       AND organization_id = p_org_id ;

    RETURN l_inventory_item_id;

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            --ErrorPrint( 'The given Item_Number ' || p_item_number || ' is invalid.');
            --ActionErrorPrint( 'Type Ctrl-C <Enter> to exit the test. Rerun the test with a valid Item_Number.' );
            RETURN 0;

        WHEN OTHERS THEN
            -- This exception is not expected to occur
            Exception_ErrorPrint( l_proc, 'p_org_id='||p_org_id);
            RETURN -2;

end INV_Get_Item_ID;

------------------------------------------------------------------------------
-- FUNCTION: INV_Display_Item_Desc
-- DESCRIPTION:
--      Display Item_number, description and long_description for the
--      given ItemID. Also display the MLS values and language
--      We use mtl_item_flexfields to handle multi-segment Item KFFs
-- Input:
--      p_item_number ( mtl_item_flexfields.item_number )
--      p_org_id ( mtl_item_flexfields.organization_id )
-- Return-Code:
--      Sucess:   >0 ok = number of retrieved rows
--      Failure:  0 Invalid combination of ItemId/OrgId
--      Failure: -2 Unexpected Exception
-- USAGE:
--      INV_Display_Item_Desc( p_inventory_item_id, p_org_id )
-- USAGE-EXAMPLES: 
--      rc:=INV_Display_Item_Desc(( 54321, 207 )
--                Display Item-Number, Lngauge, description, long_descrption
--                for Item_ID 54321 in OrgID 207.
------------------------------------------------------------------------------
FUNCTION INV_Display_Item_Desc( 
                        p_item_id IN mtl_item_flexfields.inventory_item_id%TYPE 
                      , p_org_id IN mtl_item_flexfields.organization_id%TYPE )
RETURN NUMBER IS
    l_proc VARCHAR2(30) := 'INV_Display_Item_Desc';
    l_title VARCHAR2(80) ;
    l_inventory_item_id mtl_item_flexfields.inventory_item_id%TYPE;
BEGIN -- INV_Display_Item_Desc

    g_text := 'SELECT mif.item_number "Item Number"
                    , msitl.language "Language"
                    , msitl.description "Description"
                    , msitl.long_description "Long Description"
                 FROM mtl_item_flexfields mif , mtl_system_items_tl msitl
                WHERE mif.inventory_item_id = '|| p_item_id ||'
                  AND mif.inventory_item_id = msitl.inventory_item_id
                  AND mif.organization_id = '|| p_org_id ||'
                  AND mif.organization_id = msitl.organization_id
                ORDER BY msitl.long_description';

    l_title := 'Item Information for Item Id '||p_item_id||' in Organization '||INV_Get_Org_Code( p_org_id );

    RETURN( Run_SQL( l_title, g_text, 'N', NULL, 0 ) );

    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RETURN 0;

        WHEN OTHERS THEN
            -- This exception is not expected to occur
            Exception_ErrorPrint( l_proc, 'p_item_id='||p_item_id );
            RETURN -2;

END INV_Display_Item_Desc;
