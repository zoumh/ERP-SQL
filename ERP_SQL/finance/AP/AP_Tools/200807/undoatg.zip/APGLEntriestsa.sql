REM   $Header:  APGLEntriest.sql 1.1 [Last Modified Date  05-JUL-04] support $
REM   ========================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM    Oracle Support Services.  All rights reserved.
REM   ========================================================
REM    PURPOSE:		  Display AP GL Journal Entry Data.
REM    PRODUCT:  	  501 - Oracle Payables
REM    PRODUCT VERSIONS:  11.5
REM    PLATFORM:  	  Generic
REM    PARAMETERS:	  
REM    Headers Table - Enter the table name corresponding to the headers table to be analyzed. 	
REM		       The headers table entered must have the same columns as ap_ae_headers_all.
REM    Lines Table   - Enter the table name corresponding to the lines table to be analyzed. 	
REM		       The lines table entered must have the same columns as ap_ae_lines_all.
REM    GL Details    - Enter Y to display GL data corresponding to the lines being analyzed.
REM    Transferred Lines Only - Enter Y to display only lines that have been transferred.
REM                             Only transferred entries should require journal entries.	
REM    Summarized Data - Enter Y to display summarized accounting data.
REM                      Data will be summarized by transfer run id, period name, and account.
REM   =======================================================

REM   =======================================================
REM   USAGE: 	This script should be run in SQLplus in APPS Schema
REM   EXAMPLE: 	At the SQL prompt execute :   SQL>@c:\filepath\APGLEntriest.sql
REM   OUTPUT:   The script will create a spool file: APGLEntriesmmddhhmi.txt
REM   =======================================================

REM   =======================================================
REM   CHANGE HISTORY:
REM   DATE	Modifications (In order changes were made)
REM   24-MAR-04	shorgan	Created
REM   05-JUL-04 shorgan fix summary display 
REM   =======================================================

REM  ==============SQL PLUS Environment setup===================
set verify off
set echo off
set term on
set feedback off
set head off
set heading off
set autoprint off
set serveroutput on
set linesize 200

REM ============== Define SQL Variables for input parameters =============


REM ============ Spooling the output file====================


Prompt
Prompt Getting Accounting Data...
Prompt

define outputfilename = APGLEntriest&v_date..txt

spool  &outputfilename

set feedback off

Prompt Start Time
select to_char(sysdate, 'MM-DD-YYYY HH24:MI:SS') Time from sys.dual;
Prompt


REM =================Run the Pl/SQL api file ===================================

@@CoreApiTxtX.sql

begin  -- begin1

declare --declare 2

p_username varchar2(100);

p_respid number;

/* ------------------------ Declare Section -----------------------------*/

begin  --begin2

Show_Header('', 'APGLEntries');

/* -------------------- Execution secion ------------------------------- */

Declare  --declare 3

disp_lengths 		lengths;		
col_headers  		headers;

l_exception		exception;
l_error_msg		varchar2(500);
l_count 		NUMBER;
event_count 		NUMBER;
header_count		number;
l_tab1			varchar2(8);
line_count		number;
enc_line_count		number;
payment_count		number;
pmthist_count		number;
invdist_count		number;
selected_count 		number;
SqlTxt			varchar2(15000);
SqlTxt2			varchar2(15000);
SqlTxt3			varchar2(15000);
l_applversion		varchar2(10);
l_mrc_enabled		varchar2(10);
l_ax_enabled		varchar2(10);
l_ax_info		number;
l_cursor		integer;
l_counter		integer;
l_counter2		integer;
l_counter4		integer;
l_event_id		varchar2(50) := NULL;
ql_markers 		V2T;
ql_titles  		V2T;
l_tax_code_id		number := NULL;
l_vat_code		varchar2(50) := NULL;

--Custom API's

function object_test(object_test varchar2) return number is

	l_object_test 	number;

begin

l_object_test := 0;

select count(*) 
into l_object_test
from dba_objects
where object_name = upper(object_test);

return(l_object_test);

end object_test;

--end of custom API's


Begin  --begin 3


if:p_lines_table is not null then 


--Verify delete now parameters

l_count := 0;

select count(*)
into l_count
from sys.dual
where :p_gl_details in ('Y','N');

if l_count = 0 then

brprint;
errorprint('Invalid GL Details Parameter entered.');
actionerrorprint('Please enter Y or N.');

raise l_exception;


end if;

l_count := 0;

select count(*)
into l_count
from sys.dual
where :p_tran in ('Y','N');

if l_count = 0 then

brprint;
errorprint('Invalid Transferred lines only Parameter entered.');
actionerrorprint('Please enter Y or N.');

raise l_exception;


end if;


--Display table name created/used by this report

brprint;
sectionprint('Parameters Entered');
tab1print('Headers Table     :  '||:p_headers_table);
tab1print('Lines Table       :  '||:p_lines_table);
tab1print('GL Details        :  '||:p_gl_details);
tab1print('Tran Lines Only   :  '||:p_tran);
tab1print('Summarize Data    :  '||:p_rel_details);
tab1print('Encumbrance Lines :  '||:p_enc_lines);
tab1print('Max Rows          :  '||:p_max_rows);
brprint;


l_count :=0;
event_count :=0;
header_count := 0;
line_count := 0;
enc_line_count := 0;
payment_count := 0;
pmthist_count := 0;
invdist_count := 0;

--Verify table names entered exist

if :p_enc_lines <> 'Y' then

if object_test(:p_lines_table) = 0 then

BRPRINT;
errorprint(:p_lines_table||' Table Does not exist');
actionerrorprint('The table must exist to run this script.');

	raise l_exception;

else

		if Column_Exists(:p_lines_table,'gl_sl_link_id') = 'N' then

		brprint;

		errorprint('Lines Table:  '||:p_lines_table||' does not have a GL_SL_LINK_ID column');
		actionerrorprint('The lines table entered must have the same columns as ap_ae_lines_all.');

		raise l_exception;
	
	
		end if;

end if;

end if;


if :p_lines_table2 is null then

:p_lines_table2 := :p_lines_table;

end if;


if :p_enc_lines = 'Y' or :p_enc_lines2 = 'Y' then

if object_test(:p_lines_table2) = 0 then

BRPRINT;
errorprint(:p_lines_table2||' Table Does not exist');
actionerrorprint('The table must exist to run this script.');

	raise l_exception;

else

		if Column_Exists(:p_lines_table2,'encumbrance_line_id') = 'N' then

		brprint;

		errorprint('Lines Table:  '||:p_lines_table2||' does not have a ENCUMBRANCE_LINE_ID column');
		actionerrorprint('The lines table entered must have the same columns as ap_encumbrance_lines_all.');

		raise l_exception;
	
	
		end if;

end if;

end if;


if :p_lines_table2 <> :p_lines_table then 


if object_test(:p_lines_table) = 0 then

BRPRINT;
errorprint(:p_lines_table||' Table Does not exist');
actionerrorprint('The table must exist to run this script.');

	raise l_exception;

else


		if Column_Exists(:p_lines_table,'ae_line_id') = 'N' then

		brprint;

		errorprint('Lines Table:  '||:p_lines_table||' does not have a AE_LINE_ID column');
		actionerrorprint('The lines table entered must have the same columns as ap_ae_lines_all.');

		raise l_exception;
	
	
		end if;

end if;

end if;



if object_test(:p_headers_table) = 0 then

BRPRINT;
errorprint(:p_headers_table||' Table Does not exist');
actionerrorprint('The table must exist to run this script.');

	raise l_exception;

else

		if Column_Exists(:p_headers_table,'gl_transfer_run_id') = 'N' then

		brprint;

		errorprint('Headers Table:  '||:p_headers_table||' does not have a GL_TRANSFER_RUN_ID column');
		actionerrorprint('The headers table entered must have the same columns as ap_ae_headers_all');

		raise l_exception;
	
	
		end if;


end if;



--Verify tables entered have data

selected_count := 0;

sqlTxt3 := 'select count(*) from '||:p_lines_table;

execute immediate sqltxt3 into selected_count;

	if selected_count = 0 then 

BRPRINT;
errorprint('The Lines Table has 0 Rows');
actionerrorprint('The table must have rows to run this script.');

raise l_exception;
	
	end if;


selected_count := 0;

sqlTxt3 := 'select count(distinct ae_header_id) from '||:p_headers_table;

execute immediate sqltxt3 into selected_count;

	if selected_count = 0 then 

BRPRINT;
errorprint('The Headers Table has 0 Rows');
actionerrorprint('The table must have rows to run this script.');

raise l_exception;
	
	end if;

if :p_rel_details <> 'Y' then

brprint;
tab0print('==================================================================================');
tab0print('This section will show the details for the lines from the lines table entered.');
tab0print('If GL Details selected, GL data will be displayed.');
tab0print('==================================================================================');
brprint;

if :p_enc_lines <> 'Y' then 

sqlTxt := 'select distinct '
 ||' substr(''APD:'',1,4) src, substr(ael.gl_sl_link_id,1,10) link_id,   '
 ||' substr(ael.accounted_dr,1,15) ACCT_DR, substr(ael.accounted_cr,1,15) ACCT_CR, '
 ||' substr(ael.entered_dr,1,15) ENT_DR, substr(ael.entered_cr,1,15) ENT_CR, '
 ||' substr(aeh.set_of_books_id,1,3) sob, substr(to_char(aeh.accounting_date),1,11) atg_date, substr(aeh.gl_transfer_run_id,1,6) run_id,  '
 ||' substr(aeh.gl_transfer_flag,1,1) g, substr(ael.code_combination_id,1,10) CCID, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) account,  '
 ||' substr(aeh.accounting_event_id,1,10) event_id, substr(aeh.ae_header_id,1,10) header_id, substr(ael.ae_line_number,1,6) lineno, '
 ||' substr(ael.currency_code,1,3) cur,  '
 ||' substr(ael.reference2,1,10) Invoice_id, '
 ||' substr(ael.ae_line_type_code,1,10) Line_Type, '
 ||' substr(xla.gl_transfer_mode,1,1) t,'
 ||' substr('' '',1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid'
 ||' FROM  gl_code_combinations glc, xla_gl_transfer_batches_all '
 ||' xla, '||:p_lines_table||' ael, '||:p_headers_table||' aeh,'
 ||' '||:p_event_table2
 ||' gl_sets_of_books gsob '
 ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id '
 ||' '||:p_where_c  
 ||' and     ael.code_combination_id = glc.code_combination_id(+) '
 ||' and   ael.ae_header_id = aeh.ae_header_id '
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
 ||' UNION '
 ||' select distinct '
 ||' substr(''APS:'',1,4) src, substr(ael.gl_sl_link_id,1,10) link_id,  '
 ||' substr(glk.ACCT_DR,1,15) ACCT_DR, substr(glk.ACCT_CR,1,15) ACCT_CR,  '
 ||' substr(glk.ENT_DR,1,15) ENT_DR, substr(glk.ENT_CR,1,15) ENT_CR, '
 ||' substr(aeh.set_of_books_id,1,3) sob, substr('' '',1,11) atg_date, substr(aeh.gl_transfer_run_id,1,6) run_id,  '
 ||' substr(aeh.gl_transfer_flag,1,1) g, substr(ael.code_combination_id,1,10) CCID, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) account,  '
 ||' substr('' '',1,10) event_id, substr('' '',1,10) header_id, substr('' '',1,6) lineno,' 
 ||' substr(ael.currency_code,1,3) cur,  '
 ||' substr('' '',1,10) Invoice_id, '
 ||' substr('' '',1,10) Line_Type, '
 ||' substr(xla.gl_transfer_mode,1,1) t,'
 ||' substr('' '',1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid'
 ||' FROM  (select nvl(ael9.gl_sl_link_id,-5) gl_sl_link_id, sum(ael9.accounted_dr) ACCT_DR, sum(ael9.accounted_cr) ACCT_CR,  '
 ||' sum(ael9.entered_dr) ENT_DR, sum(ael9.entered_cr) ENT_CR '
 ||' from (select * from ap_ae_lines_all UNION select * from '||:p_lines_table||') ael9'
 ||' group by nvl(ael9.gl_sl_link_id,-5)) glk, '
 ||' gl_code_combinations glc, xla_gl_transfer_batches_all '
 ||' xla, '||:p_lines_table||' ael, '||:p_headers_table||' aeh, '
 ||' '||:p_event_table2
 ||' gl_sets_of_books gsob '
 ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id '
 ||' '||:p_where_c  
 ||' and   glk.gl_sl_link_id = nvl(ael.gl_sl_link_id,-5) '
 ||' and     ael.code_combination_id = glc.code_combination_id(+) '
 ||' and   ael.ae_header_id = aeh.ae_header_id '
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
 ||' and '''||:p_gl_details||''' = ''Y'' '
 ||' and xla.gl_transfer_mode <> ''D'' '
 ||' Union '
 ||' select distinct '
 ||' substr(''GLD:'',1,4) src, substr(ael.gl_sl_link_id,1,10) link_id,  '
 ||' substr(gjl.accounted_dr,1,15) ACCT_DR, substr(gjl.accounted_cr,1,15) ACCT_CR, '
 ||' substr(gjl.entered_dr,1,15) ENT_DR, substr(gjl.entered_cr,1,15) ENT_CR, '
 ||' substr(gjl.set_of_books_id,1,3) sob, substr(to_char(gjl.effective_date),1,11) atg_date, substr(aeh.gl_transfer_run_id,1,6) run_id,  '
 ||' substr(aeh.gl_transfer_flag,1,1) g, substr(gjl.code_combination_id,1,10) CCID, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) account,  '
 ||' substr('' '',1,10) event_id, substr(gjl.je_header_id,1,10) header_id, substr(gjl.je_line_num,1,6) lineno, '
 ||' substr(glh.currency_code,1,3) cur, '
 ||' substr(gjl.reference_2,1,10) Invoice_id, '
 ||' substr(gjl.line_type_code,1,10) Line_Type, '
 ||' substr(xla.gl_transfer_mode,1,1) t,'
 ||' substr(glb.name,1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid '
 ||' FROM gl_je_lines gjl, gl_import_references gir,  '
 ||' gl_je_headers glh, gl_code_combinations glc, gl_je_batches '
 ||' glb, '||:p_lines_table||' ael, '||:p_headers_table||' aeh,'
 ||' xla_gl_transfer_batches_all xla, '
 ||' '||:p_event_table2
 ||' gl_sets_of_books gsob '
 ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id '
 ||' '||:p_where_c  
 ||' and     gjl.code_combination_id = glc.code_combination_id(+) '
 ||' and     glb.je_batch_id = gir.je_batch_id '  
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and   ael.ae_header_id = aeh.ae_header_id'
 ||' and   gir.gl_sl_link_id = ael.gl_sl_link_id '
 ||' and     gir.GL_SL_LINK_TABLE = ''APECL'' '
 ||' and     gjl.je_header_id = glh.je_header_id '
 ||' and   gjl.je_line_num = gir.je_line_num '
 ||' and   gjl.je_header_id = gir.je_header_id '
 ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
 ||' and '''||:p_gl_details||''' = ''Y'' '
  ||' Union '
  ||' select distinct '
  ||' substr(''GLI:'',1,4) src, substr(ael.gl_sl_link_id,1,10) link_id,  '
  ||' substr(gjl.accounted_dr,1,15) ACCT_DR, substr(gjl.accounted_cr,1,15) ACCT_CR, '
  ||' substr(gjl.entered_dr,1,15) ENT_DR, substr(gjl.entered_cr,1,15) ENT_CR, '
  ||' substr(gjl.set_of_books_id,1,3) sob, substr(to_char(gjl.accounting_date),1,11) atg_date, substr(aeh.gl_transfer_run_id,1,6) run_id,  '
  ||' substr(aeh.gl_transfer_flag,1,1) g, substr(gjl.code_combination_id,1,10) CCID, '
  ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) account,  '
  ||' substr('' '',1,10) event_id, substr(gjl.je_header_id,1,10) header_id, substr(gjl.je_line_num,1,6) lineno, '
  ||' substr(gjl.currency_code,1,3) cur, '
  ||' substr(gjl.reference22,1,10) Invoice_id, '
  ||' substr(gjl.reference30,1,10) Line_Type, '
  ||' substr(xla.gl_transfer_mode,1,1) t,'
  ||' substr('' '',1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid'
  ||' FROM  gl_code_combinations glc, '
  ||' gl_interface gjl , '||:p_lines_table||' ael, '||:p_headers_table||' aeh,'
  ||' xla_gl_transfer_batches_all xla, '
  ||' '||:p_event_table2
  ||' gl_sets_of_books gsob '
  ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id '
  ||' '||:p_where_c  
  ||' and     gjl.code_combination_id = glc.code_combination_id(+) '
  ||' and   ael.ae_header_id = aeh.ae_header_id'
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and   gjl.gl_sl_link_id = ael.gl_sl_link_id '
  ||' and     gjl.GL_SL_LINK_TABLE = ''APECL'' '
  ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
  ||' and '''||:p_gl_details||''' = ''Y'' '
  ||' order by 21,2,1';

disp_lengths := lengths(4,10,15,15,15,15,3,11,6,1,10,35,10,10,6,3,10,10,1,30,5);

RUN_SQL('Detail Accounting Entries', sqltxt,disp_lengths,col_headers,:p_max_rows);

end if;

if :p_enc_lines = 'Y' or :p_enc_lines2 = 'Y' then

sqlTxt := 'select distinct '
 ||' substr(''APD:'',1,4) src, substr(ael.gl_sl_link_id,1,10) link_id,   '
 ||' substr(ael.accounted_dr,1,15) ACCT_DR, substr(ael.accounted_cr,1,15) ACCT_CR, '
 ||' substr('' '',1,15) ENT_DR, substr('' '',1,15) ENT_CR, '
 ||' substr(aeh.set_of_books_id,1,3) sob, substr(to_char(aeh.accounting_date),1,11) atg_date, substr(aeh.gl_transfer_run_id,1,6) run_id,  '
 ||' substr(aeh.gl_transfer_flag,1,1) g, substr(ael.code_combination_id,1,10) CCID, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) account,  '
 ||' substr(aeh.accounting_event_id,1,10) event_id, substr(aeh.ae_header_id,1,10) header_id, substr(ael.encumbrance_line_id,1,6) lineno, '
 ||' substr(gsob.currency_code,1,3) cur,  '
 ||' substr(ael.reference2,1,10) Invoice_id, '
 ||' substr(ael.encumbrance_line_type,1,10) Line_Type, '
 ||' substr(xla.gl_transfer_mode,1,1) t,'
 ||' substr('' '',1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid'
 ||' FROM  gl_code_combinations glc, xla_gl_transfer_batches_all '
 ||' xla, '||:p_lines_table2||' ael, '||:p_headers_table||' aeh,'
 ||' '||:p_event_table2
 ||' gl_sets_of_books gsob '
 ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id '
 ||' '||:p_where_c  
 ||' and     ael.code_combination_id = glc.code_combination_id(+) '
 ||' and   ael.ae_header_id = aeh.ae_header_id '
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
 ||' UNION '
 ||' select distinct '
 ||' substr(''APS:'',1,4) src, substr(ael.gl_sl_link_id,1,10) link_id,  '
 ||' substr(glk.ACCT_DR,1,15) ACCT_DR, substr(glk.ACCT_CR,1,15) ACCT_CR,  '
 ||' substr('' '',1,15) ENT_DR, substr('' '',1,15) ENT_CR,  '
 ||' substr(aeh.set_of_books_id,1,3) sob, substr('' '',1,11) atg_date, substr(aeh.gl_transfer_run_id,1,6) run_id,  '
 ||' substr(aeh.gl_transfer_flag,1,1) g, substr(ael.code_combination_id,1,10) CCID, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) account,  '
 ||' substr('' '',1,10) event_id, substr('' '',1,10) header_id, substr('' '',1,6) lineno,' 
 ||' substr(gsob.currency_code,1,3) cur,  '
 ||' substr('' '',1,10) Invoice_id, '
 ||' substr('' '',1,10) Line_Type, '
 ||' substr(xla.gl_transfer_mode,1,1) t,'
 ||' substr('' '',1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid'
 ||' FROM  (select nvl(ael9.gl_sl_link_id,-5) gl_sl_link_id, sum(ael9.accounted_dr) ACCT_DR, sum(ael9.accounted_cr) ACCT_CR'
 ||' from (select * from ap_encumbrance_lines_all UNION select * from '||:p_lines_table2||') ael9'
 ||' group by nvl(ael9.gl_sl_link_id,-5)) glk, '
 ||' gl_code_combinations glc, xla_gl_transfer_batches_all '
 ||' xla, '||:p_lines_table2||' ael, '||:p_headers_table||' aeh, '
 ||' '||:p_event_table2
 ||' gl_sets_of_books gsob '
 ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id '
 ||' '||:p_where_c  
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and   glk.gl_sl_link_id = nvl(ael.gl_sl_link_id,-5) '
 ||' and     ael.code_combination_id = glc.code_combination_id(+) '
 ||' and   ael.ae_header_id = aeh.ae_header_id '
 ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
 ||' and '''||:p_gl_details||''' = ''Y'' '
 ||' and xla.gl_transfer_mode <> ''D'' '
 ||' Union '
 ||' select distinct '
 ||' substr(''GLD:'',1,4) src, substr(ael.gl_sl_link_id,1,10) link_id,  '
 ||' substr(gjl.accounted_dr,1,15) ACCT_DR, substr(gjl.accounted_cr,1,15) ACCT_CR, '
 ||' substr(gjl.entered_dr,1,15) ENT_DR, substr(gjl.entered_cr,1,15) ENT_CR, '
 ||' substr(gjl.set_of_books_id,1,3) sob, substr(to_char(gjl.effective_date),1,11) atg_date, substr(aeh.gl_transfer_run_id,1,6) run_id,  '
 ||' substr(aeh.gl_transfer_flag,1,1) g, substr(gjl.code_combination_id,1,10) CCID, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) account,  '
 ||' substr('' '',1,10) event_id, substr(gjl.je_header_id,1,10) header_id, substr(gjl.je_line_num,1,6) lineno, '
 ||' substr(glh.currency_code,1,3) cur, '
 ||' substr(gjl.reference_2,1,10) Invoice_id, '
 ||' substr(gjl.line_type_code,1,10) Line_Type, '
 ||' substr(xla.gl_transfer_mode,1,1) t,'
 ||' substr(glb.name,1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid '
 ||' FROM gl_je_lines gjl, gl_import_references gir,  '
 ||' gl_je_headers glh, gl_code_combinations glc, gl_je_batches '
 ||' glb, '||:p_lines_table2||' ael, '||:p_headers_table||' aeh,'
 ||' xla_gl_transfer_batches_all xla, '
 ||' '||:p_event_table2
 ||' gl_sets_of_books gsob '
 ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id '
 ||' '||:p_where_c  
 ||' and     gjl.code_combination_id = glc.code_combination_id(+) '
 ||' and     glb.je_batch_id = gir.je_batch_id '  
 ||' and   ael.ae_header_id = aeh.ae_header_id'
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and   gir.gl_sl_link_id = ael.gl_sl_link_id '
 ||' and     gir.GL_SL_LINK_TABLE = ''APENCL'' '
 ||' and     gjl.je_header_id = glh.je_header_id '
 ||' and   gjl.je_line_num = gir.je_line_num '
 ||' and   gjl.je_header_id = gir.je_header_id '
 ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
 ||' and '''||:p_gl_details||''' = ''Y'' '
  ||' Union '
  ||' select distinct '
  ||' substr(''GLI:'',1,4) src, substr(ael.gl_sl_link_id,1,10) link_id,  '
  ||' substr(gjl.accounted_dr,1,15) ACCT_DR, substr(gjl.accounted_cr,1,15) ACCT_CR, '
  ||' substr(gjl.entered_dr,1,15) ENT_DR, substr(gjl.entered_cr,1,15) ENT_CR, '
  ||' substr(gjl.set_of_books_id,1,3) sob, substr(to_char(gjl.accounting_date),1,11) atg_date, substr(aeh.gl_transfer_run_id,1,6) run_id,  '
  ||' substr(aeh.gl_transfer_flag,1,1) g, substr(gjl.code_combination_id,1,10) CCID, '
  ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) account,  '
  ||' substr('' '',1,10) event_id, substr(gjl.je_header_id,1,10) header_id, substr(gjl.je_line_num,1,6) lineno, '
  ||' substr(gjl.currency_code,1,3) cur, '
  ||' substr(gjl.reference22,1,10) Invoice_id, '
  ||' substr(gjl.reference30,1,10) Line_Type, '
  ||' substr(xla.gl_transfer_mode,1,1) t,'
  ||' substr('' '',1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid'
  ||' FROM  gl_code_combinations glc, '
  ||' gl_interface gjl , '||:p_lines_table2||' ael, '||:p_headers_table||' aeh,'
  ||' xla_gl_transfer_batches_all xla, '
  ||' '||:p_event_table2
  ||' gl_sets_of_books gsob '
  ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id '
  ||' '||:p_where_c  
  ||' and     gjl.code_combination_id = glc.code_combination_id(+) '
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and   ael.ae_header_id = aeh.ae_header_id'
  ||' and   gjl.gl_sl_link_id = ael.gl_sl_link_id '
  ||' and     gjl.GL_SL_LINK_TABLE = ''APENCL'' '
  ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
  ||' and '''||:p_gl_details||''' = ''Y'' '
  ||' order by 21,2,1';

disp_lengths := lengths(4,10,15,15,15,15,3,11,6,1,10,35,10,10,6,3,10,10,1,30,5);


RUN_SQL('Detail Encumbrance Accounting Entries', sqltxt,disp_lengths,col_headers,:p_max_rows);

end if;



	  
else


tab0print('==================================================================================');
tab0print('This section will show the summarized data corresponding to the lines from the lines table entered.');
tab0print('==================================================================================');
brprint;

if :p_enc_lines <> 'Y' then

sqlTxt := 'select substr(''APD:'',1,4) src, '
 ||' substr(sum(ael.accounted_dr),1,15) ACCT_DR, substr(sum(ael.accounted_cr),1,15) ACCT_CR,  '
 ||' substr(sum(ael.entered_dr),1,15) ENT_DR, substr(sum(ael.entered_cr),1,15) ENT_CR,  '
 ||' substr(aeh.set_of_books_id,1,3) sob, substr(to_char(aeh.period_name),1,11) per_name, substr(aeh.gl_transfer_run_id,1,6) run_id,   '
 ||' substr(aeh.gl_transfer_flag,1,1) g, substr(ael.code_combination_id,1,10) CCID,  '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) account,   '
 ||' substr(ael.ae_line_type_code,1,10) Line_Type, '
 ||' substr(ael.currency_code,1,3) cur,   '
 ||' substr(xla.gl_transfer_mode,1,1) t, '
 ||' substr('' '',1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid'
 ||' FROM  gl_code_combinations glc, xla_gl_transfer_batches_all  '
 ||' xla, '||:p_lines_table||' ael, '||:p_headers_table||' aeh, '
 ||' '||:p_event_table2
 ||' gl_sets_of_books gsob  '
 ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id  '
 ||' '||:p_where_c  
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and     ael.code_combination_id = glc.code_combination_id(+)  '
 ||' and   ael.ae_header_id = aeh.ae_header_id  '
 ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
 ||' group by aeh.org_id, aeh.set_of_books_id, aeh.period_name, aeh.gl_transfer_run_id, aeh.gl_transfer_flag, ael.code_combination_id, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) ,   '
 ||' substr(ael.ae_line_type_code,1,10), ael.currency_code, xla.gl_transfer_mode, substr('' '',1,30) '
 ||' UNION '
 ||' select substr(''APS:'',1,4) src, '
 ||' substr(sum(glk.acct_dr),1,15) ACCT_DR, substr(sum(glk.acct_cr),1,15) ACCT_CR,  '
 ||' substr(sum(glk.ent_dr),1,15) ENT_DR, substr(sum(glk.ent_cr),1,15) ENT_CR,  '
 ||' substr(ael.set_of_books_id,1,3) sob, substr(to_char(ael.period_name),1,11) per_name, substr(ael.gl_transfer_run_id,1,6) run_id,   '
 ||' substr(ael.gl_transfer_flag,1,1) g, substr(ael.code_combination_id,1,10) CCID,  '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) account,   '
 ||' substr('' '',10) Line_Type, '
 ||' substr(ael.currency_code,1,3) cur,   '
 ||' substr(xla.gl_transfer_mode,1,1) t, '
 ||' substr('' '',1,30) gl_batch_name, substr(ael.org_id, 1,5) orgid'
 ||'  FROM  (select distinct nvl(ael9.gl_sl_link_id,-5) gl_sl_link_id, sum(ael9.accounted_dr) ACCT_DR, sum(ael9.accounted_cr) ACCT_CR,   '
 ||'  sum(ael9.entered_dr) ENT_DR, sum(ael9.entered_cr) ENT_CR  '
 ||'  from (select *'
 ||'       from ap_ae_lines_all ael7'
 ||'       where exists'
 ||'       (select 1 from '||:p_lines_table||' ael8 where ael8.gl_sl_link_id = ael7.gl_sl_link_id)'
 ||'       UNION select * from '||:p_lines_table||') ael9 '
 ||'  group by nvl(ael9.gl_sl_link_id,-5)) glk,  '
 ||'  gl_code_combinations glc, xla_gl_transfer_batches_all  '
 ||'  xla,  '
 ||'   (select distinct gl_transfer_run_id, aeh.gl_transfer_flag, gl_sl_link_id, '
 ||'  period_name, set_of_books_id, aeh.org_id, ael.code_combination_id, ael.currency_code '
 ||'  from '||:p_lines_table||' ael, '
 ||' '||:p_event_table2
 ||' '||:p_headers_table||' aeh '
 ||'  where aeh.ae_header_id = ael.ae_header_id '
 ||' '||:p_where_c  
 ||'  ) ael,  '
 ||'  gl_sets_of_books gsob  '
 ||'   WHERE   gsob.set_of_books_id = ael.set_of_books_id  '
 ||'   and   glk.gl_sl_link_id = nvl(ael.gl_sl_link_id,-5)  '
 ||' and '''||:p_gl_details||''' = ''Y'' '
 ||' and xla.gl_transfer_mode <> ''D'' '
 ||' and  ael.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', ael.gl_transfer_flag)'
 ||'   and     ael.code_combination_id = glc.code_combination_id(+)  '
 ||'   and  xla.gl_transfer_run_id(+) = ael.gl_transfer_run_id  '
 ||' group by ael.org_id, ael.set_of_books_id, ael.period_name, ael.gl_transfer_run_id, ael.gl_transfer_flag, ael.code_combination_id, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) ,   '
 ||' substr('' '',10), ael.currency_code, xla.gl_transfer_mode, substr('' '',1,30) '
 ||' UNION '
 ||' select substr(''GLD:'',1,4) src, '
 ||' substr(sum(gjl.accounted_dr),1,15) ACCT_DR, substr(sum(gjl.accounted_cr),1,15) ACCT_CR,  '
 ||' substr(sum(gjl.entered_dr),1,15) ENT_DR, substr(sum(gjl.entered_cr),1,15) ENT_CR,  '
 ||' substr(gsob.set_of_books_id,1,3) sob, substr(to_char(glh.period_name),1,11) per_name, substr(ael.gl_transfer_run_id,1,6) run_id,   '
 ||' substr(ael.gl_transfer_flag,1,1) g, substr(gjl.code_combination_id,1,10) CCID,  '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) account,   '
 ||' substr('' '',10) Line_Type, '
 ||' substr(glh.currency_code,1,3) cur,   '
 ||' substr(xla.gl_transfer_mode,1,1) t, '
 ||' substr(glb.name,1,30) gl_batch_name, substr(ael.org_id, 1,5) orgid '
 ||'  FROM gl_je_lines gjl, gl_import_references gir,   '
 ||'  gl_je_headers glh, gl_code_combinations glc, gl_je_batches  '
 ||'  glb,  '
 ||'  (select distinct gl_transfer_run_id, aeh.gl_transfer_flag, gl_sl_link_id, '
 ||'  period_name, set_of_books_id,aeh.org_id   '
 ||'  from '||:p_lines_table||' ael, '
 ||' '||:p_event_table2
 ||' '||:p_headers_table||' aeh '
 ||'  where aeh.ae_header_id = ael.ae_header_id '
 ||' '||:p_where_c  
 ||'  ) ael, '
 ||'  xla_gl_transfer_batches_all xla, gl_sets_of_books gsob  '
 ||'  WHERE   gsob.set_of_books_id = ael.set_of_books_id  '
 ||'  and     gjl.code_combination_id = glc.code_combination_id(+)  '
 ||' and  ael.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', ael.gl_transfer_flag)'
 ||'  and     glb.je_batch_id = gir.je_batch_id  '
 ||'  and   gir.gl_sl_link_id = ael.gl_sl_link_id  '
 ||'  and     gir.GL_SL_LINK_TABLE = ''APECL'' '
 ||'  and     gjl.je_header_id = glh.je_header_id  '
 ||'  and   gjl.je_line_num = gir.je_line_num  '
 ||'  and   gjl.je_header_id = gir.je_header_id  '
 ||'  and '''||:p_gl_details||''' = ''Y'' '
 ||'  and  xla.gl_transfer_run_id(+) = ael.gl_transfer_run_id  '
 ||' group by ael.org_id, gsob.set_of_books_id, glh.period_name, ael.gl_transfer_run_id, ael.gl_transfer_flag, gjl.code_combination_id, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) ,   '
 ||' substr('' '',10), glh.currency_code, xla.gl_transfer_mode, substr(glb.name,1,30) '
 ||' UNION '
 ||' select distinct substr(''GLI:'',1,4) src, '
 ||' substr(sum(gjl.accounted_dr),1,15) ACCT_DR, substr(sum(gjl.accounted_cr),1,15) ACCT_CR,  '
 ||' substr(sum(gjl.entered_dr),1,15) ENT_DR, substr(sum(gjl.entered_cr),1,15) ENT_CR,  '
 ||' substr(gsob.set_of_books_id,1,3) sob, substr(to_char(ael.period_name),1,11) per_name, substr(ael.gl_transfer_run_id,1,6) run_id,   '
 ||' substr(ael.gl_transfer_flag,1,1) g, substr(gjl.code_combination_id,1,10) CCID,  '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) account,   '
 ||' substr('' '',1,10) Line_Type, '
 ||' substr(gjl.currency_code,1,3) cur,   '
 ||' substr(xla.gl_transfer_mode,1,1) t, '
 ||' substr('' '',1,30) gl_batch_name, substr(ael.org_id, 1,5) orgid'
 ||'    FROM  gl_code_combinations glc,  '
 ||'    gl_interface gjl ,  '
 ||'     (select distinct gl_transfer_run_id, aeh.gl_transfer_flag, gl_sl_link_id, '
 ||'  period_name, set_of_books_id, aeh.org_id   '
 ||'  from '||:p_lines_table||' ael, '
 ||' '||:p_event_table2
 ||' '||:p_headers_table||' aeh'
 ||'  where aeh.ae_header_id = ael.ae_header_id '
 ||' '||:p_where_c  
 ||'  ) ael, '
 ||'    xla_gl_transfer_batches_all xla, gl_sets_of_books gsob  '
 ||'    WHERE   gsob.set_of_books_id = ael.set_of_books_id  '
 ||'    and     gjl.code_combination_id = glc.code_combination_id(+)  '
 ||' and  ael.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', ael.gl_transfer_flag)'
 ||'   and   gjl.gl_sl_link_id = ael.gl_sl_link_id  '
 ||'    and     gjl.GL_SL_LINK_TABLE = ''APECL'' '
 ||'    and  xla.gl_transfer_run_id(+) = ael.gl_transfer_run_id '
 ||' and '''||:p_gl_details||''' = ''Y'' '
 ||' group by ael.org_id, gsob.set_of_books_id, ael.period_name, ael.gl_transfer_run_id, ael.gl_transfer_flag, gjl.code_combination_id, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) ,   '
 ||' substr('' '',10), gjl.currency_code, xla.gl_transfer_mode, substr('' '',1,30) '
 ||' order by 16,8,10,7,1';

disp_lengths := lengths(4,15,15,15,15,3,11,6,1,10,35,10,3,1,30,5);

RUN_SQL('Summary Accounting Entries', sqltxt,disp_lengths,col_headers,:p_max_rows);

end if;

if :p_enc_lines = 'Y' or :p_enc_lines2 = 'Y' then

sqlTxt := 'select substr(''APD:'',1,4) src, '
 ||' substr(sum(ael.accounted_dr),1,15) ACCT_DR, substr(sum(ael.accounted_cr),1,15) ACCT_CR,  '
 ||' substr('' '',1,15) ENT_DR, substr('' '',1,15) ENT_CR,  '
 ||' substr(aeh.set_of_books_id,1,3) sob, substr(to_char(aeh.period_name),1,11) per_name, substr(aeh.gl_transfer_run_id,1,6) run_id,   '
 ||' substr(aeh.gl_transfer_flag,1,1) g, substr(ael.code_combination_id,1,10) CCID,  '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) account,   '
 ||' substr(ael.encumbrance_line_type,1,10) Line_Type, '
 ||' substr(gsob.currency_code,1,3) cur,   '
 ||' substr(xla.gl_transfer_mode,1,1) t, '
 ||' substr('' '',1,30) gl_batch_name, substr(aeh.org_id, 1,5) orgid'
 ||' FROM  gl_code_combinations glc, xla_gl_transfer_batches_all  '
 ||' xla, '||:p_lines_table2||' ael, '||:p_headers_table||' aeh, '
 ||' '||:p_event_table2
 ||' gl_sets_of_books gsob  '
 ||' WHERE   gsob.set_of_books_id = aeh.set_of_books_id  '
 ||' '||:p_where_c  
 ||' and     ael.code_combination_id = glc.code_combination_id(+)  '
 ||' and  aeh.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', aeh.gl_transfer_flag)'
 ||' and   ael.ae_header_id = aeh.ae_header_id  '
 ||' and  xla.gl_transfer_run_id(+) = aeh.gl_transfer_run_id '
 ||' group by aeh.org_id, aeh.set_of_books_id, aeh.period_name, aeh.gl_transfer_run_id, aeh.gl_transfer_flag, ael.code_combination_id, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) ,   '
 ||' substr(ael.encumbrance_line_type,1,10), gsob.currency_code, xla.gl_transfer_mode, substr('' '',1,30) '
 ||' UNION '
 ||' select substr(''APS:'',1,4) src, '
 ||' substr(sum(glk.acct_dr),1,15) ACCT_DR, substr(sum(glk.acct_cr),1,15) ACCT_CR,  '
 ||' substr('' '',1,15) ENT_DR, substr('' '',1,15) ENT_CR,  '
 ||' substr(ael.set_of_books_id,1,3) sob, substr(to_char(ael.period_name),1,11) per_name, substr(ael.gl_transfer_run_id,1,6) run_id,   '
 ||' substr(ael.gl_transfer_flag,1,1) g, substr(ael.code_combination_id,1,10) CCID,  '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) account,   '
 ||' substr('' '',10) Line_Type, '
 ||' substr(gsob.currency_code,1,3) cur,   '
 ||' substr(xla.gl_transfer_mode,1,1) t, '
 ||' substr('' '',1,30) gl_batch_name, substr(ael.org_id, 1,5) orgid'
 ||'  FROM  (select distinct nvl(ael9.gl_sl_link_id,-5) gl_sl_link_id, sum(ael9.accounted_dr) ACCT_DR, sum(ael9.accounted_cr) ACCT_CR   '
 ||'  from (select *'
 ||'       from ap_encumbrance_lines_all ael7'
 ||'       where exists'
 ||'       (select 1 from '||:p_lines_table2||' ael8 where ael8.gl_sl_link_id = ael7.gl_sl_link_id)'
 ||'       UNION select * from '||:p_lines_table2||') ael9 '
 ||'  group by nvl(ael9.gl_sl_link_id,-5)) glk,  '
 ||'  gl_code_combinations glc, xla_gl_transfer_batches_all  '
 ||'  xla,  '
 ||'   (select distinct gl_transfer_run_id, aeh.gl_transfer_flag, gl_sl_link_id, '
 ||'  aeh.period_name, set_of_books_id, aeh.org_id, ael.code_combination_id '
 ||'  from '||:p_lines_table2||' ael, '
 ||' '||:p_event_table2 
 ||' '||:p_headers_table||' aeh'
 ||'  where aeh.ae_header_id = ael.ae_header_id '
 ||' '||:p_where_c  
 ||'  ) ael,  '
 ||'  gl_sets_of_books gsob  '
 ||'   WHERE   gsob.set_of_books_id = ael.set_of_books_id  '
 ||' and  ael.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', ael.gl_transfer_flag)'
 ||'   and   glk.gl_sl_link_id = nvl(ael.gl_sl_link_id,-5)  '
 ||' and '''||:p_gl_details||''' = ''Y'' '
 ||' and xla.gl_transfer_mode <> ''D'' '
 ||'   and     ael.code_combination_id = glc.code_combination_id(+)  '
 ||'   and  xla.gl_transfer_run_id(+) = ael.gl_transfer_run_id  '
 ||' group by ael.org_id, ael.set_of_books_id, ael.period_name, ael.gl_transfer_run_id, ael.gl_transfer_flag, ael.code_combination_id, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, ael.code_combination_id),1,35) ,   '
 ||' substr('' '',10), gsob.currency_code, xla.gl_transfer_mode, substr('' '',1,30) '
 ||' UNION '
 ||' select substr(''GLD:'',1,4) src, '
 ||' substr(sum(gjl.accounted_dr),1,15) ACCT_DR, substr(sum(gjl.accounted_cr),1,15) ACCT_CR,  '
 ||' substr(sum(gjl.entered_dr),1,15) ENT_DR, substr(sum(gjl.entered_cr),1,15) ENT_CR,  '
 ||' substr(gsob.set_of_books_id,1,3) sob, substr(to_char(glh.period_name),1,11) per_name, substr(ael.gl_transfer_run_id,1,6) run_id,   '
 ||' substr(ael.gl_transfer_flag,1,1) g, substr(gjl.code_combination_id,1,10) CCID,  '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) account,   '
 ||' substr('' '',10) Line_Type, '
 ||' substr(glh.currency_code,1,3) cur,   '
 ||' substr(xla.gl_transfer_mode,1,1) t, '
 ||' substr(glb.name,1,30) gl_batch_name, substr(ael.org_id, 1,5) orgid '
 ||'  FROM gl_je_lines gjl, gl_import_references gir,   '
 ||'  gl_je_headers glh, gl_code_combinations glc, gl_je_batches  '
 ||'  glb,  '
 ||'  (select distinct gl_transfer_run_id, aeh.gl_transfer_flag, gl_sl_link_id, '
 ||'  aeh.period_name, set_of_books_id,aeh.org_id   '
 ||'  from '||:p_lines_table2||' ael, '
 ||' '||:p_event_table2
 ||' '||:p_headers_table||' aeh'
 ||'  where aeh.ae_header_id = ael.ae_header_id '
 ||' '||:p_where_c  
 ||'  ) ael, '
 ||'  xla_gl_transfer_batches_all xla, gl_sets_of_books gsob  '
 ||'  WHERE   gsob.set_of_books_id = ael.set_of_books_id  '
 ||'  and     gjl.code_combination_id = glc.code_combination_id(+)  '
 ||' and  ael.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', ael.gl_transfer_flag)'
 ||'  and     glb.je_batch_id = gir.je_batch_id  '
 ||'  and   gir.gl_sl_link_id = ael.gl_sl_link_id  '
 ||'  and     gir.GL_SL_LINK_TABLE = ''APENCL'' '
 ||'  and     gjl.je_header_id = glh.je_header_id  '
 ||'  and   gjl.je_line_num = gir.je_line_num  '
 ||'  and   gjl.je_header_id = gir.je_header_id  '
 ||'  and '''||:p_gl_details||''' = ''Y'' '
 ||'  and  xla.gl_transfer_run_id(+) = ael.gl_transfer_run_id  '
 ||' group by ael.org_id, gsob.set_of_books_id, glh.period_name, ael.gl_transfer_run_id, ael.gl_transfer_flag, gjl.code_combination_id, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) ,   '
 ||' substr('' '',10), glh.currency_code, xla.gl_transfer_mode, substr(glb.name,1,30) '
 ||' UNION '
 ||' select distinct substr(''GLI:'',1,4) src, '
 ||' substr(sum(gjl.accounted_dr),1,15) ACCT_DR, substr(sum(gjl.accounted_cr),1,15) ACCT_CR,  '
 ||' substr(sum(gjl.entered_dr),1,15) ENT_DR, substr(sum(gjl.entered_cr),1,15) ENT_CR,  '
 ||' substr(gsob.set_of_books_id,1,3) sob, substr(to_char(ael.period_name),1,11) per_name, substr(ael.gl_transfer_run_id,1,6) run_id,   '
 ||' substr(ael.gl_transfer_flag,1,1) g, substr(gjl.code_combination_id,1,10) CCID,  '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) account,   '
 ||' substr('' '',1,10) Line_Type, '
 ||' substr(gjl.currency_code,1,3) cur,   '
 ||' substr(xla.gl_transfer_mode,1,1) t, '
 ||' substr('' '',1,30) gl_batch_name, substr(ael.org_id, 1,5) orgid'
 ||'    FROM  gl_code_combinations glc,  '
 ||'    gl_interface gjl ,  '
 ||'     (select distinct gl_transfer_run_id, aeh.gl_transfer_flag, gl_sl_link_id, '
 ||'  aeh.period_name, set_of_books_id, aeh.org_id   '
 ||'  from '||:p_lines_table2||' ael, '
 ||' '||:p_event_table2
 ||' '||:p_headers_table||' aeh'
 ||'  where aeh.ae_header_id = ael.ae_header_id '
 ||' '||:p_where_c  
 ||'  ) ael, '
 ||'    xla_gl_transfer_batches_all xla, gl_sets_of_books gsob  '
 ||'    WHERE   gsob.set_of_books_id = ael.set_of_books_id  '
 ||'    and     gjl.code_combination_id = glc.code_combination_id(+)  '
 ||' and  ael.gl_transfer_flag = decode('''||:p_tran||''', ''Y'', ''Y'', ael.gl_transfer_flag)'
 ||'   and   gjl.gl_sl_link_id = ael.gl_sl_link_id  '
 ||'    and     gjl.GL_SL_LINK_TABLE = ''APENCL'' '
 ||'    and  xla.gl_transfer_run_id(+) = ael.gl_transfer_run_id '
 ||' and '''||:p_gl_details||''' = ''Y'' '
 ||' group by ael.org_id, gsob.set_of_books_id, ael.period_name, ael.gl_transfer_run_id, ael.gl_transfer_flag, gjl.code_combination_id, '
 ||' substr(fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsob.chart_of_accounts_id, gjl.code_combination_id),1,35) ,   '
 ||' substr('' '',10), gjl.currency_code, xla.gl_transfer_mode, substr('' '',1,30) '
 ||' order by 16,8,10,7,1';

disp_lengths := lengths(4,15,15,15,15,3,11,6,1,10,35,10,3,1,30,5);


RUN_SQL('Summary Encumbrance Accounting Entries', sqltxt,disp_lengths,col_headers,:p_max_rows);

end if;
 




end if;


sectionprint('SRC Column Legend');
tab0print('APD = AP Detail.  This line shows the AP Lines details corresponding to the lines in the table entered.');
tab0print('APS = AP Summary.  This line was created because the transfer to GL was done in summary.');
tab0print('      It shows the total amount transferred for the gl_sl_link_id corresponding to the lines in the table entered.');
tab0print('GLD = GL Data.  This line shows the data imported into GL corresponding to the lines in the table entered.');
tab0print('GLI = GL Data.  This line shows the data in the GL_INTERFACE table corresponding to the lines in the table entered.');
brprint;

end if;


EXCEPTION

When l_exception then

tab0print('');

when others then --exception section3

  DBMS_OUTPUT.PUT_LINE(chr(9));

  ErrorPrint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; --end3



/* -------------------- Feedback ---------------------------- */



/* -------------------- Exception Section -------------------------- */

exception when others then --exception section 2

  DBMS_OUTPUT.PUT_LINE(chr(9));

  errorprint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; --end2

exception when others then   --exceptions section 1

  DBMS_OUTPUT.PUT_LINE(chr(9));

  errorprint(sqlerrm||' occurred in script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; -- end 1

/

spool off

set term on

select chr(10) from sys.dual;
select 'End Time'||chr(10)||to_char(sysdate, 'MM-DD-YYYY HH24:MI:SS') Time from sys.dual;
Prompt


PROMPT 
prompt Output spooled to filename &outputfilename

