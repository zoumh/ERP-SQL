REM   $Header:  undo_readme.txt 1.1 [Last Modified Date  24-MAY-04] support $

=======================================================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.                                                                   
=======================================================================================================================

=======================================================================================================================
Abstract                        Use these scripts to review and undo accounting.
=======================================================================================================================
FILE NAME:                      Undo Accounting Scripts
PRODUCT:                        501 -Oracle Payables
SUBCOMPONENT:           Accounting
PRODUCT VERSIONS:       11.5
PLATFORM:                       All Platforms
DATE CREATED:           14-OCT-2003
PARAMETERS:                     
=======================================================================================================================
Instructions
=======================================================================================================================
Included Files:

        undoatgh.sql
        undoatgt.sql
        APGLEntriestsa.sql
        APGLEntrieshsa.sql
        CoreApiHtmlX.sql
        CoreApiTxtX.sql
        undo_readme.txt
        
Execution Environment::

        SQL*Plus

Access Privileges:

        Requires APPS user access
        
Usage:
        
        sqlplus apps/password @filename

Instructions: 
        
All of the files should be unzipped/copied to a common directory. 

1.  STOP RUNNING THE PAYABLES ACCOUNTING AND TRANSFER
PROCESSES UNTIL THE DATAFIX IS COMPLETE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
ALSO, USERS SHOULD NOT USE CREATE ONLINE ACCOUNTING UNTIL THE DATAFIX IS COMPLETE EITHER!!!!!
DO NOT CREATE OR TRANSFER ANY ACCOUNTING UNTIL THE DATA FIX IS COMPLETE!!!!!!!!!!!!!!!!
DOING SO MAY ALTER THE DATA RETRIEVED BY THIS SCRIPT.

2.  Run undoatgh.sql (or undoatgt.sql if undoatgh.sql has errors)

3.  Enter the ORG ID, or press enter for ALL ORGS.

4.  Enter option for data to analyze

-Select option '1', to display the events and accounting lines that will be deleted.
This information can be used to analyze ALL the events that will be deleted.  

-Select option '2' to display the selected and related event details.
This information may be helpful if the accounting errors are due to the related events.  

-Select option '3' for Undo ONLY, no analysis data will be displayed.

5.  Enter option for accounting data

-Select option '1' to display Selected Event AP Accounting Data.
-Select option '2' to display Selected Event AP Accounting Data with GL Details.
-Select option '3' to display Selected Event Summarized AP Accounting Data.
-Select option '4' to display Selected Event Summarized AP Accounting Data with GL Details.
-Select option '5' to Undo ONLY, no accounting data will be displayed.

6.  Enter the method to select events for review and undo.

Option 1)  Specific Accounting event.  Select this option, to review and delete event for a specific event id.  

Option 2)  All Accounting Errors.  Select this option,
to review and delete events for all accounting errors. The script will search for all accounting events
with errors and store them in a table for use by the script

Option 3)  Event id's from an Existing Table.  Select this option,
to review and delete events already populated in a table.  Note, the table entered must have a column name, 
acccounting_event_id and it must have records.

7.  If you selected option 3 for step 6, you will be prompted for a table name.  Enter the name of the table
with the accounting_event_id's you want to UNDO.

8.  If you selected option 1 for step 6, you will be prompted for an accounting_event_id. 

9.  You will be prompted for Undo Now?  Enter Y if you want to undo the accounting for the event(s)
being analyzed.  Note:  The first time you run this script you should enter Undo Now = N, then upload the
aprunbeforeundoatg spool files for support to review data.  Then, second time you run the script choose Undo Now = Y.

10  If you entered an ORG ID you will also be prompted for, Sweep unaccounted transactions in closed periods to the first open period?
Enter Y if you are undoing accounting in a closed period and you want to sweep the transaction to the first open period.

11.  If you selected Y for sweep unaccounted transactions, you will be prompted for a period name.  Enter a valid period
name in an open period or use the default.

12.  If you have selected Y for undo accounting and you are on family pack D or higher you will be prompted for
Delete Events? Enter N, unless you have been instructed otherwise from support.

13.  The script will create 4 spool files:

aprunbeforeundoatgmmddhhmi.html(txt)  - Analysis of events to be undone/undone.
apglentriesmmddhhmi.html/txt - Shows accounting data.
apundoatgmmddhhmi.txt - Summary of accounting undone.
apundosweepmmddhhmi.txt - Summary of accounting in closed period swept.


IMPORTANT NOTES FOR THE CUSTOMERS RUNNING THESE SCRIPTS

The undo and sweep scripts DO NOT COMMIT.  You must verify the rows undone/swept by comparing the reports then COMMIT
if updates/deletes correspond.

Undoing the accounting for these events in AP will cause drilldown for the original entries 
transferred to the GL not to work.  After applying this fix you will no longer be able 
to drill down to the original entries that were transferred to GL, because this fix deleted
the entries from AP, but NOT GL. 

If you are unaccounting events that have been transferred, 
you will need to create a manual JE in GL to account for this.  You may also need to run a 
script to verify if the entries actually posted.


=======================================================================================================================
Script Description
=======================================================================================================================
Follow the instructions to use these scripts to review and undo accounting.

Review runbeforeundoatg.sql to verify the number and type of
transactions with accounting errors.  The next step will undo accounting
for any accounted with error event.  Review the output and verify that
no related accounting events will be affected by the undo.  Review the
Do's and Don'ts of Undo Accounting document and the Undo Accounting Checklist.

When you run the script with UNDO NOW = Y, verify the number of rows updated/deleted
is correct (compare to the runbeforeundoatg.sql output).  If the number of rows
deleted is correct, COMMIT the changes, otherwise ROLLBACK the changes.

Retain the backup tables through at least the next period closing.


=======================================================================================================================
References
=======================================================================================================================
No Reference

=======================================================================================================================
Disclaimer
=======================================================================================================================
EXCEPT WHERE EXPRESSLY PROVIDED OTHERWISE, THE INFORMATION, SOFTWARE, PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. 
ORACLE EXPRESSLY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE 
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ORACLE MAKES NO WARRANTY 
THAT: (A) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE SOFTWARE WILL BE ACCURATE OR RELIABLE; OR (B) THE 
INFORMATION, OR OTHER MATERIAL OBTAINED WILL MEET YOUR EXPECTATIONS. ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE 
DOWNLOADED OR OTHERWISE OBTAINED IS DONE AT YOUR OWN DISCRETION AND RISK. ORACLE SHALL HAVE NO RESPONSIBILITY FOR ANY
DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY CONTENT, MATERIALS, INFORMATION 
OR SOFTWARE.

ORACLE RESERVES THE RIGHT TO MAKE CHANGES OR UPDATES TO THE SOFTWARE AT ANY TIME WITHOUT NOTICE.

=======================================================================================================================
Limitation of Liability
=======================================================================================================================
IN NO EVENT SHALL ORACLE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, OR DAMAGES 
FOR LOSS OF PROFITS, REVENUE, DATA OR USE, INCURRED BY YOU OR ANY THIRD PARTY, WHETHER IN AN ACTION IN CONTRACT OR TORT,
ARISING FROM YOUR ACCESS TO, OR USE OF, THE SOFTWARE. 

SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY. ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS 
MAY NOT APPLY TO YOU.



