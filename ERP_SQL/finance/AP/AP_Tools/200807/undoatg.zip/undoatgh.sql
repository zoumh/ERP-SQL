REM   $Header:  undoatgh 1.10 [Last Modified Date  27-MAR-06] support $
REM   ========================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM    Oracle Support Services.  All rights reserved.
REM   ========================================================
REM    PURPOSE:		  Analyze accounting events before undo accounting is ran.
REM    PRODUCT:		  501 - Oracle Payables
REM    PRODUCT VERSIONS:  11.5
REM    PLATFORM:  	  Generic
REM    PARAMETERS:	  
REM    ORG ID - Org id corresonding to event(s) to be undone
REM    Data Analysis Option - Controls what data to analyze
REM    Accounting Data Option - Controls what accounting data is displayed
REM    Select Option - Controls what data to select
REM    Table Name (Optional) - Name of table with accounting events to undo
REM    Event ID (Optional) - Accounting event id to undo
REM    Undo Now - Enter Y to undo accounting for the event(s)
REM    Sweep Now - Enter Y to sweep undone accounting from closed periods
REM    Sweep to Period - Enter the period to sweep to
REM    Delete Event Now - Enter Y only if instructed to do so by support
REM    Note:  The sweep now parameters are only available when a specific org_id is entered.
REM           Org_id is specific to a set of books and each set of books could have a different 
REM           Period.  
REM   =======================================================

REM   =======================================================
REM   USAGE: 	This script should be run in SQLplus in APPS Schema
REM   EXAMPLE: 	in the SQL prompt execute :SQL>@c:\filepath\apundoatgh.sql
REM   OUTPUT:     The script will create 3 spool files:
REM			aprunbeforeundoatgmmddhhmi.html/txt  - Analysis of events to be undone.
REM			apglentriesmmddhhmi.html/txt - Shows accounting data.
REM			apundoatgmmddhhmi.txt - Summary of accounting undone.
REM			apundosweepmmddhhmi.txt - Summary of accounting in closed period swept.
REM   =======================================================

REM   =======================================================
REM   CHANGE HISTORY:
REM   DATE	Modifications (In order changes were made)
REM   06-OCT-03	shorgan	Created
REM   26-JAN-04 added nvl to org_id to fix script for non-multi org installs.
REM   30-JUN-04 Changed family pack D message text from not normally accounted to not normally deleted.
REM   08-APR-05 Fixed sweep for multiple sets of books. 
REM   12-FEB-06 Create indexes for mass undo of events accounted with error
REM   12-FEB-06 Miscellaneous performance/tuning updates
REM   16-FEB-06 Fixed sweep for pre-AP.K installs
REM   27-MAR-06 Added select distinct to backup table creation
REM   =======================================================

REM  ==============SQL PLUS Environment setup===================
set verify off
set echo off
set term on
set feedback off
set head off
set heading off
set autoprint off
set serveroutput on
set linesize 200

REM ============== Define SQL Variables for input parameters =============
undefine v_type
undefine v_rel_details
undefine v_org_id
undefine v_type
undefine v_rel_details
undefine v_version
undefine v_undo_now
undefine v_sweep_now
undefine v_del_events
undefine v_del_events2
undefine v_period
undefine v_mo_flag
undefine v_atg_details

clear columns


variable sqlTxt varchar2(2000)
variable sqlTxt2 varchar2(2000)
variable sqlTxt3 varchar2(2000)
variable p_org_id number
variable p_event_table varchar2(2000)
variable p_tab1 varchar2(2000)
variable p_del_events varchar2(1)
variable p_del_events2 varchar2(1)
variable p_sweep_now varchar2(1)
variable p_undo_now varchar2(1)
variable p_continue varchar2(1)
variable p_mo_flag varchar2(1)

variable p_lines_table	varchar2(50)
variable p_lines_table2	varchar2(50)
variable p_headers_table varchar2(50)
variable p_max_rows number
variable p_gl_details		varchar2(1)
variable p_tran 			varchar2(1)
variable p_rel_details		varchar2(1)
variable p_enc_lines		varchar2(1)
variable p_enc_lines2		varchar2(1)
variable p_event_table2 varchar2(2000)
variable p_where_c varchar2(2000)


set serveroutput on size 1000000 term on


--Get the ORG_ID

Prompt

set head on feedback on

--Added for family pack D


set term off

COLUMN flag NEW_VALUE v_mo_flag
SELECT multi_org_flag flag
FROM   fnd_product_groups;


set term on

set head off feedback off


select 'Multi Org is Enabled.  Delete lines by ORG? '||chr(10)
||'Please Enter the ORG ID OR Press enter for ALL ORGS' 
from sys.dual
where exists (select 'x' from fnd_product_groups where multi_org_flag = 'Y' );

select 'Multi Org is Not Enabled.'||chr(10)||'Press Enter' 
from sys.dual
where not exists (select 'x' from fnd_product_groups where multi_org_flag = 'Y' );

Accept v_org_id number prompt '>' default -99
Prompt

define v_org_id = &v_org_id


--Get the Display option

Prompt Analyze Selected Event Details(Enter 1)
Prompt Analyze Selected and Related Event Details (Enter 2)
Prompt Undo ONLY, do not display any analysis data (Enter 3)
Prompt
Accept v_rel_details number prompt 'Default=1>' default 1
Prompt

define v_rel_details = &v_rel_details

Prompt Display Selected Event AP Accounting Data (Enter 1)
Prompt Display Selected Event AP Accounting Data with GL Details (Enter 2)
Prompt Display Selected Event Summarized AP Accounting Data (Enter 3)
Prompt Display Selected Event Summarized AP Accounting Data with GL Details (Enter 4)
Prompt Undo ONLY, do not display any accounting data (Enter 5)
Prompt
Accept v_atg_details number prompt 'Default=1>' default 1
Prompt

define v_atg_details = &v_atg_details

--Get the Accounting event id's option

Prompt Analyze/Undo a specific Accounting Event Id (Enter 1)
Prompt Analyze/Undo all accounting Event Errors (Enter 2)
Prompt Analyze/Undo Accounting Events in an Existing Table (Enter 3)
Prompt
Accept v_type number prompt 'Default=1>' default 1 

define v_type = &v_type;

set heading off

--Display existing Tables created by this script.

set heading off feedback off verify off

select chr(10)
from sys.dual
where &v_type = '3';


select rpad('OWNER', 15),
rpad('OBJECT_NAME',35),
rpad('CREATED', 20)
from sys.dual
where &v_type = '3';

select substr(owner,1,15) owner,
substr(object_name,1,35) object_name, created
from dba_objects
where object_name like 'BAK_AP_EVENTS%'
and object_type = 'TABLE'
and &v_type = '3';

set heading off
set head off

--Get the table name

Prompt
select decode(&v_type, '3', 'Enter one of the table names above OR another table name with the Accounting Event IDs to be analyzed/undone.','Press Enter')
from sys.dual;


Accept v_tab_name prompt '>' default NO_TABLE_ENTERED
Prompt


Prompt
select decode(&v_type, '1', 'Enter the Accounting Event ID to be analyzed/undone.','Press Enter')
from sys.dual;


Accept v_event_id number prompt '>' default -99
Prompt

--Start PL/SQL to set which Event ID's to analyze.


set term off

begin

:p_org_id := nvl(&v_org_id,-99);

:sqlTxt := 'select distinct aea.accounting_event_id accounting_event_id '
|| 'from ap_accounting_events_all aea  '
|| 'where aea.event_status_code like ''%ERROR%'' '
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id ;


:sqlTxt2 := 'select distinct to_number(&v_event_id) accounting_event_id from sys.dual';


end;

/
set term on


Accept v_undo_now prompt 'Undo Now? (Default=N): ' default N

define v_undo_now = &v_undo_now


select chr(10)||decode(upper('&v_undo_now'), 'Y',
	decode(nvl(&v_org_id,-99), -99,
		decode(upper('&v_mo_flag'), 'Y',
'Undo must be ran with an org_id to sweep unaccounted transactions from closed periods.'||chr(10)||
'Press CTRL + C to cancel script and re-run with a specific ORG_ID '||chr(10)||
'or PRESS ENTER to continue without sweep.', 
'Sweep unaccounted transactions in closed periods to the first open period? (Default=N)')
		,'Sweep unaccounted transactions in closed periods to the first open period? (Default=N)'),
'Press Enter')
from sys.dual;

Accept v_sweep_now prompt '>' default N

set term off

COLUMN period_name NEW_VALUE v_period
select period_name
from gl_period_statuses gps, ap_system_parameters_all aps
where gps.application_id = 200
and gps.set_of_books_id = aps.set_of_books_id
and nvl(aps.org_id,-99) = nvl(&v_org_id, -99)
and closing_status = 'O'
and gps.start_date =
(select min(start_date) 
from gl_period_statuses gps2, ap_system_parameters_all aps2
where gps2.application_id = 200
and gps2.set_of_books_id = aps2.set_of_books_id
and nvl(aps2.org_id,-99) = nvl(&v_org_id,-99)
and closing_status = 'O'
and gps2.start_date > 
(select max(start_date)
from gl_period_statuses gps3, ap_system_parameters_all aps3
where gps3.application_id = 200
and gps3.set_of_books_id = aps3.set_of_books_id
and nvl(aps3.org_id,-99) = nvl(&v_org_id, -99)
and closing_status = 'C'
and start_date < sysdate))
UNION
select 'None' from sys.dual
where not exists(
select 1
from gl_period_statuses gps, ap_system_parameters_all aps
where gps.application_id = 200
and gps.set_of_books_id = aps.set_of_books_id
and nvl(aps.org_id,-99) = nvl(&v_org_id,-99)
and closing_status = 'O'
and gps.start_date =
(select min(start_date) 
from gl_period_statuses gps2, ap_system_parameters_all aps2
where gps2.application_id = 200
and gps2.set_of_books_id = aps2.set_of_books_id
and nvl(aps2.org_id,-99) = nvl(&v_org_id,-99)
and closing_status = 'O'
and gps2.start_date > 
(select max(start_date)
from gl_period_statuses gps3, ap_system_parameters_all aps3
where gps3.application_id = 200
and gps3.set_of_books_id = aps3.set_of_books_id
and nvl(aps3.org_id,-99) = nvl(&v_org_id,-99)
and closing_status = 'C'
and start_date < sysdate)));

define v_period = &v_period

set term on

select chr(10)||decode(upper('&v_sweep_now'), 'Y','Enter the Sweep to Period Name (Default = &v_period): ',
'Press Enter')
from sys.dual;

Accept v_period prompt '>' default &v_period

set head on feedback on

--Added for family pack D


set term off

COLUMN version NEW_VALUE v_version
SELECT NVL(substr(patch_level,-1,1),'A') version
FROM   fnd_product_installations
WHERE  application_id = 200;



set term on

set head off feedback off

select chr(10)||'Family Pack D is applied.  In Family Pack D events should not normally be deleted.'
from sys.dual
where upper('&v_version') > 'J' and upper('&v_undo_now') = 'Y';

select chr(10)||decode(upper('&v_undo_now'), 'Y','Delete Event (Y or N)? (Default=N): ','Press Enter')
from sys.dual
where upper('&v_version') > 'J';

select chr(10)||'Press Enter'
from sys.dual
where upper('&v_version') < 'K';

accept v_del_events prompt '>' default N

select chr(10)||decode(upper('&v_undo_now'),'Y','Are you sure you want to Delete Event (Y or N)?: (Default=N) ', 'Press Enter')
from sys.dual
where upper('&v_version') > 'J'
and upper('&v_del_events') = 'Y';

select chr(10)||'Press Enter'
from sys.dual
where upper('&v_del_events') <> 'Y';

accept v_del_events prompt '>' default N

set head on feedback on

prompt
Accept v_max_rows number prompt 'Max Rows Returned? (Default=250): ' default 250
prompt

set term off


COLUMN del_events NEW_VALUE v_del_events2
select 'Y' del_events
from sys.dual
where ((upper('&v_version') < 'K') OR (upper('&v_del_events') = 'Y'))
union
select 'N' del_events
from sys.dual
where ((upper('&v_version') > 'J') and (upper('&v_del_events') <> 'Y'));

define v_del_events2 = &v_del_events2

--Verify Y or N


begin


if upper('&v_undo_now') not in ('Y', 'N') then

:p_undo_now := 'N';

else

:p_undo_now := upper('&v_undo_now');


end if;

if upper('&v_sweep_now') not in ('Y', 'N') then

:p_sweep_now := 'N';

else

:p_sweep_now := upper('&v_sweep_now');

end if;

if upper('&v_del_events2') not in ('Y', 'N') then

:p_del_events2 := 'N';

else

:p_del_events2 := upper('&v_del_events2');


end if;


if upper('&v_del_events') not in ('Y', 'N') then

:p_del_events := 'N';

else

:p_del_events := upper('&v_del_events');


end if;


end;

/

--Get the Date and Time

COLUMN TODAY NEW_VALUE v_date
SELECT TO_CHAR(SYSDATE, 'MMDDHH24MI') TODAY
from sys.dual;

set term on

REM ============ Spooling the output file====================


Prompt
Prompt Running Analysis...
Prompt

define outputfilename = aprunbeforeundoatg&v_date..html

spool  &outputfilename

set feedback off

Prompt Start Time
select to_char(sysdate, 'MM-DD-YYYY HH24:MI:SS') Time from sys.dual;
Prompt


REM =================Run the Pl/SQL api file ===================================

@@CoreApiHtmlX.sql

begin  -- begin1

declare --declare 2

p_username varchar2(100);

p_respid number;

/* ------------------------ Declare Section -----------------------------*/

begin  --begin2

Show_Header('', 'APRunBeforeUndoAtg');

/* -------------------- Execution secion ------------------------------- */

Declare  --declare 3

--disp_lengths 	lengths;		
--col_headers  	headers;

l_exception		exception;
l_error_msg		varchar2(500);
l_count 		NUMBER;
event_count 	NUMBER;
header_count	number;
line_count		number;
enc_line_count	number;
payment_count	number;
pmthist_count	number;
invdist_count	number;
liability_count	number;
SELECTED_COUNT	NUMBER;
SqlTxt			varchar2(5000);
SqlTxt2			varchar2(5000);
SqlTxt3			varchar2(5000);
l_applversion		varchar2(10);
l_mrc_enabled		varchar2(10);
l_ax_enabled		varchar2(10);
l_ax_info		number;
l_cursor		integer;
l_counter		integer;
l_counter2		integer;
l_counter4		integer;
l_event_id		varchar2(50) := NULL;
ql_markers 		V2T;
ql_titles  		V2T;
l_tax_code_id		number := NULL;
l_vat_code		varchar2(50) := NULL;
l_chart_id		number;
l_type		varchar2(10) := nvl('&v_type', '1');
l_rel_details	varchar2(10) := nvl(&v_rel_details, 1);
l_atg_details	varchar2(10) := nvl(&v_atg_details, 1);
prim_atg		varchar2(30);
sec_atg		varchar2(30);
--l_tab_name	varchar2(50) := upper(nvl('&v_tab_name','BAK_AP_EVENTS_'||(to_char(sysdate,'MMDDHH24MI'))));
l_tab_name	      varchar2(50);
l_time		varchar2(240);
l_format			varchar2(10) := 'T';  --run_sql7
period_valid	number;
l_index_name varchar2(50);


--Custom API's

function object_test(object_test varchar2) return number is

	l_object_test 	number;

begin


l_object_test := 0;

select count(*) 
into l_object_test
from dba_objects
where object_name = object_test;

return(l_object_test);

end object_test;


function Check_Column(p_tab in varchar, p_col in varchar) return boolean is
l_counter integer:=0;
begin
  select count(*) into l_counter
  from   all_tab_columns
  where  table_name = upper(p_tab)
  and    column_name = upper(p_col);
  if l_counter > 0 then
    return(true);
  else
    return(false);
  end if;
exception when others then
  ErrorPrint(sqlerrm||' occured in Check_Column');
  ActionErrorPrint('Report this information to your support analyst');
  raise;
end Check_Column;



Begin  --begin 3

:p_continue := 'N';



--Verify parameters entered

l_count := 0;

select count(*)
into l_count
from sys.dual
where l_rel_details in (1,2,3);

if l_count = 0 then

brprint;
errorprint('Invalid Analysis Details Parameter entered.');
actionerrorprint('Please enter 1,2 or 3');

:p_continue := 'N';

raise l_exception;

end if;

l_count := 0;

select count(*)
into l_count
from sys.dual
where l_atg_details in (1,2,3,4,5);

if l_count = 0 then

brprint;
errorprint('Invalid Accounting Details Parameter entered.');
actionerrorprint('Please enter 1,2,3,4 or 5');

:p_continue := 'N';

raise l_exception;

end if;



l_count := 0;

select count(*)
into l_count
from sys.dual
where l_type in (1,2,3);

if l_count = 0 then

brprint;
errorprint('Invalid Select Type Parameter entered.');
actionerrorprint('Please enter 1,2, or 3');

:p_continue := 'N';

raise l_exception;

end if;

l_count := 0;

select count(*)
into l_count
from sys.dual
where :p_undo_now in ('Y','N');

if l_count = 0 then

brprint;
errorprint('Invalid Undo Now Parameter entered.');
actionerrorprint('Please enter Y or N');

:p_continue := 'N';

raise l_exception;

end if;

l_count := 0;

select count(*)
into l_count
from sys.dual
where :p_sweep_now in ('Y','N');

if l_count = 0 then

brprint;
errorprint('Invalid Sweep Now Parameter entered.');
actionerrorprint('Please enter Y or N');

:p_continue := 'N';

raise l_exception;

end if;

l_count := 0;

select count(*)
into l_count
from sys.dual
where :p_del_events in ('Y','N');

if l_count = 0 then

brprint;
errorprint('Invalid Delete Events Parameter entered.');
actionerrorprint('Please enter Y or N');

:p_continue := 'N';

raise l_exception;

end if;

select count(*) 
into period_valid
from gl_period_statuses gps, ap_system_parameters_all asp
where gps.period_name = '&v_period'
and ( 
(asp.org_id is null and upper('&v_mo_flag') = 'N') 
OR
(upper('&v_mo_flag') = 'Y' and asp.org_id = :p_org_id) 
     )
and asp.set_of_books_id = gps.set_of_books_id
and gps.application_id = 200
and closing_status = 'O';


if upper(:p_sweep_now) = 'Y' and period_valid = 0 then

brprint;
errorprint('Invalid Period Name Entered, '||'&v_period');
actionerrorprint('Please enter a valid Period Name');

raise l_exception;

end if;



--Set table name

if l_type = '3' then

l_tab_name := upper(nvl('&v_tab_name','NO_TABLE_ENTERED'));

else 

l_tab_name := upper('BAK_AP_EVENTS_'||'&v_date');

end if;


--Verify Org_id exists

l_count := 0;

select count(*) 
into l_count 
from fnd_product_groups 
where multi_org_flag = 'Y' ;

if l_count > 0 then


	if :p_org_id = -99 then
	
	tab0print('Org ID Entered: All Orgs');
	
	else 

	tab0print('Org ID Entered: '||:p_org_id);
	
	
	l_count := 0;

	select count(*)
	into l_count
	from ap_system_parameters_all
	where decode(:p_org_id, -99, -99, nvl(org_id, -99)) = :p_org_id;

		if l_count = 0 then
	
	        brprint;
	        errorprint('The ORG_ID entered ('||:p_org_id||') does not exist.');
		actionerrorprint('Please enter a valid ORG_ID.');
		
		raise l_exception;

		end if;

	end if;

else

tab0print('Org ID Entered: Multi Org is not enabled');

end if;


--Verify if Backup tables already exist

if object_test(l_tab_name) > 0 and l_type <> '3' THEN

brprint;
errorprint('The tables already exist.');
actionerrorprint('If you have used this script before, the old table will need to be dropped.'||chr(10)||
'Make sure you don''t need the data from this tables before dropping it.'||chr(10)||
'Use the SQL below to drop the table.');

brprint;

tab0print('drop table '||l_tab_name||';');

raise l_exception;

end if;  


Sectionprint('SQL Used for Report');

if l_type = '3' THEN

tab0print('Use Existing Table option was selected, No SQL was entered.');
tab0print('This report will review the data previously populated in the table');

--Verify if table name entered exists

	if object_test(l_tab_name) = 0 then

BRPRINT;
errorprint('>'||l_tab_name||'< Table Does not exist');
actionerrorprint('The table must exist to run this script with Table exist option selected');

	raise l_exception;

	end if;

	if object_test(l_tab_name) > 0 then

--Verify Table entered has an accounting event id column

		if Column_Exists(l_tab_name,'ACCOUNTING_EVENT_ID') = 'N' then

		brprint;
errorprint(l_tab_name||' Table Does not have an ACCOUNTING_EVENT_ID column');
actionerrorprint('The table must have an ACCOUNTING_EVENT_ID column to run this script with Table exist option selected');

raise l_exception;
	
	
		end if;
		
	end if;
	

--Verify Table being used has rows.	

selected_count := 0;

sqlTxt3 := 'select count(*) from '||l_tab_name;

execute immediate sqltxt3 into selected_count;

	if selected_count = 0 then 

BRPRINT;
errorprint('The Table has 0 Rows');
actionerrorprint('The table must be populated to run this script with Table exist option selected');

raise l_exception;
	
	end if;

else

--Set which sqltxt to use to select accounting event ids

	if l_type = '2' then

sqlTxt := :sqlTxt;

	else

sqlTxt := :sqlTxt2;

	end if;

--Display the SQL Used for the report
brprint;
line_out(sqlTxt);
	
l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
          end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

	  if l_counter = 0 then

BRPRINT;
errorprint('The SQL Statement Entered returned 0 Rows');
actionerrorprint('Review the SQL Statement and verify that it is correct');

raise l_exception;

	end if;


EXECUTE IMMEDIATE 'CREATE TABLE '||l_tab_name||' (accounting_event_id NUMBER(15))';


l_counter2 := 0;
l_counter4 := 0;
l_count := 0;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);

sqltxt3 := 'INSERT INTO '||l_tab_name||' VALUES (:1)';


EXECUTE IMMEDIATE sqltxt3 Using l_event_id;

	l_counter4 := l_counter4 + l_counter2;

	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);
	  

	  
end if;


:p_event_table := l_tab_name;
	  

--Create indexes if needed

l_count :=0;

select max(i.index_name)
into l_index_name
from	
dba_ind_columns c, dba_indexes i	
where c.index_name = i.index_name  	
and column_name = 'ACCOUNTING_EVENT_ID'
and i.table_name = l_tab_name;

if l_index_name is NULL THEN

sqltxt := 'create index '||l_tab_name||'_ID1 on '||l_tab_name||' (accounting_event_id)';

EXECUTE IMMEDIATE sqltxt;

sqltxt := 'analyze table '||l_tab_name||' compute statistics';

EXECUTE IMMEDIATE sqltxt;

select max(i.index_name)
into l_index_name
from	
dba_ind_columns c, dba_indexes i	
where c.index_name = i.index_name  	
and column_name = 'ACCOUNTING_EVENT_ID'
and i.table_name = l_tab_name;

end if;



l_count :=0;
event_count :=0;
header_count := 0;
line_count := 0;
enc_line_count := 0;
payment_count := 0;
pmthist_count := 0;
invdist_count := 0;
liability_count := 0;
SELECTED_COUNT := 0;

sqlTxt3 := 'select count(*) from '||l_tab_name;

execute immediate sqltxt3 into selected_count;


sqlTxt3 := 'select count(distinct aea.accounting_event_id) '
||' from ap_accounting_events_all aea, '||l_tab_name||' bae' 
||' where bae.accounting_event_id = aea.accounting_event_id'
||' and decode('||:p_org_id||', -99, -99, nvl(aea.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into event_count;

sqlTxt3 := 'select count(distinct aeh.ae_header_id) '
||' from ap_ae_headers_all aeh,'||l_tab_name||' bae' 
||' where bae.accounting_event_id = aeh.accounting_event_id'
||' and decode('||:p_org_id||', -99, -99, nvl(aeh.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into header_count;

sqlTxt3 := 'select count(distinct ael.ae_line_id) '
||' from ap_ae_lines_all ael, ap_ae_headers_all aeh, '||l_tab_name||' bae '
||' where bae.accounting_event_id = aeh.accounting_event_id '
||' and ael.ae_header_id = aeh.ae_header_id'
||' and decode('||:p_org_id||', -99, -99, nvl(aeh.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into line_count;


sqlTxt3 := 'select count(distinct ael.encumbrance_line_id) '
||' from ap_encumbrance_lines_all ael, ap_ae_headers_all aeh, '||l_tab_name||' bae '
||' where bae.accounting_event_id = aeh.accounting_event_id '
||' and ael.ae_header_id = aeh.ae_header_id'
||' and decode('||:p_org_id||', -99, -99, nvl(aeh.org_id, -99)) = '||:p_org_id ;

execute immediate sqltxt3 into enc_line_count;

sqlTxt3 := 'select count(distinct aid.invoice_distribution_id) '
||' from ap_invoice_distributions_all aid, ap_accounting_events_all aea, '||l_tab_name||' bae'
||' where bae.accounting_event_id = aid.accounting_event_id'
||' and bae.accounting_event_id = aea.accounting_event_id'
||' and nvl(aea.org_id,-99) = nvl(aid.org_id, -99)'
||' and decode('||:p_org_id||', -99, -99, nvl(aid.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into invdist_count;

sqlTxt3 := 'select count(distinct invoice_payment_id) '
||' from ap_invoice_payments_all aip, ap_accounting_events_all aea,'||l_tab_name||' bae '
||' where bae.accounting_event_id = aip.accounting_event_id'
||' and bae.accounting_event_id = aea.accounting_event_id'
||' and nvl(aea.org_id,-99) = nvl(aip.org_id, -99)'
||' and decode('||:p_org_id||', -99, -99, nvl(aip.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into payment_count;

sqlTxt3 := 'select count(distinct payment_history_id) '
||' from ap_payment_history_all aph, ap_accounting_events_all aea, '||l_tab_name||' bae '
||' where bae.accounting_event_id = aph.accounting_event_id'
||' and bae.accounting_event_id = aea.accounting_event_id'
||' and nvl(aea.org_id,-99) = nvl(aph.org_id, -99)'
||' and decode('||:p_org_id||', -99, -99, nvl(aph.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into pmthist_count;


if object_test('AP_LIABILITY_BALANCE') > 0 THEN

	sqlTxt3 := 'select count(distinct alb.ae_line_id)'
		||'   from ap_liability_balance alb'
		||'   where ae_header_id in (' 
		||'      select ae_header_id'
		||'        from ap_ae_headers_all aeh'
		||'           , ' || l_tab_name || ' bae'
		||'       where bae.accounting_event_id = aeh.accounting_event_id)'
		||' and decode('||:p_org_id||', -99, -99, nvl(alb.org_id, -99)) = '||:p_org_id;

/*
sqlTxt3 := 'select count(*) FROM ap_liability_balance alb '||
'where exists ('||
'select ''x'' from ap_ae_headers_all aeh, '||l_tab_name||' bae '||
'where bae.accounting_event_id = aeh.accounting_event_id and alb.ae_header_id = aeh.ae_header_id)';
*/

execute immediate sqltxt3 into liability_count;


end if;


--Display table name created/used by this report

brprint;
sectionprint('Table Created/Used for Report');
tab1print(l_tab_name);

sectionprint('Indexes Created/Exist for Table');
tab1print(l_index_name);

--Display the count for each table analyzed by this report.

sectionprint('Selected Rows Count');

tab1print('Selected Rows in '||l_tab_name||': '||selected_count);
tab1print('Selected Rows in AP_ACCOUNTING_EVENTS_ALL: '||event_count);
tab1print('Selected Rows in AP_AE_HEADERS_ALL: '||header_count);
tab1print('Selected Rows in AP_AE_LINES_ALL: '||line_count);
if 2*line_count < 1001 then
l_format := 'H';
end if;
tab1print('Selected Rows in AP_ENCUMBRANCE_LINES_ALL: '||enc_line_count);
tab1print('Selected Rows in AP_INVOICE_DISTRIBUTIONS_ALL: '||invdist_count);
tab1print('Selected Rows in AP_INVOICE_PAYMENTS_ALL: '||payment_count);
tab1print('Selected Rows in AP_PAYMENT_HISTORY_ALL: '||pmthist_count);

if object_test('AP_LIABILITY_BALANCE') > 0 THEN
tab1print('Selected Rows in AP_LIABILITY_BALANCE: '||liability_count);
end if;

if l_rel_details <> 3 then

sectionprint('Undo Accounting Check List');

tab1print('1.  Have the selected accounting events been transferred?');

l_counter2 := 0;
l_counter4 := 0;
l_count := 0;


sqlTxt3 := 'select count(distinct aeh.ae_header_id) '
||' from ap_ae_headers_all aeh ,'||l_tab_name||' bae'
||' where nvl(aeh.gl_transfer_flag,''N'') = ''Y'' '
||' and bae.accounting_event_id = aeh.accounting_event_id'
||' and decode('||:p_org_id||', -99, -99, nvl(aeh.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into l_counter4;

tab2print(l_counter4||' headers(s) of the selected events have been transferred to the GL');
BRPRINT;

if l_counter4 > 0 then

warningprint(l_counter4||' header(s) of the events selected have already been transferred to the GL');
actionwarningprint('Review the Details below for any lines with a GL Transfer flag = Y '||chr(10)||
'If you undo transferred lines, reversing JE''s must be created in GL'||chr(10)||
'Also, verify that these entries posted in the GL and are not in the GL Interface');
BRPRINT;

end if;


tab1print('2.  Are there related events***?');

l_counter2 := 0;
l_counter4 := 0;
l_count := 0;

sqlTxt3 := 'select count(distinct aeh.accounting_event_id) '
||' from ap_accounting_events_all apae, ap_ae_headers_all aeh, '
||' ( '
||' select apae3.accounting_event_id from '
||' ap_accounting_events_all apae3, '
||' ap_accounting_events_all apae2, '||l_tab_name||' bae '
||' where bae.accounting_event_id = apae2.accounting_event_id'
||' and apae3.source_table = apae2.source_table '
||' and apae3.source_id = apae2.source_id '
||' ) selected '
||' where apae.accounting_event_id = aeh.accounting_event_id(+) '
||' and apae.accounting_event_id = selected.accounting_event_id ' 
||' and apae.accounting_event_id not in (select bae.accounting_event_id from '||l_tab_name||' bae )'
||' and decode('||:p_org_id||', -99, -99, nvl(apae.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into l_counter4;

tab2print('There are '||l_counter4||' events related to the selected events');
BRPRINT;

if l_counter4 > 0 then

warningprint('There are '||l_counter4||' events related to the selected events');
actionwarningprint('Review the Details below for any related events. '||chr(10)||
'If you undo accounting and there are related events, the new accounting may not create correctly.');
BRPRINT;

end if;


tab0print('***related events =  other events created for the same source_id');
BRPRINT;


tab1print('3.  Have the related events been transferred?');

l_counter2 := 0;
l_counter4 := 0;
l_count := 0;

sqlTxt3 := 'select count(distinct aeh.accounting_event_id) '
||' from ap_accounting_events_all apae, ap_ae_headers_all aeh, '
||' ( '
||' select apae3.accounting_event_id from ap_accounting_events_all apae3, '
||' ap_accounting_events_all apae2, '||l_tab_name||' bae '
||' where bae.accounting_event_id = apae2.accounting_event_id '
||' and apae3.source_table = apae2.source_table '
||' and apae3.source_id = apae2.source_id '
||' ) selected '
||' where apae.accounting_event_id = aeh.accounting_event_id '
||' and apae.accounting_event_id = selected.accounting_event_id ' 
||' and apae.accounting_event_id not in (select bae.accounting_event_id from '||l_tab_name||' bae )'
||' and nvl(aeh.gl_transfer_flag,''N'') = ''Y'' '
||' and decode('||:p_org_id||', -99, -99, nvl(apae.org_id, -99)) = '||:p_org_id ;


 
execute immediate sqltxt3 into l_counter4;


tab2print(l_counter4||' Headers for Related event(s) of the selected events have been transferred to the GL');
BRPRINT;

if l_counter4 > 0 then

warningprint(l_counter4||' Headers for Related events of the events selected have already been transferred to the GL');
actionwarningprint('Review the Related Event Details below for any lines with a GL Transfer flag = Y '||chr(10)||
'Make sure the Related Event accounting does not need to be undone also');
BRPRINT;

end if;


tab1print('4.  Is MRC enabled?');

l_counter2 := 0;
l_counter4 := 0;
l_count := 0;
	  
select max(multi_currency_flag) into l_mrc_enabled from fnd_product_groups;

brprint;

if l_mrc_enabled = 'Y' then

warningprint('Multiple Reporting Currencies is enabled');
actionwarningprint('Undo Accoungting will undo accounting for PSOB and ALL RSOB for each event selected');
BRPRINT;

else

tab2print('Multiple Reporting Currencies is not enabled');

end if;


tab1print('5.  Has the accounting for the selected events RSOB been transferred?');

l_counter2 := 0;
l_counter4 := 0;
l_count := 0;

sqlTxt3 := 'select count(distinct aeh.accounting_event_id) '
||' from ap_ae_headers_all aeh ,'||l_tab_name||' bae '
||' where nvl(aeh.gl_transfer_flag,''N'') = ''Y'' '
||' and bae.accounting_event_id = aeh.accounting_event_id '
||' AND aeh.set_of_books_id not in (select set_of_books_id from ap_system_parameters_all)'
||' and decode('||:p_org_id||', -99, -99, nvl(aeh.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into l_counter4;

	  
tab2print('There are '||l_counter4||' events with RSOB that have accounting already transferred.');
BRPRINT;

if l_counter4 > 0 then

warningprint(l_counter4||' events of the events selected have RSOB entries that have been transferred to the GL');
actionwarningprint('Review the Details below for any RSOB lines with a GL Transfer flag = Y '||chr(10)||
'If you undo transferred lines, reversing JE''s must be created in GL for the RSOB'||chr(10)||
'Also, verify that these entries posted in the GL and are not in the GL Interface');
BRPRINT;

end if;

tab1print('6.  Is the data upgraded data?');

l_counter2 := 0;
l_counter4 := 0;
l_count := 0;


sqlTxt3 := 'select count(distinct aeh.accounting_event_id) '
||' from ap_ae_headers_all aeh ,'||l_tab_name||' bae '
||' where nvl(aeh.description,''zzz'') = ''R11.5 Upgrade'' '
||' and bae.accounting_event_id = aeh.accounting_event_id'
||' and decode('||:p_org_id||', -99, -99, nvl(aeh.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into l_counter4;

tab2print('There are '||l_counter4||' events of the selected events that are Upgraded Events.');
BRPRINT;

if l_counter4 > 0 then

warningprint('There are '||l_counter4||' events of the selected events that are Upgraded Events.');
actionwarningprint('If you undo accounting for upgraded data, it may not recreate correctly');
BRPRINT;

end if;


tab1print('7.  Are the selected events that will be unaccounted in an Open or Closed period for AP?');

l_counter2 := 0;
l_counter4 := 0;
l_count := 0;

	  
sqlTxt3 := 'select count(distinct aea.accounting_event_id) '
||' from ap_accounting_events_all aea, '||l_tab_name||' bae, gl_period_statuses gps, ap_system_parameters_all asp '
||' where asp.set_of_books_id = gps.set_of_books_id '
||' and trunc(aea.accounting_date) between gps.start_date and gps.end_date'
||' and nvl(aea.org_id,-99) = nvl(asp.org_id,-99)  '
||' and gps.application_id = 200 '
||' and closing_status <> ''O'' '
||' and bae.accounting_event_id = aea.accounting_event_id'
||' and decode('||:p_org_id||', -99, -99, nvl(aea.org_id, -99)) = '||:p_org_id ;


execute immediate sqltxt3 into l_counter4;

tab2print('There are '||l_counter4||' events of the selected events that are in a Closed Period.');
BRPRINT;

if l_counter4 > 0 then

warningprint('There are '||l_counter4||' events of the selected events that are in a Closed Period.');
actionwarningprint('Please review the details below.  If you undo accounting in a closed period it will'||chr(10)||
'not recreate or allow you to sweep.');
BRPRINT;

end if;


tab1print('8.  Do you know what caused the Bad accounting i.e. a bug, corrupt data, etc...');
brprint;
tab1print('9.  Is encumbrance accounting being used?  You may need to create manual JE''s in GL for encumbrance lines.');

tab2print('There are '||enc_line_count||' encumbrance lines created for the selected events.');
BRPRINT;

if enc_line_count > 0 then

warningprint('There are '||enc_line_count||' encumbrance lines created for the selected events.');
actionwarningprint('Please review the details below.  If the encumbrance lines are transferred'||chr(10)||
'adjusting encumbrance entries may need to be created in GL.');
BRPRINT;

end if;


if l_rel_details = 1 then

BRPRINT;
sectionprint('This sections shows all of the accounting events that are selected.'||chr(10)||
' This does not show the related events (other events created for the same source_id)');

l_counter2 := 0;
l_counter4 := 0;


sqlTxt2 := 'select apae.org_id, apae.source_id, '
||' substr(apae.source_table,1,15) source_table,  '
||' substr(apae.accounting_event_id,1,15) event_id, '
||' apae.event_number, '
||' aeh.ae_header_id, apae.event_type_code, apae.event_status_code, aeh.gl_transfer_flag tran_flag, aeh.gl_transfer_run_id run_id,'
||' aeh.accounting_error_code, aeh.period_name per_name, aeh.accounting_date, aeh.set_of_books_id sob_id, '
||' substr(aeh.description,1,20) description '
||' from ap_ae_headers_all aeh, ap_accounting_events_all apae, '||l_tab_name||' selected'
||' where apae.accounting_Event_id = aeh.accounting_Event_id(+) '
||' and selected.accounting_event_id = apae.accounting_event_id '
||' and decode('||:p_org_id||', -99, -99, nvl(apae.org_id, -99)) = '||:p_org_id
||' order by apae.source_table, apae.source_id, aeh.set_of_books_id, apae.accounting_event_id, '
||' apae.event_number';


--disp_lengths := lengths(6,15,15,15,15,15,20,20,10,6,20,8,15,6,20);

run_sql('',sqlTxt2, :p_max_rows);



BRPRINT;


sectionprint('This sections shows all of the accounting events that are selected including line details.'||chr(10)||
'This does not show the related events (other events created for the same source_id)');


l_counter2 := 0;
l_counter4 := 0;

sqlTxt2 := 'select apae.org_id, apae.source_id,  '
||' substr(apae.source_table,1,15) source_table,  '
||' apae.event_type_code,  '
||' substr(apae.accounting_event_id,1,15) event_id, '
||' substr(aeh.ae_header_id,1,15) ae_header_id, '
||' apae.event_number event_num, '
||' apae.event_status_code, aeh.gl_transfer_flag tran_flag, aeh.gl_transfer_run_id run_id, '
||' aeh.accounting_error_code Header_error_code,'
||' aeh.accounting_date, aeh.period_name per_name,  aeh.set_of_books_id sob_id,  ael.ae_line_id,  '
||' ael.code_combination_id ccid, '
||' fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsb.chart_of_accounts_id, ael.code_combination_id) account, '
||' ael.accounted_dr, ael.accounted_cr, ael.entered_dr, ael.entered_cr, ael.gl_sl_link_id , '
||' substr(ael.reference2,1,15) invoice_id, substr(ael.reference3,1,15) check_id,  '
||' substr(ael.reference9,1,15) payment_id, ael.ae_line_type_code, '
||' ael.accounting_error_code Lines_error_code, ael.currency_code cur, '
||' ael.source_id Line_source_id, substr(ael.source_table,1,15) Line_source_table  '
||' FROM ap_ae_lines_all ael, ap_ae_headers_all aeh, ap_accounting_events_all apae, '
||' gl_sets_of_books gsb, '||l_tab_name||' selected '
||' where apae.accounting_event_id = aeh.accounting_event_id(+) '
||' and aeh.ae_header_id = ael.ae_header_id(+) '
||' and gsb.set_of_books_id(+) = aeh.set_of_books_id '
||' and selected.accounting_event_id = apae.accounting_event_id '
||' and decode('||:p_org_id||', -99, -99, nvl(aeh.org_id, -99)) = '||:p_org_id
||' order by apae.source_id, aeh.set_of_books_id, apae.event_number';

--disp_lengths := lengths(6,10,15,15,15,15,10,15,10,6,15,15,8,6,15,10,35,15,15,15,15,15,15,15,15,15,15,5,15,15);

run_sql('',sqlTxt2, :p_max_rows);


if enc_line_count  > 0 then


sectionprint('This sections shows all of the accounting events that are selected with Encumbrance line details.'||chr(10)||
'This does not show the related events (other events created for the same source_id)');


l_counter2 := 0;
l_counter4 := 0;

sqlTxt2 := 'select apae.org_id, apae.source_id,  '
||' substr(apae.source_table,1,15) source_table,  '
||' apae.event_type_code,  '
||' substr(apae.accounting_event_id,1,15) event_id, '
||' substr(aeh.ae_header_id,1,15) ae_header_id, '
||' apae.event_number event_num, '
||' apae.event_status_code, aeh.gl_transfer_flag tran_flag, aeh.gl_transfer_run_id run_id, '
||' aeh.accounting_error_code Header_error_code,'
||' aeh.accounting_date, aeh.period_name per_name,  aeh.set_of_books_id sob_id,  ael.encumbrance_line_id,  '
||' ael.code_combination_id ccid, '
||' fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsb.chart_of_accounts_id, ael.code_combination_id) account, '
||' ael.accounted_dr, ael.accounted_cr, ael.gl_sl_link_id , '
||' substr(ael.reference2,1,15) invoice_id, substr(ael.reference3,1,15) check_id,  '
||' substr(ael.reference9,1,15) payment_id, ael.encumbrance_line_type, '
||' ael.invoice_distribution_id inv_dist_id '
||' FROM    ap_ae_headers_all aeh, ap_encumbrance_lines_all ael,ap_accounting_events_all apae, '
||' gl_sets_of_books gsb, '||l_tab_name||' selected '
||' where apae.accounting_event_id = aeh.accounting_event_id(+) '
||' and aeh.ae_header_id = ael.ae_header_id(+) '
||' and gsb.set_of_books_id(+) = aeh.set_of_books_id '
||' and selected.accounting_event_id = apae.accounting_event_id '
||' order by apae.source_id, aeh.set_of_books_id, apae.event_number';


--disp_lengths := lengths(6,10,15,15,15,15,10,15,10,6,15,15,8,6,15,10,35,15,15,15,15,15,15,15,15);

run_sql('',sqlTxt2, :p_max_rows);

end if;

end if;


if l_rel_details = 2 then

sectionprint('Details of what accounting events have been created related to the accounting events selected.');  

BRPRINT;

l_counter2 := 0;
l_counter4 := 0;


	  
sqlTxt2 := 'select distinct decode(apae.accounting_event_id, '
||' nvl((select bae2.accounting_event_id from '||l_tab_name||' bae2'
||' where bae2.accounting_event_id = apae.accounting_Event_id),-99), ''SELECTED'', '
||' ''RELATED'') SELECTED,  '
||' apae.org_id, apae.source_id, '
||' substr(apae.source_table,1,15) source_table,  '
||' substr(apae.accounting_event_id,1,15) event_id, '
||' apae.event_number, '
||' aeh.ae_header_id, apae.event_type_code, apae.event_status_code, aeh.gl_transfer_flag tran_flag,'
||' aeh.gl_transfer_run_id run_id,'
||' aeh.accounting_error_code, aeh.period_name per_name, aeh.accounting_date, aeh.set_of_books_id sob_id, '
||' substr(aeh.description,1,20) description '
||' from ap_accounting_events_all apae, ap_ae_headers_all aeh, '
||' ( '
||' select apae3.accounting_event_id '
||' from ap_accounting_events_all apae3, ap_accounting_events_all apae2, '||l_tab_name||' bae '
||' where bae.accounting_event_id = apae2.accounting_event_id'
||' and apae3.source_table = apae2.source_table '
||' and apae3.source_id = apae2.source_id '
||' ) selected '
||' where apae.accounting_event_id = aeh.accounting_event_id(+) '
||' and apae.accounting_event_id = selected.accounting_event_id '
||' order by apae.source_id, event_id, apae.event_number, aeh.set_of_books_id';


--disp_lengths := lengths(10,6,15,15,15,15,15,20,20,10,6,20,8,15,6,20);

run_sql('',sqlTxt2, :p_max_rows);

BRPRINT;

sectionprint('Details of what accounting events have been created related to the accounting events that are selected'||chr(10)||
'Including the accounting lines created.');

l_counter2 := 0;
l_counter4 := 0;

sqlTxt2 := 'select distinct decode(apae.accounting_event_id, '
||' nvl((select bae2.accounting_event_id from '||l_tab_name||' bae2 '
||' where bae2.accounting_event_id = apae.accounting_Event_id),-99), ''SELECTED'', '
||' ''RELATED'') SELECTED,'
||' apae.org_id, apae.source_id,  '
||' substr(apae.source_table,1,15) source_table,  '
||' apae.event_type_code,  '
||' substr(apae.accounting_event_id,1,15) event_id, '
||' substr(aeh.ae_header_id,1,15) ae_header_id, '
||' apae.event_number event_num, '
||' apae.event_status_code, aeh.gl_transfer_flag tran_flag, aeh.gl_transfer_run_id run_id, '
||' aeh.accounting_error_code Header_error_code,'
||' aeh.accounting_date, aeh.period_name per_name,  aeh.set_of_books_id sob_id,  ael.ae_line_id,  '
||' ael.code_combination_id ccid, '
||' fnd_flex_ext.get_segs(''SQLGL'',''GL#'', gsb.chart_of_accounts_id, ael.code_combination_id) account, '
||' ael.accounted_dr, ael.accounted_cr, ael.entered_dr, ael.entered_cr, ael.gl_sl_link_id , '
||' substr(ael.reference2,1,15) invoice_id, substr(ael.reference3,1,15) check_id,  '
||' substr(ael.reference9,1,15) payment_id, ael.ae_line_type_code, '
||' ael.accounting_error_code Lines_error_code, ael.currency_code cur, '
||' ael.source_id Line_source_id, substr(ael.source_table,1,15) Line_source_table  '
||' FROM ap_ae_lines_all ael, ap_ae_headers_all aeh, ap_accounting_events_all apae, '
||' ( '
||' select apae3.accounting_event_id '
||' from ap_accounting_events_all apae3 ,ap_accounting_events_all apae2 ,'||l_tab_name||' bae '
||' where bae.accounting_event_id = apae2.accounting_event_id '
||' and apae3.source_table = apae2.source_table '
||' and apae3.source_id = apae2.source_id '
||' ) selected, '
||' gl_sets_of_books gsb '
||' where apae.accounting_event_id = aeh.accounting_event_id(+) '
||' and apae.accounting_event_id = selected.accounting_event_id '
||' and aeh.ae_header_id = ael.ae_header_id(+) '
||' and gsb.set_of_books_id(+) = aeh.set_of_books_id'
||' order by apae.source_id, aeh.set_of_books_id, apae.event_number';

--disp_lengths := lengths(10,6,10,15,15,15,15,10,15,10,6,15,15,8,6,15,10,35,15,15,15,15,15,15,15,15,15,15,5,15,15);

run_sql('',sqlTxt2, :p_max_rows);

end if;

else

brprint;
tab0print('Option 3, UNDO ONLY, was selected.  No analysis data will be displayed.');
brprint;

end if;


if l_atg_details <> 5 then

if enc_line_count  > 0 then

:p_lines_table2 := 'AP_ENCUMBRANCE_LINES_ALL';
:p_enc_lines2 := 'Y';

end if;

:p_lines_table := 'AP_AE_LINES_ALL';
:p_headers_table := 'AP_AE_HEADERS_ALL';
:p_max_rows := &v_max_rows;
:p_event_table2 := l_tab_name||' aea,';
:p_where_c := 'and aeh.accounting_event_id = aea.accounting_event_id';

	if l_atg_details = 1 then

	:p_gl_details := 'N';
	:p_tran := 'Y';
	:p_rel_details := 'N'; 
	:p_enc_lines := 'N';

	end if;
	
	if l_atg_details = 2 then
	
		:p_gl_details := 'Y';
		:p_tran := 'Y';
		:p_rel_details := 'N'; 
		:p_enc_lines := 'N';
	
	end if;

	if l_atg_details = 3 then
	
		:p_gl_details := 'N';
		:p_tran := 'Y';
		:p_rel_details := 'Y'; 
		:p_enc_lines := 'N';
	
	end if;

	if l_atg_details = 4 then
	
		:p_gl_details := 'Y';
		:p_tran := 'Y';
		:p_rel_details := 'Y'; 
		:p_enc_lines := 'N';
	
	end if;


else

brprint;
tab0print('Option 5, UNDO ONLY, was selected.  No accounting data will be displayed.');
brprint;


end if;

:p_continue := 'Y';

EXCEPTION

When l_exception then

tab0print('');

when others then --exception section3

  DBMS_OUTPUT.PUT_LINE(chr(9));

  ErrorPrint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; --end3



/* -------------------- Feedback ---------------------------- */



/* -------------------- Exception Section -------------------------- */

exception when others then --exception section 2

  DBMS_OUTPUT.PUT_LINE(chr(9));

  errorprint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));


end; --end2

exception when others then   --exceptions section 1

  DBMS_OUTPUT.PUT_LINE(chr(9));

  errorprint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; -- end 1

/

set term on

PROMPT 
prompt Output spooled to filename &outputfilename

spool off

@@APGLEntrieshsa.sql

REM  ==============SQL PLUS Environment setup===================

set term on

select chr(10) from sys.dual;
Prompt End Time
select to_char(sysdate, 'MM-DD-YYYY HH24:MI:SS') Time from sys.dual;

WHENEVER SQLERROR CONTINUE ROLLBACK;
WHENEVER OSERROR CONTINUE ROLLBACK;

set feedback off
set verify off
set echo off
set term on
set autoprint off
set serveroutput on size 1000000
set pagesize 100
set head off


REM ============ Spooling the output file====================

define outputfilename = apundoatg&v_date..txt

spool  &outputfilename


Prompt
select decode(upper(:p_undo_now), 'Y', 
       decode(upper(:p_continue), 'Y', 'Running Undo Process...', 'Error in analysis process, Undo process not ran.'),
       'Undo Now = N, skipping Undo Process') from sys.dual;
Prompt



select 'Start Time'||chr(10)||to_char(sysdate, 'MM-DD-YYYY HH24:MI:SS') Time from sys.dual where upper(:p_undo_now) = 'Y';
Prompt


REM =================Run the Pl/SQL api file ===================================

@@CoreApiTxtX.sql

begin  -- begin1

declare --declare 2

p_username varchar2(100);

p_respid number;

/* ------------------------ Declare Section -----------------------------*/

begin  --begin2

Show_Header('', 'APUndoAtgWithBackup');

/* -------------------- Execution secion ------------------------------- */

Declare  --declare 3

l_exception		exception;
l_error_msg		varchar2(500);
l_count 		NUMBER;
event_count 	NUMBER;
header_count	number;
l_tab1		varchar2(8) := '&v_date';
line_count		number;
enc_line_count	number;
payment_count	number;
pmthist_count	number;
invdist_count	number;
selected_count number;
SqlTxt			varchar2(5000);
SqlTxt2			varchar2(5000);
SqlTxt3			varchar2(5000);
l_applversion		varchar2(10);
l_mrc_enabled		varchar2(10);
l_ax_enabled		varchar2(10);
l_ax_info		number;
l_cursor		integer;
l_counter		integer;
l_counter2		integer;
l_counter4		integer;
l_event_id		varchar2(50) := NULL;
ql_markers 		V2T;
ql_titles  		V2T;
l_tax_code_id		number := NULL;
l_vat_code		varchar2(50) := NULL;
prim_atg		varchar2(30);
sec_atg		varchar2(30);
l_tab_name	varchar2(50) := :p_event_table;
period_valid	number;

--Custom API's

function object_test(object_test varchar2) return number is

	l_object_test 	number;

begin

l_object_test := 0;

select count(*) 
into l_object_test
from dba_objects
where object_name = upper(object_test);

return(l_object_test);

end object_test;

--end of custom API's


Begin  --begin 3


if :p_continue = 'Y' then 

:p_continue := 'N';  --jsh added 7/21

if upper(:p_undo_now) = 'Y' then  --undo now 


--Verify Org_id exists

l_count := 0;

select count(*) 
into l_count 
from fnd_product_groups 
where multi_org_flag = 'Y' ;

if l_count > 0 then


	if :p_org_id = -99 then
	
	tab0print('Org ID Entered: All Orgs');
	
	else 

	tab0print('Org ID Entered: '||:p_org_id);
	
	
	l_count := 0;

	select count(*)
	into l_count
	from ap_system_parameters_all
	where decode(:p_org_id, -99, -99, nvl(org_id, -99)) = :p_org_id;

		if l_count = 0 then
	
	        brprint;
	        errorprint('The ORG_ID entered ('||:p_org_id||') does not exist.');
		actionerrorprint('Please enter a valid ORG_ID.');
		
		raise l_exception;

		end if;

	end if;

else

tab0print('Org ID Entered: Multi Org is not enabled');

end if;

brprint;
tab0print('Table Name Used: '||l_tab_name);
brprint;



l_count := 0;


:p_tab1 := l_tab1;


l_count :=0;
event_count :=0;
header_count := 0;
line_count := 0;
enc_line_count := 0;
payment_count := 0;
pmthist_count := 0;
invdist_count := 0;

--Verify if Backup tables already exist

if object_test('bak_ap_atg_events_'||l_tab1) > 0 THEN

brprint;
errorprint('The Backup tables already exist.');
actionerrorprint('If you have used this script before, the old tables will need to be dropped.'||chr(10)||
'Make sure you don''t need the data from these tables before dropping them.'||chr(10)||
'Use the SQL below to drop the tables.');

brprint;

line_out('drop table bak_ap_enc_lines_'||l_tab1||';');
line_out('drop table bak_ap_ae_lines_'||l_tab1||';');
line_out('drop table bak_ap_inv_dist_'||l_tab1||';');
line_out('drop table bak_ap_inv_pmt_'||l_tab1||';');
line_out('drop table bak_ap_pmt_hist_'||l_tab1||';');
line_out('drop table bak_ap_ae_headers_'||l_tab1||';');
line_out('drop table bak_ap_atg_events_'||l_tab1||';');
if object_test('AP_LIABILITY_BALANCE') > 0 then
line_out('drop table bak_ap_liab_bal_'||l_tab1||';');
end if;

raise l_exception;

end if;

if object_test(l_tab_name) = 0 then

BRPRINT;
errorprint(l_tab_name||' Table Does not exist');
actionerrorprint('The table must exist to run this script.  Run APRunBeforeUndoAtg.sql to create this table');

	raise l_exception;

end if;

	if object_test(l_tab_name) > 0 then

		if Column_Exists(l_tab_name,'ACCOUNTING_EVENT_ID') = 'N' then

		brprint;
errorprint(l_tab_name||' Table Does not have an ACCOUNTING_EVENT_ID column');
actionerrorprint('The table must have an ACCOUNTING_EVENT_ID column to run this script with Table exist option selected');

raise l_exception;
	
	
		end if;
		
	end if;


selected_count := 0;

sqlTxt3 := 'select count(*) from '||l_tab_name;

execute immediate sqltxt3 into selected_count;

	if selected_count = 0 then 

BRPRINT;
errorprint('The Table has 0 Rows');
actionerrorprint('The table must have rows to run this script.  Run APRunBeforeUndoAtg.sql to populate this table');

raise l_exception;
	
	end if;

	  
sectionprint('BackUp Table Count');

l_count := 0;

sqlTxt3 := 'select * from '||l_tab_name;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);


tab1print(l_tab_name||' COUNT: '||l_counter);


execute immediate 'create table bak_ap_atg_events_'||l_tab1||' as '
||' select distinct * from ap_accounting_events_all '
||'      WHERE  accounting_event_id in (select accounting_event_id'
||'                                     from '||l_tab_name||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := 0;

sqlTxt3 := 'select * from bak_ap_atg_events_'||l_tab1;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

tab1print('BAK_AP_ATG_EVENTS_'||l_tab1||' COUNT: '||l_counter);


execute immediate 'create table bak_ap_ae_headers_'||l_tab1
||' as select distinct * from ap_ae_headers_all '
||' WHERE  accounting_event_id in (select accounting_event_id'
||'                                from '||l_tab_name||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;


sqlTxt3 := 'select * from bak_ap_ae_headers_'||l_tab1;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

tab1print('BAK_AP_AE_HEADERS_'||l_tab1||' COUNT: '||l_counter);

execute immediate 'create table bak_ap_ae_lines_'||l_tab1
||' as select distinct * from ap_ae_lines_all'
||' WHERE ae_header_id IN ('
||'                         SELECT aeh.ae_header_id'
||'                         FROM   ap_ae_headers_all aeh'
||'                         WHERE  accounting_event_id in (select accounting_event_id'
||'                                                        from '||l_tab_name||'))'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

sqlTxt3 := 'select * from bak_ap_ae_lines_'||l_tab1;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

tab1print('BAK_AP_AE_LINES_'||l_tab1||' COUNT: '||l_counter);


execute immediate 'create table bak_ap_enc_lines_'||l_tab1
||' as select distinct * from ap_encumbrance_lines_all'
||' WHERE ae_header_id IN ('
||' 			   SELECT aeh.ae_header_id'
||' 			   FROM   ap_ae_headers_all aeh'
||'                        WHERE  accounting_event_id in (select accounting_event_id'
||' 							  from '||l_tab_name||'))'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

sqlTxt3 := 'select * from bak_ap_enc_lines_'||l_tab1;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

tab1print('BAK_AP_ENC_LINES_'||l_tab1||' COUNT: '||l_counter);



execute immediate 'create table bak_ap_inv_dist_'||l_tab1
||' as select distinct aid.* '
||' from ap_invoice_distributions_all aid, ap_accounting_events_all aea,'||l_tab_name||' bae'
||' where bae.accounting_event_id = aea.accounting_event_id'
||' and aid.accounting_event_id = aea.accounting_event_id'
||' and nvl(aea.org_id,-99) = nvl(aid.org_id, -99)'
||' and decode('||:p_org_id||', -99, -99, nvl(aid.org_id, -99)) = '||:p_org_id;

sqlTxt3 := 'select * from bak_ap_inv_dist_'||l_tab1;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

tab1print('BAK_AP_INV_DIST_'||l_tab1||' COUNT: '||l_counter);

execute immediate 'create table bak_ap_inv_pmt_'||l_tab1
||' as select distinct aip.* '
||' from ap_invoice_payments_all aip, ap_accounting_events_all aea,'||l_tab_name||' bae'
||' where bae.accounting_event_id = aea.accounting_event_id'
||' and aip.accounting_event_id = aea.accounting_event_id'
||' and nvl(aea.org_id,-99) = nvl(aip.org_id, -99)'
||' and decode('||:p_org_id||', -99, -99, nvl(aip.org_id, -99)) = '||:p_org_id;

sqlTxt3 := 'select * from bak_ap_inv_pmt_'||l_tab1;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

tab1print('BAK_AP_INV_PMT_'||l_tab1||' COUNT: '||l_counter);


execute immediate 'create table bak_ap_pmt_hist_'||l_tab1
||' as select distinct aph.* '
||' from ap_payment_history_all aph, ap_accounting_events_all aea,'||l_tab_name||' bae'
||' where bae.accounting_event_id = aea.accounting_event_id'
||' and aph.accounting_event_id = aea.accounting_event_id'
||' and nvl(aea.org_id,-99) = nvl(aph.org_id, -99)'
||' and decode('||:p_org_id||', -99, -99, nvl(aph.org_id, -99)) = '||:p_org_id;

sqlTxt3 := 'select * from bak_ap_pmt_hist_'||l_tab1;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

tab1print('BAK_AP_PMT_HIST_'||l_tab1||' COUNT: '||l_counter);

if object_test('AP_LIABILITY_BALANCE') > 0 then

execute immediate 'create table bak_ap_liab_bal_'||l_tab1
||' as select distinct * from ap_liability_balance'
||' WHERE ae_header_id IN ('
||'                         SELECT aeh.ae_header_id'
||'                         FROM   ap_ae_headers_all aeh'
||'                         WHERE  accounting_event_id in (select accounting_event_id'
||'                                                        from '||l_tab_name||'))'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

sqlTxt3 := 'select * from bak_ap_liab_bal_'||l_tab1;

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

tab1print('BAK_AP_LIAB_BAL_'||l_tab1||' COUNT: '||l_counter);

end if;

sectionprint('Update/Delete Row Count');

l_count := 0;

execute immediate 'DELETE FROM ap_accounting_events_all '
||' WHERE accounting_event_id in  (select accounting_event_id from bak_ap_atg_events_'||l_tab1||')'
||' and upper('''||:p_del_events2||''') = ''Y'''
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows Deleted from AP_ACCOUNTING_EVENTS: '||l_count);

--added for family pack D

l_count := 0;


begin

if upper(:p_del_events2) <> 'Y' then

execute immediate 'update ap_accounting_events_all '
||' set event_status_code = ''CREATED'' '
||' WHERE accounting_event_id in  (select accounting_event_id from bak_ap_atg_events_'||l_tab1||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows updated in AP_ACCOUNTING_EVENTS: '||l_count);

end if;

end;

l_count := 0;

execute immediate 'DELETE FROM ap_ae_headers_all'
 ||' WHERE ae_header_id in  (select distinct ae_header_id from bak_ap_ae_headers_'||l_tab1||')'
 ||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows Deleted from AP_AE_HEADERS: '||l_count);


l_count :=0;

execute immediate 'DELETE FROM ap_ae_lines_all'
    ||' WHERE ae_header_id IN (SELECT distinct ae_header_id from bak_ap_ae_lines_'||l_tab1||')'
    ||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows Deleted from AP_AE_LINES: '||l_count);


l_count := 0;

execute immediate 'DELETE FROM ap_encumbrance_lines_all'
    ||' WHERE ae_header_id IN (SELECT distinct ae_header_id from bak_ap_enc_lines_'||l_tab1||')'
    ||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows Deleted from AP_ENCUMBRANCE_LINES: '||l_count);

l_count := 0;

execute immediate 'UPDATE ap_invoice_distributions_all'
||' SET posted_flag = ''N'', cash_posted_flag = ''N'', accrual_posted_flag = ''N'' ,'
||' accounting_event_id = decode(upper('''||:p_del_events2||'''), ''Y'', null, accounting_event_id)'
||' where invoice_distribution_id in  (select distinct invoice_distribution_id from bak_ap_inv_dist_'||l_tab1||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows updated in AP_INVOICE_DISTRIBUTIONS: '||l_count);


l_count := 0;

execute immediate 'UPDATE ap_invoice_payments_all'
||' SET posted_flag = ''N'', cash_posted_flag = ''N'', accrual_posted_flag = ''N'' ,'
||' accounting_event_id = decode(upper('''||:p_del_events2||'''), ''Y'', null, accounting_event_id)'
||' where invoice_payment_id in  (select distinct invoice_payment_id from bak_ap_inv_pmt_'||l_tab1||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows updated in AP_INVOICE_PAYMENTS: '||l_count);

l_count := 0;

execute immediate 'UPDATE ap_payment_history_all'
||' SET posted_flag = ''N'', '
||' accounting_event_id = decode(upper('''||:p_del_events2||'''), ''Y'', null, accounting_event_id)'
||' where payment_history_id in  (select distinct payment_history_id from bak_ap_pmt_hist_'||l_tab1||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows updated in AP_PAYMENT_HISTORY: '||l_count);

if object_test('AP_LIABILITY_BALANCE') > 0 then

l_count :=0;

execute immediate 'DELETE FROM ap_liability_balance'
    ||' WHERE ae_header_id IN (SELECT distinct ae_header_id from bak_ap_liab_bal_'||l_tab1||')'
    ||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;

l_count := SQL%ROWCOUNT;

tab1print('Rows Deleted from AP_LIABILITY_BALANCE: '||l_count);

	
end if;

end if;  --undo now

:p_continue := 'Y';  --jsh added 7/21

else 

	brprint;
	ErrorPrint('Error in analysis process, Undo process not ran.');
	ActionErrorPrint('Review and fix error and run the script again.');
  	brprint;

:p_continue := 'N';  --jsh added 7/21

end if; --p_continue

if upper(:p_sweep_now) = 'N' and upper(:p_undo_now) = 'Y' then  --jsh modified 7/21

brprint;
tab0Print('*************************IMPORTANT****************************************************');
tab0print('This script does not commit the changes.  Please review the spool file to verify that the');
tab0print('correct number of rows were deleted/updated/swept.  The lines totals deleted/updated');
tab0print('should match the totals from runbeforeundoatg.sql and the totals from the count on the backup tables.');
tab0print('The events swept should match the number of selected events found in closed periods.');
tab0print('If the correct number of rows have been updated/deleted/swept');
tab0print('Type COMMIT; to commit the changes.  If the wrong number of rows were updated type ROLLBACK;');
tab0print('*************************IMPORTANT****************************************************');
BRPRINT;
tab0print('NOTE:  Please keep all backup tables through at least your next closing');

end if;

EXCEPTION

When l_exception then

tab0print('');

when others then --exception section3

  DBMS_OUTPUT.PUT_LINE(chr(9));

  ErrorPrint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; --end3



/* -------------------- Feedback ---------------------------- */



/* -------------------- Exception Section -------------------------- */

exception when others then --exception section 2

  DBMS_OUTPUT.PUT_LINE(chr(9));

  errorprint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; --end2

exception when others then   --exceptions section 1

  DBMS_OUTPUT.PUT_LINE(chr(9));

  errorprint(sqlerrm||' occurred in script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; -- end 1

/

select chr(10) from sys.dual;
select 'End Time'||chr(10)||to_char(sysdate, 'MM-DD-YYYY HH24:MI:SS') Time from sys.dual where upper(:p_undo_now) = 'Y';
Prompt

spool off

PROMPT 
prompt Output spooled to filename &outputfilename


REM ============ Spooling the output file====================

define outputfilename = apundosweep&v_date..txt

spool  &outputfilename


Prompt
select decode(upper(:p_sweep_now), 'Y', 
       decode(upper(:p_continue), 'Y', 'Running Sweep Process...', 'Error in prereq process, Sweep process not ran.'),
       'Sweep Now = N, skipping Sweep Process') from sys.dual;
Prompt



select 'Start Time'||chr(10)||to_char(sysdate, 'MM-DD-YYYY HH24:MI:SS') Time from sys.dual where upper(:p_sweep_now) = 'Y';
Prompt


REM =================Run the Pl/SQL api file ===================================

@@CoreApiTxtX.sql

begin  -- begin1

declare --declare 2

p_username varchar2(100);

p_respid number;

/* ------------------------ Declare Section -----------------------------*/

begin  --begin2

Show_Header('', 'APUndoSweep');

/* -------------------- Execution secion ------------------------------- */

Declare  --declare 3

l_exception		exception;
l_error_msg		varchar2(500);
l_count 		NUMBER;
  l_accounting_event_id             NUMBER;
  v_count					NUMBER :=0;
v_count1					NUMBER :=0;
v_count2					NUMBER :=0;
v_count3					NUMBER :=0;
v_count4					NUMBER :=0;
v_count5					NUMBER :=0;
v_count6					NUMBER :=0;
v_count7					NUMBER :=0;
sqlTxt3 					varchar2(2000);
l_cursor		integer;
l_counter		integer;
l_event_id		varchar2(50) := NULL;
per_name		varchar2(50);
atg_date		date;
period_valid	number := 0;
ql_markers 		V2T;
ql_titles  		V2T;

Begin  --begin 3


if upper(:p_undo_now) = 'Y' and upper(:p_sweep_now) = 'Y' and :p_continue = 'Y' then

--Verify Org_id exists

l_count := 0;

select count(*) 
into l_count 
from fnd_product_groups 
where multi_org_flag = 'Y' ;

if l_count > 0 then


	if :p_org_id = -99 then
	
	tab0print('Org ID Entered: All Orgs');
	
	else 

	tab0print('Org ID Entered: '||:p_org_id);
	
	
	l_count := 0;

	select count(*)
	into l_count
	from ap_system_parameters_all
	where decode(:p_org_id, -99, -99, nvl(org_id, -99)) = :p_org_id;

		if l_count = 0 then
	
	        brprint;
	        errorprint('The ORG_ID entered ('||:p_org_id||') does not exist.');
		actionerrorprint('Please enter a valid ORG_ID.');
		
		raise l_exception;

		end if;

	end if;

else

tab0print('Org ID Entered: Multi Org is not enabled');

end if;


select max(start_date), max(period_name)
into atg_date, per_name
from gl_period_statuses gps, ap_system_parameters_all asp
where gps.period_name = '&v_period'
and nvl(asp.org_id,-99) = nvl(&v_org_id,-99)
and asp.set_of_books_id = gps.set_of_books_id
and gps.application_id = 200
and closing_status = 'O';

sqlTxt3 := 'select distinct bae.accounting_event_id '
||' from bak_ap_atg_events_'||:p_tab1||' bae, gl_period_statuses gps, ap_system_parameters_all asp '
||' where nvl(bae.org_id,-99) = nvl(asp.org_id, -99) '
||' and trunc(bae.accounting_date) between gps.start_date and gps.end_date'
||' and asp.set_of_books_id = gps.set_of_books_id '
||' and gps.application_id = 200 '
||' and closing_status <> ''O''';



	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt3, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_event_id,15);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
	    dbms_sql.column_value(l_cursor, 1, l_event_id);

execute immediate 'update ap_accounting_events_all'
||' set accounting_date = '''||atg_date||''''
||' WHERE accounting_event_id in  (select accounting_event_id from bak_ap_atg_events_'||:p_tab1
||' where accounting_event_id = '||l_event_id||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;


v_count1:= v_count1 + SQL%ROWCOUNT;

execute immediate 'update ap_invoice_payments_all'
||' set accounting_date = '''||atg_date||''',period_name = '''||per_name||''''
||' WHERE invoice_payment_id in (select invoice_payment_id from bak_ap_inv_pmt_'||:p_tab1
||' where accounting_event_id = '||l_event_id||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;


v_count2:= v_count2 + SQL%ROWCOUNT;

execute immediate 'update ap_payment_history_all'
||' set accounting_date = '''||atg_date||''''
||' WHERE payment_history_id in (select payment_history_id from bak_ap_pmt_hist_'||:p_tab1
||' where accounting_event_id = '||l_event_id||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;


v_count3:= v_count3 + SQL%ROWCOUNT;

execute immediate 'update ap_invoice_distributions_all'
||' set accounting_date = '''||atg_date||''',period_name = '''||per_name||''''
||' WHERE invoice_distribution_id in (select invoice_distribution_id from bak_ap_inv_dist_'||:p_tab1
||' where accounting_event_id = '||l_event_id||')'
||' and decode('||:p_org_id||', -99, -99, nvl(org_id, -99)) = '||:p_org_id;


v_count4:= v_count4 + SQL%ROWCOUNT;

 end loop;
 DBMS_OUTPUT.PUT_LINE(chr(9));
 dbms_sql.close_cursor(l_cursor);

dbms_output.put_line(TO_CHAR(v_count4)|| ' rows updated in ap_invoice_distributions_all'); 
dbms_output.put_line(TO_CHAR(v_count2)|| ' rows updated in ap_invoice_payments_all'); 
dbms_output.put_line(TO_CHAR(v_count3)|| ' rows updated in ap_payment_history_all'); 
dbms_output.put_line(TO_CHAR(v_count1)|| ' rows udpated in ap_accounting_events_all'); 

brprint;
tab0Print('*************************IMPORTANT****************************************************');
tab0print('This script does not commit the changes.  Please review the spool file to verify that the');
tab0print('correct number of rows were deleted/updated/swept.  The lines totals deleted/updated');
tab0print('should match the totals from runbeforeundoatg.sql and the totals from the count on the backup tables.');
tab0print('The events swept should match the number of selected events found in closed periods.');
tab0print('If the correct number of rows have been updated/deleted/swept');
tab0print('Type COMMIT; to commit the changes.  If the wrong number of rows were updated type ROLLBACK;');
tab0print('*************************IMPORTANT****************************************************');
BRPRINT;
tab0print('NOTE:  Please keep all backup tables through at least your next closing');

end if;

EXCEPTION

When l_exception then

tab0print('');

when others then --exception section3

  DBMS_OUTPUT.PUT_LINE(chr(9));

  ErrorPrint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; --end3



/* -------------------- Feedback ---------------------------- */



/* -------------------- Exception Section -------------------------- */

exception when others then --exception section 2

  DBMS_OUTPUT.PUT_LINE(chr(9));

  errorprint(sqlerrm||' occurred in Script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; --end2

exception when others then   --exceptions section 1

  DBMS_OUTPUT.PUT_LINE(chr(9));

  errorprint(sqlerrm||' occurred in script');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; -- end 1

/

select chr(10) from sys.dual;
select 'End Time'||chr(10)||to_char(sysdate, 'MM-DD-YYYY HH24:MI:SS') Time from sys.dual where upper(:p_sweep_now) = 'Y';
Prompt

spool off

PROMPT 
prompt Output spooled to filename &outputfilename

