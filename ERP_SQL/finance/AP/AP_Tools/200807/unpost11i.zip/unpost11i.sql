REM   $Header:  unpost11i.sql version 2.0 [Last Modified Date  19-MAR-03 00:00:00] support 
REM   ========================================================================= 
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA 
REM   Oracle Support Services.  All rights reserved. 
REM
REM   PURPOSE:           Backup and Unpost a transfer run in AP.
REM   PRODUCT:           Accounts Payable (AP) 
REM   PRODUCT VERSIONS:  11.5 
REM   PLATFORM:          Generic 
REM   PARAMETERS:        Transfer Run Id
REM   =========================================================================   
REM   USAGE:    sqlplus apps/password@unpost11i.sql
REM   OUTPUT:     The test will create an output file in text format named 
REM                   unpost11i_transfer_run_id_MMDDHH24MI.txt Open the file in a text editor and 
REM                   review the output
REM   =========================================================================
REM   CHANGE HISTORY:
REM     19-MAR-2003   shorgan  Created
REM   =========================================================================


undefine v_tr_run_id

set linesize 1000 
set echo off
set head on
set feedback on
set verify off
set termout on

prompt
accept v_tr_run_id NUMBER Prompt 'Enter the transfer run Id you want to unpost in AP: '
prompt

define v_tr_run_id = &v_tr_run_id

--Get the Date and Time

set term off

COLUMN TODAY NEW_VALUE v_date
SELECT TO_CHAR(SYSDATE, 'MMDDHH24MI') TODAY
from sys.dual;

--Get Chart Of Accounts ID

COLUMN coa NEW_VALUE v_coa
select chart_of_accounts_id coa
from gl_sets_of_books
where set_of_books_id in (
select set_of_books_id 
from ap_system_parameters);

set term on

--Spooling the output file

Define v_spoolfilename  = 'unpost11i_&v_tr_run_id._&v_date..txt'

PROMPT
PROMPT Running.....
PROMPT 
spool  &v_spoolfilename


prompt If you have used this script before, the old tables may need to be dropped.
prompt If 
prompt Make sure you don't need the data from these tables before dropping them.
prompt Use the SQL below to drop the tables.
PROMPT
prompt drop table unpost_ap_ae_lines_&v_tr_run_id;
prompt drop table unpost_ap_ae_headers_&v_tr_run_id;



--backup the data in ap_ae_lines_all

create table UNPOST_ap_ae_lines_&v_tr_run_id as
select * from ap_ae_lines_all ael
 where exists (select 'x' from ap_ae_headers_all aeh
                        where aeh.ae_header_id = ael.ae_header_id 
                        and aeh.gl_transfer_run_id in (&v_tr_run_id));

--backup the data in ap_ae_headers_all

create table UNPOST_ap_ae_headers_&v_tr_run_id as 
select * from ap_ae_headers_all
where gl_transfer_run_id in (&v_tr_run_id);



prompt
Prompt Backup Table Name = unpost_AP_AE_LINES_&v_TR_RUN_ID 
prompt
Prompt UNPOST_AP_AE_LINES_&v_TR_RUN_ID Row Count
PROMPT =========================================
PROMPT
select count(*) from UNPOST_AP_AE_LINES_&v_TR_RUN_ID; 

--added code for ap_liability_balance table

declare

l_cursor                integer;
l_counter               integer;
l_exception             exception;
l_error_msg             varchar2(500);
l_count                 NUMBER;
SqlTxt          varchar2(5000);


function object_test(object_test varchar2) return number is

        l_object_test   number;

begin

l_object_test := 0;

select count(*) 
into l_object_test
from dba_objects
where object_name = object_test;

return(l_object_test);

end object_test;


begin


if object_test('AP_LIABILITY_BALANCE') > 0 THEN

sqlTxt := 'create index UNPOST_AP_AE_L_IDX_&v_TR_RUN_ID on UNPOST_AP_AE_LINES_&v_TR_RUN_ID (ae_header_id)';

execute immediate sqltxt;

sqlTxt := 'analyze table UNPOST_AP_AE_LINES_&v_TR_RUN_ID estimate statistics';

execute immediate sqltxt;

sqlTxt := 'DELETE FROM ap_liability_balance alb' 
||' WHERE ae_line_id in (select ael.ae_line_Id  '
||' from UNPOST_AP_AE_LINES_&v_TR_RUN_ID ael)';

execute immediate sqltxt;

end if;

end;


/

--Update ap_ae_lines_all

prompt
Prompt Rows updated in AP_AE_LINES_ALL for transfer run id = &v_tr_run_id
PROMPT ==================================================================
PROMPT

 update ap_ae_lines_all ael
   set ael.gl_sl_link_id = NULL
 where exists (select 'x' from ap_ae_headers_all aeh
                        where aeh.ae_header_id = ael.ae_header_id 
                        and aeh.gl_transfer_run_id in (&v_tr_run_id));





prompt
Prompt Backup Table Name = UNPOST_AP_AE_HEADERS_&v_TR_RUN_ID
prompt

Prompt UNPOST_AP_AE_HEADERS_&v_TR_RUN_ID Row Count
PROMPT ============================================
PROMPT
select count(*) from UNPOST_AP_AE_HEADERS_&v_TR_RUN_ID; 


--Update ap_ae_headers_all

Prompt Rows updated in AP_AE_HEADERS_ALL for transfer run id = &v_tr_run_id
prompt ====================================================================
PROMPT

set serveroutput on

declare

l_cursor                integer;
l_counter               integer;
l_exception             exception;
l_error_msg             varchar2(500);
l_count                 NUMBER;
SqlTxt          varchar2(5000);


function object_test(object_test varchar2) return number is

        l_object_test   number;

begin

l_object_test := 0;

select count(*) 
into l_object_test
from dba_objects
where object_name = object_test;

return(l_object_test);

end object_test;


begin


if object_test('AP_LIABILITY_BALANCE') > 0 THEN

sqltxt := 'update ap_ae_headers_all'
||' set gl_transfer_run_id = -1,'
||' gl_transfer_flag   = ''N'','
||' trial_balance_flag = ''N'' '
||' where  gl_transfer_run_id in (&v_tr_run_id)';

execute immediate sqltxt;

else

sqltxt := 'update ap_ae_headers_all'
||' set gl_transfer_run_id = -1,'
||' gl_transfer_flag   = ''N'' '
||' where  gl_transfer_run_id in (&v_tr_run_id)';

execute immediate sqltxt;

end if;

dbms_output.put_line(SQL%ROWCOUNT||' rows updated.'); 

end;

/

set serveroutput off

COMMIT;

spool off

prompt
prompt Output spooled to filename = &v_spoolfilename
prompt
