/*************************************************************************************************************************
Modified display_sql Code.  The code was modified to allow the columns to be displayed in Portrait layout format
*************************************************************************************************************************/
-- Function Name: Display_SQLP
--
-- Usage:
--     a_number := Display_SQLP('SQL statement','Name for Header','Long Flag',
--                 'Feedback','Max Rows','Indent Level','Null Columns', 'Show Spaces');
--
-- Parameters:
--     SQL Statement - Any valid SQL Select Statement
--     Name for Header - Text String to for heading the output
--     Long Flag - Y or N  - If set to N then this will not output
--                 any LONG columns (default = Y)
--     Feedback - Y or N indicates whether to indicate the number of rows
--                selected automatically in the output (default = Y)
--     Max Rows - Limits the number of rows output to this number. NULL or
--                ZERO value indicates unlimited. (Default = NULL)
--     Indent Level - Indicates if the table should be indented and if so
--                    how far: 0 = no indent, 1=.25in, 2=.5in, 3 = .75in
--                    (Default = 0)
--	 Null Columns - Y or N - If set to Y, columns will Null values will be displayed.  If set to N,
--   			   columns with null values will not be displayed.
--
--	 Show Spaces - Y or N - If set to Y, column value will be enclosed by >< to show leading and 
--   			   trailing spaces.  If set to N, only the column value will be displayed.

-- Returns:
--      The function returns the # of rows selected.
--      If there is an error then the function returns -1.
--
-- Output:
--      Displays the output of the SQL statement in various HTML table formats.
--
-- Examples:
--      declare
--         num_rows number;
--      begin
--         num_rows := Display_SQLPL('select * from ar_system_parameters_all',
--                                 'AR Parameters', 'Y', 'N',null, 'P', 'Y');
--      end;
--

function Display_SQLP (p_sql_statement  varchar2
                    , table_alias      varchar2
                    , display_longs    varchar2 default 'Y'
                    , p_feedback       varchar2 default 'Y'
                    , p_max_rows       number   default null
                    , p_ind_level      number   default 0
			  , p_null		   varchar2 default 'N'
			  , p_spaces		   varchar2 default 'N'
                    , p_current_exec   number default 0) return number is

	error_position			number;
	error_position_end		number;
      row_counter				number;
      hold_exclude_cols			boolean;
      hold_sql_needed			varchar2(3);
	hold_string				varchar2(32767)  default null;
	hold_option				varchar2(32767)  default null;
	hold_sql				varchar2(32767)  default null;
	hold_sql_remain			varchar2(32767)  default null;
	hold_element			varchar2(32767)  default null;
	hold_long				long;
	hold_clob				clob;
	hold_length				integer;
	hold_bgcolor			varchar2(40);
	hold_color				varchar2(40);
	hold_open_paren			number;
	hold_curr_loc			number;
	hold_end_pos			number;
	column_counter			binary_integer  default 1;
	value_counter			binary_integer  default 1;
	column_high				binary_integer  default 1;
      value_high				binary_integer  default 1;
	v_cursor_id				number;
	v_dummy				integer;
	l_hold_length			varchar2(20);
	l_hold_date_format		varchar2(40);
	l_hold_type				varchar2(40);
	v_col_headers			V2T;
	v_values				V2T;
	v_options				V2T;
	v_describe				dbms_sql.desc_tab;
	T_VARCHAR2				constant integer := 1;
	T_NUMBER				constant integer := 2;
	T_LONG				constant integer := 8;
	T_ROWID				constant integer := 11;	
	T_DATE				constant integer := 12;	
	T_RAW					constant integer := 23;
	T_CHAR				constant integer := 96;
	T_TYPE				constant integer := 109;
	T_CLOB				constant integer := 112;
	T_BLOB				constant integer := 113;
	T_BFILE				constant integer := 114;
	l_max_rows 				integer;
	l_feedback_txt			varchar2(240);

begin

   if nvl(p_max_rows,0) = 0 then
     l_max_rows := null;
   else
     l_max_rows := p_max_rows;
   end if;


	if p_current_exec = 0 then
		select value into l_hold_date_format from nls_session_parameters where parameter = 'NLS_DATE_FORMAT';
		execute immediate 'alter session set nls_date_format = ''DD-MON-YYYY HH24:MI''';
	end if;
	begin
		v_cursor_id := DBMS_SQL.OPEN_CURSOR;
		DBMS_SQL.PARSE(v_cursor_id, p_sql_statement, DBMS_SQL.V7);
		DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, column_high, v_describe);
		hold_sql := 'select ';
		hold_sql_needed := null;
		hold_exclude_cols := false;
		hold_sql_remain := ltrim(substr(replace(p_sql_statement,chr(10),' '), 7));
		for value_counter in 1..column_high loop
			if v_describe(value_counter).col_type = T_LONG then
				hold_length := 25000;
			else
				hold_length := to_number(v_describe(value_counter).col_max_len);
			end if;
			if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
				DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_string, greatest(hold_length,30));
			elsif v_describe(value_counter).col_type = T_CLOB then
				DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_clob);
			else
				null;
			end if;
			hold_string := v_describe(value_counter).col_name;
			if value_counter = 1 then
				v_col_headers := V2T(replace(initcap(hold_string),'|','<br>'));
			else
				v_col_headers.EXTEND;
 			        v_col_headers(value_counter) := replace(initcap(hold_string),'|','<br>');
 			end if;
			
 			if substr(hold_sql_remain,1,1) != '*' then
				hold_end_pos := 1;
				hold_open_paren := 0;
				loop
					if substr(hold_sql_remain,hold_end_pos,1) = '(' then
						hold_open_paren := hold_open_paren + 1;
					elsif substr(hold_sql_remain,hold_end_pos,1) = ')' then
						hold_open_paren := hold_open_paren - 1;
					elsif substr(hold_sql_remain,hold_end_pos,1) = ',' 
					   or lower(substr(hold_sql_remain, hold_end_pos, 4)) = ' from ' then
						if hold_open_paren = 0 then
							exit;
						end if;
					end if;
					hold_end_pos := hold_end_pos + 1;
					if hold_end_pos > length(p_sql_statement) then 
						exit; 
					end if;
				end loop;
				hold_element := substr(hold_sql_remain, 1, hold_end_pos);
				hold_sql_remain := ltrim(substr(hold_sql_remain, hold_end_pos + 1));
			else
				hold_element := v_describe(value_counter).col_name;
			end if;
 			if v_describe(value_counter).col_type in (T_VARCHAR2, T_CHAR, T_NUMBER, T_DATE, T_LONG, T_CLOB, T_ROWID) then
				hold_sql := hold_sql || hold_sql_needed || hold_element;
			else
 				hold_exclude_cols := true;
			end if;
			hold_sql_needed := ', ';
		end loop;
		if hold_exclude_cols then
			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
			hold_sql := hold_sql || ' ' || substr(p_sql_statement,instr(lower(p_sql_statement),' from '));
			row_counter := Display_SQL (hold_sql, table_alias, display_longs, p_current_exec + 1) + 1;
		else
         if nvl(p_ind_level,0) != 0 then
            line_out('<div class=ind'||to_char(p_ind_level)||'>');
         end if;
			if table_alias is not null then

				line_out('<br><span class="BigPrint">' || table_alias ||'</span>');  
			 	
			end if;
			Start_Table(table_alias);  
		
				line_out('<tr>');
				line_out('<th id=1>Column</th>');
				line_out('<th id=2>Value</th>');
				line_out('</tr>');

			v_dummy := DBMS_SQL.EXECUTE(v_cursor_id);

			row_counter := 1;
			loop
				if DBMS_SQL.FETCH_ROWS(v_cursor_id) = 0 then
					exit;
				end if;
				for value_counter in 1..column_high loop
					if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_string);
					else
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_clob);
						hold_string := 'CLOB';
					end if;
					hold_option := null;
					if v_describe(value_counter).col_type = T_DATE then
						hold_string := replace(hold_string,' ','&nbsp;');
					elsif v_describe(value_counter).col_type = T_VARCHAR2 then
						hold_string := replace(replace(hold_string,'<','&lt;'),'>','&gt;');
					else
						null;
					end if;
					hold_string := replace(hold_string,' ','&nbsp;');  
					if value_counter = 1 then
						v_values := V2T(hold_string);
						
					else
						v_values.EXTEND;
						v_values(value_counter) := hold_string;
					end if;
				end loop;

				if row_counter > 1 then

	line_out('<br><span class="BigPrint">' || table_alias ||' Row '||row_counter||' </span> '); 
 	line_out('</style>') ; 
	line_out('</head><body>');  
	line_out('<table cellspacing=0 summary="' || table_alias ||' Row '||row_counter||' "><tr> ');  

line_out('<tr>');
line_out('<th id=1>Column</th>');
line_out('<th id=2>Value</th>');
line_out('</tr>');


				end if;

		for i in 1..v_values.COUNT loop
				if v_values(i) is null then
					if upper(nvl(p_null,'Y')) = 'Y' then 

line_out('<tr>');
line_out('<td align=left headers="'||1||'" nowrap>'||'<tt>' ||v_col_headers(i)||' </tt>'||'</td>');  
line_out('<td align=left headers="'||2||'" nowrap>'||'<tt>&gt&lt;</tt>'||'</td>');  
line_out('</tr>');
					end if;
			else

line_out('<tr>');
line_out('<td align=left headers="'||1||'" nowrap>'||'<tt>' ||v_col_headers(i)||' </tt>'||'</td>');  

if p_spaces = 'Y' then

	if v_describe(i).col_type in (T_NUMBER, T_DATE)	then

	line_out('<td align=left headers="'||2||'" nowrap>'||'<tt>' ||v_values(i)||'</tt>'||'</td>');

	else

	line_out('<td align=left headers="'||2||'" nowrap>'||'<tt>&gt;' ||v_values(i)||'&lt; </tt>'||'</td>');

	end if;

else 

line_out('<td align=left headers="'||2||'" nowrap>'||'<tt>' ||v_values(i)||'</tt>'||'</td>');

end if;

line_out('</tr>');

				end if;	
			
		end loop;

line_out('<br>');  

 				row_counter := row_counter + 1;

            if row_counter >  nvl(l_max_rows,row_counter) then
               exit;
		end if;

	line_out('</tr></table><br>');  

			end loop;

			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
			Show_Table('END');
		end if;

      if p_current_exec = 0 and p_feedback = 'Y' then

         if row_counter = 1 then
           l_feedback_txt := '<BR><span class="SmallPrint">'||
              '0 Rows Selected</span><br>';
         elsif row_counter = 2 then
           l_feedback_txt := '<span class="SmallPrint">'||
              '1 Row Selected</span><br>';
         else
           l_feedback_txt := '<span class="SmallPrint">'||
              ltrim(to_char(row_counter - 1,'9999999')) ||
              ' Rows Selected</span><br>';
         end if;
         line_out(l_feedback_txt);

			execute immediate 'alter session set nls_date_format = ''' || l_hold_date_format || '''';
		end if;
		return row_counter-1;
	exception
		when others then
			line_out('</table><br>');
			error_position := DBMS_SQL.LAST_ERROR_POSITION;
			ErrorPrint(sqlerrm || ' occurred in Display_SQLP');
			ActionErrorPrint('Please report the error below to support.');
			line_out('Position: ' || error_position  || ' of ' || length(p_sql_statement) || '<br>');
			line_out(replace(substr(p_sql_statement,1,error_position),chr(10),'<br>'));
			error_position_end := instr(p_sql_statement,' ',error_position+1) - error_position;
			line_out('<span class="error">' || replace(substr(p_sql_statement,error_position+1, error_position_end),chr(10),'<br>') || '</span>');
			line_out(replace(substr(p_sql_statement,error_position+error_position_end+1),chr(10),'<br>') || '<br>');
			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
			if p_current_exec = 0 then
				execute immediate 'alter session set nls_date_format = ''' || l_hold_date_format || '''';
			end if;

			return -1;
	end;
end display_sqlP;



-- Function Name: Display_SQLPL
--
-- Usage:
--     a_number := Display_SQLPL('SQL statement','Name for Header','Long Flag',
--                 'Feedback','Max Rows','Indent Level', 'Null Columns', 'Show Spaces');
--
-- Parameters:
--     SQL Statement - Any valid SQL Select Statement
--     Name for Header - Text String to for heading the output
--     Long Flag - Y or N  - If set to N then this will not output
--                 any LONG columns (default = Y)
--     Feedback - Y or N indicates whether to indicate the number of rows
--                selected automatically in the output (default = Y)
--     Max Rows - Limits the number of rows output to this number. NULL or
--                ZERO value indicates unlimited. (Default = NULL)
--     Indent Level - Indicates if the table should be indented and if so
--                    how far: 0 = no indent, 1=.25in, 2=.5in, 3 = .75in
--                    (Default = 0)
--     Null Columns - Y or N - If set to Y Null columns will Null values will be displayed.  If set to N
--   			   columns with null values will not be displayed.
--
--	 Show Spaces - Y or N - If set to Y, column value will be enclosed by >< to show leading and 
--   			   trailing spaces.  If set to N, only the column value will be displayed.
-- Returns:
--      The function returns the # of rows selected.
--      If there is an error then the function returns -1.
--
-- Output:
--      Displays the output of the SQL statement in various HTML table formats.
--
-- Examples:
--      declare
--         num_rows number;
--      begin
--         num_rows := Display_SQLPL('select * from ar_system_parameters_all',
--                                 'AR Parameters', 'Y', 'N',null, 'P', 'Y');
--      end;
--

function Display_SQLPL (p_sql_statement  varchar2
                    , table_alias      varchar2
                    , display_longs    varchar2 default 'Y'
                    , p_feedback       varchar2 default 'Y'
                    , p_max_rows       number   default null
                    , p_ind_level      number   default 0
			  , p_null		   varchar2 default 'N'
			  , p_spaces	   varchar2 default 'N'
                    , p_current_exec   number default 0) return number is

  	error_position		number;
	error_position_end	number;
      row_counter			number;
      row_counter2		number;
      hold_exclude_cols		boolean;
      hold_sql_needed		varchar2(3);
	hold_string			varchar2(32767)  default null;
	hold_option			varchar2(32767)  default null;
	hold_string2		varchar2(32767)  default null;
	hold_option2		varchar2(32767)  default null;
	hold_sql			varchar2(32767)  default null;
	hold_sql_remain		varchar2(32767)  default null;
	hold_element		varchar2(32767)  default null;
	hold_long			long;
	hold_clob			clob;
	hold_length			integer;
	hold_bgcolor		varchar2(40);
	hold_color			varchar2(40);
	hold_open_paren		number;
	hold_curr_loc		number;
	hold_end_pos		number;
	column_counter		binary_integer  default 1;
	value_counter		binary_integer  default 1;
	column_high			binary_integer  default 1;
	column_high2		binary_integer  default 1;
      value_high			binary_integer  default 1;
	v_cursor_id			number;
	v_dummy			integer;
	l_hold_length		varchar2(20);
	l_hold_date_format	varchar2(40);
	l_hold_type			varchar2(40);
	v_col_values_count	number;
	v_col_values		V2T;
	v_values			v2t;
	v_valuesN			v2t;
	v_options			v2t;
	v_values2			v2t;
	v_options2			v2t;
	nullCounter 		number;
	v_describe			dbms_sql.desc_tab;
	T_VARCHAR2			constant integer := 1;
	T_NUMBER			constant integer := 2;
	T_LONG			constant integer := 8;
	T_ROWID			constant integer := 11;	
	T_DATE			constant integer := 12;	
	T_RAW				constant integer := 23;
	T_CHAR			constant integer := 96;
	T_TYPE			constant integer := 109;
	T_CLOB			constant integer := 112;
	T_BLOB			constant integer := 113;
	T_BFILE			constant integer := 114;
	l_max_rows 		integer;
	l_feedback_txt	varchar2(240);


begin

   if nvl(p_max_rows,0) = 0 then
     l_max_rows := null;
   else
     l_max_rows := p_max_rows;
   end if;


	if p_current_exec = 0 then
		select value into l_hold_date_format from nls_session_parameters where parameter = 'NLS_DATE_FORMAT';
		execute immediate 'alter session set nls_date_format = ''DD-MON-YYYY HH24:MI''';
	end if;
	begin
		v_cursor_id := DBMS_SQL.OPEN_CURSOR;
		DBMS_SQL.PARSE(v_cursor_id, p_sql_statement, DBMS_SQL.V7);
		DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, column_high, v_describe);
		hold_sql := 'select ';
		hold_sql_needed := null;
		hold_exclude_cols := false;
		hold_sql_remain := ltrim(substr(replace(p_sql_statement,chr(10),' '), 7));
		for value_counter in 1..column_high loop
			if v_describe(value_counter).col_type = T_LONG then
				hold_length := 25000;
			else
				hold_length := to_number(v_describe(value_counter).col_max_len);
			end if;
			if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
				DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_string, greatest(hold_length,30));
			elsif v_describe(value_counter).col_type = T_CLOB then
				DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_clob);
			else
				null;
			end if;
			hold_string := v_describe(value_counter).col_name;
			if value_counter = 1 then
				v_col_values := V2T(replace(initcap(hold_string),'|','<br>'));
			else
				v_col_values.EXTEND;
 			        v_col_values(value_counter) := replace(initcap(hold_string),'|','<br>');
 			end if;
			
 			if substr(hold_sql_remain,1,1) != '*' then
				hold_end_pos := 1;
				hold_open_paren := 0;
				loop
					if substr(hold_sql_remain,hold_end_pos,1) = '(' then
						hold_open_paren := hold_open_paren + 1;
					elsif substr(hold_sql_remain,hold_end_pos,1) = ')' then
						hold_open_paren := hold_open_paren - 1;
					elsif substr(hold_sql_remain,hold_end_pos,1) = ',' 
					   or lower(substr(hold_sql_remain, hold_end_pos, 4)) = ' from ' then
						if hold_open_paren = 0 then
							exit;
						end if;
					end if;
					hold_end_pos := hold_end_pos + 1;
					if hold_end_pos > length(p_sql_statement) then 
						exit; 
					end if;
				end loop;
				hold_element := substr(hold_sql_remain, 1, hold_end_pos);
				hold_sql_remain := ltrim(substr(hold_sql_remain, hold_end_pos + 1));
			else
				hold_element := v_describe(value_counter).col_name;
			end if;
 			if v_describe(value_counter).col_type in (T_VARCHAR2, T_CHAR, T_NUMBER, T_DATE, T_LONG, T_CLOB, T_ROWID) then
				hold_sql := hold_sql || hold_sql_needed || hold_element;
			else
 				hold_exclude_cols := true;
			end if;
			hold_sql_needed := ', ';
		end loop;
		if hold_exclude_cols then
			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
			hold_sql := hold_sql || ' ' || substr(p_sql_statement,instr(lower(p_sql_statement),' from '));
			row_counter := Display_SQL (hold_sql, table_alias, display_longs, p_current_exec + 1) + 1;
		else
	
         if nvl(p_ind_level,0) != 0 then
            line_out('<div class=ind'||to_char(p_ind_level)||'>');
         end if;

			v_dummy := DBMS_SQL.EXECUTE(v_cursor_id);  -------->find null columns

			row_counter2 := 1;
			loop
				if DBMS_SQL.FETCH_ROWS(v_cursor_id) = 0 then
					exit;
				end if;
				for value_counter in 1..column_high loop
					if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_string);
					else
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_clob);
						hold_string := 'CLOB';
					end if;
					hold_option := null;
					if v_describe(value_counter).col_type = T_DATE then
						hold_string := replace(hold_string,' ','&nbsp;');
						hold_option := 'nowrap align=right';
					elsif v_describe(value_counter).col_type = T_VARCHAR2 then
						hold_string := replace(replace(hold_string,'<','&lt;'),'>','&gt;');
						if hold_string != rtrim(hold_string) then
							hold_option := 'nowrap bgcolor=yellow';
						else
							hold_option := 'nowrap';
						end if;
					elsif v_describe(value_counter).col_type = T_NUMBER then
						hold_option := 'nowrap align=right';
					else
						null;
					end if;
					hold_string := replace(hold_string,' ','&nbsp;');  
					if value_counter = 1 then
						v_valuesN := v2t(hold_string);
						
					else
						v_valuesN.EXTEND;
						v_valuesN(value_counter) := v_valuesN(value_counter)||hold_string;
					end if;

				end loop;

row_counter2 := row_counter2 + 1;

			end loop;

if table_alias is not null then

				line_out('<br><span class="BigPrint">' || table_alias ||'</span>');  
			 	
			end if;

			Start_Table(table_alias);  

				line_out('<tr>');

				line_out('<th id=1>Column</th>');
		
for i in 1..row_counter2-1 loop

if i > l_max_rows then
exit;
end if; 

				line_out('<th id='||(i)||'> Row '||(i)||'</th>');



end loop;
				line_out('</tr>');

column_high2 := column_high;



						v_values2 := V2T('');
						v_options2 := V2T('');



			v_dummy := DBMS_SQL.EXECUTE(v_cursor_id);

			row_counter := 1;
			loop
				if DBMS_SQL.FETCH_ROWS(v_cursor_id) = 0 then
					exit;
				end if;
				for value_counter in 1..column_high loop

					if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_string);
					else
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_clob);
						hold_string := 'CLOB';
					end if;
					--hold_string := nvl(hold_string,NULL); 
					--hold_string := nvl(hold_string,'&nbsp;'); 
					hold_option := null;
					if v_describe(value_counter).col_type = T_DATE then
						hold_string := replace(hold_string,' ','&nbsp;');
						hold_option := 'nowrap align=right';
					elsif v_describe(value_counter).col_type = T_VARCHAR2 then
						hold_string := replace(replace(hold_string,'<','&lt;'),'>','&gt;');
						if hold_string != rtrim(hold_string) then
							hold_option := 'nowrap bgcolor=yellow';
						else
							hold_option := 'nowrap';
						end if;
					elsif v_describe(value_counter).col_type = T_NUMBER then
						hold_option := 'nowrap align=right';
					else
						null;
					end if;
				
	hold_string := replace(hold_string,' ','&nbsp;');  
					if value_counter = 1 then

						v_values := V2T('~1~2'||hold_string||'~8~9');
		
					else
	
				v_values.EXTEND;
						v_values(value_counter) := '~1~2'||hold_string||'~8~9';
		
					end if;

						v_values2.EXTEND;

v_values2(value_counter) := v_values2(value_counter)||v_values(value_counter);


				end loop;

 				row_counter := row_counter + 1;

            if row_counter >  nvl(l_max_rows,row_counter) then
               exit;
		end if;

v_col_values_count := v_col_values.count;

			end loop;

			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);


if v_col_values_count <> 0 then

for i in 1..v_col_values_count loop


if v_valuesN(i) is not null or p_null = 'Y' then

line_out('<tr>');

if p_spaces = 'Y' then

	if v_describe(i).col_type in (T_NUMBER, T_DATE)	then

	line_out('<td align=left headers="'||1||'" nowrap>'||'<tt>' ||v_col_values(i)||' </tt>'||'</td></N>'||chr(10)||
	replace(replace(v_values2(i),'~1~2','<td align=left headers="'||(i)||'" nowrap><tt>'), '~8~9','</tt></td></N>')||chr(10));
	
	else
	

	line_out('<td align=left headers="'||1||'" nowrap>'||'<tt>' ||v_col_values(i)||' </tt>'||'</td></N>'||chr(10)||
	replace(replace(v_values2(i),'~1~2','<td align=left headers="'||(i)||'" nowrap><tt>&gt;'), '~8~9','&lt;</tt></td></N>')||chr(10));
	
	end if;

else 

line_out('<td align=left headers="'||1||'" nowrap>'||'<tt>' ||v_col_values(i)||' </tt>'||'</td></N>'||chr(10)||
replace(replace(v_values2(i),'~1~2','<td align=left headers="'||(i)||'" nowrap><tt>'), '~8~9','</tt></td></N>')||chr(10));

end if;

line_out('</tr>');
end if;


end loop;

end if;

			Show_Table('END');
		end if;

      if p_current_exec = 0 and p_feedback = 'Y' then
         if row_counter = 1 then
           l_feedback_txt := '<BR><span class="SmallPrint">'||
              '0 Rows Selected</span><br>';
         elsif row_counter = 2 then
           l_feedback_txt := '<span class="SmallPrint">'||
              '1 Row Selected</span><br>';
         else
           l_feedback_txt := '<span class="SmallPrint">'||
              ltrim(to_char(row_counter - 1,'9999999')) ||
              ' Rows Selected</span><br>';
         end if;
         line_out(l_feedback_txt);

			execute immediate 'alter session set nls_date_format = ''' || l_hold_date_format || '''';
		end if;
		return row_counter-1;
	exception
		when others then
			line_out('</table><br>');
			error_position := DBMS_SQL.LAST_ERROR_POSITION;
			ErrorPrint(sqlerrm || ' occurred in display_sqlPL');
			ActionErrorPrint('Please report the error below to support.');
			line_out('Position: ' || error_position  || ' of ' || length(p_sql_statement) || '<br>');
			line_out(replace(substr(p_sql_statement,1,error_position),chr(10),'<br>'));
			error_position_end := instr(p_sql_statement,' ',error_position+1) - error_position;
			line_out('<span class="error">' || replace(substr(p_sql_statement,error_position+1, error_position_end),chr(10),'<br>') || '</span>');
			line_out(replace(substr(p_sql_statement,error_position+error_position_end+1),chr(10),'<br>') || '<br>');
			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
			if p_current_exec = 0 then
				execute immediate 'alter session set nls_date_format = ''' || l_hold_date_format || '''';
			end if;

			return -1;
	end;
end display_sqlPL;


-- Function Name: Run_SQLPL
--
-- Usage:
--      a_number := Run_SQL('Heading', 'SQL statement', 'Feedback', 'Max Rows',
--                          'Indent Level', 'Layout', 'Null Columns', 'Show Spaces');
--
-- Parameters:
--      Heading - Text String to for heading the output
--      SQL Statement - Any valid SQL Select Statement
--      Feedback - Y or N to indicate whether to automatically print the 
--                 number of rows returned (default 'Y')
--      Max Rows - Limit the output to this many rows.  NULL or ZERO values
--                 indicate unlimited rows (default NULL)
--      Indent Level - Indicate if table should be indented and by how much
--                     0=No indentation, 1=.25in, 2=.5in, 3=.75in (default 0)
--	 Layout - P, PL or L - If set to P the columns for each row will be printed
--              down the page in a portrait format.  And each additional row will be printed below the
--		    previous in the same format.  If set to PL the columns for each row will
--		    be printed down the page in a portrait format.  And each additional row will be printed next
--		    to the previous in the same format.  If set to L the columns will be printed
--		    across the page in a landscape format.
--     Null Columns - Y or N - If set to Y Null columns will Null values will be displayed.  If set to N
--   			   columns with null values will not be displayed.
--	 Show Spaces - Y or N - If set to Y, column value will be enclosed by >< to show leading and 
--   			   trailing spaces.  If set to N, only the column value will be displayed.
--
-- Returns:
--      The function returns the # of rows selected.
--      If there is an error then the function returns -1.
--
-- Output:
--      Displays the output of the SQL statement as an HTML table.
--
-- Examples:
--      declare
--         num_rows number;
--      begin
--         num_rows := Run_SQL('AR Parameters','select * from ar_system_parameters_all', 'N',0,0,'P','Y','Y');
--      end;
--

function RUN_SQLPL(p_title varchar2, p_sql_statement varchar2, p_feedback varchar2 default 'Y', p_max_rows number default 0, p_ind_level number, p_layout varchar2 default 'P', p_null varchar2 default 'N', p_spaces varchar2 default 'N') return number is

begin
	if p_layout = 'P' then
	return(display_sqlP(p_sql_statement, p_title, 'Y', p_feedback, p_max_rows, p_ind_level, p_null, p_spaces));
	elsif p_layout = 'PL' then
	return(display_sqlP(p_sql_statement, p_title, 'Y', p_feedback, p_max_rows, p_ind_level, p_null, p_spaces));
			else
	return(Display_SQL(p_sql_statement, p_title, 'Y','Y',null,0,'N',0,p_null, p_spaces));
	
	
	end if;
	
end RUN_SQLPL;


-- Procedure Name: Run_SQL
--
-- Usage:
--      Run_SQL('Heading', 'SQL statement', 'Feedback', 'Max Rows', 'Indent Level', 'Layout', 'Null Columns', 'Show Spaces');
--
-- Parameters:
--     Heading - Text String to for heading the output
--     SQL Statement - Any valid SQL Select Statement
--     Feedback - Y or N to indicate whether to automatically print the
--                number of rows returned (default 'Y')
--     Max Rows - Limit the output to this many rows.  NULL or ZERO values
--                indicate unlimited rows (default NULL)
--     Indent Level - Indicate if table should be indented and by how much
--                    0=No indentation, 1=.25in, 2=.5in, 3=.75in (default 0)
--	 Layout - P, PL or L - If set to P the columns for each row will be printed
--              down the page in a portrait format.  And each additional row will be printed below the
--		    previous in the same format.  If set to PL the columns for each row will
--		    be printed down the page in a portrait format.  And each additional row will be printed next
--		    to the previous in the same format.  If set to L the columns will be printed
--		    across the page in a landscape format.
--     Null Columns - Y or N - If set to Y Null columns will Null values will be displayed.  If set to N
--   			   columns with null values will not be displayed.
--	 Show Spaces - Y or N - If set to Y, column value will be enclosed by >< to show leading and 
--   			   trailing spaces.  If set to N, only the column value will be displayed.
--
-- Output:
--      Displays the output of the SQL statement as an HTML table.
--
-- Examples:
--      begin
--         Run_SQL('AR Parameters','select * from ar_system_parameters_all', 'N',0,0,'P','Y');
--      end;
--


procedure RUN_SQLPL(p_title varchar2, p_sql_statement varchar2, p_feedback varchar2 default 'Y', p_max_rows number default 0, p_ind_level number default 0, p_layout varchar2 default 'P', p_null varchar2 default 'N', p_spaces varchar2 default 'N') is
	dummy	number;
begin
	if p_layout = 'P' then
	dummy := display_sqlP(p_sql_statement, p_title, 'Y', p_feedback, p_max_rows, p_ind_level, p_null, p_spaces);

	elsif 	p_layout = 'PL' then
	dummy := display_sqlPL(p_sql_statement, p_title, 'Y', p_feedback, p_max_rows, p_ind_level, p_null, p_spaces);

	else 
	dummy := Display_SQL(p_sql_statement, p_title, 'Y','Y',null,0,'N',0,p_null, p_spaces);
	end if;

end RUN_SQLPL;



/*************************************************************************************************************************
End of Modified Run_SQL Code.  The code was modified to allow the columns to be displayed in Portrait layout format
*************************************************************************************************************************/
