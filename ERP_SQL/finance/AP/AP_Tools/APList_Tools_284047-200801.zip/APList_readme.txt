=======================================================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.                   				                 
=======================================================================================================================

=======================================================================================================================
Abstract			This test displays ALL of the Data for ALL of the tables used to process an invoice in AP.
=======================================================================================================================
FILE NAME:			APList.sql
PRODUCT: 			501 -Oracle Payables
SUBCOMPONENT:		PAYMENT
PRODUCT VERSIONS: 	11.5, 11.0, 10.7
PLATFORM: 			All Platforms
DATE CREATED:		05-June-2002
PARAMETERS:			Invoice/Check Number
				Supplier Name
				Invoice ID
				Print Null Columns Y or N - Default N
				Details Layout Portrait (P) or Landscape (L) - Default P
				GL Details Y or N - Default N
=======================================================================================================================
Instructions
=======================================================================================================================
Included Files:

	CoreApiHtml.sql
	APListh.sql (HTML version)
	CoreApiTxt.sql
	APListt.sql (Text version)
	
Execution Environment::

	SQL*Plus

Access Privileges:

	Requires APPS user access
	
Usage:
	
	sqlplus apps/password @APListh.sql (HTML version)

	sqlplus apps/password @APListt.sql (Text version)

	

Instructions: 
	
The files should be unzipped to a common directory. 

For HTML output (recommended), run the file APListh.sql in SQL*Plus in the APPS schema.  
Follow the prompts and enter the requested information. The test will create an output file in html 
format named APListh_<invoice_ID>_diag.html. Open the file in your browser and review the output.

Note:  The HTML version of this test is incompatible NLS Character Set UTF8 for RDBMS version 8.1.7.3 or lower.
Please run the Text version of this test, if you have UTF8 and RDMBS version 8.1.7.3 or lower.

For Text output, run the file APListh.sql in SQL*Plus in the APPS schema.  
Follow the prompts and enter the requested information. The test will create an output file in Text 
format named APListt_<invoice_id>_<mmddhhmm>_diag.lst. Open the file in a Text editor and review the output.


=======================================================================================================================
Test Description
=======================================================================================================================
This test displays ALL of the Data for ALL of the tables used to process an invoice in AP.
The test displays the data in an HTML format to be viewed in a browser.  
The data is displayed in the following sections:

-Summarized Invoice/Payment Information
-Trial Balance Information
-Setup Information
-Transaction Details
-Accounting/AX Details (If applicable)
-MRC Information (If MRC is enabled)
-Supplier Information
-PO Information (If any invoice lines are matched to PO)
-GL Information (If any transaction data has been transferred)
-Tax Information (If any invoice lines are assigned tax codes)
-Encumbrance Information (If encumbrances are used)
-Prepayment Information
-Payment Document/Bank Information


The Quick Links Section (HTML Only) at the top of the Page, has links to each section.  Click on a link to go to
a specific section in the report.

The test has 3 parameters that allow some control of the appearance of the data and what data is returned.

Parameter 1:  Print Null Columns (Y or N) - Default N
This parameter is defaulted to No (N).  That is the recommended setting for this parameter.
If set to Y, the test would display all columns in each table, including columns with NULL values.

Parameter 2: Details Layout Portrait (P) or Landscape (L) - Default P (HTML Only)
This parameter is defaulted to P.  That is the recommended setting for this parameter.
Setting this option to P, will display all table details in a portrait format.
Setting this option to L, will display all table details in a Landscape format.

Parameter 3: GL Details Y or N - Default N
This parameter is defaulted to N.  That is the recommended setting for this parameter.
Setting this option to Y, will display any transaction data transferred to the GL.
WARNING:  SETTING THIS OPTION TO Y WILL RESULT IN LONGER RUN TIME FOR THE TEST

=======================================================================================================================
References
=======================================================================================================================
Oracle Payable User Guide 

=======================================================================================================================
Disclaimer
=======================================================================================================================
EXCEPT WHERE EXPRESSLY PROVIDED OTHERWISE, THE INFORMATION, SOFTWARE, PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. 
ORACLE EXPRESSLY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE 
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ORACLE MAKES NO WARRANTY 
THAT: (A) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE SOFTWARE WILL BE ACCURATE OR RELIABLE; OR (B) THE 
INFORMATION, OR OTHER MATERIAL OBTAINED WILL MEET YOUR EXPECTATIONS. ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE 
DOWNLOADED OR OTHERWISE OBTAINED IS DONE AT YOUR OWN DISCRETION AND RISK. ORACLE SHALL HAVE NO RESPONSIBILITY FOR ANY
DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY CONTENT, MATERIALS, INFORMATION 
OR SOFTWARE.

ORACLE RESERVES THE RIGHT TO MAKE CHANGES OR UPDATES TO THE SOFTWARE AT ANY TIME WITHOUT NOTICE.

=======================================================================================================================
Limitation of Liability
=======================================================================================================================
IN NO EVENT SHALL ORACLE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, OR DAMAGES 
FOR LOSS OF PROFITS, REVENUE, DATA OR USE, INCURRED BY YOU OR ANY THIRD PARTY, WHETHER IN AN ACTION IN CONTRACT OR TORT,
ARISING FROM YOUR ACCESS TO, OR USE OF, THE SOFTWARE. 

SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY. ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS 
MAY NOT APPLY TO YOU.



