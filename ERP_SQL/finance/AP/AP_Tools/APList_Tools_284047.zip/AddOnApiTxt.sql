/*************************************************************************************************************************
Modified Run_SQL Code.  The code was modified to allow the columns to be displayed in Portrait layout format
*************************************************************************************************************************/
-- Function  Name: Display_SQLP
-- Usage:
--    Function:
--       a_number := Display_SQLP('Title', 'SQL statement', 'feedback', 'max rows', 'Null Columns', 'Show Spaces');
--
-- Parameters:
--   SQL Statement - Any valid SQL select statement text which selects only
--                   columns of type Number, Date, or Varchar2.
--   feedback - Y or N to indicate whether a count of rows should automaticall
--              be printed at the end of the output.  (Default = Y)
--   max rows - Maximum number of rows to output.  NULL or ZERO indicates 
--              unlimited.  (Default = NULL)
--   Null Columns - Y or N - If set to Y Null columns will Null values will be displayed.  If set to N
--                  columns with null values will not be displayed.
--	 Show Spaces - Y or N - If set to Y, column value will be enclosed by >< to show leading and 
--   			   trailing spaces.  If set to N, only the column value will be displayed.
-- Returns:
--    The function returns the number of rows selected.
--    If there is an error then the function returns null.
-- Output:
--      Displays the output of the SQL statement in portrait table format.
--	  The columns for each row will be printed down the page in a portrait format.  
--	  And each additional row will be printed below the previous in the same format.  
--
-- Examples:
--   declare
--      sqltxt       varchar2(2000);
--   begin
--	sqlTxt := 'select * FROM ap_invoice_distributions_all WHERE invoice_id = 24372 order by distribution_line_number asc';
--	dummy := Display_SQLP('AP_Invoice_Distributions', sqTxt, 'Y', 10, 'N');
--   end;

function Display_SQLP(p_title varchar2
	   , p_sql_statement varchar2
         , p_feedback      varchar2 default 'Y'
         , p_max_rows      number default null
         , p_null		   varchar2 default 'N'
	   , p_spaces	   varchar2 default 'N')

 return number is

	error_position			number;
	error_position_end		number;
      row_counter				number;
      hold_exclude_cols			boolean;
      hold_sql_needed			varchar2(3);
	hold_string				varchar2(32767)  default null;
	hold_option				varchar2(32767)  default null;
	hold_sql				varchar2(32767)  default null;
	hold_sql_remain			varchar2(32767)  default null;
	hold_element			varchar2(32767)  default null;
	hold_long				long;
	hold_clob				number;
	hold_length				integer;
	hold_bgcolor			varchar2(40);
	hold_color				varchar2(40);
	hold_open_paren			number;
	hold_curr_loc			number;
	hold_end_pos			number;
	column_counter			binary_integer  default 1;
	value_counter			binary_integer  default 1;
	column_high				binary_integer  default 1;
      value_high				binary_integer  default 1;
	v_cursor_id				number;
	v_dummy				integer;
	l_hold_length			varchar2(20);
	l_hold_date_format		varchar2(40);
	l_hold_type				varchar2(40);
	v_col_headers			V2T;
	v_values				V2T;
	v_options				V2T;
	v_describe				dbms_sql.desc_tab;
	T_VARCHAR2				constant integer := 1;
	T_NUMBER				constant integer := 2;
	T_LONG				constant integer := 8;
	T_ROWID				constant integer := 11;	
	T_DATE				constant integer := 12;	
	T_RAW					constant integer := 23;
	T_CHAR				constant integer := 96;
	T_TYPE				constant integer := 109;
	T_CLOB				constant integer := 112;
	T_BLOB				constant integer := 113;
	T_BFILE				constant integer := 114;
	table_alias				varchar2(240) := p_title;
	l_max_rows				number;

begin

   if nvl(p_max_rows,0) = 0 then
     l_max_rows := null;
   else
     l_max_rows := p_max_rows;
   end if;

	begin
		v_cursor_id := DBMS_SQL.OPEN_CURSOR;
		DBMS_SQL.PARSE(v_cursor_id, p_sql_statement, DBMS_SQL.V7);
		DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, column_high, v_describe);
		hold_sql := 'select ';
		hold_sql_needed := null;
		hold_exclude_cols := false;
		hold_sql_remain := ltrim(substr(replace(p_sql_statement,chr(10),' '), 7));
		for value_counter in 1..column_high loop
			if v_describe(value_counter).col_type = T_LONG then
				hold_length := 25000;
			else
				hold_length := to_number(v_describe(value_counter).col_max_len);
			end if;
			if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
				DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_string, greatest(hold_length,30));
			elsif v_describe(value_counter).col_type = T_CLOB then
				DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_clob);
			else
				null;
			end if;
			hold_string := v_describe(value_counter).col_name;
			if value_counter = 1 then
				v_col_headers := V2T(replace(initcap(hold_string),'|','<br>'));
			else
				v_col_headers.EXTEND;
 			        v_col_headers(value_counter) := replace(initcap(hold_string),'|','<br>');
 			end if;
			
 			if substr(hold_sql_remain,1,1) != '*' then
				hold_end_pos := 1;
				hold_open_paren := 0;
				loop
					if substr(hold_sql_remain,hold_end_pos,1) = '(' then
						hold_open_paren := hold_open_paren + 1;
					elsif substr(hold_sql_remain,hold_end_pos,1) = ')' then
						hold_open_paren := hold_open_paren - 1;
					elsif substr(hold_sql_remain,hold_end_pos,1) = ',' 
					   or lower(substr(hold_sql_remain, hold_end_pos, 4)) = ' from ' then
						if hold_open_paren = 0 then
							exit;
						end if;
					end if;
					hold_end_pos := hold_end_pos + 1;
					if hold_end_pos > length(p_sql_statement) then 
						exit; 
					end if;
				end loop;
				hold_element := substr(hold_sql_remain, 1, hold_end_pos);
				hold_sql_remain := ltrim(substr(hold_sql_remain, hold_end_pos + 1));
			else
				hold_element := v_describe(value_counter).col_name;
			end if;
 			if v_describe(value_counter).col_type in (T_VARCHAR2, T_CHAR, T_NUMBER, T_DATE, T_LONG, T_CLOB, T_ROWID) then
				hold_sql := hold_sql || hold_sql_needed || hold_element;
			else
 				hold_exclude_cols := true;
			end if;
			hold_sql_needed := ', ';
		end loop;
		if hold_exclude_cols then
			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
			hold_sql := hold_sql || ' ' || substr(p_sql_statement,instr(lower(p_sql_statement),' from '));
			row_counter := 1;
		else
		
			v_dummy := DBMS_SQL.EXECUTE(v_cursor_id);

			row_counter := 1;
			loop
				if DBMS_SQL.FETCH_ROWS(v_cursor_id) = 0 then
					exit;
				end if;
				for value_counter in 1..column_high loop

					if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_string);
					else
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_clob);
						hold_string := 'CLOB';
					end if;
					--hold_string := nvl(hold_string,NULL); --jsh
					hold_option := null;
					if v_describe(value_counter).col_type = T_DATE then
						hold_option := 'nowrap align=right';
					elsif v_describe(value_counter).col_type = T_VARCHAR2 then
						if hold_string != rtrim(hold_string) then
							hold_option := 'nowrap bgcolor=yellow';
						else
							hold_option := 'nowrap';
						end if;
					elsif v_describe(value_counter).col_type = T_NUMBER then
						hold_option := 'nowrap align=right';
					else
						null;
					end if;

					if value_counter = 1 then
						v_values := V2T(hold_string);
						v_options := V2T(hold_option);
						
					else
						v_values.EXTEND;
						v_values(value_counter) := hold_string;
						v_options.EXTEND;
						v_options(value_counter) := hold_option;
					end if;

				end loop;


            if row_counter >  nvl(l_max_rows, row_counter) then
               exit;
		end if;
	

				if row_counter > 1 then

sectionprint(table_alias||' Row '||row_counter);  --jsh
line_out(chr(10));


 				end if;


		for i in 1..v_values.COUNT loop

				if v_values(i) is null then
					if upper(nvl(p_null,'Y')) = 'Y' then --jsh
				
line_out(rpad(v_col_headers(i),30)||': ><');  --jsh

					end if;
			else

if p_spaces = 'Y' then

line_out(rpad(v_col_headers(i),30)||': >'||v_values(i)||'<');  --jsh

else 

line_out(rpad(v_col_headers(i),30)||': '||v_values(i));  --jsh

end if;
				end if;	
			
		end loop;

line_out(chr(10));  
 				row_counter := row_counter + 1;

			end loop;

		end if;

  if p_feedback = 'Y' then
    BRPrint;
    line_out(to_char(row_counter-1)||' rows selected');
    BRPrint;
  end if;

		return row_counter-1;
	exception
  when others then
    ErrorPrint(sqlerrm||' occured in Display_SQL');
    ActionErrorPrint('Report this information to your support representative.');
    return(sqlcode);
			return -1;
	end;
end Display_SQLP;

-- Function  Name: Display_SQLPL
-- Usage:
--    Function:
--       a_number := Display_SQLPL('Title', 'SQL statement', 'feedback', 'max rows', 'Null Columns', 'Show Spaces');
--
-- Parameters:
--   Title - The title for the table.
--   SQL Statement - Any valid SQL select statement text which selects only
--                   columns of type Number, Date, or Varchar2.
--   feedback - Y or N to indicate whether a count of rows should automaticall
--              be printed at the end of the output.  (Default = Y)
--   max rows - Maximum number of rows to output.  NULL or ZERO indicates 
--              unlimited.  (Default = NULL)
--   Null Columns - Y or N - If set to Y Null columns will Null values will be displayed.  If set to N
--                  columns with null values will not be displayed.
--	 Show Spaces - Y or N - If set to Y, column value will be enclosed by >< to show leading and 
--   			   trailing spaces.  If set to N, only the column value will be displayed.

-- Returns:
--    The function returns the number of rows selected.
--    If there is an error then the function returns null.
-- Output:
--      Displays the output of the SQL statement in portrait table format.
--      If set to PL the columns for each row will be printed down the page in a portrait format.  
--	  And each additional row will be printed next to the previous in the same format. 
--
-- Examples:
--   declare
--      sqltxt       varchar2(2000);
--   begin
--	sqlTxt := 'select * FROM ap_invoice_distributions_all WHERE invoice_id = 24372 order by distribution_line_number asc';
--	dummy := Display_SQLPL('AP_Invoice_Distributions', sqTxt, 'Y', 10, 'N');
--   end;

function Display_SQLPL(p_title varchar2
         , p_sql_statement varchar2
         , p_feedback      varchar2 default 'Y'
         , p_max_rows      number default null
         , p_null		   varchar2 default 'N'
         , p_spaces	   varchar2 default 'N')
			 return number is

  	error_position		number;
	error_position_end	number;
      row_counter			number;
      row_counter2		number;
      hold_exclude_cols		boolean;
      hold_sql_needed		varchar2(3);
	hold_string			varchar2(32767)  default null;
	hold_option			varchar2(32767)  default null;
	hold_string2		varchar2(32767)  default null;
	hold_option2		varchar2(32767)  default null;
	hold_sql			varchar2(32767)  default null;
	hold_sql_remain		varchar2(32767)  default null;
	hold_element		varchar2(32767)  default null;
	hold_long			long;
	hold_clob			clob;
	hold_length			integer;
	hold_bgcolor		varchar2(40);
	hold_color			varchar2(40);
	hold_open_paren		number;
	hold_curr_loc		number;
	hold_end_pos		number;
	column_counter		binary_integer  default 1;
	value_counter		binary_integer  default 1;
	column_high			binary_integer  default 1;
	column_high2		binary_integer  default 1;
      value_high			binary_integer  default 1;
	v_cursor_id			number;
	v_dummy			integer;
	l_hold_length		varchar2(20);
	l_hold_date_format	varchar2(40);
	l_hold_type			varchar2(40);
	v_col_values_count	number;
	v_col_values		V2T;
	v_values			v2t;
	v_valuesN			v2t;
	v_valuesN2			v2t;
	v_options			v2t;
	v_values2			v2t;
	v_options2			v2t;
	nullCounter 		number;
	v_describe			dbms_sql.desc_tab;
	T_VARCHAR2			constant integer := 1;
	T_NUMBER			constant integer := 2;
	T_LONG			constant integer := 8;
	T_ROWID			constant integer := 11;	
	T_DATE			constant integer := 12;	
	T_RAW				constant integer := 23;
	T_CHAR			constant integer := 96;
	T_TYPE			constant integer := 109;
	T_CLOB			constant integer := 112;
	T_BLOB			constant integer := 113;
	T_BFILE			constant integer := 114;
	l_max_rows			number;


begin

   if nvl(p_max_rows,0) = 0 then
     l_max_rows := 7;
   elsif p_max_rows > 7 then
	 	l_max_rows := 7;
   else 
     l_max_rows := p_max_rows + 1;
   end if;


	begin
		v_cursor_id := DBMS_SQL.OPEN_CURSOR;
		DBMS_SQL.PARSE(v_cursor_id, p_sql_statement, DBMS_SQL.V7);
		DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, column_high, v_describe);
		hold_sql := 'select ';
		hold_sql_needed := null;
		hold_exclude_cols := false;
		hold_sql_remain := ltrim(substr(replace(p_sql_statement,chr(10),' '), 7));
		for value_counter in 1..column_high loop
			if v_describe(value_counter).col_type = T_LONG then
				hold_length := 25000;
			else
				hold_length := to_number(v_describe(value_counter).col_max_len);
			end if;
			if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
				DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_string, greatest(hold_length,30));
			elsif v_describe(value_counter).col_type = T_CLOB then
				DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_clob);
			else
				null;
			end if;
			hold_string := v_describe(value_counter).col_name;
			if value_counter = 1 then
				v_col_values := V2T(replace(initcap(hold_string),'|','<br>'));
			else
				v_col_values.EXTEND;
 			        v_col_values(value_counter) := replace(initcap(hold_string),'|','<br>');
 			end if;
			
 			if substr(hold_sql_remain,1,1) != '*' then
				hold_end_pos := 1;
				hold_open_paren := 0;
				loop
					if substr(hold_sql_remain,hold_end_pos,1) = '(' then
						hold_open_paren := hold_open_paren + 1;
					elsif substr(hold_sql_remain,hold_end_pos,1) = ')' then
						hold_open_paren := hold_open_paren - 1;
					elsif substr(hold_sql_remain,hold_end_pos,1) = ',' 
					   or lower(substr(hold_sql_remain, hold_end_pos, 4)) = ' from ' then
						if hold_open_paren = 0 then
							exit;
						end if;
					end if;
					hold_end_pos := hold_end_pos + 1;
					if hold_end_pos > length(p_sql_statement) then 
						exit; 
					end if;
				end loop;
				hold_element := substr(hold_sql_remain, 1, hold_end_pos);
				hold_sql_remain := ltrim(substr(hold_sql_remain, hold_end_pos + 1));
			else
				hold_element := v_describe(value_counter).col_name;
			end if;
 			if v_describe(value_counter).col_type in (T_VARCHAR2, T_CHAR, T_NUMBER, T_DATE, T_LONG, T_CLOB, T_ROWID) then
				hold_sql := hold_sql || hold_sql_needed || hold_element;
			else
 				hold_exclude_cols := true;
			end if;
			hold_sql_needed := ', ';
		end loop;
		if hold_exclude_cols then
			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
			hold_sql := hold_sql || ' ' || substr(p_sql_statement,instr(lower(p_sql_statement),' from '));
--			row_counter := Display_SQL (hold_sql, table_alias, display_longs, p_current_exec + 1) + 1;
		else
	

			v_dummy := DBMS_SQL.EXECUTE(v_cursor_id);  -------->jsh added begin find null columns

			v_valuesN2 := V2T('');

			row_counter2 := 1;
			loop
				if DBMS_SQL.FETCH_ROWS(v_cursor_id) = 0 then
					exit;
				end if;
				for value_counter in 1..column_high loop
					if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_string);
					else
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_clob);
						hold_string := 'CLOB';
					end if;
					hold_option := null;

					if value_counter = 1 then

						v_valuesN := V2T(hold_string);
		
					else
	
				v_valuesN.EXTEND;

						v_valuesN(value_counter) := hold_string;
		
					end if;

						v_valuesN2.EXTEND;

v_valuesN2(value_counter) := v_valuesN2(value_counter)||v_valuesN(value_counter);

				end loop;

row_counter2 := row_counter2 + 1;

EXIT WHEN row_counter2 = l_max_rows;

			end loop;   -----> jsh added End find null columns

brprint;

				dbms_output.put(rpad('Column',30));
		
for i in 1..row_counter2-1 loop


				dbms_output.put('  '||rpad('Row '||i,30));

end loop;

brprint;


        dbms_output.put(chr(10)||RPAD('-----------------------------------',30)); 
		
for i in 1..row_counter2-1 loop


        dbms_output.put('  '||RPAD('----------------------------------------------------',30)); 



end loop;

brprint;


column_high2 := column_high;



						v_values2 := V2T('');
						v_options2 := V2T('');



			v_dummy := DBMS_SQL.EXECUTE(v_cursor_id);

			row_counter := 1;
			loop
				if DBMS_SQL.FETCH_ROWS(v_cursor_id) = 0 then
					exit;
				end if;
				for value_counter in 1..column_high loop

					if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_string);
					else
						DBMS_SQL.COLUMN_VALUE(v_cursor_id, value_counter, hold_clob);
						hold_string := 'CLOB';
					end if;
					hold_option := null;

if hold_string is NULL then

hold_string := '';

end if;
				
					if value_counter = 1 then

if p_spaces = 'Y' then
						v_values := V2T('  '||rpad('>'||hold_string||'<',30));
		else

if hold_string is NULL then

hold_string := ' ';

end if;
	
				v_values := V2T('  '||rpad(hold_string,30));
	
end if;
					else
	
				v_values.EXTEND;
if p_spaces = 'Y' then 
						v_values(value_counter) := '  '||rpad('>'||hold_string||'<',30);
		else

if hold_string is NULL then

hold_string := ' ';

end if;

		v_values(value_counter) := '  '||rpad(hold_string,30);

		end if;
					end if;

						v_values2.EXTEND;

v_values2(value_counter) := v_values2(value_counter)||v_values(value_counter);



				end loop;

 				row_counter := row_counter + 1;

v_col_values_count := v_col_values.count;

EXIT WHEN row_counter = l_max_rows;

			end loop;



brprint;

if v_col_values_count <> 0 then

for i in 1..v_col_values_count loop


if v_valuesN2(i) is not null or p_null = 'Y' then

line_out(rpad(v_col_values(i),30)||v_values2(i));

end if;


end loop;

end if;

			DBMS_SQL.CLOSE_CURSOR(v_cursor_id);

		end if;

  if p_feedback = 'Y' then
    BRPrint;
    line_out(to_char(row_counter-1)||' rows selected');
    BRPrint;
  end if;

		return row_counter-1;
	exception
  when others then
    ErrorPrint(sqlerrm||' occured in Display_SQL');
    ActionErrorPrint('Report this information to your support representative.');
    return(sqlcode);
			return -1;
	end;
end Display_SQLPL;

-- Function Name: Run_SQLPL
-- Procedure Name: Run_SQLPL
-- Usage:
--    Function:
--	a_number := RUN_SQLPL('Title, 'SQL Statement', 'Display Lengths','Headers', 'feedback', 
--				    'Max Rows', 'Layout', 'Null Columns');
--
--    Procedure:
--	 RUN_SQLPL('Title, 'SQL Statement', 'Display Lengths','Headers', 'feedback', 
--	           'Max Rows', 'Layout', 'Null Columns', 'Show Spaces');
--
-- Parameters:
--   Title - The title for the table.
--   SQL Statement - Any valid SQL select statement text which selects only
--                   columns of type Number, Date, or Varchar2.
--   Display lengths - a table of type 'lengths' indicating the display
--                      length for each of the columns in the select.
--                      A value must be supplied for each column even if
--                      that value is null.  If the value is null,
--                      the length of the header will be used.
--   headers -  a table of type 'headers' indicating the column heading
--                 for each of the columns in the select.  If an individual
--                 element of this parameter is null, or if this parameter
--                 is not provided (it is not required) the heading will be
--                 1) the column alias
--                 2) the column name
--   feedback - Y or N to indicate whether a count of rows should automaticall
--              be printed at the end of the output.  (Default = Y)
--   max rows - Maximum number of rows to output.  NULL or ZERO indicates 
--              unlimited.  (Default = NULL)
--	 Layout - P, PL or L - If set to P the columns for each row will be printed
--              down the page in a portrait format.  And each additional row will be printed below the
--		    previous in the same format.  If set to PL the columns for each row will
--		    be printed down the page in a portrait format.  And each additional row will be printed next
--		    to the previous in the same format.  If set to L the columns will be printed
--		    across the page in a landscape format.
--   Null Columns - Y or N - If set to Y Null columns will Null values will be displayed.  If set to N
--                  columns with null values will not be displayed.
--	 Show Spaces - Y or N - If set to Y, column value will be enclosed by >< to show leading and 
--   			   trailing spaces.  If set to N, only the column value will be displayed.

-- Returns:
--    The function returns the number of rows selected.
--    If there is an error then the function returns null.
-- Output:
--      Displays the output of the SQL statement in various formats.
-- Examples:
--   declare
--      sqltxt       varchar2(2000);
--   begin
--		sqlTxt := 'select * FROM ap_invoice_distributions_all WHERE invoice_id = 24372 order by distribution_line_number asc';
--		RUN_SQLPL('AP_Invoice_Distributions_All', sqltxt,null, null, 'Y', 2, 'PL', 'Y');
--   end;

function RUN_SQLPL(p_title varchar2
			, p_sql_statement varchar2
			, p_disp_lengths  lengths
			, p_headers		headers
			, p_feedback varchar2
			, p_max_rows number
			, p_layout varchar2 default 'P'
			, p_null varchar2 default 'Y'
		      , p_spaces varchar2 default 'N') return number is

begin
	if p_layout = 'P' then

SectionPrint(p_title);
	
return(Display_SQLP(p_title,p_sql_statement, p_feedback, p_max_rows, p_null, p_spaces));

elsif 

p_layout = 'PL' then

SectionPrint(p_title);
	
return(Display_SQLPL(p_title, p_sql_statement, p_feedback, p_max_rows, p_null, p_spaces));

elsif 

p_layout = 'L' then

   SectionPrint(p_title);
   BRPrint;
   return(Display_SQL(p_sql_statement , p_disp_lengths, p_headers,
      p_feedback,p_max_rows));

	end if;
	
end RUN_SQLPL;

procedure RUN_SQLPL(p_title varchar2
			, p_sql_statement varchar2
			, p_disp_lengths lengths
			, p_headers headers
			, p_feedback varchar2
			, p_max_rows number
			, p_layout varchar2 default 'P'
			, p_null varchar2 default 'Y'
                  , p_spaces varchar2 default 'N') is

	dummy	number;
begin
	if p_layout = 'P' then

SectionPrint(p_title);

	dummy := Display_SQLP(p_title, p_sql_statement, p_feedback, p_max_rows, p_null, p_spaces);


elsif p_layout = 'PL' then

SectionPrint(p_title);

	dummy := Display_SQLPL(p_title, p_sql_statement, p_feedback, p_max_rows, p_null, p_spaces);


elsif 

p_layout = 'L' then

   SectionPrint(p_title);
   BRPrint;

	dummy := Display_SQL(p_sql_statement , p_disp_lengths, p_headers,
      p_feedback,p_max_rows);

	end if;
	
end RUN_SQLPL;

-- Function Name: Run_SQLP
-- Procedure Name: Run_SQLP
--
--
-- Usage:
--    Function:
--       a_number := Display_SQLP('Title', 'SQL statement', 'feedback', 'max rows', 'Null Columns', 'Show Spaces');
--
--    Procedure:
--	 RUN_SQLP('Title, 'SQL Statement',  'feedback', 'Max Rows', 'Null Columns', 'Show Spaces');
--
--
-- Parameters:
--   SQL Statement - Any valid SQL select statement text which selects only
--                   columns of type Number, Date, or Varchar2.
--   feedback - Y or N to indicate whether a count of rows should automaticall
--              be printed at the end of the output.  (Default = Y)
--   max rows - Maximum number of rows to output.  NULL or ZERO indicates 
--              unlimited.  (Default = NULL)
--   Null Columns - Y or N - If set to Y Null columns will Null values will be displayed.  If set to N
--                  columns with null values will not be displayed.
--	 Show Spaces - Y or N - If set to Y, column value will be enclosed by >< to show leading and 
--   			   trailing spaces.  If set to N, only the column value will be displayed.
-- Returns:
--    The function returns the number of rows selected.
--    If there is an error then the function returns null.
-- Output:
--      Displays the output of the SQL statement in portrait table format.
--	  The columns for each row will be printed down the page in a portrait format.  
--	  And each additional row will be printed below the previous in the same format.  
--
-- Examples:
--   declare
--      sqltxt       varchar2(2000);
--   begin
--	sqlTxt := 'select * FROM ap_invoice_distributions_all WHERE invoice_id = 24372 order by distribution_line_number asc';
--	dummy := Display_SQLP('AP_Invoice_Distributions', sqTxt, 'Y', 10, 'N');
--   end;
-- Examples:
--   declare
--      sqltxt       varchar2(2000);
--   begin
--		sqlTxt := 'select * FROM ap_invoice_distributions_all WHERE invoice_id = 24372 order by distribution_line_number asc';
--		RUN_SQLP('AP_Invoice_Distributions_All', sqltxt,null, null, 'Y', 2, 'PL', 'Y');
--   end;

function RUN_SQLP(p_title varchar2
			, p_sql_statement varchar2
			, p_feedback varchar2
			, p_max_rows number
			, p_null varchar2 default 'Y'
		      , p_spaces varchar2 default 'Y') return number is

begin

SectionPrint(p_title);
	
return(Display_SQLP(p_title,p_sql_statement, p_feedback, p_max_rows, p_null, p_spaces));

end RUN_SQLP;

procedure RUN_SQLP(p_title varchar2
			, p_sql_statement varchar2
			, p_feedback varchar2
			, p_max_rows number
			, p_null varchar2 default 'Y'
                  , p_spaces varchar2 default 'Y') is

	dummy	number;
begin

SectionPrint(p_title);

	dummy := Display_SQLP(p_title, p_sql_statement, p_feedback, p_max_rows, p_null, p_spaces);

end RUN_SQLP;

/*************************************************************************************************************************
End of Modified Run_SQL Code.  The code was modified to allow the columns to be displayed in Portrait layout format
*************************************************************************************************************************/
--end of custom API's
