undefine v_headerinfo
Define   v_headerinfo     =  '$Header: APTrialBal15.sql 1.8  06-SEP-2002 support $'
undefine v_scriptlongname
Define   v_scriptlongname = 'Diagnose Trial Balance issue for a specific invoice.'

REM   =========================================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM   Oracle Support Services.  All rights reserved.
REM   =========================================================================
REM   PURPOSE:           Diagnose Trial Balance issue for a specific invoice.
REM   PRODUCT:           Accounts Payable (AP)
REM   PRODUCT VERSIONS:  11.5.x
REM   PLATFORM:          Generic
REM   PARAMETERS:        As of Date, Invoice/Check Number, Supplier Name, Invoice_ID
REM   =========================================================================


REM   =========================================================================
REM   USAGE:            sqlplus apps/apps_password @APTrialBal115.sql
REM   EXAMPLE: 
REM   OUTPUT:           The script will produce and output file named APTrialBal115_<the invoice id>_diag.html
REM				This file can be viewed in a browser or uploaded for support analysis.
REM   =========================================================================


REM   =========================================================================
REM   CHANGE HISTORY:
REM     01-MAY-2002   shorgan  Created
REM     <DD-MON-YYYY>   <UserID  >  <Change Details> 
REM   =========================================================================



REM  ================SQL PLUS Environment setup================================
set serveroutput on size 1000000
set verify off
set feedback off
set term on
set autoprint off

REM ============== Define SQL Variables for input parameters ==================
undefine v_invoice_id
undefine v_doc_number
undefine v_doc_amount
undefine v_doc_type
undefine v_details

VARIABLE    v_username VARCHAR2(100);
VARIABLE    v_respid  VARCHAR2(100);


--Verify correct application version

declare

l_appsver   fnd_product_groups.release_name%type := null;

begin

   select max(release_name)
    into l_appsver 
   from fnd_product_groups;
     
   l_appsver := substr(l_appsver,1,4);

if l_appsver <> '11.5' THEN

dbms_output.put_line(chr(10));
dbms_output.put_line('ERROR  - This script was created for Application version 11.5');
dbms_output.put_line('ACTION - Type Ctrl-C <Enter> to exit the script.');
dbms_output.put_line('ACTION - Review the Main Catalog for Applications Support Diagnostic Scripts available for version: '||l_appsver);
dbms_output.put_line('         Note:  178043.1');
dbms_output.put_line(chr(10));

end if;

exception

  when others then

dbms_output.put_line(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR  - RDBMS Version error: '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the script.'  || chr(10) );
dbms_output.put_line(chr(10));

end;

/

--Verify RDBMS version

declare

l_version	varchar2(17);

BEGIN

   select MAX(version)
   into l_version
   from v$instance;

l_version := substr(l_version,1,9);


if l_version < '8.1.6.0.0' then
dbms_output.put_line(chr(10));
dbms_output.put_line('RDBMS Version = '||l_version);
dbms_output.put_line('ERROR - The Script requires RDBMS version 8.1.6 or higher');
dbms_output.put_line('ACTION - Type Ctrl-C <Enter> to exit the script.');
dbms_output.put_line(chr(10));
end if;

exception

  when others then
dbms_output.put_line(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR  - RDBMS Version error: '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the script.'  || chr(10) );
dbms_output.put_line(chr(10));

END;
/




REM ============= Accept other Input Parameters ===============================

--Get Trial Balance As of Date

Prompt
accept v_asof_date prompt 'Enter the As of Date entered for the Trial Balance Report (DD-MON-YY): '

--Get Invoice_ID

set head on verify off linesize 100 feedback on termout on pagesize 100

--The following SQL will retrieve the invoice_id, based on invoice number or check number and amount.

set head off verify off linesize 100 feedback off termout on 
set pagesize 200

PROMPT
PROMPT Are you entering an Invoice Number, Check Number or Invoice_id?
PROMPT
Prompt Enter 1 for Invoice Number
Prompt Enter 2 for Check Number
Prompt Enter 3 for Invoice Id
Accept v_doc_type number prompt '>' DEFAULT 1
PROMPT

define v_doc_type = &v_doc_type

Select decode('&v_doc_type','1','Enter the Invoice Number',
				  '2','Enter the Check Number',
				  '3','Press Enter',
				  'Press Ctrl + C to cancel the script and then run the script again and select option 1 - 3')
from sys.dual
/

set head off feedback off

accept v_doc_number Prompt '>' Default NULL

Prompt

Select decode('&v_doc_type','3','Press Enter','2','Enter the Supplier Name','1','Enter the Supplier Name')
from sys.dual
/
accept v_vendor Prompt '>' Default %

define v_vendor = &v_vendor

Prompt

select decode('&v_doc_type', '1','*****MATCHING INVOICES*****')
from sys.dual
where '&v_doc_type' = 1;

select rpad('Invoice ID',15), rpad('Supplier Name', 25), rpad('Invoice Number',25), 
rpad('Invoice Date',15), rpad('Invoice Amount',15)
from sys.dual 
where '&v_doc_type' = '1';

SELECT distinct rpad(ai.invoice_id,15) invoice_id,  rpad(substr(pv.vendor_name,1,25),25),
rpad(substr(ai.invoice_num,1,25),25), rpad(ai.invoice_date,15), rpad(ai.invoice_amount,15)
FROM   ap_invoices_all ai, po_vendors pv, po_vendor_sites_all pvs
WHERE  Upper(ai.invoice_num) like upper(nvl('&v_doc_number%',''))
and ai.vendor_id = pv.vendor_id
and ai.vendor_site_id = pvs.vendor_site_id
and upper(pv.vendor_name) like upper(nvl('&v_vendor%','%'))
and '&v_doc_type' = '1'
order by invoice_id;

select decode('&v_doc_type', '1',chr(9))
from sys.dual
where '&v_doc_type' = 1;

select 'ERROR - Could not retrieve any Invoices for this Invoice Number and Supplier',
chr(9),'Action - Ensure Invoice Number and Supplier is valid and try again', chr(9),
'Press Ctrl + C to Cancel this script and try again'
from sys.dual
where not exists (
SELECT 'x'
FROM   ap_invoices_all ai, po_vendors pv, po_vendor_sites_all pvs
WHERE  Upper(ai.invoice_num) like upper(nvl('&v_doc_number%',''))
and ai.vendor_id = pv.vendor_id
and ai.vendor_site_id = pvs.vendor_site_id
and upper(pv.vendor_name) like upper(nvl('&v_vendor%','%'))
and '&v_doc_type' = '1'
)
and '&v_doc_type' = '1';

select decode('&v_doc_type', '2','*****MATCHING CHECK NUMBERS*****')
from sys.dual
where '&v_doc_type' = 2;

select distinct rpad('Invoice ID',15), rpad('Check ID',15), rpad('Supplier Name', 25), rpad('Check Number',15), 
rpad('Check Amount',15)
from sys.dual 
where '&v_doc_type' = '2';

SELECT distinct rpad(ai.invoice_id,15) invoice_id, rpad(aip.check_id,15), substr(pv.vendor_name,1,25), rpad(aca.check_number,15),
rpad(aca.amount,15)
FROM   ap_invoices_all ai, po_vendors pv, po_vendor_sites_all pvs,
ap_invoice_payments_all aip, ap_checks_all aca
WHERE  Upper(aca.check_number) = upper(nvl('&v_doc_number',''))
and aca.vendor_id = pv.vendor_id
and aca.vendor_site_id = pvs.vendor_site_id
and ai.invoice_id = aip.invoice_id
and aca.check_id = aip.check_id
and upper(pv.vendor_name) like upper(nvl('&v_vendor%','%'))
and &v_doc_type = '2'
order by invoice_id;

select 'ERROR - Could not retrieve any Checks for this Check Number and Supplier'||
chr(10)||'Action - Ensure Invoice Number and Supplier is valid and try again', chr(9),
'Press Ctrl + C to Cancel this script and try again'
from sys.dual
where not exists (
SELECT 'x'
FROM   ap_invoices_all ai, po_vendors pv, po_vendor_sites_all pvs,
ap_invoice_payments_all aip, ap_checks_all aca
WHERE  Upper(aca.check_number) = upper(nvl('&v_doc_number',''))
and aca.vendor_id = pv.vendor_id
and aca.vendor_site_id = pvs.vendor_site_id
and ai.invoice_id = aip.invoice_id
and aca.check_id = aip.check_id
and upper(pv.vendor_name) like upper(nvl('&v_vendor%','%'))
and &v_doc_type = '2'
)
and '&v_doc_type' = '2';

select chr(9)
from sys.dual
where '&v_doc_type' in (1,2);

Prompt Enter the Invoice ID: 
accept v_invoice_id number Prompt '>' default -99
Prompt

define v_invoice_id = &v_invoice_id


REM ============ Spooling the output file======================================
Define v_spoolfilename  = APTrialBal_&v_invoice_id._diag.html

PROMPT
PROMPT Running.....
PROMPT 
spool  &v_spoolfilename


REM =================Run the Pl/SQL api file ==================================
@@CoreApiHtml.sql
begin  -- begin (block 1) 

  declare -- declare (block 2) 
    p_username varchar2(100);
    p_respid number;

-- ------------------------ Script Declare Section ---------------------- 

  begin  -- begin (block 2) 
    
Show_Header('180167.1', 'Payables Trial Balance Diagnostic Script');

-- -------------------- Script Execution Section ----------------------- 

Declare

sqltxt				varchar2(2000);
l_sob_id                      NUMBER;
l_org_id                      NUMBER;
l_invoice_id                  NUMBER := to_number(nvl('&v_invoice_id','-1'));
l_dummy                       NUMBER;
l_posting_status			VARCHAR2(1) := 'N';
l_test				VARCHAR2(10) := 'zzz';
l_pay_status_flag			VARCHAR2(1);
l_set_of_books			VARCHAR2(30);
l_invoice_idtb			NUMBER;
l_ccid				NUMBER;
l_rem_amt				NUMBER;
l_vendor_id1			NUMBER;
l_sob_idtb				NUMBER;
l_inv_gl_transfer_flag		VARCHAR2(1) := 'N';
l_pay_gl_transfer_flag		VARCHAR2(1) := 'N';
l_source_id				NUMBER;
l_asof_date				DATE := nvl('&v_asof_date',sysdate);
l_asof_date2			DATE := nvl('&v_asof_date',sysdate);
l_automatic_offsets_flag	VARCHAR2(1) := 'N';
l_pay_atg_status_flag		VARCHAR2(1) := 'N';
l_error_code NUMBER        := 0;
l_error_msg  VARCHAR2(300) := '';
l_sob_name				VARCHAR2(35);
l_header_flag		VARCHAR2(1);
l_count				NUMBER;
l_header_test			NUMBER;
l_exception				Exception;
l_ap_liability_bal		varchar2(1);
l_ae_header_id 			Number;
l_ae_line_id			Number;
l_counter				Number;
l_cursor				Integer;
tbalr_sob_id				number;	
tbalr_invoice_id			number;
tbalr_remaining			number;
tbalr_vendor_id			number;
tbalr_ccid				number;



cursor c_invoice_details is
SELECT ai.invoice_id a, substr(ai.vendor_name,1,25) b,
substr(ai.invoice_num,1,25) c,
ai.invoice_date d, ai.invoice_amount e,
substr(ai.invoice_type_lookup_code,1,15) f,
substr(ai.invoice_currency_code,1,3) g, 
substr(ai.payment_currency_code,1,3) h,
ai.approval_status_lookup_code i, ai.holds_count j,
ai.payment_Status_flag k, ai.payments_exist_flag l,
ai.posting_flag m
FROM ap_invoices_v ai
WHERE  ai.invoice_id = l_invoice_id;

cursor c_inv_dists is 
select invoice_id, posted_flag, amount, accounting_event_id, line_type_lookup_code, accounting_date,
invoice_distribution_id
from ap_invoice_distributions
where invoice_id = l_invoice_id;

cursor c_inv_pay is
select distinct aip.check_id c, ac.status_lookup_code k,
ac.check_number h, ac.amount i, ap_checks_pkg.get_posting_status(ac.check_id) j
from ap_invoice_payments aip, ap_checks ac
where aip.invoice_id = l_invoice_id
and ac.check_id = aip.check_id;

/*old cursor (slow)
cursor c_ae_lines is
select ael.reference2, ael.ae_line_Type_code, ael.accounted_dr, ael.accounted_cr, aeh.accounting_date,
to_number(ael.reference3) reference3, aeh.ae_category, aeh.gl_transfer_flag, aeh.set_of_books_id, aeh.org_id
from ap_ae_lines ael, ap_ae_headers aeh
where  aeh.ae_header_id = ael.ae_header_id(+)
and    to_number(NVL(ael.reference2,0)) = l_invoice_id
and    aeh.set_of_books_id = l_sob_id;
*/

cursor c_ae_lines is
select ael.reference2, ael.ae_line_Type_code, ael.accounted_dr, ael.accounted_cr, aeh.accounting_date,
to_number(ael.reference3) reference3, aeh.ae_category, aeh.gl_transfer_flag, aeh.set_of_books_id, aeh.org_id
from
(select distinct ai2.invoice_id, aip2.check_id
				from ap_invoice_payments aip2, ap_invoices ai2
				where ai2.invoice_id = aip2.invoice_id(+)
				) id,
ap_ae_lines ael,
ap_ae_headers aeh, 
ap_accounting_events apae 
where apae.accounting_event_id = aeh.accounting_event_id
and aeh.ae_header_id = ael.ae_header_id(+)
and (
	   (apae.source_table = 'AP_INVOICES' and apae.source_id = id.invoice_id)
 	or (apae.source_table in ('AP_CHECKS', 'AP_PAYMENT_HISTORY') and apae.source_id = id.check_id)
     )
and id.invoice_id = l_invoice_id
and aeh.set_of_books_id(+) = l_sob_id
order by id.invoice_id, apae.accounting_event_id, apae.event_number, aeh.set_of_books_id;

/*too slow
cursor c_orphans is
select distinct aeh.accounting_event_id, aeh.ae_category
from ap_ae_headers aeh, ap_ae_lines ael
where aeh.ae_header_id = ael.ae_header_id(+)
AND    to_number(NVL(ael.reference2,0)) = l_invoice_id
and not exists
(SELECT 'no rows in aip' FROM  ap_invoice_payments aip where aip.accounting_event_id = aeh.accounting_event_id
and aip.invoice_id = l_invoice_id)
and not exists
(select 'no rows in aph' from ap_payment_history aph where aph.accounting_event_id = aeh.accounting_event_id
 and check_id in (select aip2.check_id from ap_invoice_payments aip2 where aip2.invoice_id = l_invoice_id))
and not exists
(select 'no rows in aid' from ap_invoice_distributions aid where aid.accounting_event_id = aeh.accounting_event_id
 and aid.invoice_id = l_invoice_id);
*/

cursor c_orphans is
select distinct aeh.accounting_event_id, aeh.ae_category
from ap_ae_headers aeh, ap_ae_lines ael
where aeh.ae_header_id = ael.ae_header_id(+)
and aeh.ae_category = 'Purchase Invoices'
AND    (ael.source_table = 'AP_INVOICES' and ael.source_id = l_invoice_id)
and not exists
(select 'no rows in aid' from ap_invoice_distributions aid where aid.accounting_event_id = aeh.accounting_event_id
 and aid.invoice_id = l_invoice_id)
UNION
select distinct aeh.accounting_event_id, aeh.ae_category
from ap_ae_headers aeh, ap_ae_lines ael
where aeh.ae_header_id = ael.ae_header_id(+)
and aeh.ae_category = 'Purchase Invoices'
AND  (ael.source_table = 'AP_INVOICE_DISTRIBUTIONS' and ael.source_id in
						    (select invoice_distribution_id  
							from ap_invoice_distributions
							where invoice_id = l_invoice_id))
and not exists
(select 'no rows in aid' from ap_invoice_distributions aid where aid.accounting_event_id = aeh.accounting_event_id
 and aid.invoice_id = l_invoice_id)
UNION
select distinct aeh.accounting_event_id, aeh.ae_category
from ap_ae_headers aeh, ap_ae_lines ael
where aeh.ae_header_id = ael.ae_header_id(+)
and aeh.ae_category like '%Payments%'
AND    (
(source_table = 'AP_CHECKS' AND ael.source_id in
							(select check_id 
							 from ap_invoice_payments
							 where invoice_id = l_invoice_id))
		OR
(source_table = 'AP_INVOICE_PAYMENTS' AND ael.source_id in
							(select invoice_payment_id
							 from ap_invoice_payments
							 where invoice_id = l_invoice_id))
	)
and not exists
(SELECT 'no rows in aip' FROM  ap_invoice_payments aip where aip.accounting_event_id = aeh.accounting_event_id
and aip.invoice_id = l_invoice_id)
and not exists
(select 'no rows in aph' from ap_payment_history aph where aph.accounting_event_id = aeh.accounting_event_id
 and check_id in (select aip2.check_id from ap_invoice_payments aip2 where aip2.invoice_id = l_invoice_id));


cursor c_ae_events_pay is
select aea.source_table, aea.event_type_code, aea.event_status_code, aeh.gl_transfer_flag, aea.source_id,
aea.accounting_event_id, aeh.accounting_date, aeh.ae_header_id
from ap_accounting_events aea, ap_ae_headers aeh
where aea.source_table in ('AP_CHECKS', 'AP_PAYMENT_HISTORY')
and aea.accounting_event_id = aeh.accounting_event_id(+)
and aeh.set_of_books_id(+) = l_sob_id
and aea.source_id = l_source_id
order by aea.source_id, aea.accounting_Event_id;

cursor c_ae_events_inv is
select aea.source_table, aea.event_type_code, aea.event_status_code, aeh.gl_transfer_flag, aea.source_id,
aea.accounting_event_id, aeh.accounting_date, aeh.ae_header_id
from ap_accounting_events aea, ap_ae_headers aeh
where aea.source_table in ('AP_INVOICES')
and aea.accounting_event_id = aeh.accounting_event_id(+)
and aeh.set_of_books_id(+) = l_sob_id
and aea.source_id = l_source_id
order by aea.source_id, aea.accounting_Event_id;

cursor c_pay_sched is 
select invoice_id, amount_remaining, payment_status_flag
from ap_payment_schedules 
where invoice_id = l_invoice_id;

cursor rsob is 
SELECT set_of_books_id, name,
	 DECODE (mrc_sob_type_code,'N','N/A',
                                 'P','Primary',
                                 'R','Reporting') sob_type
  FROM gl_sets_of_books 
where set_of_books_id = (select set_of_books_id from ap_invoices where invoice_id = l_invoice_id)
      OR set_of_books_id in (select reporting_set_of_books_id from gl_mc_book_assignments
                               where primary_set_of_books_id = (select set_of_books_id 
											from ap_invoices where invoice_id = l_invoice_id));

cursor c_tbal is 
SELECT to_number(NVL(ael.reference2,0)) invoice_id,
              ael.code_combination_id code_combination_id,
              SUM(NVL(ael.accounted_cr,0)) - SUM(NVL(ael.accounted_dr,0)) remaining_amount,
              ael.third_party_id vendor_id,
              aeh.set_of_books_id set_of_books_id,
              ael.org_id org_id
        FROM   ap_ae_lines ael,
               ap_ae_headers aeh
        WHERE  ael.ae_line_type_code = 'LIABILITY'
        AND    ael.ae_header_id = aeh.ae_header_id
        AND    aeh.gl_transfer_flag = 'Y'
	  and    aeh.set_of_books_id = l_sob_id
	  AND    to_number(NVL(ael.reference2,0)) = l_invoice_id
--        AND    aeh.accounting_date <= :p_accounting_date
        AND    nvl(ael.org_id,-99) = nvl(aeh.org_id,-99)
        GROUP BY 
               to_number(NVL(ael.reference2,0)),
               ael.code_combination_id,
               ael.third_party_id,
               aeh.set_of_books_id,
               ael.org_id
order by set_of_Books_id;

-- Begin Local Program Units 
procedure div is
begin
Tab0Print('********************************************************************************');
end div;

-- End Local Program Units 

BEGIN

--Verify that the invoice_id exists

l_count := 0;

select count(*) into l_count from ap_invoices_all where invoice_id = l_invoice_id;

if l_count < 1 
THEN

BRPrint;

errorprint('Invoice ID= '|| l_invoice_id ||' does not exist.');
actionerrorprint('Please verify the invoice_id entered and try again.');

Raise l_exception;

end if;


/*  Next verify valid ORG_ID 

l_dummy := 0;

select count(*) 
into l_dummy 
from ap_system_parameters
where nvl(org_id, -999) = nvl(l_org_id, -999);

if l_dummy < 1 then

loghd('test');

BRPrint;


  RAISE_APPLICATION_ERROR(-20001,
    'AP has not been set up for organization ' || l_org_id ||
    '.  Please provide a valid organization ID.');
end if;
*/

--Set the org_id, based on the invoice_id

select org_id 
into l_org_id
from ap_invoices_all
where invoice_id = l_invoice_id;

dbms_application_info.set_client_info(l_org_id);

BRPrint;

l_dummy := 0;

--Verify if ap_liability_balances_table exists

l_ap_liability_bal := column_exists('AP_LIABILITY_BALANCE', 'AE_LINE_ID');

FOR mrc in rsob LOOP		--BEGIN MRC LOOP 

--This loop will allow the script to run all of the invoice validations against the Primary Set of Books 
--and any reporting Set of books assigned to the Primary Set of Books for this invoice_id


l_sob_id := mrc.set_of_books_id;
--l_sob_id := 1;
l_set_of_books := mrc.sob_type;
--l_set_of_books := 'Primary';
l_sob_name := mrc.name;
--l_sob_name := 'Test Name';

--Test to see if there are any headers and lines for Reporting Set of books

select count(*)
into l_header_test
from
(select distinct ai2.invoice_id, aip2.check_id
				from ap_invoice_payments aip2, ap_invoices ai2
				where ai2.invoice_id = aip2.invoice_id(+)
				) id,
ap_ae_lines ael,
ap_ae_headers aeh, 
ap_accounting_events apae 
where apae.accounting_event_id = aeh.accounting_event_id
and aeh.ae_header_id = ael.ae_header_id(+)
and (
	   (apae.source_table = 'AP_INVOICES' and apae.source_id = id.invoice_id)
 	or (apae.source_table in ('AP_CHECKS', 'AP_PAYMENT_HISTORY') and apae.source_id = id.check_id)
     )
and id.invoice_id = l_invoice_id
and aeh.set_of_books_id(+) = l_sob_id;

--Display Set of Books Name and Set of Books ID Invoice Validation is being run against.

sectionprint('Trial Balance Diagnostic for '||l_set_of_books||' Set of Books = '||l_sob_name||' (ID = '||l_sob_id||')');

BRPrint;

--Display Invoice Details

For details in c_invoice_details LOOP  --begin details loop

Tab0Print('Invoice Details');

BRPrint;
Tab1Print('Supplier Name = '||details.b);
Tab1Print('Invoice Number = '||details.c);
Tab1Print('Invoice ID = '||details.a);
Tab1Print('Invoice Date = '||details.d);
Tab1Print('Invoice Amount = '||details.e);

END LOOP;					--end details loop

--Display Invoice Accounting Details

BRPrint;

Tab0Print('Invoice Accounting Details');

BRPrint;

--Tab0Print('Verfiy if Invoice is accounted.');

/*select posting_Flag
into l_posting_status
from ap_invoices_v
where invoice_id = to_number(l_invoice_id);*/

select AP_INVOICES_PKG.GET_POSTING_STATUS(to_number(l_invoice_id))
into l_posting_status
from sys.dual;

IF l_posting_status = 'N'  THEN
	ErrorPrint('This Invoice is not accounted.  The Invoice must be accounted and transferred to the GL before it will be included in the Trial Balance Report.');
	ActionErrorPrint('Create and Transfer the Accounting for this invoice.');
ELSIF l_posting_status = 'P' THEN
	ErrorPrint('This Invoice is Partially accounted.  This invoice has unaccounted lines.  Only the Accounted and Transferred lines will be included in the trial Balance Report.');
	ActionErrorPrint('Create and Transfer the Accounting for any unaccounted lines.');
ELSIF l_posting_status = 'Y' THEN
	Tab1Print('This Invoice is accounted');
ELSE Tab0Print('UNKNOWN STATUS = <'||l_posting_status||'>'||l_invoice_id);
end if;

IF l_posting_status in('P', 'Y') THEN

--Tab0Print('Verify if the invoice accounting is transferred.');

BRPrint;

Tab1Print('The following Invoice Accounting Events have been created');
BRPrint;

l_source_id := l_invoice_id;
l_header_flag := 'z';
l_dummy := 0;
l_test :='zzz';
l_count :=0;

FOR invevents in c_ae_events_inv LOOP 	--begin invevents loop

--Tab0Print('Verify that all of the Invoice events have headers');

select count(*)
into l_dummy
from ap_ae_headers
where set_of_books_id = l_sob_id
and accounting_event_id = invevents.accounting_event_id;

if l_dummy = 0 THEN
ErrorPrint('No headers exists for Event ID = '||invevents.accounting_event_id||' for Set of books ID = '||l_sob_id);
ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
l_header_flag := 'N';
end if;

	if l_header_flag <> 'N' and l_dummy <> 0 THEN
	
	Tab2Print(invevents.event_type_code||' Event ID = '||invevents.accounting_event_id||', Event Status = '||invevents.event_status_code||', Transfer Status = '||invevents.gl_transfer_flag||', Accounting Date = '||invevents.accounting_date);

		IF l_posting_status in('P', 'Y') THEN
			FOR lines in c_ae_lines LOOP  --begin lines loop
				IF lines.gl_transfer_flag <> 'Y' and lines.ae_category = 'Purchase Invoices' THEN
				l_test := 'TRUE';
				ELSIF lines.ae_category = 'Purchase Invoices' THEN
				l_inv_gl_transfer_flag := 'Y';
				end if;
				l_count := l_count+1;
			END LOOP;				--end lines loop
		END IF;
	
	end if;

END LOOP;					--end invevents loop

BRPrint;

	IF l_test = 'TRUE' THEN
			ErrorPrint('This Invoice has untransferred accounting lines. Only the Accounted and Transferred lines will be included in the trial Balance Report.');  
			ActionErrorPrint('Please run the Payables Transfer to GL process to transfer these lines.');
	ELSIF	l_count > 0 THEN
	Tab1Print('All of the Invoice accounting lines have been transferred.');
      end if;	


END IF;

BRPrint;

Tab0Print('Payment Details');

BRPrint;

--Tab0Print('Verify if Invoice is Paid.');

select payment_status_flag 
into l_pay_status_flag
from ap_invoices
where invoice_id = l_invoice_id;

IF l_pay_status_flag = 'Y' THEN
			Tab1Print('This invoice is fully paid');  
ELSIF l_pay_status_flag = 'P' THEN
			ErrorPrint('This invoice is Partially paid. An invoice must be fully paid, accounted and all accounting transferred to the GL before it will be removed from the Trial Balance.');  
			ActionErrorPrint('Pay the invoice in full and create and transfer the payment Accounting.');
ELSIF l_pay_status_flag = 'N' THEN
			ErrorPrint('This invoice is not paid.  An invoice must be paid and all of the accounting
must be created and transferred for an invoice to be removed from the Trial Balance.');
			ActionErrorPrint('Pay the invoice in full and create and transfer the payment Accounting.');
ELSE Tab0Print('UNKNOWN STATUS = <'||l_pay_status_flag||'>'||l_invoice_id);
end if;

--Tab0Print('Display Payments and accounting Status.');

BRPrint;

l_dummy := 0;
	
select count(*)
into l_dummy
from ap_invoice_payments
where invoice_id = l_invoice_id;

if l_dummy > 0 THEN

l_pay_status_flag := 'Z';

Tab1Print('List of Payments issued for this invoice');

BRPrint;

/*select posting_Flag
into l_posting_status
from ap_checks_v
where check_id = l_check_Id*/


	FOR pay in c_inv_pay LOOP  	--begin pay loop
		IF pay.j = 'N'  THEN
			Tab2Print(pay.k||' Check# '||pay.h||' for $'||pay.i||' is not accounted.');
			ErrorPrint('The payment accounting must be created and transferred to be included in the Trial Balance Report');
			ActionErrorPrint('Create and Transfer the Accounting for any unaccounted payments.');

		ELSIF pay.j = 'P' THEN
			Tab2Print(pay.k||' Check# '||pay.h||' for $'||pay.i||' is partially accounted.');
    			ErrorPrint('All payment accounting must be created and transferred to be included in the Trial Balance Report');
			ActionErrorPrint('Create and Transfer the Accounting for any unaccounted payments.');
			l_pay_atg_status_flag := 'P';
		ELSIF pay.j = 'Y' THEN
			Tab2Print(pay.k||' Check# '||pay.h||' for $'||pay.i||' is accounted.');
			l_pay_atg_status_flag := 'Y';
		ELSE Tab0Print('UNKNOWN STATUS = <'||pay.j||'>'||l_invoice_id);
		end if;
	END LOOP;				--end pay loop

			if l_pay_atg_status_flag not in ('Y', 'P') THEN

BRPrint;

			ErrorPrint('Payment Accounting has not been created for any of the payments for this invoice.<br>'||
			'All payment accounting must be created and transferred to be included in the Trial Balance Report');
			ActionErrorPrint('Create and Transfer the Accounting for any unaccounted payments.');
		
BRPrint;

			end if;



end if;

--Tab0Print('Verify if the Payment accounting is transferred.');

--I dont check for posted_flag here because accounting could be created for one payment, but not another
--like in the case of void and reissue.  The accounting is created for the void, but not the reissue.
--I want to check the accounting for both.

	l_test := 'zzz';

if l_pay_atg_status_flag in ('Y', 'P') THEN  --If any Payments have any accounting events created


BRPrint;
Tab0Print('Payment Accounting Details');

BRPrint;

Tab1Print('The following Payment Accounting Events have been created');

BRPrint;

l_source_id := -1;
l_header_flag := 'z';
l_count := 0;

FOR checks in c_inv_pay LOOP  --begin checks loop

	l_test := 'zzz';
	l_dummy := 0;
	l_source_id := checks.c;

	IF checks.j in ('Y','P') THEN
	
	FOR payevents in c_ae_events_pay LOOP

--Tab0Print('Verify that all of the Payments events have headers');

	select count(*)
	into l_dummy
	from ap_ae_headers aeh
	where aeh.accounting_event_id = payevents.accounting_event_id
	and nvl(aeh.set_of_books_id,-1) = l_sob_id;

		if l_dummy = 0 THEN
		ErrorPrint('No headers exists for '||payevents.event_type_code||' event (Event ID) = '||payevents.accounting_event_id||' for Check# '||checks.h||' for Set of books ID = '||l_sob_id);
		ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
		l_header_flag := 'N';
		end if;
	
			if l_dummy <> 0 and l_header_flag <> 'N' THEN
				Tab2Print(payevents.event_type_code||' Event ID = '||payevents.accounting_event_id||' for Check# '||checks.h||' Event Status = '||payevents.event_status_code||' Transfer Status = '||payevents.gl_transfer_flag);
					IF payevents.gl_transfer_flag <> 'Y' THEN
					l_test := 'TRUE';
					ELSE l_pay_gl_transfer_flag := 'Y';
      	    			end if;
			l_count := l_count+1;
			end if;
	
	END LOOP;
	
	end if;
BRPrint;

END LOOP;			--end check loop

		IF l_test = 'TRUE' THEN
		ErrorPrint('There are untransferred Payment Accounting lines.  All payment accounting must be created and transferred to be included in the Trial Balance Report');
		ActionErrorPrint('Create and Transfer the Accounting for any unaccounted payments.');
		ELSIF l_count <> 0 THEN
	  	Tab1Print('All of Payment Accounting Lines have been transferred.');  
		end if;	

end if; --If any Payments have any accounting events created


if (l_pay_atg_status_flag in ('Y', 'P') OR l_posting_status in ('Y', 'P'))  THEN  --Only proceed with Other Trial Balance checks if accounting events exist for the invoice or its payment


BRPrint;

Tab0Print('Other Trial Balance Checks');

BRPrint;


end if;  --Only proceed with Other Trial Balance checks if accounting events exist for the invoice or its payment



IF l_posting_status in('P', 'Y') and l_header_test > 0 THEN

l_dummy := 0;
l_test :='zzz';

BRPrint;
Tab1Print('Verify that all of the Invoice Events have Balanced accounting lines');
BRPrint;

l_source_id := l_invoice_id;

	FOR invevents in c_ae_events_inv LOOP

	select count(*)
	into l_dummy
	from ap_ae_lines ael, ap_ae_headers aeh
	where aeh.ae_header_id = invevents.ae_header_id
	and  ael.ae_header_id = aeh.ae_header_id;

		if l_dummy = 0 THEN
		ErrorPrint('No Accounting lines exist for event_id = '||invevents.accounting_event_id);
		ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
		elsif l_dummy > 0 THEN
		l_dummy := 0;

/*		select count(*)
		into l_dummy
		from ap_ae_lines ael, ap_ae_headers aeh
		where	aeh.ae_header_id = invevents.ae_header_id
				and  ael.ae_header_id = aeh.ae_header_id
			--		and  1=2;
				having nvl(sum(ael.accounted_dr),0) <> nvl(sum(ael.accounted_cr),0));
*/

	select count(*)
		into l_dummy
		from ap_ae_lines ael, ap_ae_headers aeh,
		(select aeh2.ae_header_id, nvl(sum(ael2.accounted_dr),0) sumdr,nvl(sum(ael2.accounted_cr),0) sumcr
		from ap_ae_lines ael2, ap_ae_headers aeh2
		where	aeh2.ae_header_id = invevents.ae_header_id
		and  ael2.ae_header_id = aeh2.ae_header_id
		group by aeh2.ae_header_id) sl		
		where	aeh.ae_header_id = invevents.ae_header_id
		and  ael.ae_header_id = aeh.ae_header_id
		and  sl.ae_header_id = aeh.ae_header_id
		and  sl.sumdr <> sl.sumcr;

			if l_dummy > 0 THEN
			ErrorPrint('Event_id = '||invevents.accounting_event_id||' has unbalanced accounting lines.');
			ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
			else l_test := 'TRUE';
			end if;
	
	end if;



	end loop;

			if l_test = 'TRUE' THEN
			Tab2Print('All of the Invoice Events have balanced Accounting Lines');
			end if;
end if;


if l_pay_atg_status_flag in ('Y', 'P') and l_header_test > 0 THEN

l_dummy := 0;
l_test :='zzz';

BRPrint;
Tab1Print('Verify that all of the Payments have Balanced accounting lines');
BRPrint;

FOR checks in c_inv_pay LOOP  --begin checks loop

l_test := 'zzz';
l_dummy := 0;
l_source_id := checks.c;

	Tab2Print(checks.k||' Check# '||checks.h||' for $'||checks.i);

	if checks.j <> 'N' THEN 	

	FOR payevents in c_ae_events_pay LOOP

	select count(*)
	into l_dummy
	from ap_ae_lines ael, ap_ae_headers aeh
	where aeh.ae_header_id = payevents.ae_header_id
	and  ael.ae_header_id = aeh.ae_header_id;

		if l_dummy = 0 THEN
		ErrorPrint('No Accounting lines exist for event_id = '||payevents.accounting_event_id);
		ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
		elsif l_dummy > 0 THEN
		l_dummy := 0;

/*		select count(*)
		into l_dummy
		from ap_ae_lines ael, ap_ae_headers aeh
		where	aeh.ae_header_id = payevents.ae_header_id
				and  ael.ae_header_id = aeh.ae_header_id
			--		and  1=2;
				having nvl(sum(ael.accounted_dr),0) <> nvl(sum(ael.accounted_cr),0));
*/

	select count(*)
		into l_dummy
		from ap_ae_lines ael, ap_ae_headers aeh,
		(select aeh2.ae_header_id, nvl(sum(ael2.accounted_dr),0) sumdr,nvl(sum(ael2.accounted_cr),0) sumcr
		from ap_ae_lines ael2, ap_ae_headers aeh2
		where	aeh2.ae_header_id = payevents.ae_header_id
		and  ael2.ae_header_id = aeh2.ae_header_id
		group by aeh2.ae_header_id) sl		
		where	aeh.ae_header_id = payevents.ae_header_id
		and  ael.ae_header_id = aeh.ae_header_id
		and  sl.ae_header_id = aeh.ae_header_id
		and  sl.sumdr <> sl.sumcr;

			if l_dummy > 0 THEN
			ErrorPrint('Event_id = '||payevents.accounting_event_id||' has unbalanced accounting lines.');
			ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
			else l_test := 'TRUE';
			end if;
	
		end if;

	end loop;

			if l_test = 'TRUE' THEN
		brprint;	
		Tab2Print('All of the Payments Events for this check have balanced Accounting Lines');
			end if;

	else Tab2Print('No Payment Accounting events have been created for this check.');
	end if;

end loop;

end if;



if l_pay_atg_status_flag in ('Y', 'P') and l_header_test > 0 THEN

BRPrint;
Tab1Print('Verify that the Invoice and Payment have the same Vendor ID');
BRPrint;

l_dummy := 0;

select count(distinct third_party_id) 
into l_dummy
from ap_ae_lines
where to_number(NVL(reference2,0)) = l_invoice_id;
      
	IF l_dummy > 1 THEN
	ErrorPrint('One or more of the accounting lines has a different vendor_id.');
	ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
	ELSE
	Tab2Print('All of the accounting lines use the same vendor_id');
	end if;

BRPrint;

end if;

if l_pay_atg_status_flag in ('Y', 'P') and l_header_test > 0 THEN

Tab1Print('Verify As of Date');
BRPrint;

select max(aeh.accounting_date)
into l_asof_date2
from ap_ae_lines ael, ap_ae_headers aeh
where  aeh.ae_header_id = ael.ae_header_id
and    to_number(NVL(ael.reference2,0)) = l_invoice_id
and    aeh.set_of_books_id = l_sob_id;

	If l_asof_date < l_asof_date2 THEN
	ErrorPrint('Not all accounting entries are included in the As of date '||l_asof_date);
	ActionErrorPrint('Rerun the Trial Balance and use As of date '||l_asof_date2||' or greater.');
	else Tab2Print('All the Transferred accounting entries are included in the As of date '||l_asof_date);
	end if;

end if;

if l_pay_atg_status_flag in ('Y', 'P') and l_header_test > 0 THEN

BRPrint;
Tab1Print('Verify Invoice and Payment have corresponding liability accounts');
BRPrint;

l_test := 'zzz';

select automatic_offsets_flag 
into l_automatic_offsetS_flag
from ap_system_parameters;

select count(*) 
into l_dummy
from 
ap_ae_lines ael, ap_ae_headers aeh
WHERE  aeh.ae_header_id = ael.ae_header_id
and aeh.set_of_books_id = l_sob_id
and ael.ae_line_type_code = 'LIABILITY'
and to_number(NVL(ael.reference2,0)) = l_invoice_id
and aeh.ae_category = 'Payments'
and not exists (select 'x' from 
ap_ae_lines ael2, ap_ae_headers aeh2
WHERE  aeh2.ae_header_id = ael2.ae_header_id
and aeh2.set_of_books_id = l_sob_id
and ael2.ae_line_type_code = 'LIABILITY'
and aeh2.ae_category = 'Purchase Invoices'
and to_number(NVL(ael.reference2,0)) = l_invoice_id
and ael2.code_combination_id = ael.code_combination_id);

	IF l_dummy > 0 THEN
		ErrorPrint('Payment accounting lines have been created for Liability 
accounts that do not exist on the invoice.  All of the Payment Liability Lines should correspond
to Invoice Liability lines.');
ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
	l_test := 'TRUE';
      END IF;

	select count(*) 
	into l_dummy
	from 
	ap_ae_lines ael, ap_ae_headers aeh
	WHERE  aeh.ae_header_id = ael.ae_header_id
	and aeh.set_of_books_id = l_sob_id
	and ael.ae_line_type_code = 'LIABILITY'
	and to_number(NVL(ael.reference2,0)) = l_invoice_id
	and aeh.ae_category = 'Purchase Invoices'
	and not exists (select 'x' from 
	ap_ae_lines ael2, ap_ae_headers aeh2
	WHERE  aeh2.ae_header_id = ael2.ae_header_id
	and aeh2.set_of_books_id = l_sob_id
	and ael2.ae_line_type_code = 'LIABILITY'
	and aeh2.ae_category = 'Payments'
	and to_number(NVL(ael.reference2,0)) = l_invoice_id
	and ael2.code_combination_id = ael.code_combination_id);
	
	IF l_dummy > 0 THEN
ErrorPrint('Invoice accounting lines have been created for Liability 
accounts that do not exist on the payment.  All of the Payment Liability Lines should correspond
to Invoice Liability lines.');
ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
	l_test := 'TRUE';	
	end if;

	if l_test <> 'TRUE' THEN
		Tab2Print('The invoice and payment liability accounts correspond.');
	end if;

end if;

l_test := 'zzz';

if l_pay_atg_status_flag in ('Y', 'P') OR l_posting_status in ('Y', 'P') THEN

BRPrint;
Tab1Print('Check for orphan entries');
BRPrint;

	FOR orphans in c_orphans LOOP
	ErrorPrint(orphans.ae_category||' Accounting Event ID = '||orphans.accounting_event_id||' is orphaned.');
	ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar.');
	l_test := 'TRUE';
	end loop;

			if l_test <> 'TRUE' THEN
			Tab2Print('There are no orphan accounting events.');
			end if;

end if;  

if (  --Verify if the liability amounts are fully relieved
(l_pay_atg_status_flag in ('Y', 'P') OR l_posting_status in ('Y', 'P')) 
and
(l_inv_gl_transfer_flag in ('Y', 'P') OR l_pay_gl_transfer_flag in ('Y', 'P'))
and l_header_test > 0
   )  THEN

if l_ap_liability_bal = 'N' then  --start of added for new table, ap_liability_balance, and new trial balance code

BRPrint;
Tab1Print('Verify if the liability amounts are fully relieved');
BRPrint;


FOR tbalr in c_tbal LOOP 		--begin tbalr loop

Tab2Print('Invoice_id = '||tbalr.invoice_id||' has $'||tbalr.remaining_amount||' remaining for Vendor ID = '||tbalr.Vendor_id||', CCID = '||tbalr.code_combination_id||', SOB ID = '||tbalr.set_of_books_id);  

	if tbalr.remaining_amount <> 0 THEN
	l_test := 'TRUE';
	end if;

END LOOP;					--end tbalr loop

BRPrint;

	if l_test = 'TRUE' THEN

	ErrorPrint('There are unrelieved Liability account lines for this invoice.');
	ActionErrorPrint('Please review and correct the errors above');

	end if;


else --Updated for new table, ap_liability_balance and trial balance code changes.

BRPrint;
Tab1Print('Verify all Transferred liability lines exist in the AP_LIABILITY_BALANCE table.');
BRPrint;

l_counter := 0;

sqltxt := 'select ael.reference2 invoice_id, ael.reference3 check_id, '||
'ael.reference4 check_num, ael.reference5 invoice_num, '||
'ael.ae_header_id, ael.ae_line_id '||
'from ap_ae_lines ael, ap_ae_headers aeh '||
'WHERE  ael.ae_line_type_code = ''LIABILITY'' '||
'AND    ael.ae_header_id = aeh.ae_header_id '||
'AND    aeh.gl_transfer_flag = ''Y'' '||
'and    aeh.set_of_books_id = '||l_sob_id||
' AND    to_number(NVL(ael.reference2,0)) = '||l_invoice_id||
--        AND    aeh.accounting_date <= :p_accounting_date
'        AND    nvl(ael.org_id,-99) = nvl(aeh.org_id,-99) '||
'and not exists '||
'(select ''x'' '|| 
'from ap_liability_balance alb '||
'where ael.ae_line_id = alb.ae_line_id)';

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_ae_header_id);
	  dbms_sql.define_column(l_cursor, 2, l_ae_line_id);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
if l_counter = 1 then
brprint;
tab2print('The following transferred lines do not exist in the AP_LIABILITY_BALANCE table');
brprint;
end if;
	  dbms_sql.column_value(l_cursor, 1, l_ae_header_id);
	  dbms_sql.column_value(l_cursor, 2, l_ae_line_id);
	  tab3print('AE_HEADER_ID = '||l_ae_header_id||', AE_LINE_ID = '||l_ae_line_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

if l_counter = 0 then 
tab3print('All Transferred Lines exist in the AP_LIABILITY_BALANCE table.');
else
ErrorPrint('There are transferred lines that do not exist in the AP_LIABILITY_BALANCE table.');
ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar..');
end if;

BRPrint;
Tab1Print('Verify all liability lines in the AP_LIABILITY_BALANCE table exist in AP_AE_LINES_ALL table.');
BRPrint;

l_counter := 0;

sqltxt := 'select alb.ae_Line_id, alb.ae_header_id '|| 
'from ap_liability_balance alb '||
'WHERE alb.invoice_id = '||l_invoice_id||
' and alb.set_of_books_id = '||l_sob_id||
' and not exists (select ''x'' ' ||
'from ap_ae_lines ael, ap_ae_headers aeh '||
'WHERE   aeh.set_of_books_id = '||l_sob_id||
' and aeh.ae_header_id = ael.ae_header_id '||
' AND    to_number(NVL(ael.reference2,0)) = '||l_invoice_id||
--        AND    aeh.accounting_date <= :p_accounting_date
'        AND    nvl(ael.org_id,-99) = nvl(aeh.org_id,-99) '||
'and alb.ae_line_id = ael.ae_line_id)';


	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, l_ae_header_id);
	  dbms_sql.define_column(l_cursor, 2, l_ae_line_id);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;
if l_counter = 1 then
brprint;
tab2print('The following lines exist in the AP_LIABILITY_BALANCE table, but not in AP_AE_LINES_ALL');
brprint;
end if;
	  dbms_sql.column_value(l_cursor, 1, l_ae_header_id);
	  dbms_sql.column_value(l_cursor, 2, l_ae_line_id);
	  tab3print('AE_HEADER_ID = '||l_ae_header_id||', AE_LINE_ID = '||l_ae_line_id);
	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);

if l_counter = 0 then 
tab3print('All Lines from the AP_LIABILITY_BALANCE table exist in AP_AE_LINES_ALL.');
else
ErrorPrint('There are lines in the AP_LIABILITY_BALANCE table that do not exist in the AP_AE_LINES_ALL table.');
ActionErrorPrint('Please log an iTAR and upload the output of this script to the tar..');
end if;


BRPrint;
Tab1Print('Verify if the liability amounts are fully relieved in the AP_AE_LINES_ALL table');
BRPrint;


FOR tbalr in c_tbal LOOP 		--begin tbalr loop

Tab2Print('Invoice_id = '||tbalr.invoice_id||' has $'||tbalr.remaining_amount||' remaining for Vendor ID = '||tbalr.Vendor_id||', CCID = '||tbalr.code_combination_id||' SOB ID = '||tbalr.set_of_books_id);  

	if tbalr.remaining_amount <> 0 THEN
	l_test := 'TRUE';
	end if;

END LOOP;					--end tbalr loop

BRPrint;

	if l_test = 'TRUE' THEN

	ErrorPrint('There are unrelieved Liability account lines in AP_AE_LINES_ALL for this invoice.');
	ActionErrorPrint('Please review and correct the errors above' );

	end if;


BRPrint;
Tab1Print('Verify if the liability amounts are fully relieved in the AP_LIABILITY_BALANCE table');
BRPrint;

l_counter := 0;

sqltxt := '  SELECT alb.invoice_id invoice_id, '
  || '         alb.code_combination_id code_combination_id, '
  || '         SUM (alb.accounted_cr) -  '
  || '             SUM (alb.accounted_dr) remaining_amount, '
  || '         alb.vendor_id vendor_id, '
  || '         alb.set_of_books_id set_of_books_id, '
  || '         alb.org_id org_id, '
--  || '         '||p_request_id||' request_id, '
  || '         SUM(ae_invoice_amount) invoice_amount '
  || '  FROM   ap_liability_balance alb '
  || '  WHERE  alb.invoice_id = '||l_invoice_id
  || '  and alb.set_of_books_id = '||l_sob_id 
  --|| '  WHERE  trunc(accounting_date) <=  '
  --|| '         trunc(to_date('''||p_accounting_date||''')) '
  || '  GROUP BY '
  || '         alb.invoice_id, '
  || '         alb.code_combination_id, '
  || '         alb.vendor_id, '
  || '         alb.set_of_books_id, '
  || '         alb.org_id ';
--|| '         '||p_request_id||' '
--|| '  HAVING SUM (accounted_cr) <> SUM (accounted_dr) ';
 
l_test := 'false';

	  l_cursor := dbms_sql.open_cursor; 
	  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
	  dbms_sql.define_column(l_cursor, 1, tbalr_invoice_id);
	  dbms_sql.define_column(l_cursor, 2, tbalr_ccid);
	  dbms_sql.define_column(l_cursor, 3, tbalr_remaining);
	  dbms_sql.define_column(l_cursor, 4, tbalr_vendor_id);
	  dbms_sql.define_column(l_cursor, 5, tbalr_sob_id);
	  l_counter := dbms_sql.execute(l_cursor); 
	  l_counter := 0;
	  while dbms_sql.fetch_rows(l_cursor) > 0 loop
	    l_counter := l_counter + 1;

	  dbms_sql.column_value(l_cursor, 1, tbalr_invoice_id);
	  dbms_sql.column_value(l_cursor, 2, tbalr_ccid);
	  dbms_sql.column_value(l_cursor, 3, tbalr_remaining);
	  dbms_sql.column_value(l_cursor, 4, tbalr_vendor_id);
	  dbms_sql.column_value(l_cursor, 5, tbalr_sob_id);

Tab2Print('Invoice_id = '||tbalr_invoice_id||' has $'||tbalr_remaining||' remaining for Vendor ID = '||tbalr_Vendor_id||', CCID = '||tbalr_ccid||', SOB ID = '||tbalr_sob_id);  

	if tbalr_remaining <> 0 THEN
	l_test := 'TRUE';
	end if;

	  end loop;
	   DBMS_OUTPUT.PUT_LINE(chr(9));
	  dbms_sql.close_cursor(l_cursor);


BRPrint;

	if l_test = 'TRUE' THEN

	ErrorPrint('There are unrelieved Liability account lines in AP_LIABILITY_BALANCE for this invoice.');
	ActionErrorPrint('Please review and correct the errors above' );

	end if;

end if;  --end of added for new table, ap_liability_balance, and new trial balance code


end if;   --Verify if the liability amounts are fully relieved



/*       SELECT to_number(NVL(ael.reference2,0)) invoice_id,
              ael.code_combination_id code_combination_id,
              SUM(NVL(ael.accounted_cr,0)) - SUM(NVL(ael.accounted_dr,0)) remaining_amount,
              ael.third_party_id vendor_id,
              aeh.set_of_books_id set_of_books_id,
              ael.org_id org_id
        FROM   ap_ae_lines ael,
               ap_ae_headers aeh
        WHERE  ael.ae_line_type_code = 'LIABILITY'
        AND    ael.ae_header_id = aeh.ae_header_id
        AND    aeh.gl_transfer_flag = 'Y'
        AND    aeh.accounting_date <= :p_accounting_date
        AND    nvl(ael.org_id,-99) = nvl(aeh.org_id,-99)
        GROUP BY 
               to_number(NVL(ael.reference2,0)),
               ael.code_combination_id,
               ael.third_party_id,
               aeh.set_of_books_id,
               ael.org_id
        HAVING SUM(NVL(ael.accounted_cr,0)) <> SUM(NVL(ael.accounted_dr,0)) ; 

*/


END LOOP;		--END MRC LOOP

EXCEPTION

When l_exception then

    Tab3Print(l_error_msg);

When others then -- exception section (block 3) for script code

    BRPrint;
    ErrorPrint(sqlerrm ||' occurred in Script');
    ActionErrorPrint('Please report the above error to Oracle Support Services.');
    BRPrint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo');
    BRPrint;

end;  -- end (block 3), script code 


/* -------------------- Feedback ---------------------------- */

brprint;
Show_Footer('&v_scriptlongname', '&v_headerinfo');

    
  -- -------------------- Script Exception Section ------------------------- 
  exception when others then -- exception section (block 2) for script code

    BRPrint;
    ErrorPrint(sqlerrm ||' occurred in Script');
    ActionErrorPrint('Please report the above error to Oracle Support Services.');
    BRPrint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo');
    BRPrint;
  end;  -- end (block 2), script code 

exception when others then   -- exceptions (block 1) for API and template code
  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in script');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('&v_scriptlongname', '&v_headerinfo');
  BRPrint;
end;  -- end (block 1), API and template code 
/


REM  ==============SQL PLUS Environment setup===================
Spool off
set term on

PROMPT
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================