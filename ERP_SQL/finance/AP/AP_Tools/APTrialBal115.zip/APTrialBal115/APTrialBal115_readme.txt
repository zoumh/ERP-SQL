=======================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.		                 
=======================================================

=======================================================
Abstract		Diagnose Trial Balance issue for a specific invoice.
=======================================================
FILE NAME:		APTrialBal115.sql
PRODUCT: 		Accounts Payable (AP)
SUBCOMPONENT: 	Trial Balance
PRODUCT VERSIONS: 11.5.x
PLATFORM: 		Generic
DATE CREATED:	01-MAY-2002
PARAMETERS:		As of Date, Invoice/Check Number, Supplier Name, Invoice_ID
=======================================================
Instructions
=======================================================
Included Files:
	
      APTrialBal115.sql
      CoreApiHtml.sql
      APTrialBal115_readme.txt	
      APTrialBal115_readme.html

Execution Environment::
	
SQL*Plus Version 8.0.6 Release 8.0.6.0.0 or higher

Access Privileges:
	
	Requires APPS user access.
	
Usage: 

sqlplus apps/apps_password @APTrialBal115.sql

Instructions: 

The files APTrialBal115.sql and CoreApiHtml.sql should be unzipped
to a common directory. From this directory run the file APTrialBal115.sql
in SQL*Plus in the APPS schema.  Follow the prompts and enter the requested information.

The script will produce and output file named APTrialBal115_<the invoice id>_diag.html.
This file can be viewed in a browser or uploaded for support analysis.


=======================================================
Description
=======================================================

This script will detect and report common problems for invoices appearing or not appearing on the 
Trial Balance, such as:

	-Invoice Accounting not created or transferred.
	-Invoice not fully paid.
	-Payment Accounting not created or transferred.
	-Data Corruption.

It verifies if MRC is enabled and reports trial balance issues for Primary and Reporting SOB.


=======================================================
References
=======================================================
None

=======================================================
Disclaimer
=======================================================
EXCEPT WHERE EXPRESSLY PROVIDED OTHERWISE, THE INFORMATION, SOFTWARE, PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. 
ORACLE EXPRESSLY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, 
THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ORACLE MAKES NO 
WARRANTY THAT: (A) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE SOFTWARE WILL BE ACCURATE OR RELIABLE; OR (B) 
THE INFORMATION, OR OTHER MATERIAL OBTAINED WILL MEET YOUR EXPECTATIONS. ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE
DOWNLOADED OR OTHERWISE OBTAINED IS DONE AT YOUR OWN DISCRETION AND RISK. ORACLE SHALL HAVE NO RESPONSIBILITY FOR ANY 
DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY CONTENT, MATERIALS, INFORMATION
OR SOFTWARE.

ORACLE RESERVES THE RIGHT TO MAKE CHANGES OR UPDATES TO THE SOFTWARE AT ANY TIME WITHOUT NOTICE.

=======================================================
Limitation of Liability
=======================================================
IN NO EVENT SHALL ORACLE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, OR DAMAGES
FOR LOSS OF PROFITS, REVENUE, DATA OR USE, INCURRED BY YOU OR ANY THIRD PARTY, WHETHER IN AN ACTION IN CONTRACT OR TORT,
ARISING FROM YOUR ACCESS TO, OR USE OF, THE SOFTWARE.

SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY. ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS
MAY NOT APPLY TO YOU.
