=======================================================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.                   				                 
=======================================================================================================================

=======================================================================================================================
Abstract:               Analyze a payment batch and report problems.
=======================================================================================================================
PRODUCT:                Accounts Payable (AP)
SUBCOMPONENT:           Payment Batch (PBATCH)
PRODUCT VERSIONS:       11.5, 11.0, 10.7
PLATFORM:               All Platforms
DATE CREATED:           26-DEC-2002
PARAMETERS:             Payment Batch Name 
=======================================================================================================================
Instructions
=======================================================================================================================
Included Files:

      APPayBatchStatush.sql (HTML version)
      APPayBatchStatust.sql (Text version)
      APPayBatchStatus_readme.txt
      APPayBatchStatus_readme.html
      APPayBatchStatus_Sample_Output.html
      CoreApiHtml.sql
      CoreApiTxt.sql
	
Execution Environment::

	SQL*Plus

Access Privileges:

	Requires APPS user access
	
Usage:
	
	sqlplus apps/password @APPayBatchStatush.sql (HTML version)

	sqlplus apps/password @APPayBatchStatust.sql (Text version)
	

Instructions: 
	
The files should be unzipped to a common directory. 

For HTML output (recommended), run the file APPaymentSetuph.sql in SQL*Plus in the APPS schema.  
Follow the prompts and enter the requested information. The test will create an output file in html 
format named APPaymentSetuph_<Check_stock_Id>_diag.html. Open the file in your browser and review the output.

For Text output, run the file APPaymentSetupt.sql in SQL*Plus in the APPS schema.  
Follow the prompts and enter the requested information. The test will create an output file in Text 
format named APPaymentSetupt_<Check_stock_Id>_diag.txt. Open the file in a Text editor and review the output.

Note:  The HTML version of this test is incompatible with the UTF8 NLS Character Set for RDBMS version 8.1.7.3 or lower.
Please run the Text version of this test, if you have UTF8 and RDMBS version 8.1.7.3 or lower.


=======================================================================================================================
Test Description
=======================================================================================================================

This test analyzes a payment batch and reports potential problems.  It verifies and displays the following:

-Displays Payment Batch Details from AP_INV_SELECTION_CRITERIA_V
-Displays AP_CHECKRUN_CONC_PROCESSES_ALL Info
-Displays AP_CHECKRUN_CONFIRMATIONS_ALL Info
-Displays FND_CONCURRENT_REQUESTS Info
-Displays AP_SELECTED_INVOICES_ALL Info
-Displays AP_SELECTED_INVOICE_CHECKS_ALL Info
-Displays AP_CHECKS_ALL Info
-Analyzes the payment batch data and reports problems. 

=======================================================================================================================
References
=======================================================================================================================
Oracle Payable User Guide
=======================================================================================================================

Disclaimer
=======================================================================================================================
EXCEPT WHERE EXPRESSLY PROVIDED OTHERWISE, THE INFORMATION, SOFTWARE, PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. 
ORACLE EXPRESSLY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE 
IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ORACLE MAKES NO WARRANTY 
THAT: (A) THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE SOFTWARE WILL BE ACCURATE OR RELIABLE; OR (B) THE 
INFORMATION, OR OTHER MATERIAL OBTAINED WILL MEET YOUR EXPECTATIONS. ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE 
DOWNLOADED OR OTHERWISE OBTAINED IS DONE AT YOUR OWN DISCRETION AND RISK. ORACLE SHALL HAVE NO RESPONSIBILITY FOR ANY
DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY CONTENT, MATERIALS, INFORMATION 
OR SOFTWARE.

ORACLE RESERVES THE RIGHT TO MAKE CHANGES OR UPDATES TO THE SOFTWARE AT ANY TIME WITHOUT NOTICE.

=======================================================================================================================
Limitation of Liability
=======================================================================================================================
IN NO EVENT SHALL ORACLE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES, OR DAMAGES 
FOR LOSS OF PROFITS, REVENUE, DATA OR USE, INCURRED BY YOU OR ANY THIRD PARTY, WHETHER IN AN ACTION IN CONTRACT OR TORT,
ARISING FROM YOUR ACCESS TO, OR USE OF, THE SOFTWARE. 

SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY. ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS 
MAY NOT APPLY TO YOU.



