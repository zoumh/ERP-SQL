undefine v_headerinfo
Define   v_headerinfo     =  '$Header: APPayBatchStatust.sql 1.2  31-DEC-2002 support $'
undefine v_scriptlongname
Define   v_scriptlongname = 'Payment Batch Status Test'

REM   =========================================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM   Oracle Support Services.  All rights reserved.
REM   =========================================================================
REM   PURPOSE:           Analyze Payment Batch Status
REM   PRODUCT:           Accounts Payable (AP)
REM   PRODUCT VERSIONS:  10.7, 11, 11.5
REM   PLATFORM:          Generic
REM   PARAMETERS:        Payment Batch Name
REM   =========================================================================


REM   =======================================================
REM   USAGE: 	sqlplus apps/password @APPayBatchStatust.sql
REM   EXAMPLE: 
REM   OUTPUT:     The script will create an output file in text format named 
REM		      APPayBatchStatust_<ChechrunName>_diag.txt.
REM			Open the file in a text editor and review the output
REM   =======================================================


REM   =========================================================================
REM   CHANGE HISTORY:
REM     01-AUG-2002   shorgan  Created
REM     26-DEC-2002   cganapai  Updated 
REM   =========================================================================



REM  ================SQL PLUS Environment setup================================
set serveroutput on size 1000000
set verify off
set feedback off
set linesize 132

REM ============== Define SQL Variables for input parameters ==================
undefine v_checkrun_name
clear columns



REM ============= Accept other Input Parameters ===============================
set head on verify off feedback on termout on

prompt
accept v_checkrun_name prompt 'Enter Payment Batch Name (Case Sensitive): '
prompt
set head on feedback on


REM ============ Spooling the output file======================================
Define v_spoolfilename  = 'APPayBatchStatust_&v_checkrun_name._diag.txt'

PROMPT
PROMPT Running.....
PROMPT 
spool  &v_spoolfilename


REM =================Run the Pl/SQL api file ==================================
@@CoreApiTxt.sql
begin  -- begin (block 1) 

  declare -- declare (block 2) 
    p_username varchar2(100);
    p_respid number;
    -- ------------------------ Script Declare Section ---------------------- 

  begin  -- begin (block 2) 
   
    Show_Header('182988.1', '&v_scriptlongname');

    
    -- -------------------- Script Execution Section ----------------------- 

Declare

l_sob_id                      NUMBER;
l_test				VARCHAR2(5);
l_dummy                       VARCHAR2(50);
l_set_of_books_id			NUMBER;
l_source_id				NUMBER;
l_sob_name				VARCHAR2(35);
l_count				NUMBER;
l_chk_count				NUMBER;
l_inv_count				NUMBER;
l_exception				Exception;
l_org_id				NUMBER;
l_error_code 			NUMBER;
l_error_msg  			VARCHAR2(1000);
l_status				ap_inv_selection_criteria_all.status%TYPE;
l_checkrun_name			ap_inv_selection_criteria_all.checkrun_name%TYPE := nvl('&v_checkrun_name', 'Not Defined');
l_checkrun_id			NUMBER;
l_checks_created			VARCHAR2(1);
l_request_id			NUMBER;
l_program				VARCHAR2(35);
l_phase_code			VARCHAR2(1);
l_status_code			VARCHAR2(1);
l_min_chk_num			number;
l_max_chk_num			number;
l_ap_checks_count			number;
l_test_errors			boolean := false;


cursor c_invselcrit is
select distinct checkrun_name, checkrun_id, status, first_available_document,
start_print_document, end_print_document,  org_id,
invoice_count, negot_payment_count, overall_payment_count
from ap_inv_selection_criteria_v
where checkrun_name = l_checkrun_name;

cursor c_concproc is
select checkrun_name, request_id, program
from ap_checkrun_conc_processes
where checkrun_name = l_checkrun_name;

cursor c_chkrunconf is
select checkrun_name, start_check_number, end_check_number,
range_lookup_code, processed_flag
from ap_checkrun_confirmations
where checkrun_name = l_checkrun_name
order by start_check_number;

cursor c_reqstatus is
SELECT decode(PHASE_CODE, 'C', 'COMPLETED',
				  'I', 'INACTIVE',
				  'P', 'PENDING',
				  'R', 'RUNNING',
				  'UNKNOWN') PHASE, PHASE_CODE,
	decode(STATUS_CODE, 'D', 'CANCELLED',
				  'U', 'DISABLED',
 				  'E', 'ERROR',
                          'M', 'NO MANAGER',
                          'R', 'NORMAL',
                          'H', 'ON HOLD',
				  'W', 'PAUSED',
				  'B', 'RESUMING',
				  'I', 'SCHEDULED',
				  'Q', 'STANDBY',
				  'S', 'SUSPENDED',
				  'X', 'TERMINATED',
				  'T', 'TERMINATING',
				  'A', 'WAITING',
				  'G', 'Error',
				  'C', 'NORMAL',
					 'UNKNOWN') STATUS, STATUS_CODE,
                        IMPLICIT_CODE,
CONCURRENT_PROGRAM_ID,PROGRAM_APPLICATION_ID,
  ARGUMENT_TEXT, ACTUAL_COMPLETION_DATE,COMPLETION_TEXT,
  PARENT_REQUEST_ID,REQUEST_TYPE,REQUESTED_BY,rEQUESTED_START_DATE,
  REQUEST_ID
FROM
FND_CONCURRENT_REQUESTS 
WHERE (DECODE(IMPLICIT_CODE, 'N', STATUS_CODE,'E','E', 'W', 'G') = STATUS_CODE 
OR DECODE(IMPLICIT_CODE, 'W', 'E') = STATUS_CODE)  
and request_id = l_request_id
order by REQUEST_ID DESC;

cursor c_valid is
select checkrun_name, status, org_id
from ap_inv_selection_criteria_all;


BEGIN

/*Validate Checkrun Name*/

l_count := 0;

select count(*)
into l_count
from ap_inv_selection_criteria_all
where checkrun_name = l_checkrun_name;

if l_count = 0 THEN

brprint;
errorprint('No payment batch found with payment batch name: '||l_checkrun_name);
actionerrorprint('Please verify the payment batch name and try again.');
brprint;

sectionprint('List of valid payment batch names:');
brprint;

for valid in c_valid LOOP
EXIT WHEN c_valid%NOTFOUND;
l_test := 'TRUE';

tab1print('Payment Batch Name: '||valid.checkrun_name||' Status: '||valid.status||' Org ID: '||valid.org_id);

end loop;

brprint;
sectionprint('Note: Search for payment batch name is case sensitive');
l_error_msg := '';
Raise l_exception;

end if;

/* Set org_id */

select max(org_id)
into l_org_id
from ap_inv_selection_criteria_all
where checkrun_name = l_checkrun_name;

dbms_application_info.set_client_info(l_org_id);

/*Diplay Payment Batch Details from AP_INV_SELECTION_CRITERIA_V */

brprint;

sectionprint('Payment Batch Details from AP_INV_SELECTION_CRITERIA_V'); 

brprint;

for invsel in c_invselcrit LOOP
EXIT WHEN c_invselcrit%NOTFOUND;
tab1print('Payment Batch Name: '||invsel.checkrun_name);
tab1print('Checkrun ID: '||invsel.checkrun_id);
tab1print('Organization ID: '||invsel.org_id);
l_checkrun_id := invsel.checkrun_id;
tab1print('Status: '||invsel.status);
l_status := invsel.status;
tab1print('First Available Document: '||invsel.first_available_document);
tab1print('Start Print Document: '||invsel.start_print_document);
tab1print('End Print Document:'||invsel.end_print_document);
tab1print('Invoice Count: '||invsel.invoice_count); 
tab1print('Negotiable Pmt Count: '||invsel.negot_payment_count);
tab1print('Overall Pmt Count '||invsel.overall_payment_count);

end loop;

/*Verify info in ap_checkrun_conc_processes_all */

	brprint;
	
	sectionprint('AP_CHECKRUN_CONC_PROCESSES_ALL Info');
	
	brprint;	

l_test := 'zzz';

	for concproc in c_concproc LOOP
	EXIT WHEN c_concproc%NOTFOUND;
	l_test := 'TRUE';
	tab1print('Payment Batch Name: '||concproc.checkrun_name);
	tab1print('Request ID: '||concproc.request_id);
	l_request_id := concproc.request_id;
	tab1print('Program: '||concproc.program);
	l_program := concproc.program;
	end loop;

if l_test <> 'TRUE' THEN
tab1print('There are 0 rows for this Payment Batch name in AP_CHECKRUN_CONC_PROCESSES_ALL .');
end if;



/* Verify info in AP_CHECKRUN_CONFIRMATIONS */

	brprint;
	
	sectionprint('AP_CHECKRUN_CONFIRMATIONS_ALL Info');
	
	brprint;

l_test := 'zzz';

	for conf in c_chkrunconf LOOP
	EXIT WHEN c_chkrunconf%NOTFOUND;
	l_test := 'TRUE';
	tab1print('Payment Batch Name: '||conf.checkrun_name);
	tab1print('Start Check Number: '||conf.start_check_number);
	tab1print('End Check Number: '||conf.end_check_number);
	tab1print('Range Lookup Code: '||conf.range_lookup_code);
	tab1print('Processed Flag: '||conf.processed_flag);
	brprint;
	end loop;

if l_test <> 'TRUE' THEN
tab1print('There are 0 rows for this payment batch name in AP_CHECKRUN_CONFIRMATIONS_ALL.');
end if;


/* Status of the Payment Batch in FND_CONCURRENT_REQUESTS */

brprint;
sectionprint('FND_CONCURRENT_REQUESTS Info'); 
brprint;

l_test := 'zzz';

for status in c_reqstatus LOOP
EXIT WHEN c_reqstatus%NOTFOUND;

l_test := 'TRUE';
tab1print('Request ID: '||l_request_id||' Program: '||l_program||' Phase: '||status.phase||' Status: '||status.status);
l_phase_code := status.phase_code;
l_status_code := status.status_code;
end loop;

if l_test <> 'TRUE' THEN
tab1print('There are 0 rows for this payment batch in FND_CONCURRENT_REQUESTS .');
l_phase_code := 'C';
end if;



/* Verify if there are rows in ap_selected_invoices */

	brprint;
	
	sectionprint('AP_SELECTED_INVOICES_ALL Info');
	
	brprint;

	l_inv_count := 0;

	select count(*)
	into l_inv_count
	from ap_selected_invoices
	where checkrun_name = l_checkrun_name;

	if l_inv_count = 0 THEN

	tab1print('There are 0 rows for this payment batch in AP_SELECTED_INVOICES_ALL.');

	else 

	tab1print(l_inv_count||' Rows exist for this payment batch name in AP_SELECTED_INVOICES_ALL.');

	end if;

/* Verify if there are rows in AP_SELECTED_INVOICE_CHECKS */

	brprint;
	
	sectionprint('AP_SELECTED_INVOICE_CHECKS_ALL Info');
	
	brprint;

	l_chk_count := 0;

	select count(*)
	into l_chk_count
	from ap_selected_invoice_checks
	where checkrun_name = l_checkrun_name;

	if l_chk_count = 0 THEN

	tab1print('There are 0 rows for this payment batch in AP_SELECTED_INVOICE_CHECKS_ALL.');
	
brprint;

	else 

	tab1print(l_chk_count||' Rows exist for this payment batch name in AP_SELECTED_INVOICE_CHECKS_ALL.');
	brprint;	

	end if;


/*Verify if any rows have been created in AP_CHECKS for this checkrun name.*/


sectionprint('AP_CHECKS_ALL Info');  

brprint;


l_ap_checks_count := 0;

select count(*)
into l_ap_checks_count
from ap_checks 
where checkrun_id = l_checkrun_id;

if l_ap_checks_count <> 0 THEN

tab1print(l_ap_checks_count||' Checks have been created with this payment batch name in AP_CHECKS_ALL .');
l_checks_created := 'Y';

else  

tab1print('There are 0 checks for this payment batch name in AP_CHECKS_ALL.');
	
end if;

brprint;

sectionprint('Analysis of Payment Batch Status and Data');

brprint;


	if l_inv_count <> 0 and l_chk_count <> 0 and l_status = 'FORMATTING' and l_phase_code = 'C' THEN

	brprint;
	Errorprint('The payment batch status is FORMATTING, but no process is running. '||chr(10)||
	'There are rows in AP_SELECTED_INVOICES_ALL and AP_SELECTED_INVOICE_CHECKS_ALL.');
	actionErrorprint('Please contact Oracle support and for data fix');
	brprint;
	tab1print('Note to Oracle Support: '||'Review internal Note:1048198.6, solution #1 for data fix');

	l_test_errors := true;

	elsif l_status = 'FORMATTING' and l_phase_code = 'C' THEN

	brprint;
	Errorprint('The payment batch status is FORMATTING, but no process is running. '||chr(10)||
	'AP_SELECTED_INVOICES_ALL or AP_SELECTED_INVOICE_CHECKS_ALL, does not have any rows');
	actionErrorprint('Please contact oracle support for data fix');

	brprint;
	tab1print('Note to Oracle Support:  Incomplete payment batches should still have rows in the payment temp tables. '||chr(10)||
                'Further analysis of this payment batch is required before proceeding with any data fix.');

	l_test_errors := true;

	elsif l_inv_count <> 0 and l_chk_count <> 0 and l_status = 'CONFIRMING' and l_phase_code = 'C' THEN

	brprint;
	Errorprint('The payment batch status is CONFIRMING, but no process is running '||chr(10)||
	'There are rows in AP_SELECTED_INVOICES_ALL and AP_SELECTED_INVOICE_CHECKS_ALL.');
	actionErrorprint('Please contact Oracle support for data fix');
	brprint;
	tab1print('Note to Oracle Support: '||'Review internal Note:1048198.6, solution #2 & #3 for data fix');

	l_test_errors := true;

	elsif l_status = 'CONFIRMING' and l_phase_code = 'C' THEN

	brprint;
	Errorprint('The payment batch status is CONFIRMING, but no process is running.'||chr(10)||
	'AP_SELECTED_INVOICES or AP_SELECTED_INVOICE_CHECKS, does not have any rows');
	actionErrorprint('Please contact Oracle support for data fix');

	brprint;
	tab1print('Note to Oracle Support:  Incomplete payment batches should still have rows in the payment temp tables. '||chr(10)||
                'Further analysis of this payment batch is required before proceeding with any data fix.');

	l_test_errors := true;

	elsif l_inv_count <> 0 and l_chk_count <> 0 and l_status = 'CANCELING' and l_phase_code = 'C' THEN

	brprint;
	Errorprint('The payment batch status is CANCELING, but no process is running.'||chr(10)||
	'There are rows in AP_SELECTED_INVOICES_ALL and AP_SELECTED_INVOICE_CHECKS_ALL.');
	actionErrorprint('Please contact Oracle support for data fix');
	brprint;
	tab1print('Note to Oracle Support: '||'  Review internal Note:1048198.6, solution #2 & #3 for data fix');

	l_test_errors := true;

	elsif l_status = 'CANCELING' and l_phase_code = 'C' THEN

	brprint;
	Errorprint('The payment batch status is CANCELING, but no process is running.'||chr(10)||
	'AP_SELECTED_INVOICES or AP_SELECTED_INVOICE_CHECKS, does not have any rows');
	actionErrorprint('Please contact Oracle support for data fix');

	brprint;
	tab1print('Note to Oracle Support:  Incomplete payment batches should still have rows in the payment temp tables.' ||chr(10)|| 
                'Further analysis of this payment batch is required before proceeding with any data fix.');

	l_test_errors := true;

	elsif l_status in ('BUILT', 'FORMATTED') and l_chk_count = 0 then
brprint;
Errorprint('No checks were built for this payment batch to format');
actionErrorprint('Please review Note.11338.1 for more details on why no checks were built.');

	l_test_errors := true;

	elsif l_status in ('SELECTED') and l_inv_count = 0 then

brprint;
Errorprint('No invoices were selected to build checks to format.');
actionErrorprint('Please review Note.11338.1 for more details on why no invoices were selected.');

	l_test_errors := true;

	end if;


if l_checks_created = 'Y' and l_status not in ('CONFIRMED') THEN

brprint;
Errorprint(l_ap_checks_count||' Checks have been created in AP_CHECKS_ALL with this payment batch name.'||chr(10)||
'And this payment batch does not have a confirmed status.');
actionErrorprint('Please Contact Oracle Support');
l_checks_created := 'Y';

brprint;
tab1print('Note to Oracle Support: This payment batch may have been confirmed or partially confirmed.'||chr(10)||
'Further analysis of this payment batch is required before proceeding with any data fix.');

	l_test_errors := true;

end if;


if l_phase_code <> 'C' THEN

brprint;
Errorprint('The '||l_program||' process has not completed.');
actionErrorprint('Please contact Oracle Support if the process does not complete in a reasonable amount of time.');
brprint;

	l_test_errors := true;

end if;

if not l_test_errors then

	tab1print('No problems were found for this payment batch.');

end if;

EXCEPTION

When l_exception then

    line_out(l_error_msg);

when others then --exception section3

  DBMS_OUTPUT.PUT_LINE(chr(9));

  ErrorPrint(sqlerrm||' occurred in Script');

  actionErrorPrint('Please use the Feedback option on Readme of the Script to contact support');

  DBMS_OUTPUT.PUT_LINE(chr(9));

    Show_Footer('&v_scriptlongname', '&v_headerinfo');

  DBMS_OUTPUT.PUT_LINE(chr(9));

end; --end3


    --  -------------------- Feedback ---------------------------- 
    BRPrint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo');
    
  -- -------------------- Script Exception Section ------------------------- 
  exception when others then -- exception section (block 2) for script code
    BRPrint;
    ErrorPrint(sqlerrm ||' occurred in Script');
    ActionErrorPrint('Please report the above error to Oracle Support Services.');
    BRPrint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo');
    BRPrint;
  end;  -- end (block 2), script code 

exception when others then   -- exceptions (block 1) for API and template code
  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in script');
  ActionErrorPrint('Please report the above error to Oracle Support Services.');
  BRPrint;
  Show_Footer('&v_scriptlongname', '&v_headerinfo');
  BRPrint;
end;  -- end (block 1), API and template code 
/


REM  ==============SQL PLUS Environment setup===================
Spool off
set term on

PROMPT
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================