undefine v_headerinfo
Define   v_headerinfo     =  '$Header: APClosing115h.sql Version 1.6  04-DEC-2002 support $'
undefine v_scriptlongname
Define   v_scriptlongname = 'Test to Diagnose why a period cannot be closed '

REM   =========================================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM   Oracle Support Services.  All rights reserved.
REM   =========================================================================
REM   PURPOSE:            To check why a period cannot be closed
REM   PRODUCT:            Accounts Payable (AP) 
REM   PRODUCT VERSIONS:   11.5
REM   PLATFORM:           All Platforms
REM   PARAMETERS:         Application User Name, Responsibility Id, Period Name
REM				  Set of Books Id	
REM   =========================================================================


REM   =========================================================================
REM   USAGE:             sqlplus apps/password @APClosing115h.sql
REM   EXAMPLE: 
REM   OUTPUT:            The test will create will create an output in html format
REM				 named APClosing115_<Set of books id>_<Period Name>_diag.html
REM				 Open the file in a browser and review the output	
REM   =========================================================================


REM   =========================================================================
REM   CHANGE HISTORY:
REM     <18-NOV-2002>   <CGANAPAI.IN>  Created
REM     <DD-MON-YYYY>   <UserID  >  <Change Details> 
REM   =========================================================================



REM  ================SQL PLUS Environment setup================================
set serveroutput on size 1000000
set verify off
set autoprint off


REM ============== Define SQL Variables for input parameters ==================
VARIABLE    v_username VARCHAR2(100);
VARIABLE    v_respid  VARCHAR2(100);

prompt


REM ================Show responsibilities assigned to given user===============
DECLARE
  l_applversion  fnd_product_groups.release_name%type;
  l_counter      integer;
  l_cursor       integer;
  sqltxt         varchar2(3000);
  l_resp_id      integer;
  l_resp_name    varchar2(300);
  
  invalid_version exception;

BEGIN

  select substr(release_name,1,4)  into l_applversion from fnd_product_groups;
  
  if l_applversion != '11.5' then
     raise invalid_version;
  end if;

  select nvl(rtrim(ltrim(upper('&Application_user_name'))), '<NULL username>')
  into :v_username
  from dual;
  
  sqltxt := 'select to_char(a.responsibility_id) id, '||
            '       b.responsibility_name name '||
            'from   fnd_user_resp_groups a, '||
            '       fnd_responsibility_vl b, '||
            '       fnd_user u '||
            'where  a.user_id = u.user_id '||
            'and    a.responsibility_id = b.responsibility_id '||
            'and    a.responsibility_application_id = b.application_id '||
            'and    sysdate between '||
            '          a.start_date and nvl(a.end_date,sysdate+1) '||
            'and    upper(u.user_name) = '''|| :v_username ||''''||
            'order  by b.responsibility_name';

  DBMS_OUTPUT.PUT_LINE(chr(10) || 'Responsibilities assigned to User:  '|| :v_username);
  DBMS_OUTPUT.PUT_LINE('=================================================================' || chr(10) );
  
  l_cursor := dbms_sql.open_cursor; 
  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
  dbms_sql.define_column(l_cursor, 1, l_resp_id);
  dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
  l_counter := dbms_sql.execute(l_cursor); 
  l_counter := 0;
  while dbms_sql.fetch_rows(l_cursor) > 0 loop
    l_counter := l_counter + 1;
    dbms_sql.column_value(l_cursor, 1, l_resp_id);
    dbms_sql.column_value(l_cursor, 2, l_resp_name);
    DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
  end loop;
  
  DBMS_OUTPUT.PUT_LINE(' ');
  
  if l_counter = 0 then
    raise no_data_found;
  end if;
  dbms_sql.close_cursor(l_cursor);

exception
  when no_data_found then
    DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
    DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.' || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.  Rerun the diagnostic test with a valid user name.' || chr(10));

  when invalid_version then
    DBMS_OUTPUT.PUT_LINE('ERROR  - Invalid Application Version  '|| l_applversion);
    DBMS_OUTPUT.PUT_LINE('ACTION - This Diagnostic Test is not intended for this Application version.'  || chr(10) || 
                         '         Type Ctrl-C <Enter> to exit the test.');

  when others then
    DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error: '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.'  || chr(10) );

END;
/

PROMPT 
undefine v_respid
accept v_respid number PROMPT  'Please choose a Responsibility ID from the list : '
PROMPT 


REM ============= Accept other Input Parameters ===============================
undefine v_period_name
undefine v_sob_id
undefine v_start_date
undefine v_end_date
undefine v_org_id

PROMPT
accept v_period_name prompt 'Enter Period Name: '


--Get the Set of Books ID

PROMPT
PROMPT All Primary Set of Books Used in Payables

set pagesize 20 linesize 200

SELECT distinct gl.set_of_books_id sob_id, gl.name sob_name, 
	 DECODE (gl.mrc_sob_type_code,'N','N/A',
                                 'P','Primary',
                                 'R','Reporting') sob_type
  FROM gl_sets_of_books gl,  hr_operating_units hr, ap_system_parameters_all asp
where nvl(asp.org_id,-99) = hr.organization_id(+)
and asp.set_of_books_id = gl.set_of_books_id
order by sob_type desc, gl.set_of_books_id;


accept v_sob_id prompt 'Enter the Set of books ID: '

REM ============ Spooling the output file======================================
Define v_spoolfilename  = 'APClosing115h_&v_sob_id._&v_period_name._diag.html'

PROMPT
PROMPT Running.....
PROMPT 
spool  &v_spoolfilename


REM =================Run the Pl/SQL api file ==================================
@@CoreApiHtml.sql
begin  -- begin (block 1) 

  declare -- declare (block 2) 
    p_username varchar2(100);
    p_respid number;
    -- ------------------------ Script Declare Section ---------------------- 


  begin  -- begin (block 2) 
    p_username := :v_username;
    
    IF &v_respid IS NULL THEN
      p_respid := -10;
    ELSE
      p_respid := &v_respid;
    END IF;
    
    
    Set_Client(p_username,p_respid);
    Show_Header('180165.1', 'Payables Closing Diagnostic Test');
    
    -- -------------------- Script Execution Section ----------------------- 
    Declare --declare3

l_sob_id                      NUMBER := &v_sob_id;
l_dummy                       NUMBER;
l_set_of_books_id			NUMBER;
l_source_id				NUMBER;
l_sob_name				VARCHAR2(35);
l_count				NUMBER;
l_count2				NUMBER;
l_exception				Exception;
l_period_name			VARCHAR2(30) := '&v_period_name';
l_org_id				NUMBER;
l_error_code 			NUMBER;
l_error_msg  			VARCHAR2(1000);
sqltxt			      varchar2(2000);
ql_markers 		V2T;
ql_titles  		V2T;
ql_markers1 		V2T;
ql_titles1  		V2T;
ql_markers2 		V2T;
ql_titles2  		V2T;
ql_markers3 		V2T;
ql_titles3  		V2T;
ql_markers4 		V2T;
ql_titles4  		V2T;
ql_markers5 		V2T;
ql_titles5  		V2T;
ql_markers6 		V2T;
ql_titles6  		V2T;
ql_markers7 		V2T;
ql_titles7  		V2T;
ql_markers8 		V2T;
ql_titles8  		V2T;
ql_markers9 		V2T;
ql_titles9  		V2T;
ql_markers10 		V2T;
ql_titles10  		V2T;
l_name varchar2(32727);
l_max	number;

cursor rsob is 
SELECT gl.set_of_books_id sob_id, gl.name sob_name, 
	 DECODE (gl.mrc_sob_type_code,'N','N/A',
                                 'P','Primary',
                                 'R','Reporting') sob_type,
hr.name hr_name, hr.organization_id org_id
  FROM gl_sets_of_books gl,  hr_operating_units hr, ap_system_parameters_all asp
where (gl.set_of_books_id = l_sob_id
      OR gl.set_of_books_id in (select reporting_set_of_books_id from gl_mc_book_assignments
                               where primary_set_of_books_id = l_sob_id))
and nvl(asp.org_id,-99) = hr.organization_id(+)
and asp.set_of_books_id = l_sob_id
order by gl.mrc_sob_type_code, gl.set_of_books_id;


--Begin Custom API

procedure Tag(p_txt varchar2) is
begin
  Insert_HTML('<a NAME='||p_txt||'></a>');
end Tag;
procedure Top is
begin
  Insert_HTML('<a HREF=#quicklinks>Back to Quick Links</a><BR>');
end Top; 


procedure Show_Quicklink_Row(p_ql_titles in V2T, p_ql_markers in V2T) is
 l_row_values V2T;
begin
  if p_ql_titles.count = p_ql_markers.count then
    l_row_values := V2T();
    for i in 1..p_ql_titles.count loop
      l_row_values.extend;
      l_row_values(i) := '<a href=#'||p_ql_markers(i)||'>'||
        p_ql_titles(i)||'</a>';
    end loop;
    Show_table_row(l_row_values,null);
  end if;
end Show_Quicklink_Row;


--end custom api


BEGIN  --Begin3

--Verify Valid Set of Books ID Entered

l_count := 0;

select count(*) into l_count 
FROM gl_sets_of_books gl,  hr_operating_units hr, ap_system_parameters_all asp
where nvl(asp.org_id,-99) = hr.organization_id(+)
and asp.set_of_books_id = gl.set_of_books_id
order by gl.mrc_sob_type_code desc, gl.set_of_books_id;

if l_count < 1 

THEN
ErrorPrint('Set of Books ID: ' || l_sob_id ||' does not exist');
ActionErrorPrint('Please verify the Set of Books Id entered and try again');
--l_error_msg := 'Set of Books ID: ' || l_sob_id ||' does not exist.  Please verify the Set of Books Id entered and try again.';

Raise l_exception;

end if;

--Verify Valid Period Name Entered

l_count := 0;

select count(*) 
into l_count 
from gl_period_statuses 
where period_name = l_period_name
and set_of_books_id = l_sob_id;

if l_count < 1 

THEN

--l_error_msg := 'Period Name: ' || l_period_name ||' does not exist.  Please verify the Period Name entered and try again.';
ErrorPrint('Period Name: ' || l_period_name ||' does not exist');
ActionErrorPrint('Please verify the Period Name entered and try again.');
Raise l_exception;

end if;

--  Set up the output mechanism 

DBMS_OUTPUT.ENABLE(1000000);


--Display Quicklinks

tag('quicklinks');

SectionPrint('Quick Links to Data');
Start_Table('Quick Links to Data Collection');

l_max :=0;

FOR mrc in rsob LOOP		--BEGIN MRC LOOP 

l_max := l_max +1;

end loop;


l_count := 1;
l_count2 := 1;

FOR mrc in rsob LOOP		--BEGIN MRC LOOP 

l_name := mrc.sob_type||'_Set of Books:_'||mrc.sob_name||'_(ID='||mrc.sob_id||')_Organization:_'||mrc.hr_name||' (ID='||mrc.org_id||')';

l_name := replace(l_name, ' ', '_');

if l_count = 1 then

	ql_markers := v2t(l_name);
	ql_titles := v2t(l_name);

else

	ql_markers.extend;
	ql_markers(l_count) := l_name;
	ql_titles.extend;
	ql_titles(l_count) := l_name;
end if;

if l_count = 2 OR l_count2 = l_max then

	Show_Quicklink_Row(ql_titles, ql_markers);

l_count := 0;

end if;

l_count := l_count +1;
l_count2 := l_count2 +1;

end loop;

l_count := 0;

End_Table;



tag('MRC SOBs Assigned');
BRPRINT;


--Display All MRC Reporting Sets of Books assigned this Primary Sets of Books

sqlTxt :=   'SELECT gl1.name "PRIMARY SET OF BOOKS", glmc.primary_set_of_books_id, '||	
 ' DECODE (gl1.mrc_sob_type_code,''N'',''N/A'', '||	
 '                                 ''P'',''Primary'', '||	
 '                                 ''R'',''Reporting'') sob_type, '||	
 '       gl2.name "REPORTING SET OF BOOKS", glmc.reporting_set_of_books_id, '||	
 '       DECODE (gl2.mrc_sob_type_code,''N'',''N/A'', '||	
 '                                 ''P'',''Primary'', '||	
 '                                 ''R'',''Reporting'') sob_type '||	
 '  FROM gl_mc_book_assignments glmc, '||	
 '       gl_sets_of_books gl1, '||	
 '       gl_sets_of_books gl2 '||	
 ' WHERE gl1.set_of_books_id = glmc.primary_set_of_books_id '||	
 '   and gl2.set_of_books_id = glmc.reporting_set_of_books_id '||	
 '   and gl1.set_of_books_id = &v_sob_id '||	
 'order by glmc.primary_set_of_books_id';	


l_count := 0;

l_count := Run_SQL('All MRC Reporting Sets of Books assigned this Primary Sets of Books', sqltxt);




--Display All Organizations assigned this set of books id for Payables
tag('Orgs Assigned');
BRPRINT;


sqlTxt := 'select asp.org_id, hou.name,  '||	
 'substr(gl.set_of_books_id,1,3) SOB,  '||	
 'substr(gl.name,1,25) Name '||	
 'from ap_system_parameters_all asp,  '||	
 'gl_sets_of_books gl, hr_operating_units hou '||	
 'where asp.set_of_books_id = to_char(''&v_sob_id'') '||	
 'and asp.set_of_books_id = gl.set_of_books_id '||	
 'and hou.organization_id(+) = nvl(asp.org_id,-99)';	

l_count := 0;

l_count := Run_SQL('All Organizations assigned this set of books id for Payables', sqltxt);

tab0print('==================================================================================');

BRPRINT;

--Period Status and date ranges by Application_ID

tag('Period Status');
BRPRINT;



sqlTxt := 'SELECT rpad(substr(application_short_name,-2,2),11,'' '') Application, '||	
 'gl.APPLICATION_ID app_id,gl.SET_OF_BOOKS_ID SOB_ID,  '||	
 'rpad(gl.CLOSING_STATUS,6,'' '') Status,gl.PERIOD_NUM, '||	
 'gl.PERIOD_YEAR,gl.PERIOD_NAME,gl.START_DATE,  '||	
 'gl.END_DATE, gl.ADJUSTMENT_PERIOD_FLAG '||	
 'FROM  '||	
 'GL_PERIOD_STATUSES gl, fnd_application fnd '||	
 ' WHERE fnd.application_id = gl.application_id '||	
 'and gl.application_id in (101,200,201)' ||
' and gl.set_of_books_id = '||l_sob_id ||	
' and period_name = '''||l_period_name||'''';

l_count := 0;

l_count := Run_SQL('Period Status and date ranges by Application_ID',sqltxt);


BRPRINT;	

-- This loop, will loop through each reporting SOB assigned to the SOB entered. 

FOR mrc in rsob LOOP		--BEGIN MRC LOOP 

l_org_id := mrc.org_id;
l_set_of_books_id := mrc.sob_id;

dbms_application_info.set_client_info(l_org_id);

l_name := mrc.sob_type||'_Set of Books:_'||mrc.sob_name||'_(ID='||mrc.sob_id||')_Organization:_'||mrc.hr_name||' (ID='||mrc.org_id||')';

l_name := replace(l_name, ' ', '_');


tag(l_name);
tab0print('_____________________________________________________________________________________________________________');

sectionprint(l_name);

--BRPRINT;

--Display UnAccounted_Invoices
tag('UnAccounted_Invoices');
--BRPRINT;



sqlTxt := 'select distinct ai.invoice_id,  '||	
 'aid.accounting_date, ai.vendor_name,  '||	
 'ai.invoice_date,  '||	
 'ai.invoice_amount, ai.invoice_num, '||	
 'aid.period_name, aid.posted_flag,  '||	
 'aid.org_id, aid.set_of_books_id  '||	
 'from  '||	
 'ap_invoice_distributions aid, '||	
 'ap_invoices_v ai '||	
 'where aid.period_name = ''' ||l_period_name|| 	
 ''' and aid.posted_flag <> ''Y'' '||	
 'and aid.set_of_books_id = '||l_sob_id||	
 ' and ai.invoice_id = aid.invoice_id '||
'and rownum < 101'||
 ' order by ai.invoice_id';

l_count := 0;

sectionprint('UnAccounted_Invoices');
l_count := Run_SQL('',sqltxt);


	If l_count = 0 THEN
		BRPRINT;
		line_out('This Org_ID does not have any unaccounted invoice distributions for this SOB.');
	Else 
		BRPRINT;

	     ErrorPrint('This Org_Id has '||l_count||' Invoices with unaccounted distributions for this SOB All Invoice Distributions must be accounted and transferred before this period can be closed.');
	     ActionErrorPrint('Run the Payables Accounting Process to account and transfer these distributions');

		BRPRINT;
		line_out('Note: The list above only displays the first 100 records.');

	end if;


BRPRINT;

--Display UnAccounted_Payments
tag('UnAccounted_Payments');
BRPRINT;

       
sqlTxt := 'select distinct aip.accounting_date, ai.vendor_name,   '||	
 'ac.amount check_amount, '||	
 'ac.check_id, ac.check_number,  '||	
 'ac.amount, ac.check_date, '||	
 'aip.period_name, aip.posted_flag,  '||	
 'aip.org_id, aip.set_of_books_id  '||	
 'from  '||	
 'ap_invoice_payments aip, '||	
 'ap_invoices_v ai, '||	
 'ap_checks ac '||	
 'where aip.period_name = '''||l_period_name||	
 ''' and aip.posted_flag <> ''Y'' '||	
 'and aip.set_of_books_id = '||l_sob_id||	
 ' and ac.check_id = aip.check_id '||	
 'and ai.invoice_id = aip.invoice_id '||	
 'and rownum < 101'||
 'order by ac.check_id';	

l_count := 0;
sectionprint('UnAccounted_Payments');
l_count := Run_SQL('',sqltxt);

	If l_count = 0 THEN
	BRPRINT;
	line_out('This Org_ID does not have any UnAccounted_Payments for this SOB.');
	Else BRPRINT;
	     ErrorPrint('This Org_Id has '||l_count||' UnAccounted_Payments for this SOB. All Payments must be accounted and transferred before this period can be closed.');
	     ActionErrorPrint('Run the Payables Accounting Process to account and transfer these payments.');

		BRPRINT;
		line_out('Note: The list above only displays the first 100 records.');

	end if;


BRPRINT;


--Display Not Accounted ClearingTransactions
tag('UnAccounted_Clearing_Transactions');
BRPRINT;



sqlTxt := 'select distinct aip.accounting_date, ai.vendor_name,   '||	
 'ac.amount check_amount, '||	
 'ac.check_id, ac.check_number,  '||	
 'ac.amount, ac.check_date, '||	
 'aip.period_name, aip.posted_flag,  '||	
 'aip.org_id, aip.set_of_books_id  '||	
 'from  '||	
 'ap_invoice_payments aip, '||	
 'ap_invoices_v ai, '||	
 'ap_checks ac, '||	
 'ap_payment_history aph, '||	
 '(select start_date, end_date  '||	
 'from gl_period_statuses '||	
 'where period_name = '''||l_period_name||	
 ''' and application_id = 200 and set_of_books_id = '||l_sob_id||') range '||	
 'where aph.posted_flag <> ''Y'' '||	
 'and aph.check_id = ac.check_id '||	
 'and aip.set_of_books_id = '||l_sob_id||
 ' and ac.check_id = aip.check_id '||	
 'and ai.invoice_id = aip.invoice_id '||	
 'and aph.accounting_date between range.start_date and range.end_date '||	
 'and rownum < 101'||
 'order by ac.check_id';	

l_count := 0;
sectionprint('UnAccounted_Clearing_Transactions');
l_count := Run_SQL('',sqltxt);

	If l_count = 0 THEN
	BRPRINT;
	line_out('This Org_ID does not have any Not Accounted ClearingTransactions for this SOB.');
	Else BRPRINT;
	     ErrorPrint('This Org_Id has Not Accounted ClearingTransactions for this SOB. All Clearing Transactions must be accounted and transferred before this period can be closed.');
	     ActionErrorPrint('Run the Payables Accounting Process to account and transfer these payments.');
	end if;


BRPRINT;

--Display UnTransferred Journal Entries
tag('UnTransferred JEs');
BRPRINT;



sqlTxt := 'select distinct  '||	
 'aeh.accounting_event_id, '||	
 'aeh.accounting_date, '||	
 'aeh.org_id, '||	
 'aeh.PERIOD_NAME, '||	
 'aeh.gl_transfer_flag, '||	
 'aeh.set_of_books_id, '||	
 'aeh.accounting_error_code, '||	
 'ael.accounting_error_code, '||	
 'ael.ae_header_id, '||	
 'ael.reference1 Supplier_Name, '||	
 'decode(aea2.source_table, ''AP_INVOICES'', aea2.invoice_num, null) invoice_num, '||	
 'decode(aea2.source_table,''AP_CHECKS'', aea2.check_number, '||	
 '                                        ''AP_PAYMENT_HISTORY'', aea2.check_number, null) check_number2 '||	
 'from ap_ae_lines ael, ap_ae_headers aeh, '||	
 '(select aea.accounting_event_id, ai.invoice_num, ac.check_number, aea.source_table, ac.check_id '||	
 'from ap_accounting_events aea, ap_invoices ai, ap_checks ac, ap_invoice_Payments_all aip '||	
 'where ( '||	
 '   (aea.source_table = ''AP_INVOICES'' and aea.source_id = ai.invoice_id) '||	
 'or (aea.source_table in (''AP_CHECKS'', ''AP_PAYMENT_HISTORY'') and aea.source_id = ac.check_id) '||	
 '     ) '||	
 'and ai.invoice_id = aip.invoice_id(+) '||	
 'and aip.check_id = ac.check_id(+) '||	
 ') aea2 '||	
 'where aeh.gl_transfer_flag <> ''Y'' '||	
 'and aeh.ae_header_id = ael.ae_header_id(+) '||	
 'and aeh.period_name = '''||l_period_name||	
 ''' and aeh.accounting_event_id = aea2.accounting_event_id(+) '||	
 'and aeh.set_of_books_id = '|| l_sob_id ||	
 'and rownum < 101'||
 'order by ael.ae_header_id';	

l_count := 0;
sectionprint('UnTransferred Journal Entries');
l_count := Run_SQL('',sqltxt);

	If l_count = 0 THEN
	BRPRINT;
	line_out('This Org_ID does not have any untransferred Journal Entries for this SOB.');
	Else BRPRINT;
	     ErrorPrint('This Org_Id has '||l_count||' untransferred Journals for this SOB. All Journal Entries must be transferred before this period can be closed.');
	     ActionErrorPrint('Run the Payables Transfer to GL Process to transfer these Journal Entries.');

		BRPRINT;
		line_out('Note: The list above only displays the first 100 records.');

	end if;


BRPRINT;

--Display Unconfirmed Payment Batches
tag('Unconfirmed Paybatches');
BRPRINT;



sqlTxt := 'select ais.checkrun_name, ais.org_id,  '||	
 'ais.status, asp.set_of_books_id '||	
 'from ap_invoice_selection_criteria ais,  '||	
 'ap_system_parameters asp '||	
 'where STATUS NOT IN (''CONFIRMED'',''CANCELED'',''QUICKCHECK'' ) '||	
 'and period_name = '''||l_period_name||	
 ''' and nvl(asp.org_id,-99) = nvl(ais.org_id,-99) '||	
 'and asp.set_of_books_id = '||l_sob_id||	
 'and rownum < 101'||
 'order by ais.checkrun_name';	


l_count := 0;
sectionprint('Unconfirmed Payment Batches');
l_count := Run_SQL('',sqltxt);


	If l_count = 0 THEN
	BRPRINT;
	line_out('This Org_ID does not have any unconfirmed Payment Batches for this SOB.');
	Else BRPRINT;
	     ErrorPrint('This Org_Id has has unconfirmed Payment Batches for this SOB. All Payment Batches for this period must be Confirmed or Cancelled before this period can be closed.');
	     ActionErrorPrint('Confirm or Cancel the unconfirmed Payment Batches for this period.');
	end if;


BRPRINT;

--Display Matured Future Dated Payments
tag('Matured Future Dated Payments');
BRPRINT;



sqlTxt := 'SELECT c.check_id, c.check_number, org_id,  '||	
 'range.set_of_books_id, c.vendor_name, c.amount, '||	
 'c.future_pay_due_date, c.status_lookup_code '||	
 'FROM AP_CHECKS C, '||	
 '(select start_date, end_date, set_of_books_id  '||	
 'from gl_period_statuses '||	
 'where period_name = '''||l_period_name||	
 ''' and application_id = 200 and set_of_books_id = '||l_sob_id||') range '||	
 'WHERE C.FUTURE_PAY_DUE_DATE IS NOT NULL '||	
 'AND  C.STATUS_LOOKUP_CODE = ''ISSUED''   '||	
 'AND  range.set_of_books_id = '||l_sob_id||	
 'AND C.FUTURE_PAY_DUE_DATE between range.start_date and range.end_date '||	
 'and rownum < 101'||
 'order by c.check_id';


l_count := 0;
sectionprint('Matured Future Dated Payments');
l_count := Run_SQL('',sqltxt);

	If l_count = 0 THEN
	BRPRINT;
	line_out('This Org_ID does not have any Matured Futured Dated Payments for this SOB that still have a status of ISSUED.');
	Else BRPRINT;
	     ErrorPrint('This Org_Id has has Matured Future Dated Payments for this SOB that still have a status of ISSUED.');
	     ActionErrorPrint('Submit the Update Matured Future Dated Payment Status Program.');
	end if;


BRPRINT;

END LOOP;		--END MRC LOOP

  exception 

when l_exception then

brprint;

when others then -- exception section (block 3) for script code
    BRPrint;
    ErrorPrint(sqlerrm ||' occurred in the Diagnostic Test');
    ActionErrorPrint('Please report the above error (for block 3) to Oracle Support Services.');
    BRPrint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo');
    BRPrint;
  end;  -- end (block 3), script code 

    --  -------------------- Feedback ---------------------------- 
    BRPrint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo');
    
  -- -------------------- Script Exception Section ------------------------- 

exception

when others then -- exception section (block 2) for script code
    BRPrint;
    ErrorPrint(sqlerrm ||' occurred in the Diagnostic Test');
    ActionErrorPrint('Please report the above error (for block 2) to Oracle Support Services.');
    BRPrint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo');
    BRPrint;
  end;  -- end (block 2), script code 

exception

when others then   -- exceptions (block 1) for API and template code
  BRPrint;
  ErrorPrint(sqlerrm ||' occurred in the Diagnostic Test');
  ActionErrorPrint('Please report the above error (for block 1) to Oracle Support Services.');
  BRPrint;
  Show_Footer('&v_scriptlongname', '&v_headerinfo');
  BRPrint;
end;  -- end (block 1), API and template code 
/



REM  ==============SQL PLUS Environment setup===================
Spool off
set term on


PROMPT
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================