================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract:               Test to Check why a period cannot be closed
================================================================================
PRODUCT:                Accounts Payable (AP)
SUBCOMPONENT:           CLOSING
PRODUCT VERSIONS:       11.5.x
PLATFORM:               All Platforms
DATE CREATED:           14-NOV-2002
PARAMETERS:             Applicaton User Name, Responsibility_id, Period Name, 
  			Set of Books id

================================================================================
Instructions
================================================================================
Included Files:

	APClosing115h.sql (HTML version)
	APClosing115t.sql (Text version)
	APClosing115_readme.txt
	APClosing115_readme.html
	APClosing115h_Sample_Output.html
	CoreApiTxt.sql
	CoreApiHtml.sql

Execution Environment::

	SQL*Plus

Access Privileges:

	Requires APPS user access
	
Usage:
	
	sqlplus apps/password @APClosing115h.sql (HTML version)

	sqlplus apps/password @APClosing115t.sql (Text version)

	

Instructions: 
	
The files should be unzipped to a common directory. 

For HTML output (recommended), run the file APClosing115h.sql in SQL*Plus in the APPS schema.  
Follow the prompts and enter the requested information. The test will create an output file 
in html format named APClosing115h_<Set of Books ID>_<Period Name>_diag.html. Open the file 
in your browser and review the output.

For Text output, run the file APClosing115t.sql in SQL*Plus in the APPS schema.  
Follow the prompts and enter the requested information. The test will create an output file 
in Text format named APClosing115t_<Set of Books ID>_<Period Name>_diag.txt. 
Open the file in a Text editor and review the output.

Note:  The HTML version of this test is incompatible with the UTF8 NLS Character Set for RDBMS 
version 8.1.7.3 or lower. Please run the Text version of this test, if you have UTF8 and RDMBS 
version 8.1.7.3 or lower.


=======================================================================================================================
Test Description
=======================================================================================================================
This test will detect and report common problems that prevent a period from being closed.  

This test displays transactions in the Primary Set of Books (PSOB) and Reporting 
Set of Books (RSOB) tied to the PSOB entered that will prevent the period from closing.
It also displays transactions in other org's using this PSOB with transactions that will prevent 
the period from being closed. 

It provides details for all of the problems that prevent a period from being closed, such as:

Unaccounted Invoices.
Unaccounted Payments
Untransfered Journal Entries
Unconfirmed Payment Batch exists for period
Future Dated payments

The test includes information, such as:  Invoice Number and Check number and actions referring 
clients to notes and user guide references to assist them in fixing closing issues.  

================================================================================
References
================================================================================
Oracle Payables Users Guide


================================================================================
Disclaimer
================================================================================
Except where expressly provided otherwise, the information, software, provided 
on an "AS IS" and "AS AVAILABLE" basis. Oracle expressly disclaims all 
warranties of any kind, whether express or implied, including, but not limited 
to, the implied warranties of merchantability, fitness for a particular purpose 
and non-infringement.  Oracle makes no warranty that: (A) the results that may 
be obtained from the use of the software will be accurate or reliable; or (B) 
the information, or other material obtained will meet your expectations.  Any 
content, materials, information or software downloaded or otherwise obtained is 
done at your own discretion and risk.  Oracle shall have no responsibility for 
any damage to your computer system or loss of data that results from the 
download of any content, materials, information or software.

Oracle reserves the right to make changes or updates to the software at any time
without notice.

================================================================================
Limitation of Liability
================================================================================
In no event shall Oracle be liable for any direct, indirect, incidental, special
or consequential damages, or damages for loss of profits, revenue, data or use, 
incurred by you or any third party, whether in an action in contract or tort, 
arising from your access to, or use of, the software.

Some jurisdictions do not allow the limitation or exclusion of liability.
Accordingly, some of the above limitations may not apply to you.
