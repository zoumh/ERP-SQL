undefine v_headerinfo
Define   v_headerinfo     = '$Header: ARCheckSetup115.sql 1.13 06-OCT-2003 support $'
undefine v_scriptlongname
Define   v_scriptlongname = ' Receivables General Setup Diagnostic Test'

REM   =================================================================================== 
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA 
REM   Oracle Support Services.  All rights reserved. 
REM   ===================================================================================
REM   PURPOSE:                AR - Check Setup   
REM   PRODUCT:                Accounts Receivable (AR)    
REM   PRODUCT VERSIONS:       11.5.2 +
REM   PLATFORM:               GENERIC
REM   PARAMETERS              1. Apps username
REM                           2. Responsibility to be chosen from list 
REM                                 
REM   ===================================================================================

REM   ===================================================================================
REM   USAGE:                  sqlplus apps/apps@appsdb 
REM                           @ARCheckSetup115 
REM   EXAMPLE:  
REM   OUTPUT:                 ARCheckSetup115_[responsibility_id]_diag.html 
REM   =================================================================================== 

REM   ===================================================================================
REM   CHANGE HISTORY: 
REM   DATE	01-AUG-2002       Created     Igovaert
REM   DATE	03-MAR-2003       Modified    Igovaert   
REM         Bug Fix Location Based TAX Code :
REM           check has been revised 
REM         Bug Fix System options :
REM           changed SQL to work for Single Org 
REM         Autoaccounting : 
REM           added checks for Bill Receivables   
REM         Error Messages : 
REM           Improvements
REM         Profile Options :
REM           Improved Error, Warning Reporting with new version of API 
REM   DATE  07-MAY-2003        Modified    Igovaert
REM         Bug Fix - Performance Issue :
REM           New SQL-statement to count customers with active bill-to sites 
REM   DATE  20-JUN-2003        Modified    Igovaert
REM         Fix BUG 3013111 
REM           Location Tax code message changed from error to warning     
REM   DATE  01-AUG-2003        Modified    Igovaert 
REM         added checks related with customers
REM           Statements, Dunning Letters, Pricelists, customer Quickcodes 
REM   DATE  18-AUG-2003        Modified    FQA
REM         Final QA changed title to match catalog title
REM   DATE  01-OCT-2003        Modified    Igovaert
REM         Modified Account Generator SQL ( under Application Set Up ) 
REM         Added WHEN Others exception where missing to avoid undesired fatal exceptions  
REM   DATE  06-OCT-2003        Modified    Igovaert
REM         Bug Fix In Profile Options reporting 
REM           Profile options need to be shown on level of user, resp, app and site 
REM   ===================================================================================   

REM   ==============SQL PLUS Environment setup===========================================

set serveroutput on size 1000000 
set verify off 
set echo off
set autoprint off
set termout on 
set feedback off

REM ============== Define SQL Variables for input parameters ============================
VARIABLE    v_username       VARCHAR2(100); 
Undefine    Application_user_name
VARIABLE    v_abort          VARCHAR2(1); 

REM =========================Validate DATABASE Version =========================================
REM ======================NOTE - This section only needed for tests using HTML API's============

DECLARE 
  l_version           VARCHAR2(30);
BEGIN 

  SELECT MAX(version)
  INTO   l_version
  FROM   v$instance;

  IF l_version < '8.1.6.0.0' THEN 
     DBMS_OUTPUT.PUT_LINE(chr(10));
     DBMS_OUTPUT.PUT_LINE('ERROR - Invalid Database Version '||l_version || '. The test requires RDBMS version 8.1.6 or higher');
     DBMS_OUTPUT.PUT_LINE('ACTION - Type Ctrl-C <Enter> to exit the test.');
     DBMS_OUTPUT.PUT_LINE(chr(10));
  END IF;

EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - Database Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM =========================Validate SQL*Plus Version Character Set Combination=================
REM ======================NOTE - This section only needed for tests using HTML API's=============

DECLARE
  l_nls_characterset    nls_database_parameters.value%TYPE;
  l_sql_release_int     INTEGER(20) :=  to_number('&_SQLPLUS_RELEASE');
  l_sql_release_chr     VARCHAR2(50) := '&_SQLPLUS_RELEASE';

BEGIN

  SELECT value 
  INTO  l_nls_characterset
  FROM  nls_database_parameters
  WHERE parameter = 'NLS_CHARACTERSET';
    
  FOR i IN 1..4 LOOP
    l_sql_release_chr := substr(l_sql_release_chr,1,(2*i)-1)||'.'||
      substr(l_sql_release_chr,(2*i)+1);
  END LOOP;
  
  IF l_nls_characterset LIKE 'UTF%' THEN
     IF l_sql_release_int IS null THEN 
        DBMS_OUTPUT.PUT_LINE(chr(10));
        DBMS_OUTPUT.PUT_LINE('ATTENTION - Cannot determine version of SQL*plus being used for test run.');
        DBMS_OUTPUT.PUT_LINE('.           This test may fail if not run using a version 8.1.X of SQL*plus or higher.');
        DBMS_OUTPUT.PUT_LINE('Attempting to run the test.......');
        DBMS_OUTPUT.PUT_LINE(chr(10));
     ELSIF l_sql_release_int < 801000000 THEN
        DBMS_OUTPUT.PUT_LINE(chr(10));
        DBMS_OUTPUT.PUT_LINE('ERROR - Invalid SQL*plus Version '||l_sql_release_chr);
        DBMS_OUTPUT.PUT_LINE('ACTION - On databases using the '||l_nls_characterset||' NLS characterset this test should not be run using this ');
        DBMS_OUTPUT.PUT_LINE('.        SQL*plus Version.  Please rerun this test using version 8.1.X of SQL*plus or higher.');
        DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
        DBMS_OUTPUT.PUT_LINE(chr(10));
     END IF;
  END IF;
EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - SQL*plus Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM ================ Show responsibilities assigned to given user ===================== 
DECLARE   
  l_applversion   fnd_product_groups.release_name%type;
  l_counter       integer;
  l_cursor        integer;
  sqltxt          varchar2(3000);
  l_resp_id       integer;
  l_resp_name     varchar2(300);  
BEGIN
  :v_abort    := 'N';

  select nvl(rtrim(ltrim(upper('&Application_user_name'))), '<Null username>')
  into :v_username
  from dual;

  select substr(release_name,1,4)  
  into   l_applversion 
  from   fnd_product_groups;

  IF l_applversion = '11.5' then
     BEGIN 
       sqltxt := 'select to_char(a.responsibility_id) id, '||
                 '       b.responsibility_name name '||
                 'from   fnd_user_resp_groups a, '||
                 '       fnd_responsibility_vl b, '||
                 '       fnd_user u '||
                 'where  a.user_id = u.user_id '||
                 'and    a.responsibility_id = b.responsibility_id '||
                 'and    a.responsibility_application_id = b.application_id '||
                 'and    sysdate between '|| 
                 '          a.start_date and nvl(a.end_date,sysdate+1) '||
                 'and    upper(u.user_name) = '''||:v_username||''''||
                 'order  by b.responsibility_name';
     

       DBMS_OUTPUT.PUT_LINE(chr(9));
       DBMS_OUTPUT.PUT_LINE('Following are the Responsibilities assigned to User:  '|| :v_username );
       DBMS_OUTPUT.PUT_LINE('=================================================================');

       l_cursor := dbms_sql.open_cursor;
       dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
       dbms_sql.define_column(l_cursor, 1, l_resp_id);
       dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
       l_counter := dbms_sql.execute(l_cursor);
       l_counter := 0; 

       WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
             l_counter := l_counter + 1;
             dbms_sql.column_value(l_cursor, 1, l_resp_id);
             dbms_sql.column_value(l_cursor, 2, l_resp_name);
             DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
       END LOOP; 
       DBMS_OUTPUT.PUT_LINE(chr(9));

       IF l_counter = 0 then
          raise no_data_found;
       END IF;   
       dbms_sql.close_cursor(l_cursor);
  
     EXCEPTION
     when NO_DATA_FOUND then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
       DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.' || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the diagnostic test.  Rerun the test with a valid user name.' || chr(10));
     when OTHERS then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error: '|| sqlerrm);
       DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the diagnostic test.'  || chr(10) );
     END; 
  ELSE  -- apps version is not 11.5
     DBMS_OUTPUT.PUT_LINE('ERROR  - This diagnostic test is not designed to run against version '|| l_applversion ||' of applications');
     DBMS_OUTPUT.PUT_LINE('ACTION - Please run the test against an 11I instance'  || chr(10) ||
                          '         Type Ctrl-C <Enter> to exit the diagnostic test'  || chr(10) );
  END IF; 

END; 
/
 
REM ===================== Accept Responsibility ====================================

PROMPT 
undefine v_respid
accept   v_respid number PROMPT  'Please choose a Responsibility ID from the list : '
define   v_respidc = &v_respid    

PROMPT
PROMPT  

REM ===================== Spooling the output file ========================================== 

Define   v_spoolfilename  = 'ARCheckSetup115_&v_respidc._diag.html'

PROMPT  =======================================================================
PROMPT  Output will be spooled to &v_spoolfilename
PROMPT  =======================================================================
PROMPT 
PROMPT Running..... 
spool  &v_spoolfilename

set    termout off

REM ============================== Run the Pl/SQL api file ================================== 
@@CoreApiHtml.sql

/*------------------------- Start Of the Main Program ( Part 1 ) -----------------------------*/

BEGIN  -- begin 1
  DECLARE -- declare 2 
    p_username     varchar2(100);   
    p_respid       number;
    
    v_respname     varchar2(100)   := NULL;
    v_appid        number          := 0;
    v_ar_status    varchar2(50)    := NULL;
    v_patch_level  varchar2(30)    := NULL;   
    v_orgid        varchar2(15);
    v_orgname      varchar2(60)    := null;    
    v_mrc_flag     varchar2(1)     := null;
    v_multi_org    varchar2(1)     := null;

    v_sobid        number;
    v_sobname      varchar2(30);

    l_count        number  := 0;
    sqltxt         varchar2(32767);
    l_counter      integer;
    l_cursor       integer; 

    STOPEXECUTION  exception;

  BEGIN  -- begin2 

/* ----------------------------- Set Client ( validate user and responsibility ) -----------------------*/
      
    Show_Header('202260.1', '&v_scriptlongname' ); 

    p_username := :v_username;
  
    IF &v_respid IS Null THEN
       p_respid := -10;     
    ELSE        
       p_respid := TO_NUMBER(&v_respid);
    END IF; 

    Set_Client(p_username, p_respid);

    -- pick up responsibility name and application id assigned to this responsibility
    BEGIN 
      SELECT responsibility_name,
             application_id 
      INTO   v_respname,
             v_appid 
      FROM   fnd_responsibility_vl b
      WHERE  b.responsibility_id = p_respid;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Null;
    END; 

    SectionPrint('Parameters');
    Tab1Print('Username         = '|| upper(:v_username)); 
    Tab1Print('Responsibility   = '|| v_respname || ' ( ID = ' || &v_respid || ' )');

    IF v_appid <> 222 THEN 
       ErrorPrint('This diagnostic test checks the Oracle Receivables set up. The entered responsibility is not '||
                  'for the application being tested');
       ActionErrorPrint('Please run the test for an Oracle Receivables responsibility');
       RAISE StopExecution;
    END IF;   

/* ---------------------------------- Application information  -------------------------------------------- */ 
 
    SectionPrint('Application Information');
    
    -- pick up installation status of AR 
    BEGIN 
      SELECT   DECODE(status, 'I','INSTALLED', 
                              'N','NOT INSTALLED', 
                              'L','CUSTOM', 
                              'S','SHARED', status )     status,
               patch_level     
      INTO     v_ar_status,
               v_patch_level  
      FROM     FND_PRODUCT_INSTALLATIONS  
      WHERE    application_id = 222;
    EXCEPTION 
      WHEN OTHERS THEN 
           null;
    END;  

    v_orgid   := Get_profile_option('ORG_ID');

    -- pick up orgname 
    IF v_orgid is NOT NULL THEN 
       BEGIN -- Level 4
         SELECT  name 
         INTO    v_orgname 
         FROM    HR_ALL_ORGANIZATION_UNITS
         WHERE   organization_id = v_orgid; 
       EXCEPTION
           WHEN NO_DATA_FOUND then NULL;
       END; -- level 4
    END IF; 

    -- pick up multi currency and multi org flag 
    BEGIN 
      SELECT multi_currency_flag,
             multi_org_flag  
      INTO   v_mrc_flag,
             v_multi_org  
      FROM   fnd_product_groups;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Null;
      WHEN TOO_MANY_ROWS THEN
           Errorprint('More than one row ( more than one installation ) was found in FND_PRODUCT_GROUPS');
           ActionErrorPrint('Check the installtion of Oracle Applications on this instance. Execution of the test will stop');
           RAISE StopExecution;
    END; 

    Tab1Print('MultiOrg Flag = '|| v_multi_org );
    Tab1Print('MultiCurrency Flag = '|| v_mrc_flag );
    Tab1Print('Application is Oracle Receivables (ID = 222) and has an install status = '||
                 v_ar_status );   
    Tab1Print('AR Patch Level = '|| v_patch_level );
    Tab1Print('MO: Operating Unit = ' || v_orgid );
    Tab1Print('Set Up validation will be done for Operating Unit "'||v_orgname ||'"'  );      

/* ------------------------- Application information, Related Products -------------------------- */ 
 
    DECLARE  
      CURSOR C1 IS
        SELECT   a.application_id ,   
                 substr(a.application_name,1,25)    appsname, 
                 DECODE(p.status,'I','INSTALLED', 
                                 'N','NOT INSTALLED', 
                                 'L','CUSTOM', 
                                 'S','SHARED', status )       status,
                 DECODE(a.application_id, 101, 1, 660,  2, 673, 3, 260, 4, 
                                          275, 5, 8901, 6, 170, 7, 283, 8, 9 ) seq
        FROM     FND_APPLICATION_ALL_VIEW a, 
                 FND_PRODUCT_INSTALLATIONS p 
        WHERE    a.application_id = p.application_id
        AND      a.application_id in (101,260,283,170,8901,673,660,275) 
        ORDER BY seq ;
    BEGIN 
      SectionPrint('Related Products Installation Status');
      l_count := 0;
      FOR c1_rec IN c1 LOOP 
          Tab1Print( c1_rec.appsname || ' = ' || c1_rec.status );
          l_count := l_count + 1;
      END LOOP;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Related Products Installation Status" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;  

/* ------------------------------------ 	AR System Options  ------------------------------------------------ */ 

    DECLARE  -- level 3
      -- declare workfields for AR_system_parameters 
      t_default_grouping_rule_id         NUMBER(15)  := NULL;     
      t_salesrep_required_flag           VARCHAR2(1) := NULL;
      t_auto_rec_inv_per_commit          NUMBER(8)   := NULL;
      t_auto_rec_rec_per_commit          NUMBER(8)   := NULL;
      t_pay_unrelated_invoices_flag      VARCHAR2(1) := NULL;
      t_print_home_country_flag          VARCHAR2(1) := NULL;
      t_location_tax_account             NUMBER(15)  := NULL;
      t_from_postal_code                 VARCHAR2(60):= NULL;
      t_to_postal_code                   VARCHAR2(60):= NULL;
      t_tax_registration_number          VARCHAR2(60):= NULL;
      t_populate_gl_segments_flag        VARCHAR2(1) := NULL;
      t_unallocated_revenue_ccid         NUMBER(15)  := NULL;
      t_orgname                          VARCHAR2(60):= NULL; 
      t_calc_discount_on_lines_flag      VARCHAR2(1) := NULL;
      t_change_printed_invoice_flag      VARCHAR2(1) := NULL;
      t_code_combination_id_loss         NUMBER(15)  := NULL;
      t_create_reciprocal_flag           VARCHAR2(1) := NULL;
      t_default_country                  VARCHAR2(60):= NULL;
      t_default_territory                VARCHAR2(30):= NULL;
      t_generate_customer_number         VARCHAR2(1) := NULL;
      t_invoice_deletion_flag            VARCHAR2(1) := NULL;
      t_id_flex_structure_name           VARCHAR2(30):= NULL;
      t_site_required_flag               VARCHAR2(1) := NULL;
      t_tax_allow_compound_flag          VARCHAR2(1) := NULL;
      t_tax_invoice_print                VARCHAR2(30):= NULL;
      t_tax_method                       VARCHAR2(30):= NULL;
      t_tax_use_customer_exempt_flag     VARCHAR2(1) := NULL;
      t_tax_use_cust_exc_rate_flag       VARCHAR2(1) := NULL;
      t_tax_use_loc_exc_rate_flag        VARCHAR2(1) := NULL;
      t_tax_use_product_exempt_flag      VARCHAR2(1) := NULL;
      t_tax_use_prod_exc_rate_flag       VARCHAR2(1) := NULL;
      t_tax_use_site_exc_rate_flag       VARCHAR2(1) := NULL;
      t_ai_log_file_message_level        NUMBER(15)  := NULL;
      t_ai_max_memory_in_bytes           NUMBER(15)  := NULL;
      t_ai_acct_flex_key_left_prompt     VARCHAR2(80):= NULL;
      t_ai_mtl_items_key_left_prompt     VARCHAR2(80):= NULL;
      t_ai_territory_key_left_prompt     VARCHAR2(80):= NULL;
      t_ai_purge_interface_tab_flag      VARCHAR2(1) := NULL;
      t_ai_activate_sql_trace_flag       VARCHAR2(1) := NULL;
      t_set_of_books_id                  NUMBER(15)  := NULL;
      t_created_by                       NUMBER(15)  := NULL;
      t_creation_date                    DATE := NULL;
      t_last_updated_by                  NUMBER(15)  := NULL;
      t_last_update_date                 DATE := NULL;
      t_last_update_login                NUMBER(15)  := NULL;
      t_accounting_method                VARCHAR2(30):= NULL;
      t_accrue_interest                  VARCHAR2(1) := NULL;
      t_unearned_discount                VARCHAR2(1) := NULL;
      t_partial_discount_flag            VARCHAR2(1) := NULL;
      t_print_remit_to                   VARCHAR2(1) := NULL;
      t_default_cb_due_date              VARCHAR2(30):= NULL;
      t_auto_site_numbering              VARCHAR2(1) := NULL;
      t_cash_basis_set_of_books_id       NUMBER(15)  := NULL;
      t_code_combination_id_gain         NUMBER(15)  := NULL;
      t_autocash_hierarchy_id            NUMBER(15)  := NULL;
      t_run_gl_journal_import_flag       VARCHAR2(1) := NULL;
      t_cer_split_amount                 NUMBER(9)   := NULL;
      t_cer_dso_days                     NUMBER(5)   := NULL;
      t_posting_days_per_cycle           NUMBER(5)   := NULL;
      t_address_validation               VARCHAR2(30):= NULL;
      t_tax_code                         VARCHAR2(50):= NULL;
      t_tax_currency_code                VARCHAR2(15):= NULL;
      t_tax_header_level_flag            VARCHAR2(6) := NULL;
      t_tax_minimum_accountable_unit     NUMBER      := NULL;    
      t_tax_precision                    NUMBER(1)   := NULL;
      t_tax_rounding_rule                VARCHAR2(30):= NULL;
      t_tax_rounding_allow_override      VARCHAR2(1) := NULL;
      t_rule_set_id                      NUMBER      := NULL;
      t_tax_use_account_exc_rate_flg     VARCHAR2(1) := NULL;
      t_tax_use_system_exc_rate_flag     VARCHAR2(1) := NULL;
      t_tax_hier_site_exc_rate           VARCHAR2(15):= NULL;
      t_tax_hier_cust_exc_rate           VARCHAR2(15):= NULL;
      t_tax_hier_prod_exc_rate           VARCHAR2(15):= NULL;
      t_tax_hier_account_exc_rate        VARCHAR2(15):= NULL;
      t_tax_hier_system_exc_rate         VARCHAR2(15):= NULL;
      t_tax_enforce_account_flag         VARCHAR2(1) := NULL;
      t_tax_database_view_set            VARCHAR2(30):= NULL;
      t_inclusive_tax_used               VARCHAR2(1) := NULL;
      t_code_combination_id_round        NUMBER(15)  := NULL;
      t_trx_header_level_rounding        VARCHAR2(1) := NULL;
      t_trx_header_round_ccid            NUMBER(15)  := NULL;
      t_trxname                          VARCHAR2(50):= NULL;
      t_sales_tax_geocode                VARCHAR2(30):= NULL;
      t_bills_receiv_enabled_flag        VARCHAR2(1) := NULL;
      t_ta_installed_flag                VARCHAR2(1) := NULL;
      t_sobname                          VARCHAR2(30):= NULL;
      t_currency_code                    VARCHAR2(15):= NULL;
      t_precision                        VARCHAR2(1) := NULL; 

      
      -- declare workfields for descriptions to be picked up
      t_tax_printing_meaning             VARCHAR2(80):= NULL;
      t_discount_basis_meaning           VARCHAR2(80):= NULL;
      t_chargeback_due_date_meaning      VARCHAR2(80):= NULL;
      t_grouping_rule_name               VARCHAR2(40):= NULL;
      t_rule_set_name                    VARCHAR2(30):= NULL; 
      t_hierarchy_name                   VARCHAR2(30):= NULL; 
      t_user_conversion_type             VARCHAR2(30):= NULL; 

      -- declare workfields for columns added to ar_system_parameters after 11I base 
      t_sales_credit_pct_limit           NUMBER      := NULL;
      t_rev_transfer_clear_ccid          NUMBER(15)  := NULL;
      t_max_wrtoff_amount                NUMBER      := NULL;
      t_irec_cc_receipt_method_id        NUMBER(15)  := NULL;
      t_show_billing_number_flag         VARCHAR2(1) := NULL;
      t_cross_currency_rate_type         VARCHAR2(30):= NULL;
      t_document_seq_gen_level           VARCHAR2(80):= NULL;
      t_calc_tax_on_credit_memo_flag     VARCHAR2(1) := NULL;
      t_new_columns                      VARCHAR2(1000):=NULL;

    BEGIN  -- level 3
      SectionPrint ('System Options');
      
   -- select ar_system_parameters  - columns in base 11I release 
      SELECT   a.default_grouping_rule_id, 
               a.salesrep_required_flag,
               a.auto_rec_invoices_per_commit,
               a.auto_rec_receipts_per_commit,
               a.pay_unrelated_invoices_flag,
               a.print_home_country_flag, 
               a.location_tax_account,
               a.from_postal_code,
               a.to_postal_code,
               a.tax_registration_number,
               a.populate_gl_segments_flag,
               a.unallocated_revenue_ccid,
               b.name, 
               a.calc_discount_on_lines_flag,
               a.change_printed_invoice_flag,
               a.code_combination_id_loss,
               a.create_reciprocal_flag,
               a.default_country,
               decode(a.default_territory, 'SALES', 'Salesrep',
                                           'BILL','Bill to Site',
                                           'NONE','None',
                                           'SHIP','Ship to Site', a.default_territory ), 
               a.generate_customer_number,
               a.invoice_deletion_flag,
               c.id_flex_structure_name,
               a.site_required_flag,
               a.tax_allow_compound_flag,
               a.tax_invoice_print,
               decode(a.tax_method, 'SALES_TAX','Sales Tax', 'VAT', 'VAT', a.tax_method ),
               a.tax_use_customer_exempt_flag,
               a.tax_use_cust_exc_rate_flag,
               a.tax_use_loc_exc_rate_flag,
               a.tax_use_product_exempt_flag,
               a.tax_use_prod_exc_rate_flag,
               a.tax_use_site_exc_rate_flag,
               a.ai_log_file_message_level,
               a.ai_max_memory_in_bytes,
               a.ai_acct_flex_key_left_prompt,
               a.ai_mtl_items_key_left_prompt,
               a.ai_territory_key_left_prompt,
               a.ai_purge_interface_tables_flag,
               a.ai_activate_sql_trace_flag,
               a.set_of_books_id,
               a.created_by,
               a.creation_date,
               a.last_updated_by,
               a.last_update_date,
               a.last_update_login,
               a.accounting_method,
               a.accrue_interest,
               a.unearned_discount,
               a.partial_discount_flag,
               a.print_remit_to,
               a.default_cb_due_date,
               a.auto_site_numbering,
               a.cash_basis_set_of_books_id,
               a.code_combination_id_gain,
               a.autocash_hierarchy_id,
               a.run_gl_journal_import_flag,
               a.cer_split_amount,
               a.cer_dso_days,
               a.posting_days_per_cycle,
               decode(a.address_validation,'NOVAL','No Validation',
                                           'ERR','Error',
                                           'WARN','Warning', a.address_validation ),
               a.tax_code,
               a.tax_currency_code,
               decode(a.tax_header_level_flag,'Y','Header','Line'),
               a.tax_minimum_accountable_unit,
               a.tax_precision,
               a.tax_rounding_rule,
               a.tax_rounding_allow_override,
               a.rule_set_id,
               a.tax_use_account_exc_rate_flag,
               a.tax_use_system_exc_rate_flag,
               a.tax_hier_site_exc_rate,
               a.tax_hier_cust_exc_rate,
               a.tax_hier_prod_exc_rate,
               a.tax_hier_account_exc_rate,
               a.tax_hier_system_exc_rate,
               a.tax_enforce_account_flag,
               decode(a.tax_database_view_set,'_A','Taxware',
                                              '_V','Vertex',
                                              'O','Oracle', a.tax_database_view_set ),
               a.inclusive_tax_used,
               a.code_combination_id_round,
               a.trx_header_level_rounding,
               a.trx_header_round_ccid,
               d.name, 
               a.sales_tax_geocode,
               a.bills_receivable_enabled_flag,
               a.ta_installed_flag,
               e.name,
               e.currency_code,
               f.precision    
      INTO     t_default_grouping_rule_id,     
               t_salesrep_required_flag,
               t_auto_rec_inv_per_commit,
               t_auto_rec_rec_per_commit,
               t_pay_unrelated_invoices_flag,
               t_print_home_country_flag, 
               t_location_tax_account,
               t_from_postal_code,
               t_to_postal_code,
               t_tax_registration_number,
               t_populate_gl_segments_flag,
               t_unallocated_revenue_ccid,
               t_orgname, 
               t_calc_discount_on_lines_flag,
               t_change_printed_invoice_flag,
               t_code_combination_id_loss,
               t_create_reciprocal_flag,
               t_default_country,
               t_default_territory, 
               t_generate_customer_number,
               t_invoice_deletion_flag,
               t_id_flex_structure_name,
               t_site_required_flag,
               t_tax_allow_compound_flag,
               t_tax_invoice_print,
               t_tax_method,
               t_tax_use_customer_exempt_flag,
               t_tax_use_cust_exc_rate_flag,
               t_tax_use_loc_exc_rate_flag,
               t_tax_use_product_exempt_flag,
               t_tax_use_prod_exc_rate_flag,
               t_tax_use_site_exc_rate_flag,
               t_ai_log_file_message_level,
               t_ai_max_memory_in_bytes,
               t_ai_acct_flex_key_left_prompt,
               t_ai_mtl_items_key_left_prompt,
               t_ai_territory_key_left_prompt,
               t_ai_purge_interface_tab_flag,
               t_ai_activate_sql_trace_flag,
               t_set_of_books_id,
               t_created_by,
               t_creation_date,
               t_last_updated_by,
               t_last_update_date,
               t_last_update_login,
               t_accounting_method,
               t_accrue_interest,
               t_unearned_discount,
               t_partial_discount_flag,
               t_print_remit_to,
               t_default_cb_due_date,
               t_auto_site_numbering,
               t_cash_basis_set_of_books_id,
               t_code_combination_id_gain,
               t_autocash_hierarchy_id,
               t_run_gl_journal_import_flag,
               t_cer_split_amount,
               t_cer_dso_days,
               t_posting_days_per_cycle,
               t_address_validation,
               t_tax_code,
               t_tax_currency_code,
               t_tax_header_level_flag,
               t_tax_minimum_accountable_unit,
               t_tax_precision,
               t_tax_rounding_rule,
               t_tax_rounding_allow_override,
               t_rule_set_id,
               t_tax_use_account_exc_rate_flg,
               t_tax_use_system_exc_rate_flag,
               t_tax_hier_site_exc_rate,
               t_tax_hier_cust_exc_rate,
               t_tax_hier_prod_exc_rate,
               t_tax_hier_account_exc_rate,
               t_tax_hier_system_exc_rate,
               t_tax_enforce_account_flag,
               t_tax_database_view_set,
               t_inclusive_tax_used,
               t_code_combination_id_round,
               t_trx_header_level_rounding,
               t_trx_header_round_ccid,
               t_trxname, 
               t_sales_tax_geocode,
               t_bills_receiv_enabled_flag,
               t_ta_installed_flag,
               t_sobname,
               t_currency_code,
               t_precision  
      FROM     AR_SYSTEM_PARAMETERS a,
               HR_ALL_ORGANIZATION_UNITS b, 
               FND_ID_FLEX_STRUCTURES_VL c, 
               AR_RECEIVABLES_TRX d , 
               GL_SETS_OF_BOOKS e,
               FND_CURRENCIES_VL f 
      WHERE    b.organization_id(+) = a.org_id 
      AND      c.id_flex_code = 'RLOC' 
      AND      c.id_flex_num  = a.location_structure_id
      AND      d.receivables_trx_id(+) = a.finchrg_receivables_trx_id 
      AND      e.set_of_books_id = a.set_of_books_id
      AND      f.currency_code    = e.currency_code;

   -- select ar_system_parameters columns added after base release 
   -- dynamic sql depending on whether the column exists 

      IF column_exists('AR_SYSTEM_PARAMETERS','REV_TRANSFER_CLEAR_CCID') = 'Y' THEN
         t_new_columns := 'rev_transfer_clear_ccid ';
      ELSE 
         t_new_columns := ' NULL ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','SALES_CREDIT_PCT_LIMIT') = 'Y' THEN
         t_new_columns := t_new_columns || ', sales_credit_pct_limit ';
      ELSE 
         t_new_columns := t_new_columns ||  ', NULL ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','MAX_WRTOFF_AMOUNT') = 'Y' THEN
         t_new_columns := t_new_columns || ', max_wrtoff_amount ';
      ELSE 
         t_new_columns := t_new_columns ||  ', NULL ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','IREC_CC_RECEIPT_METHOD_ID') = 'Y' THEN
         t_new_columns := t_new_columns || ', irec_cc_receipt_method_id ';
      ELSE 
         t_new_columns := t_new_columns ||  ', NULL ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','SHOW_BILLING_NUMBER_FLAG') = 'Y' THEN
         t_new_columns := t_new_columns || ', show_billing_number_flag ';
      ELSE 
         t_new_columns := t_new_columns ||  ', NULL ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','CROSS_CURRENCY_RATE_TYPE') = 'Y' THEN
         t_new_columns := t_new_columns || ', cross_currency_rate_type ';
      ELSE 
         t_new_columns := t_new_columns ||  ', NULL ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','DOCUMENT_SEQ_GEN_LEVEL') = 'Y' THEN
         t_new_columns := t_new_columns || ', document_seq_gen_level ';
      ELSE 
         t_new_columns := t_new_columns ||  ', NULL ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','CALC_TAX_ON_CREDIT_MEMO_FLAG') = 'Y' THEN
         t_new_columns := t_new_columns || ', calc_tax_on_credit_memo_flag ';
      ELSE 
         t_new_columns := t_new_columns ||  ', NULL ';
      END IF; 

      sqltxt := 'SELECT ' || t_new_columns ||
                'FROM        AR_SYSTEM_PARAMETERS';
 
      l_cursor := dbms_sql.open_cursor;
      dbms_sql.parse( l_cursor, sqltxt, dbms_sql.native);
      dbms_sql.define_column( l_cursor, 1, t_sales_credit_pct_limit );
      dbms_sql.define_column( l_cursor, 2, t_rev_transfer_clear_ccid ); 
      dbms_sql.define_column( l_cursor, 3, t_max_wrtoff_amount );
      dbms_sql.define_column( l_cursor, 4, t_irec_cc_receipt_method_id );
      dbms_sql.define_column( l_cursor, 5, t_show_billing_number_flag, 1 );
      dbms_sql.define_column( l_cursor, 6, t_cross_currency_rate_type, 30 );
      dbms_sql.define_column( l_cursor, 7, t_document_seq_gen_level, 80 );
      dbms_sql.define_column( l_cursor, 8, t_calc_tax_on_credit_memo_flag, 1 );

      l_counter := dbms_sql.execute(l_cursor);
      l_counter := 0; 

      WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
         l_counter := l_counter + 1;
         dbms_sql.column_value( l_cursor, 1, t_sales_credit_pct_limit );
         dbms_sql.column_value( l_cursor, 2, t_rev_transfer_clear_ccid );
         dbms_sql.column_value( l_cursor, 3, t_max_wrtoff_amount );
         dbms_sql.column_value( l_cursor, 4, t_irec_cc_receipt_method_id );
         dbms_sql.column_value( l_cursor, 5, t_show_billing_number_flag );
         dbms_sql.column_value( l_cursor, 6, t_cross_currency_rate_type );
         dbms_sql.column_value( l_cursor, 7, t_document_seq_gen_level );
         dbms_sql.column_value( l_cursor, 8, t_calc_tax_on_credit_memo_flag );
      END LOOP; 
      IF l_counter = 0 then
         RAISE NO_DATA_FOUND;
      END IF;   
      dbms_sql.close_cursor(l_cursor);

   -- start reporting the system options 

      Tab1Print('Receivables System Options are set up');

   -- Start : System Options - accounting
      BrPrint; 
      Tab1Print('Accounting');
      Tab2Print('Accounting Method  = ' || t_accounting_method );
      Tab2Print('Organization Name  = ' || t_orgname );
      Tab2Print('Set of Books Name  = ' || t_sobname );
      Tab3Print('Set of Books Id = ' || to_char(t_set_of_books_id) );
  --  If Mrc is not enabled profile option sob id must match     
      IF v_mrc_flag <> 'Y' THEN 
         IF to_number(Get_Profile_option('GL_SET_OF_BKS_ID')) = t_set_of_books_id THEN 
            Tab3Print('Set of Books Name defined in System Options matches  "GL: Set of Books" profile option ');
         ELSE 
            ErrorPrint('Set of Books Name defined in System Options does not match "GL: Set of Books" profile option');
            ActionerrorPrint('Set the proffile option "GL: Set of Books" to ' || t_sobname );
         END IF;                                                     
      END IF;
      v_sobid   := t_set_of_books_id; 
      v_sobname := t_sobname;
   
      Tab3Print('Currency = ' || t_currency_code );
      Tab3Print('Currency Precision = ' || t_precision );

      Tab2Print('Finance Charge Activity = '|| t_trxname );

      IF t_code_combination_id_gain is NULL THEN 
         ErrorPrint('Realized Gains Account is not defined');
         ActionErrorPrint('Define the Realized Gains Account in System Options');
      ELSE 
         Tab2Print('Realized Gains Account is defined');
      END IF;

      IF t_code_combination_id_loss is NULL THEN 
         ErrorPrint('Realized Losses Account is not defined');
         ActionErrorPrint('Define the Realized Losses Account in System Options');
      ELSE 
         Tab2Print('Realized Losses Account is defined');
      END IF;

      IF t_location_tax_account is NULL THEN 
         Tab2Print('Tax Account is not defined');
      ELSE 
         Tab2Print('Tax Account is defined');
      END IF;

   -- 'Cross currency rate type' 
      IF column_exists('AR_SYSTEM_PARAMETERS','CROSS_CURRENCY_RATE_TYPE') = 'Y' THEN
         IF t_cross_currency_rate_type IS NULL THEN
            ErrorPrint('Cross Currency Rate Type is not defined'); 
            ActionErrorprint('Define Cross Currency Rate Type in System Options');
         ELSE  
            BEGIN            
              SELECT  user_conversion_type 
              INTO    t_user_conversion_type 
              FROM    GL_DAILY_CONVERSION_TYPES 
              WHERE   conversion_type = t_cross_currency_rate_type;
            EXCEPTION 
              WHEN NO_DATA_FOUND THEN 
                   ErrorPrint('Cross Currency Rate Type value "' || t_cross_currency_rate_type || '" is not valid' );
                   ActionErrorprint('Redefine Cross Currency Rate Type in System Options');
            END; 
            Tab2Print('Cross Currency Rate Type = ' || t_user_conversion_type );
         END IF; 
      END IF; 

      IF t_code_combination_id_round is NULL THEN 
         ErrorPrint('Cross Currency Rounding Account is not defined');
         ActionErrorPrint('Define the Cross Currency Rounding Account in System Options');
      ELSE 
         Tab2Print('Cross Currency Account is defined');
      END IF;

      IF t_trx_header_level_rounding = 'Y' THEN 
         IF t_trx_header_round_ccid IS NULL THEN 
            WarningPrint('Header Rounding Account is not defined');
            ActionWarningprint('Define the Header Rounding Account in System Options');
         ELSE
            Tab2Print('Header Rounding Account is defined');
         END IF;
      END IF;

      Tab2Print('Automatic Journal Import = ' ||  t_run_gl_journal_import_flag );

      Tab2Print('Header Level Rounding = ' || t_trx_header_level_rounding );
      Tab2Print('Days per Posting Cycle = ' || t_posting_days_per_cycle );
   -- End : System options - Accounting 

   -- Start : System Options - Tax
      BrPrint; 
      Tab1Print('Tax');
      Tab2Print('Tax Method = ' || t_tax_method );
      Tab2Print('Location Flexfield Structure = ' || t_id_flex_structure_name );
      Tab2Print('Postal Code Range = From ' || t_from_postal_code || ' To ' || t_to_postal_code );
      Tab2Print('Address Validation = ' || t_address_validation );
      Tab2Print('Allow Compound Taxes = ' || t_tax_allow_compound_flag );

   -- 'Invoice Printing' -- not null column -- Print associated meaning iso code
      BEGIN
        SELECT meaning 
        INTO   t_tax_printing_meaning 
        FROM   AR_LOOKUPS 
        WHERE  lookup_type = 'TAX_PRINTING_OPTION' 
        AND    lookup_code = t_tax_invoice_print;
        Tab2Print('Invoice Printing = ' || t_tax_printing_meaning );  
      EXCEPTION
        WHEN NO_DATA_FOUND THEN 
             ErrorPrint ('Invoice Printing is set to an invalid value' ); 
             ActionErrorPrint('Redefine Invoice Printing in System options');
      END; 
            
      IF t_tax_registration_number IS NULL THEN 
         WarningPrint('Tax Registration Number is not defined');
         ActionWarningPrint('Define Tax Registration Number in System Options if customers are charged tax '||
                            'in order to have the Tax Registration Number printed on the invoices');   
      ELSE 
         Tab2Print('Tax Registration Number is defined');
      END IF;     

      Tab2Print('Tax Vendor views = '    || t_tax_database_view_set );
      Tab2Print('Inclusive Tax used = '  || t_inclusive_tax_used );   

      Tab2Print('Rounding Options');
      Tab3Print('Calculation Level = '   || t_tax_header_level_flag ); 
      Tab3Print('Tax Rounding Rule = '   || t_tax_rounding_rule );
      Tab3Print('Min Accountable Unit = '|| to_char(t_tax_minimum_accountable_unit) ); 
      Tab3Print('Allow Override = '      || t_tax_rounding_allow_override );
 
      Tab2Print('Enforce Tax from Revenue Account = ' || t_tax_enforce_account_flag );

      IF column_exists('AR_SYSTEM_PARAMETERS','CALC_TAX_ON_CREDIT_MEMO_FLAG') = 'Y' THEN
         Tab2Print('Calculate Tax on Credit Memo during Autoinvoice = '|| t_calc_tax_on_credit_memo_flag );
      END IF;
 
      Tab2Print('Tax Code Defaults:');
      Tab3Print('Customer Site . . . . . . Enabled = ' || t_tax_use_site_exc_rate_flag || '. . . . . Hierarchy = '||
                nvl(t_tax_hier_site_exc_rate,   'null') );
      Tab3Print('Customer. . . . . . . . . . Enabled = ' || t_tax_use_cust_exc_rate_flag || '. . . . . Hierarchy = '||
                nvl(t_tax_hier_cust_exc_rate,   'null') );
      Tab3Print('Product . . . . . . . . . . . Enabled = ' || t_tax_use_prod_exc_rate_flag || '. . . . . Hierarchy = '||
                nvl(t_tax_hier_prod_exc_rate,   'null') );
      Tab3Print('Revenue Account . . Enabled = ' || t_tax_use_account_exc_rate_flg || '. . . . . Hierarchy = '||
                nvl(t_tax_hier_account_exc_rate,'null') );
      Tab3Print('System Options. . . . Enabled = ' || t_tax_use_system_exc_rate_flag || '. . . . . Hierarchy = '||
                nvl(t_tax_hier_system_exc_rate, 'null') ); 
      Tab3Print('Tax Code  = ' || t_tax_code );

      Tab2Print('Exception Rates: ');
      Tab3Print('Use Customer Exemptions = '|| t_tax_use_customer_exempt_flag );
      Tab3Print('Use Item Exemptions = '|| t_tax_use_product_exempt_flag );
      Tab3Print('Use Item Tax Rate Exceptions = '||t_tax_use_loc_exc_rate_flag );
   -- End  : System Options - Tax 

   -- Start : System Options : Transactions and Customers
      BrPrint;
      Tab1Print('Transactions and Customers');
      Tab2Print('Allow Changes to Printed Transactions = ' || t_change_printed_invoice_flag );
      Tab2Print('Allow Payment of Unrelated Transactions = '  || t_pay_unrelated_invoices_flag );
      Tab2Print('Allow Transaction Deletion = ' || t_invoice_deletion_flag );

      IF column_exists('AR_SYSTEM_PARAMETERS','SHOW_BILLING_NUMBER_FLAG') = 'Y' THEN
          Tab2Print('Show Billing Number = '|| t_show_billing_number_flag ); 
      END IF; 

      IF column_exists('AR_SYSTEM_PARAMETERS','DOCUMENT_SEQ_GEN_LEVEL') = 'Y' THEN
         If    t_document_seq_gen_level  = 'WHEN_TRX_COMMITTED' THEN 
               t_document_seq_gen_level := 'When Saved'; 
         ELSIF t_document_seq_gen_level  = 'WHEN_TRX_COMPLETED' THEN 
               t_document_seq_gen_level := 'When Completed'; 
         ELSIF t_document_seq_gen_level IS NULL THEN
               t_document_seq_gen_level := 'None';
         END IF;
         Tab2Print('Document Number Generation Level = '|| t_document_seq_gen_level ); 
      END IF; 

      Tab2Print('AutoInvoice');

      Tab3Print('Accounting Flex Tuning Segment = ' || t_ai_acct_flex_key_left_prompt );
      Tab3Print('System Item Tuning Segment = ' || t_ai_mtl_items_key_left_prompt );
      Tab3Print('Territory Tuning Segment = ' || t_ai_territory_key_left_prompt ); 

      
      Tab3Print('Max Memory in bytes = ' || t_ai_max_memory_in_bytes );
      IF t_ai_max_memory_in_bytes  < 3000000 THEN 
         WarningPrint('Max Memory setting is less than 3MB. This decreases AutoInvoice performance when processing a large volume of data');
         ActionWarningPrint('Suggested Max Memory setting for Autoinvoice is 3MB or higher if the machine has enough memory');
      END IF; 
      IF t_ai_max_memory_in_bytes  > 10000000 THEN 
         WarningPrint('Max Memory setting is greater than 10MB. A too high setting can decrease AutoInvoice performance just aswell as a too low setting');
         ActionWarningPrint('Suggested Max Memory setting for AutoInvoice is 3MB or higher if the machine has enough memory');
      END IF; 

      Tab3Print('Log File Message Level = ' || t_ai_log_file_message_level  );
      IF t_ai_log_file_message_level > 1 THEN 
         WarningPrint('Log File Message Level is set to greater than 1. This decreases AutoInvoice performance');
         ActionWarningprint('Suggested Log File Message Level for day to day business is 1. '||
                            'Change the Log File Message Level to 3 or above only when troubleshooting AutoInvoice issues');
      END IF; 

      Tab3Print('SQL Trace = ' || t_ai_activate_sql_trace_flag );
      IF t_ai_activate_sql_trace_flag = 'Y' THEN 
         Warningprint('Sql Trace is turned on. This decreases AutoInvoice performance');
         ActionWarningPrint('Uncheck the Sql Trace checkbox to improve Autoinvoice performance. '||
                            'Check the SQL Trace checkbox only when troubleshooting AutoInvoice issues');
      END IF;

      Tab3Print('Purge Interface Table = ' ||  t_ai_purge_interface_tab_flag );

      Tab2Print('Customers');
      Tab3Print('Automatic Customer Numbering = '|| t_generate_customer_number );
      Tab3Print('Automatic Site Numbering = '    || t_auto_site_numbering );
      Tab3Print('Create Reciprocal Customer = '  || t_create_reciprocal_flag );

   -- 'Grouping Rule Name' -- not null column -- Print associated name iso id 
      BEGIN
        SELECT name 
        INTO   t_grouping_rule_name 
        FROM   RA_GROUPING_RULES
        WHERE  grouping_rule_id = t_default_grouping_rule_id;  
        Tab3Print('Grouping Rule Name = ' || t_grouping_rule_name );
      EXCEPTION 
        WHEN NO_DATA_FOUND THEN 
             ErrorPrint( 'Grouping Rule Name is set to an invalid value ');
             ACtionErrorPrint ('Redefine Grouping Rule Name in System Options');
      END; 
   -- End : System Options - Transactions and Customers

   -- Start : System Options - Miscellaneous
      BrPrint;
      Tab1Print('Miscellaneous');

      Tab2Print('Split Amount = '|| to_char(t_cer_split_amount) ); 
 
   -- 'Discount Basis' -- not null column - Print associated meaning iso code                               
      BEGIN 
        SELECT meaning 
        INTO   t_discount_basis_meaning 
        FROM   AR_LOOKUPS 
        WHERE  lookup_type = 'DISCOUNT_BASIS'
        AND    lookup_code = t_calc_discount_on_lines_flag;
        Tab2Print('Discount basis = ' || t_discount_basis_meaning  );
      EXCEPTION
        WHEN NO_DATA_FOUND THEN 
             ErrorPrint( 'Discount Basis is set to an invalid value ');
             ACtionErrorPrint ('Redefine Discount Basis in System Options');
      END; 
        
   -- 'Autocash Rule Set' -- Null column  -- Printed associated name iso id 
      IF t_autocash_hierarchy_id is NOT NULL THEN       
         BEGIN 
           SELECT  hierarchy_name 
           INTO    t_hierarchy_name 
           FROM    AR_AUTOCASH_HIERARCHIES 
           WHERE   autocash_hierarchy_id  = t_autocash_hierarchy_id;  
         EXCEPTION
           WHEN NO_DATA_FOUND THEN 
                ErrorPrint( 'Autocash Rule Set is set to an invalid value ');
                ACtionErrorPrint ('Redefine Autocash Rule Set in System Options');
         END;
      END IF;  
      Tab2Print('Autocash Rule Set = ' || t_hierarchy_name );

      Tab2Print('Days in Days Sales Outstanding Calculation = '|| to_char(t_cer_dso_days)); 

      IF column_exists('AR_SYSTEM_PARAMETERS','SALES_CREDIT_PCT_LIMIT') = 'Y' THEN
         IF t_sales_credit_pct_limit IS NULL THEN 
            WarningPrint('Sales Credit Percent Limit is not defined. No validation is performed when using '||
                         'Revenue Accounting');
            ActionWarningPrint('Define Sales Credit Percent Limit in System Options when required to limit '||
                               'the percentage of revenue plus non-revenue sales credit that a salesperson can have '||
                               'on any transaction line'); 
         ELSE 
            Tab2Print('Sales Credit Percent Limit = '|| to_char(t_sales_credit_pct_limit) );
         END IF; 
      END IF;                      
  
      IF column_exists('AR_SYSTEM_PARAMETERS','MAX_WRTOFF_AMOUNT') = 'Y' THEN
         IF t_max_wrtoff_amount IS NULL THEN 
            WarningPrint('Maximum Write-off Amount is not defined.');
            ActionWarningPrint('Define Maximum Write-off Amount in System Options if required to limit the '||
                               'write-off of receipt balances');
         ELSE   
            Tab2Print('Maximum Write-off Amount = '|| to_char(t_max_wrtoff_amount));
         END IF; 
      END IF;                      

      Tab2Print('Accrue Interest = ' || t_accrue_interest );
      Tab2Print('Allow Unearned Discounts = ' || t_unearned_discount  );
      Tab2Print('Discount on Partial Payments = ' || t_partial_discount_flag );
      Tab2Print('Trade Accounting Installed = '   || t_ta_installed_flag );
      Tab2Print('Bills Receivable Enabled = '     || t_bills_receiv_enabled_flag );
      Tab2Print('Require Billing Location for Receipts = '|| t_site_required_flag );
      Tab2Print('Require Salesperson = '   || t_salesrep_required_flag );
      Tab2Print('Print Remit to Address = '|| t_print_remit_to );
      Tab2Print('Print Home Country = '    || t_print_home_country_flag );

      Tab2Print('Auto receipts'); 
      Tab3print('Invoices per Commit = ' || to_char(t_auto_rec_inv_per_commit) );
      Tab3Print('Receipts per Commit = ' || to_char(t_auto_rec_rec_per_commit) );

   -- 'Chargeback due date' -- not null column -- print meaning iso code 
      BEGIN 
        SELECT    meaning 
        INTO      t_chargeback_due_date_meaning 
        FROM      AR_LOOKUPS
        WHERE     lookup_type = 'DEFAULT_CB_DUE_DATE' 
        AND       lookup_code = t_default_cb_due_date;
        Tab2Print('Chargeback Due Date = ' || t_chargeback_due_date_meaning ); 
      EXCEPTION 
        WHEN NO_DATA_FOUND THEN 
             ErrorPrint('Chargeback Due Date is set to an invalid value');
             ActionErrorPrint('Redefine Chargeback Due Date in System options');
      END; 
     
      Tab2Print('Default Country = '      || t_default_country );
      Tab2Print('Source of Territory = '  || t_default_territory );

   -- 'Application Rule Set' -- not null column -- print name iso id 
      BEGIN 
        SELECT  rule_set_name
        INTO    t_rule_set_name 
        FROM    AR_APP_RULE_SETS 
        WHERE   rule_set_id = t_rule_set_id ;
        Tab2Print('Application Rule Set = ' || t_rule_set_name );  
      EXCEPTION 
        WHEN NO_DATA_FOUND THEN 
             ErrorPrint('Application Rule Set is set to an invalid value');
             ActionErrorPrint('Redefine Application Rule Set in System options');
      END; 
   -- End : System Options - Miscellaneous 

    EXCEPTION   
      WHEN NO_DATA_FOUND THEN   
           ErrorPrint ('AR System Options have not been defined for this Operating Unit');
           ACtionErrorPrint ('Please refer to Users Guide and define AR System Options');
           RAISE STOPEXECUTION;
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "System Options" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
           RAISE STOPEXECUTION;           
    END;   -- level 3 AR System Options 

/* -------------------------------- Conversion Rates ------------------------------------------------------ */ 

    DECLARE  
      Cursor C1 IS 
        SELECT  count(*)               count,
                a.user_conversion_type type 
        FROM    gl_daily_conversion_types a,
                gl_daily_rates_v b
        WHERE   a.conversion_type = b.conversion_type  
        GROUP BY a.user_conversion_type;
    BEGIN    
      SectionPrint('Conversion Rates');
      l_count := 0;
      FOR C1_rec in C1 LOOP 
          Tab1Print('There are ' || to_char(c1_rec.count)  || ' Conversion Rates enabled ' ||
                    'for currency type "' || c1_rec.type  || '"' );
          l_count := l_count + 1;
      END LOOP;
      IF l_count = 0 THEN 
         WarningPrint('Daily Conversion Rates have not been setup');
         ActionWarningPrint('Define Conversion Rates');
         Show_link('66935.1'); 
         ActionPrint(' : "General Ledger Product Documentation"' ); 
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Conversion Rates" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;    

/* -------------------------------- Reporting set of books ----------------------------------------------- */ 

    DECLARE  
      t_profile_sobid   NUMBER; 
      t_rep_sobname     VARCHAR2(30); 
      CURSOR C1 IS 
        SELECT rep.name              sobname,
               rep.currency_code    currency,
               rep.set_of_books_id     sobid 
        FROM   GL_SETS_OF_BOOKS rep, 
               GL_SETS_OF_BOOKS prim,
               GL_MC_BOOK_ASSIGNMENTS_V d 
        WHERE  prim.set_of_books_id = v_sobid 
        AND    prim.mrc_sob_type_code = 'P' 
        AND    d.primary_set_of_books_id = prim.set_of_books_id  
        AND    rep.set_of_books_id = d.reporting_set_of_books_id     
        AND    rep.mrc_sob_type_code = 'R';  
        
    BEGIN    
      IF v_sobid is NOT NULL and v_mrc_flag = 'Y' THEN 
         SectionPrint('Reporting Sets of Books');
         l_count := 0;
         FOR c1_rec in C1 LOOP 
             IF l_count = 0 THEN 
                TAB1Print('Following Reporting Sets Of Books are tied to Primary Set of Books "'|| v_sobname || '"' );
             END IF;
             Tab2Print('Name = ' || c1_rec.sobname || ', ID = '|| to_char(c1_rec.sobid) || ', Currency = '|| 
                       c1_rec.currency  );
             l_count := l_count + 1 ;
         END LOOP;
         IF  l_count = 0 THEN   
             Tab1PRint('MRC is enabled, but there are no Reporting Sets of Books tied to Primary Set of Books "'|| 
                        v_sobname || '"' );
         END IF;

         t_profile_sobid :=  to_number(Get_Profile_option('GL_SET_OF_BKS_ID'));
 
         IF t_profile_sobid = v_sobid THEN 
            Tab1Print('Profile option "GL: Set of Books" is set to Primary Set of Books "' || v_sobname || '"' );   
         ELSE 
--       check if profile option set of books is a Reporting Set of Books of the Primary set of books
            BEGIN 
              SELECT    a.name
              INTO      t_rep_sobname
              FROM      GL_SETS_OF_BOOKS a,
                        GL_MC_BOOK_ASSIGNMENTS_V b
              WHERE     b.primary_set_of_books_id = v_sobid
              AND       b.reporting_set_of_books_id = t_profile_sobid 
              AND       a.set_of_books_id =  b.reporting_set_of_books_id
              AND       a.mrc_sob_type_code = 'R';
              Tab1Print('Profile option "GL: Set of Books" is set to Reporting Set of Books "'|| t_rep_sobname ||'"');   
            EXCEPTION 
              WHEN NO_DATA_FOUND THEN 
                   ErrorPrint('Profile option "GL: Set of Books" does not match Set of Books Name defined in System '||
                              'Options, or one of its Reporting Sets of Books' );
                   ActionErrorPrint('Change the profile option "GL: Set of Books" to Set of Books Name defined in '||
                              'System Options, or one of its Reporting Sets of Books' );
            END;
          END IF;

      END IF;
    EXCEPTION 
      WHEN OTHERS THEN
           Errorprint(sqlerrm||' occurred in test in section "Reporting Sets of Books" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;      

/* -------------------------------- Open Calender Periods AR and GL ------------------------------------- */ 
    BEGIN 
      IF v_sobid is NOT NULL then 
   
         SectionPrint('Open Calendar Periods - AR');
         checkFinPeriod(v_sobid ,222);

         SectionPrint('Open Calendar Periods - GL');
         checkFinPeriod(v_sobid,101);
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Open Calendar Periods" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------------ Accounting Flexfield -------------------------------------------- */ 

    DECLARE  
      t_chart_of_acc_id      NUMBER(15);
      t_chart_of_acc_name    VARCHAR2(30); 
    BEGIN
      SectionPrint('Accounting Flexfield');
      
      SELECT    a.chart_of_accounts_id,
                a.chart_of_accounts_name
      INTO      t_chart_of_acc_id, 
                t_chart_of_acc_name   
      FROM      gl_sets_of_books_v a, 
                ar_system_parameters b
      WHERE     a.set_of_books_id = b.set_of_books_id;

      Tab1Print('Organization "' || v_orgname || '" is using Accounting Flexfield "'|| t_chart_of_acc_name || '"');
      checkKeyFlexfield('GL#', t_chart_of_acc_id, true  );

    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('AR System Options are not defined for this Operating Unit. Unable '||
                      'to check Accounting Flexfield.');
           ActionErrorPrint('Please refer to Users Guide and define AR System Options');
      WHEN OTHERS THEN
           Errorprint(sqlerrm||' occurred in test in section "Accounting Flexfield" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');          
    END; 

/* ----------------------------- Sales Tax Location Flexfield Structure ---------------------------------- */ 

    DECLARE  
      t_location_structure_id     NUMBER(15);
      t_location_structure_name   VARCHAR2(30); 
    BEGIN
      SectionPrint('Sales Tax Location Flexfield Structure');
     
      SELECT    a.location_structure_id,
                c.id_flex_structure_name 
      INTO      t_location_structure_id,
                t_location_structure_name  
      FROM      AR_SYSTEM_PARAMETERS a, 
                FND_ID_FLEX_STRUCTURES_VL c 
      WHERE     c.id_flex_code = 'RLOC' 
      AND       c.id_flex_num  = a.location_structure_id; 

      Tab1Print('Location Flexfield Structure is set to "'|| t_location_structure_name || '" in System Options' );
      checkKeyFlexfield('RLOC', t_location_structure_id, true );

    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('AR System Options are not been defined for this Operating Unit. Unable '||
                      'to check Sales Tax Location Flexfield.');
           ActionErrorPrint('Please refer to Users Guide and define AR System Options');
      WHEN OTHERS THEN
           Errorprint(sqlerrm||' occurred in test in section "Sales Tax Location Flexfield" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------------ Territory Flexfield Setup ---------------------------------------- */ 

    DECLARE  
      t_id_flex_structure_name     VARCHAR2(30);
    BEGIN
      SectionPrint('Territory Flexfield');
  
      SELECT     a.id_flex_structure_name 
      INTO       t_id_flex_structure_name 
      FROM       FND_ID_FLEX_STRUCTURES_VL a
      WHERE      a.id_flex_code = 'CT#' 
      AND        a.enabled_flag = 'Y'
      AND        a.freeze_flex_definition_flag = 'Y' 
      AND        0 < (  SELECT count(*) 
                        FROM   FND_ID_FLEX_SEGMENTS_VL b 
                        WHERE  b.id_flex_code = 'CT#' 
                        AND    b.enabled_flag = 'Y' 
                        AND    b.id_flex_num = a.id_flex_num );
      
      Tab1Print('Territory Flexfield Structure is  "' || t_id_flex_structure_name || 
                '". At least one segment of this structure is enabled'); 
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('Territory Flexfield is not defined');
           ActionErrorPrint('Please refer to Users Guide to define Territory Flexfield. Define, enable, '||
                            'freeze a "Territory Flexfield" structure with at least one enabled segment ');
      WHEN OTHERS THEN
           Errorprint(sqlerrm||' occurred in test in section "Territory Flexfield" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ----------------------------------- System Item Flexfield Setup --------------------------------------- */ 

   DECLARE  
      CURSOR C1 IS 
        SELECT     a.id_flex_structure_name 
        FROM       FND_ID_FLEX_STRUCTURES_VL a 
        WHERE      a.id_flex_code = 'MSTK'
        AND        a.enabled_flag = 'Y' 
        AND        a.freeze_flex_definition_flag = 'Y'
        AND        0 < ( SELECT     count(*) 
                         FROM       FND_ID_FLEX_SEGMENTS_VL b 
                         WHERE      b.id_flex_code = 'MSTK' 
                         AND        b.enabled_flag = 'Y'
                         AND        b.id_flex_num = a.id_flex_num );
    BEGIN
      SectionPrint('System Item Flexfield');
      l_count := 0 ;
      
      FOR c1_rec in C1 LOOP
          Tab1Print('System Item Flexfield structure is "'|| c1_rec.id_flex_structure_name  || 
                    '". At least one segment of this structure is enabled');
          l_count := l_count + 1; 
      END LOOP; 
 
      IF l_count = 0 THEN 
         Errorprint('System Item Flexfield is not defined' );
         ActionErrorPrint('Please refer to Users Guide to define System Item Flexfield. Define, enable, '||
                          'freeze a System Item Flexfield structure with at least one enabled segment ');
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "System Item Flexfield" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------ Line Transaction Flexfield Setup --------------------------------------- */ 

   DECLARE  
      t_total       NUMBER   := 0;
      CURSOR C1 IS 
        SELECT      a.descriptive_flex_context_code   context_code 
        FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                    FND_DESCRIPTIVE_FLEXS_VL c
        WHERE       a.descriptive_flexfield_name = 'RA_INTERFACE_LINES' 
        AND         a.enabled_flag = 'Y'
        AND         c.freeze_flex_definition_flag = 'Y'
        AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
        AND         0 < ( SELECT     count(*)  
                          FROM       FND_DESCR_FLEX_COL_USAGE_VL b
                          WHERE      b.descriptive_flex_context_code = a.descriptive_flex_context_code
                          AND        b.enabled_flag = 'Y' 
                          AND        b.descriptive_flexfield_name = 'RA_INTERFACE_LINES' );
    BEGIN
      SectionPrint('Line Transaction Flexfield');  
      l_count := 0 ;
      Tab1Print('Following Line Transaction Flexfield Contexts are enabled');

      FOR c1_rec in C1 LOOP
          Tab2Print( '"' || c1_rec.context_code || '"');
          BEGIN -- level 4 
  
            SELECT     count(*)
            INTO       t_total 
            FROM       FND_DESCR_FLEX_COL_USAGE_VL 
            WHERE      required_flag = 'N'
            AND        enabled_flag = 'Y' 
            AND        descriptive_flexfield_name  = 'RA_INTERFACE_LINES'
            AND        descriptive_flex_context_code = c1_rec.context_code ;

            IF t_total > 0 THEN 
               Tab3Print('Required Flag is not checked for ' || to_char (t_total) || ' segments of ' || 
                         c1_rec.context_code );
            END IF; 
          END; -- level 4 
          l_count := l_count + 1; 
      END LOOP; 
 
      IF l_count = 0 THEN 
         Warningprint('Line Transaction Flexfield is not defined');
         ActionwarningPrint('Line Transaction Flexfield is a required Descriptive Flexfield to use '||
                          'Autoinvoice functionality. Define and/or enable at least one context to use '||
                          'Autoinvoice functionality.'); 
      END IF;

      NoticePrint('AutoInvoice requires all the enabled segments of the Line Transaction Flexfield to be '||
                  'populated irrespective of the "Required Flag" on the segments');     

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Line Transaction Flexfield" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* --------------------------------- Application Set Up, item validation ----------------------------------- */ 

    DECLARE  
      t_org_id                    NUMBER; 
      t_item_validation_org_id    NUMBER;
      t_item_validation_org_name  VARCHAR2(60); 
    BEGIN
      SectionPrint('Application Set Up');
      SELECT   a.org_id,                  
               a.master_organization_id,
               b.name
      INTO     t_org_id,
               t_item_validation_org_id,
               t_item_validation_org_name  
      FROM     OE_SYSTEM_PARAMETERS a,   
               HR_ALL_ORGANIZATION_UNITS b 
      WHERE    b.organization_id = a.master_organization_id;

      Tab1Print('Item Validation Organization has been set to "'|| t_item_validation_org_name ||
                '" ( Org ID = '|| to_char(t_item_validation_org_id) || ' )');  

    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('Item Validation Organization is not defined' );
           ActionErrorPrint('Define Item Validation Organization in Order Management ( Set Up Parameters )');
      WHEN OTHERS THEN
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Item Validation" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------ Application Set Up, Account Generator ------------------------------------ */ 

    DECLARE  
      t_process_name              VARCHAR2(50); 
    BEGIN
      SELECT    decode(a.wf_process_name, 'FLEXBUILDER_UPGRADE' , 'Upgrade From flexbuilder', 
                                          'DEFAULT_ACCOUNT_GENERATION','Replace Balancing Segment',
                                          a.wf_process_name ) 
      INTO      t_process_name
      FROM      FND_FLEX_WORKFLOW_PROCESSES a, 
                FND_ID_FLEX_STRUCTURES_VL b, 
                GL_SETS_OF_BOOKS_V c, 
                AR_SYSTEM_PARAMETERS d 
      WHERE     a.id_flex_num = b.id_flex_num 
      AND       a.id_flex_code = b.id_flex_code 
      AND       a.application_id = b.application_id
      AND       a.wf_item_type = 'ARSBALSG' 
      AND       b.application_id = 101 
      AND       b.id_flex_code = 'GL#'
      AND       b.id_flex_num = c.chart_of_accounts_id
      AND       c.set_of_books_id = d.set_of_books_id;
     
      Tab1Print('AR Account Generator Process has been set to "' || t_process_name || '"' ); 

    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('Account Generator Process has not been set' );
           ActionErrorPrint('Set the Account Generator Process for the Accounting Flexfield structure ');
      WHEN OTHERS THEN
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Account Generator" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ----------------------------- Application Set Up, Transaction Types ----------------------------------- */ 

    DECLARE  
      CURSOR C1 IS 
        SELECT  DECODE(type, 'CM'  , 'Creditmemo',
                             'BR'  , 'Bills Receivables',
                             'CB'  , 'Chargeback',
                             'DEP' , 'Deposit',
                             'DM'  , 'Debitmemo',
                             'GUAR', 'Guarantee',
                             'INV',  'Invoice', type )   type, 
                count(*)                                 total
        FROM    RA_CUST_TRX_TYPES
        WHERE   NVL ( start_date, sysdate ) <= sysdate
        AND     NVL ( end_date,   sysdate ) >= sysdate
        GROUP BY type;
    BEGIN
      Tab1Print('Transaction Types Set Up');
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    RA_CUST_TRX_TYPES
      WHERE   NVL( start_date, sysdate ) <= sysdate
      AND     NVL( end_date, sysdate )   >= sysdate ;

      IF l_count = 0 THEN 
         ErrorPrint('Active Transaction Types have not been set up');
         ActionErrorPrint('Define Transaction Types with valid active dates');
      ELSE
         Tab2Print( to_char(l_count) || ' active Transaction Types have been set up. They are classified as :');

         -- list the different transaction types 

         FOR c1_rec in C1 LOOP
             Tab3Print ( to_char(c1_rec.total) || ' Transaction Types with Class "' || c1_rec.type || '"' );
         END LOOP;

         -- show how many transaction types require tax calculation 

         l_count := 0;
         SELECT  count(*)
         INTO    l_count 
         FROM    RA_CUST_TRX_TYPES
         WHERE   NVL( start_date, sysdate) <= sysdate
         AND     NVL( end_date, sysdate)   >= sysdate
         AND     tax_calculation_flag ='Y';

         Tab2Print('Tax calculation is enabled for ' || to_char(l_count) || ' Transaction Type(s)'); 
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Transaction Types" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;  

/* ---------------------------------- Application Set Up, Transaction Sources --------------------------- */ 

    BEGIN 
      Tab1Print('Transaction Sources Set Up');

      -- transaction Sources of type MANUAL  
     
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    RA_BATCH_SOURCES 
      WHERE   batch_source_type = 'INV' 
      AND     status = 'A' 
      AND     NVL( start_date, sysdate ) <= sysdate 
      AND     NVL( end_date, sysdate )   >= sysdate;

      IF l_count = 0 THEN 
         ErrorPrint('Active Manual Transaction Sources have not been set up');
         ActionErrorPrint('Set up Transaction Source of type "Manual".  Please refer to Users Guide for setting '||
                          'up Transaction Sources');
      ELSE
         Tab2Print( to_char(l_count) || ' active Transaction Sources of type "Manual" have been set up');
      END IF; 

      -- transaction Sources of type IMPORT  
     
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    RA_BATCH_SOURCES 
      WHERE   batch_source_type = 'FOREIGN' 
      AND     status = 'A' 
      AND     NVL( start_date, sysdate) <= sysdate 
      AND     NVL( end_date, sysdate)   >= sysdate;

      IF l_count = 0 THEN 
         ErrorPrint('Active Import Transaction Sources have not been set up');
         ActionErrorPrint('Set up Transaction Source of type "Import".  Please refer to Users Guide for setting '||
                          'up Transaction Sources');
      ELSE
         Tab2Print( to_char(l_count) || ' active Transaction Sources of type "Import" have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Transaction sources" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;  

/* --------------------------------- Application Set UP,Payment Terms --------------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    RA_TERMS_VL
      WHERE   NVL( start_date_active, sysdate ) <= sysdate
      AND     NVL( end_date_active, sysdate)    >= sysdate;
  
      IF l_count = 0 THEN 
         ErrorPrint('Active Payment Terms have not been set up');
         ActionErrorPrint('Set up Payment Terms with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || ' active Payment Terms have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set up, Payment Terms" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ------------------------------- Application Set Up, Receipt Class and Payment Methods --------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_RECEIPT_CLASSES a, 
              AR_RECEIPT_METHODS b, 
              AR_RECEIPT_METHOD_ACCOUNTS c, 
              AP_BANK_ACCOUNTS d
      WHERE   a.receipt_class_id = b.receipt_class_id
      AND     b.receipt_method_id = c.receipt_method_id
      AND     d.bank_account_id = c.bank_account_id
      AND   ( NVL( b.start_date, sysdate ) <= sysdate AND NVL( b.end_date, sysdate ) >= sysdate )
      AND   ( NVL( c.start_date, sysdate ) <= sysdate AND NVL( c.end_date, sysdate ) >= sysdate );

      IF l_count = 0 THEN 
         ErrorPrint('Receipts Classes with active Payment Methods and Bank Accounts have not been set up');
         ActionErrorPrint('Define Receipt Classes with active Payment Methods and assign a '||
                          'Bank Account to these Payment Methods');
      ELSE
         Tab1Print( to_char(l_count) || ' Receipts Classes have been defined with active Payment '||
                   'Methods and Bank Accounts');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set up, Receipt Classes" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ------------------------------- Application Set Up, Manual Receipt source --------------------------- */ 

    BEGIN 
      Tab1Print('Receipt Source Setup');
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_BATCH_SOURCES
      WHERE   default_receipt_class_id is not NULL
      AND     default_remit_bank_account_id  is not NULL
      AND     default_receipt_method_id is not NULL
      AND     type = 'MANUAL'
      AND     NVL( start_date_active, sysdate ) <= sysdate 
      AND     NVL( end_date_active, sysdate )   >= sysdate ;

      IF l_count = 0 THEN 
         ErrorPrint('Active Manual Receipt Sources have not been set up');
         ActionErrorPrint('Define Manual Receipt Sources with valid active dates');
      ELSE
         Tab2Print( to_char(l_count) || '  Receipt Sources of type "Manual" have been set up');
      END IF; 
    EXCEPTION
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Manual Receipt Source" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ----------------------------- Application Set Up, Automatic Receipt source ------------------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_BATCH_SOURCES
      WHERE   type = 'AUTOMATIC'
      AND     NVL( start_date_active, sysdate ) <= sysdate 
      AND     NVL( end_date_active, sysdate )   >= sysdate ;

      IF l_count <> 1 THEN 
         ErrorPrint( to_char(l_count) || ' Receipt Sources of type "Automatic" have been set up. ' );
         ActionErrorPrint('Define only one active Receipt Source of type "Automatic" as there should be ' || 
                          'one and only one active Receipt Source of type "Automatic"');  

      ELSE
         Tab2Print( to_char(l_count) || ' Receipt Source of type "Automatic" has been set up');
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Automatic Receipt Source" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------- Application Set Up, Location Based Tax Code -------------------------------- */ 

    DECLARE 
      t_tax_code     VARCHAR2(30);
      t_taxmethod    VARCHAR2(15) := NULL;

      CURSOR C1 IS 
        SELECT   tax_code 
        FROM     AR_VAT_TAX 
        WHERE    NVL( start_date, sysdate ) <= sysdate 
        AND      NVL( end_date, sysdate )   >= sysdate
        AND      enabled_flag ='Y'
        AND      tax_type = 'LOCATION';

    BEGIN 
      Tab1Print('Tax Codes Set Up');

      -- pick up tax method
      -- in case tax_method = 'SALES_TAX' a location based tax code has to be set up  
      BEGIN 
        SELECT  upper(tax_method) 
        INTO    t_taxmethod  
        FROM    AR_SYSTEM_PARAMETERS;
      EXCEPTION 
        WHEN OTHERS THEN 
             null;    
      END;

      l_count := 0;
      FOR c1_rec in C1 LOOP 
          Tab2Print( 'Location Based Tax Code = ' || c1_rec.tax_code );
          l_count := l_count + 1; 
      END LOOP; 
      
      IF t_taxmethod = 'SALES_TAX'  and l_count = 0 THEN 
         WarningPrint('Tax method used is Sales Tax, but an active "Location Based Tax Code" has not been set up');  
         ActionWarningPrint('Set up an active "Location Based Tax code" as descibed in the Receivables Tax Manual');
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN    
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Location Based Tax Code" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');     
    END;

/* ---------------------------- Application Setup, Non Location Based Tax codes Setup --------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_VAT_TAX 
      WHERE   NVL( start_date, sysdate) <= sysdate
      AND     NVL( end_date, sysdate)   >= sysdate
      AND     enabled_flag ='Y'
      AND     tax_type <> 'LOCATION';

      IF l_count = 0 THEN 
         ErrorPrint('Non Location Based Tax Codes have not been set up' );
         ActionErrorPrint('Define at least one Non Location Based Tax Code');
      ELSE
         Tab2Print( to_char(l_count) || ' active Tax Codes have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Non Location Tax Codes" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;
    
/* --------------------------- Application Set Up, Autocash Rule Sets -------------------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_AUTOCASH_HIERARCHIES a, 
              AR_AUTOCASH_RULES b
      WHERE   a.autocash_hierarchy_id = b.autocash_hierarchy_id;

      IF l_count = 0 THEN 
         WarningPrint('Autocash Rule Sets have not been set up' );
         ActionWarningPrint('Define Autocash Rule Sets to use the functionality of automatically '||
                          'applying receipts to invoices via Lockbox or Quick Batch');
      ELSE
         Tab1Print( to_char(l_count) || ' Autocash Rules have been set up ');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Autocash Rule Sets" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* -------------------------- Application Set Up, Line Ordering Rules ------------------------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    RA_LINE_ORDERING_RULES
      WHERE   NVL( start_date, sysdate ) <= sysdate
      AND     NVL( end_date, sysdate )   >= sysdate ;


      IF l_count = 0 THEN 
         WarningPrint('Active Line Ordering Rules have not been set up' );
         ActionWarningPrint('Define Line Ordering Rule with valid active dates to use Autoinvoice functionality');
      ELSE
         Tab1Print( to_char(l_count) || ' Line Ordering Rules have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Line Ordering Lines" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------  Application Setup, Grouping Rules ---------------------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    RA_GROUPING_RULES
	WHERE   NVL( start_date, sysdate ) <= sysdate
      AND     NVL( end_date, sysdate )   >= sysdate ;

      IF l_count = 0 THEN 
         WarningPrint('Active Grouping Rules have not been set up' );
         ActionWarningPrint('Define Grouping Rules with valid active dates to use Autoinvoice functionality');
      ELSE
         Tab1Print( to_char(l_count) || ' Grouping  Rules have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Grouping Rules" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------- Application Setup, Collectors ------------------------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_COLLECTORS
      WHERE   status = 'A' 
      AND     NVL( inactive_date, sysdate ) >= sysdate;

      IF l_count = 0 THEN 
         ErrorPrint('Active Collectors have not been setup' );
         ActionErrorPrint('Define Collectors with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || ' active Collectors have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Collectors" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ------------------------------ Application Set Up, Remittance Banks  ---------------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AP_BANK_ACCOUNTS a,  
              AP_BANK_BRANCHES c
      WHERE   c.bank_branch_id = a.bank_branch_id
      AND     NVL( c.end_date, sysdate )      >= sysdate
      AND     NVL( a.inactive_date, sysdate ) >= sysdate 
      AND     a.account_type = 'INTERNAL';

      IF l_count = 0 THEN 
         ErrorPrint('Remittance Banks with active Bank Accounts have not been set up' );
         ActionErrorPrint('Define Remittance Banks with active Bank Accounts');
      ELSE
         Tab1Print( to_char(l_count) || ' Remittance Banks have been set up and have active Accounts');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Remittance Banks" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------------- Application Set Up, Salespersons ------------------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    JTF_RS_SRP_VL 
      WHERE   NVL( start_date_active, sysdate )   <= sysdate
      AND     NVL( end_date_active, sysdate )     >= sysdate
      AND     status ='A';

      IF l_count = 0 THEN 
         ErrorPrint('Active Salespersons have not been setup' );
         ActionErrorPrint('Define Salespersons with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || ' active Salespersons have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Salespersons" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------------- Application Set Up, Unit of Measures ----------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    MTL_UNITS_OF_MEASURE_VL
      WHERE   NVL( disable_date, sysdate ) >= sysdate;

      IF l_count = 0 THEN 
         WarningPrint('Unit of Measures have not been set up' );
         ActionWarningPrint('Define Unit of Measures with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || ' active Unit of Measures have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Unit Of measures" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------------- Application Setup, Standard Memo Lines  ------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_MEMO_LINES_VL
      WHERE   NVL( end_date, sysdate ) >= sysdate
      AND     NVL( start_date,sysdate) <= sysdate;

      IF l_count = 0 THEN 
         WarningPrint('Standard Memo Lines have not been setup');
         ActionWarningPrint('Define Standard Memo Lines with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || '  active Standard Memo Lines have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Standard Memo Lines"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ------------------------------- Application Set Up, Lockboxes  ------------------------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_LOCKBOXES
      WHERE   status = 'A';

      IF l_count = 0 THEN 
         WarningPrint('Lockboxes have not been setup. Lockbox functionality cannot be used ' ||
                      'if there are no active lockboxes' );
         ActionWarningPrint('Define Lockboxes with an active status in order to use Lockbox functionality');
      ELSE
         Tab1Print( to_char(l_count) || ' active Lockboxes have been setup');
          
         -- lockboxes with autoassociation checked 

         l_count := 0;
         SELECT  count(*) 
         INTO    l_count 
         FROM    AR_LOCKBOXES
         WHERE   status = 'A' 
         AND     auto_associate = 'Y';
         Tab2Print( to_char(l_count) || ' Lockboxes have "Auto Association" checked ');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Lockboxes" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------------- Application Set Up, Lockbox Transmission formats ------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_TRANSMISSION_FORMATS
      WHERE   status_lookup_code = 'A';

      IF l_count = 0 THEN 
         WarningPrint('Lockbox Transmission Formats have not been setup');
         ActionWarningPrint('Lockbox functionality cannot be used without this set up. Define '||
                            'Transmission Formats with an active status to use Lockbox functionality');
      ELSE
         Tab1Print( to_char(l_count) || '  Lockbox Transmission Formats have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Lockbox Transmission Formats" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------------- Application Set Up, Customer Profile Classes ------------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    HZ_CUST_PROFILE_CLASSES
      WHERE   status = 'A';

      IF l_count = 0 THEN 
         ErrorPrint('Customer Profile Classes have not been set up');
         ActionErrorPrint('Define Customer Profile Classes with Status Active');
      ELSE
         Tab1Print( to_char(l_count) || ' active Customer Profile Classes have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Customer Profile Classes" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------------- Application Set Up, Statement Cycles ------------------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_STATEMENT_CYCLES
      WHERE   status = 'A';

      IF l_count = 0 THEN 
         WarningPrint('Active Statement Cycles have not been set up');
         ActionWarningPrint('When Statements are a business requirement, define active Statement Cycles ' ||
		   'to assign to customers');
      ELSE
         Tab1Print( to_char(l_count) || ' active Statement Cycles have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Statement Cycles" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------------- Application Set Up, Dunning Letter Sets ------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_DUNNING_LETTER_SETS
      WHERE   status = 'A';

      IF l_count = 0 THEN 
         WarningPrint('Active Dunning Letter Sets have not been set up');
         ActionWarningPrint('When Dunning Letters are a business requirement, define active Dunning ' ||
               'Letter Sets to assign to customers');
      ELSE
         Tab1Print( to_char(l_count) || ' active Dunning Letter Sets have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Dunning Letter Sets" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------------- Application Set Up, Price Lists  ------------------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    SO_PRICE_LISTS
      WHERE   NVL( end_date_active, sysdate ) >= sysdate 
      AND     NVL( start_date_active,sysdate) <= sysdate ;
      
      IF l_count = 0 THEN 
         WarningPrint('Active PriceLists have not been set up in Order Management');
         ActionWarningPrint('When using Order Management, define active PriceLists to assign to customers');
      ELSE
         Tab1Print( to_char(l_count) || ' active Pricelists have been set up in Order Management');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Price Lists" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------- Application Set Up, Customer active Bill-to sites  ------------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  COUNT(*)
      INTO    l_count 
      FROM    HZ_CUST_ACCOUNTS a
      WHERE   a.status = 'A'
      AND EXISTS ( SELECT 'x' 
                   FROM   HZ_CUST_SITE_USES u,
                          HZ_CUST_ACCT_SITES s
                   WHERE  u.status = 'A'
                   AND    s.status = 'A'
                   AND    u.site_use_code = 'BILL_TO'
                   AND    u.cust_acct_site_id = s.cust_acct_site_id
                   AND    s.cust_account_id   = a.cust_account_id );

      IF l_count = 0 THEN 
         ErrorPrint('Customers with active bill-to sites have not been defined in this organization' );
         ActionErrorPrint('Define active addresses with active bill-to sites in this organization. Transactions '||
                          'cannot be entered if there are no customers with active bill-to sites');
      ELSE
         Tab1Print( to_char(l_count) || ' Customers have active bill-to sites in this Organization');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Customer bill-to" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* -------------------------------- Application Set Up, Remit to Address -------------------------------- */ 

    BEGIN 
      Tab1Print('Remit to Address Set Up');
     
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_REMIT_TO_ADDRESSES_V a
      WHERE   a.status = 'A' 
      AND     a.address_id in ( SELECT b.address_id 
                                FROM   RA_REMIT_TOS b 
                                WHERE  b.address_id = a.address_id );

      IF l_count = 0 THEN 
         ErrorPrint('Remit to Address has not been set up');
         ActionErrorPrint('Define a Remit to Address with active status and assign a Country');
      ELSE
         Tab2Print( to_char(l_count) || ' Remit to addresses have been set up with countries assigned to it');
      END IF;

      -- checking for remit to address with default country and default state

      l_count := 0;      
      SELECT   count(*) 
      INTO     l_count 
      FROM     RA_REMIT_TOS 
      WHERE    country = 'DEFAULT' 
      and      state   = 'DEFAULT';

      IF l_count = 0 THEN 
         WarningPrint('A Default Remit to Address has not been set up');
         ActionWarningPrint('Define a default Remit to address. Receivables can use this address if the bill-to location on the ' || 
              'transaction is not covered by any other remit-to address assignment. This may happen, for example, ' ||
              'when transactions are created for a new customer' );
      ELSE
         Tab2Print( to_char(l_count) || ' Remit to Addresses have been set up with "Default country" '||
                    'and "Default state" assignments');
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Remit To address" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ----------------------------------- Application Set Up, Approval Limits ---------------------------- */ 

    BEGIN 
      Tab1Print('Approval Limits Set Up');
      
      -- approval limit set up document type ADJ ( Adjustments )
      l_count := 0;
      SELECT count(*)
      INTO   l_count 
      FROM   AR_APPROVAL_USER_LIMITS 
      WHERE  document_type = 'ADJ';

      IF l_count = 0 THEN 
         WarningPrint('Approval Limits have not been set up for any users for "Adjustments"');
         ActionWarningPrint('Define Approval Limits for users for "Adjustments"');
      ELSE 
         Tab2Print( 'Approval Limits have been set for ' || to_char(l_count) || ' users for "Adjustments"');  
      END IF; 

      -- approval limit set up document type CM ( Credit Memo ) 
      l_count := 0;
      SELECT count(*)
      INTO   l_count 
      FROM   AR_APPROVAL_USER_LIMITS 
      WHERE  document_type = 'CM';

      IF l_count = 0 THEN 
         WarningPrint('Approval Limits have not been set up for any users for "Credit Memo"');
         ActionWarningPrint('Define Approval Limits for users for "Credit Memo"');
      ELSE 
         Tab2Print( 'Approval Limits have been set for ' || to_char(l_count) || ' users for "Credit Memo"');  
      END IF; 

      -- approval limit set up document type  WRTOFF ( Receipt Write-off ) 
      l_count := 0;
      SELECT count(*)
      INTO   l_count 
      FROM   AR_APPROVAL_USER_LIMITS 
      WHERE  document_type = 'WRTOFF';

      IF l_count = 0 THEN 
         WarningPrint('Approval Limits have not been set up for any users for "Receipt Write-off"');
         ActionWarningPrint('Define Approval Limits for users for "Receipt Write-off"');
      ELSE 
         Tab2Print( 'Approval Limits have been set for ' || to_char(l_count) || ' users for "Receipt Write-off"');  
      END IF; 
      
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Approval Limits" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* -------------------------------- Application Setup, Receivables activities----------------------------- */ 

    DECLARE
      misccash     boolean := false;
      writeoff     boolean := false;
 
      CURSOR C1 IS 
        SELECT count(*)                                                  total,
               type,
               decode ( type, 'ADJUST',   'Adjustment',
                              'EDISC' ,   'Earned Discount', 
                              'FINCHRG',  'Finance Charges',
                              'MISCCASH', 'Misc Cash',
                              'UNEDISC',  'Unearned Discount',
                              'WRITEOFF', 'Write Off', type )         type_desc 
        FROM   AR_RECEIVABLES_TRX 
        WHERE  receivables_trx_id > 0  
        AND    status = 'A' 
        GROUP BY type;

      CURSOR C2 IS 
        SELECT  Name,
                decode (STATUS, 'A','Active',
                                'I','Inactive', status )     status,
                receivables_trx_id                               id,
                type, 
                code_combination_id                            ccid,
                gl_account_source                            source
        FROM    AR_RECEIVABLES_TRX 
        WHERE   receivables_trx_id < 0;

    BEGIN 
      Tab1Print('Non Seeded Receivables Activities');

      -- non seeded receivables activities 

      l_count := 0;
      FOR c1_rec IN C1 LOOP
          Tab2Print( to_char(c1_rec.total) || '  active Receivables Activities have been set up '||
                     'with type "' || c1_rec.type_desc ||'"');
          IF c1_rec.type = 'MISCCASH' THEN 
             misccash := true;              
          END IF;
          IF c1_rec.type = 'WRITEOFF' THEN 
             writeoff := true;
          END IF;
          l_count := l_count + 1; 
      END LOOP;

      IF l_count = 0 THEN 
         ErrorPrint('Active Receivables Activities have not been set up');
         ActionErrorPrint('Define Receivable Activities with an active status');
      ELSE 
         IF NOT misccash THEN 
            ErrorPrint('There are no active Receivable Activities set up for type "Misc Cash"');
            ActionErrorPrint('Define Receivable Activities with active status for type "Misc Cash"');
         END IF; 
         IF NOT writeoff THEN 
            ErrorPrint('There are no active Receivable Activities set up for type "Write Off"');
            ActionErrorPrint('Define Receivable Activities with active status for type "Write Off"');
         END IF; 
      END IF; 
   
      -- Seeded receivables activities 

      Tab2Print('Seeded Receivables Activities :'); 
      FOR c2_rec IN C2 LOOP
          Tab3Print('"' || c2_rec.name || '". . . . . . Status: ' || c2_rec.status );
          IF  c2_rec.id in ( -11, -12 ) THEN 
              IF substr(c2_rec.status, 1, 1 ) = 'I' THEN  
                 WarningPrint( c2_rec.name || ' is inactive');
                 ActionWarningPrint('This should be active to use Chargeback functionality');
              END IF;
              IF c2_rec.source = 'ACTIVITY_GL_ACCOUNT' AND c2_rec.ccid = 0 THEN 
                 WarningPrint('Activity GL Account is blank for '||  c2_rec.name );
                 ActionWarningPrint('Gl Account should be filled in to use Chargeback functionality');
              END IF; 
           END IF;
      END LOOP;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Receivables Activities" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ------------------------ Exception Section : Main Program ( Part 1 ) ----------------------------- */ 
/* Whenever an exception was raised set the variable v_abort to 'Y' so Part 2 of the MAin Program     */
/* also knows to do nothing                                                                           */
/*----------------------------------------------------------------------------------------------------*/

  EXCEPTION   -- begin 2 
    WHEN STOPEXECUTION THEN     
         brprint;
         Show_Footer('&v_scriptlongname', '&v_headerinfo');
         brprint;
         :v_abort := 'Y'; 
    WHEN OTHERS THEN  
         brprint;
         ErrorPrint(sqlerrm||' occurred in diagnostic test');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
         brprint;
         Show_Footer('&v_scriptlongname', '&v_headerinfo');
         brprint; 
         :v_abort := 'Y';
  END;   --end2 

EXCEPTION  --  begin 1  
  WHEN OTHERS then   -- exceptions begin 1
       Brprint;
       Errorprint(sqlerrm||' occurred in diagnostic test');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');
       Brprint; 
       Show_Footer('&v_scriptlongname', '&v_headerinfo');
       Brprint;
       :v_abort := 'Y'; 
END; 
/

REM =========================================================================================
REM
REM    Because the above block became too big and resulted in a PLS-123 Program TOO Large 
REM    We needed to split up the original Main block in Two plsql Blocks 
REM     
REM =========================================================================================
REM ====================== Run the Pl/SQL api file again ==================================== 
@@CoreApiHtml.sql

/*------------------------ Define procedure getAutoAccCCidDetails -------------------------*/ 

function getAutoAccCcidDetails ( p_typedesc            varchar2, 
                                 p_type                varchar2, 
                                 p_transType_Flag      varchar2, 
                                 p_site_Flag           varchar2, 
                                 p_salesrep_Flag       varchar2, 
                                 p_tax_Flag            varchar2, 
                                 p_standardLine_Flag   varchar2, 
                                 p_remittanceBank_Flag varchar2 ) return VARCHAR IS
  t_count             number;
  t_whereclause       varchar2(200) := NULL;
  t_purpose           varchar2(10)  := NULL;
  t_accountname       varchar2(30)  := NULL;
  t_sqltxt            varchar2(3000);
  t_cursor            integer;
  t_counter           integer;
  t_orgid             Number; 
  null_accounts_found varchar2(5) := 'FALSE';

BEGIN
  
  -- handling taxflag : check for taxcodes with null Tax accounts

  IF p_tax_flag = 'Y' THEN 
     t_count := 0;

     SELECT  count(*)
     INTO    t_count 
     FROM    AR_VAT_TAX
     WHERE   tax_type <> 'TAX_GROUP'
     AND     NVL( end_date,   sysdate ) >= sysdate
     AND     NVL( start_date, sysdate)  <= sysdate
     AND     enabled_flag = 'Y'
     AND     tax_account_id is null;
 
     Tab2Print('There are ' || to_char(t_count) || ' Tax Codes with null "Tax" Account'); 
     IF t_count > 0 THEN 
        null_accounts_found := 'TRUE';
     END IF;
  END IF;

  -- handling transaction type flag : check for transaction types with null accounts
  -- Depending on the type of the transaction ( Bills receivable or not ) certain accounts
  -- are always null 

  IF p_transType_Flag = 'Y' THEN 
     t_whereclause := NULL;
     t_sqltxt      := NULL;
     t_count       := NULL;

     IF    p_type = 'REV' THEN 
        t_whereclause := 'gl_id_rev is NULL and type <> ''BR'' ';
     ELSIF p_type = 'REC' THEN 
        t_whereclause  := 'gl_id_rec is NULL and type <> ''BR'' ';
     ELSIF p_type = 'FREIGHT' THEN 
        t_whereclause  := 'gl_id_freight is NULL and type <> ''BR'' ';
     ELSIF p_type = 'SUSPENSE' THEN  
        t_whereclause  := 'gl_id_clearing  is NULL and type <> ''BR'' ';
     ELSIF p_type = 'TAX' THEN  
        t_whereclause  := 'gl_id_tax is NULL and type <> ''BR'' ';
     ELSIF p_type = 'UNBILL' THEN 
        t_whereclause  := 'gl_id_unbilled is NULL and type <> ''BR'' ';
     ELSIF p_type = 'UNEARN' THEN 
        t_whereclause  := 'gl_id_unearned  is NULL and type <> ''BR'' ';
     ELSIF p_type = 'BR_REC' THEN 
        t_whereclause  := 'gl_id_rec  is NULL and type = ''BR'' ';
     ELSIF p_type = 'BR_UNPAID_REC' THEN  
        t_whereclause  := 'gl_id_unpaid_rec is NULL and type = ''BR'' ';
     ELSIF p_type = 'BR_REMITTANCE' THEN 
        t_whereclause  := 'gl_id_remittance is NULL and type = ''BR'' ';
     ELSIF p_type = 'BR_FACTOR' THEN 
        t_whereclause  := 'gl_id_factor is NULL and type = ''BR'' ';
     END IF; 
  
     IF t_whereclause IS NOT NULL THEN 

        t_sqltxt := 'SELECT     count(*) ' ||
                    'FROM       RA_CUST_TRX_TYPES ' ||
                    'WHERE      NVL( start_date, sysdate ) <= sysdate  '|| 
                    'AND        NVL( end_date, sysdate)    >= sysdate '||
                    'AND        NVL( status,''A'') =''A''' ||
                    'AND '      || t_whereclause ;

        t_cursor := dbms_sql.open_cursor;
        dbms_sql.parse(t_cursor, t_sqltxt, dbms_sql.native);
        dbms_sql.define_column(t_cursor, 1, t_count);
        t_counter := dbms_sql.execute(t_cursor);
        WHILE dbms_sql.fetch_rows(t_cursor) > 0 LOOP   
        dbms_sql.column_value(t_cursor, 1, t_count);
        END LOOP; 
     
        Tab2Print('There are '|| to_char(t_count) || ' Transaction Types with null "' || 
                  p_typedesc || '" Account');
        IF t_count > 0 THEN 
           null_accounts_found := 'TRUE'; 
        END IF;
     END IF;
  END IF;   

  -- handling customer site flag : check for customer sites with null accounts
  -- Bill-to sites must be checked for the normal accounts 
  -- Drawee sites must be checked for the bills Receivable accounts 

  IF p_site_flag = 'Y' THEN 
     t_whereclause := NULL;
     t_purpose     := 'Bill-To';
     t_sqltxt      := NULL;
     t_count       := NULL;
     IF p_type = 'REV' THEN 
        t_whereclause := 'gl_id_rev is NULL and site_use_code = ''BILL_TO'' ';
     ELSIF p_type = 'REC' THEN 
        t_whereclause  := 'gl_id_rec  is NULL and site_use_code = ''BILL_TO'' ';
     ELSIF p_type = 'FREIGHT' THEN 
        t_whereclause  := 'gl_id_freight is NULL and site_use_code = ''BILL_TO'' ';
     ELSIF p_type = 'SUSPENSE' THEN  
        t_whereclause  := 'gl_id_clearing is NULL and site_use_code = ''BILL_TO'' ';
     ELSIF p_type = 'TAX' THEN 
        t_whereclause  := 'gl_id_tax is NULL and site_use_code = ''BILL_TO'' ';
     ELSIF p_type = 'UNBILL' THEN  
        t_whereclause  := 'gl_id_unbilled is NULL and site_use_code = ''BILL_TO'' ';
     ELSIF p_type = 'UNEARN' THEN 
        t_whereclause  := 'gl_id_unearned is NULL and site_use_code = ''BILL_TO'' ';
     ELSIF p_type = 'BR_REC' THEN 
        t_whereclause  := 'gl_id_rec is NULL and site_use_code = ''DRAWEE'' ';
        t_purpose      := 'Drawee';
     ELSIF p_type = 'BR_UNPAID_REC' THEN  
        t_whereclause  := 'gl_id_unpaid_rec is NULL and site_use_code = ''DRAWEE'' ';
        t_purpose      := 'Drawee';
     ELSIF p_type = 'BR_REMITTANCE' THEN         
        t_whereclause  := 'gl_id_remittance is NULL and site_use_code = ''DRAWEE'' ';
        t_purpose      := 'Drawee';
     ELSIF p_type = 'BR_FACTOR' THEN  
        t_whereclause  := 'gl_id_factor is NULL and site_use_code = ''DRAWEE'' ';
        t_purpose      := 'Drawee';
     END IF; 
          
     IF t_whereclause is NOT NULL THEN  

        t_sqltxt := 'SELECT count(*) '||
                    'FROM   AR_SITE_USES_V ' ||
                    'WHERE  status =''A'' ' ||
                    'AND  ' || t_whereclause;

        t_cursor := dbms_sql.open_cursor;
        dbms_sql.parse(t_cursor, t_sqltxt, dbms_sql.native);
        dbms_sql.define_column(t_cursor, 1, t_count);
        -- count(*) always returns One row   
        t_counter := dbms_sql.execute(t_cursor);
        WHILE dbms_sql.fetch_rows(t_cursor) > 0 LOOP   
          dbms_sql.column_value(t_cursor, 1, t_count);
        END LOOP; 
      
        Tab2Print('There are ' || to_char(t_count) || ' ' || t_purpose || ' Customer Sites with null "'|| 
                  p_typedesc || '" Account' );
        IF t_count > 0 THEN 
           null_accounts_found := 'TRUE';
        END IF;
     END IF;

  END IF;

  -- handling salesrep flag : check for salespersons with null accounts
  -- not used for Bill Receivables 

  IF p_salesrep_flag = 'Y' THEN 
     t_whereclause := NULL;
     t_accountname := NULL; 
     t_sqltxt      := NULL;
     t_count       := NULL;
     IF p_type IN ('REV', 'UNEARN', 'SUSPENSE', 'TAX' )  THEN 
        t_whereclause  := 'gl_id_rev';
        t_accountname  := 'Revenue';
     ELSIF p_type in ('REC','UNBILL') THEN 
        t_whereclause  := 'gl_id_rec';
        t_accountname  := 'Receivable';
     ELSIF p_type = 'FREIGHT' THEN
        t_whereclause  := 'gl_id_freight';
        t_accountname  := 'Freight';
     END IF;   

     IF t_whereclause is NOT NULL THEN 
        t_sqltxt := 'SELECT  count(*) '||
                    'FROM    jtf_rs_srp_vl '||
                    'WHERE   status = ''A'' '|| 
                    'AND     NVL( start_date_active, sysdate) <= sysdate '||
                    'AND     NVL( end_date_active,   sysdate) >= sysdate '||  
                    'AND '|| t_whereclause || ' IS NULL';

        t_cursor := dbms_sql.open_cursor;
        dbms_sql.parse(t_cursor, t_sqltxt, dbms_sql.native);
        dbms_sql.define_column(t_cursor, 1, t_count);
        -- count(*) always returns One row   
        t_counter := dbms_sql.execute(t_cursor);
        WHILE dbms_sql.fetch_rows(t_cursor) > 0 LOOP   
          dbms_sql.column_value(t_cursor, 1, t_count);
        END LOOP; 
   
        Tab2Print('There are '|| to_char(t_count) || ' Salespersons with null "' || t_accountname ||  '" Account');
        IF t_count > 0 THEN 
           null_accounts_found := 'TRUE';
        END IF;
     END IF;

  END IF;

  -- handling remittance  : check for remittance banks with null accounts
  -- only applies to Remitted and Factored Bills Receivable 
  
  IF p_remittanceBank_Flag = 'Y' THEN 
     t_whereclause := NULL;
     t_sqltxt      := NULL;
     t_count       := NULL;
 
     IF p_type = 'BR_REMITTANCE' THEN 
        t_whereclause := 'br_remittance_ccid';
     ELSIF p_type = 'BR_FACTOR' THEN 
        t_whereclause := 'br_factor_ccid';
     END IF; 
          
     IF t_whereclause is NOT NULL THEN  
        t_sqltxt := 'SELECT  count(*) FROM AR_RECEIPT_METHOD_ACCOUNTS '||
                    'WHERE   NVL( start_date, sysdate) <= sysdate '||
                    'AND     NVL( end_date, sysdate)   >= sysdate '||  
                    'AND '   || t_whereclause || ' IS NULL';

        t_cursor := dbms_sql.open_cursor;
        dbms_sql.parse(t_cursor, t_sqltxt, dbms_sql.native);
        dbms_sql.define_column(t_cursor, 1, t_count);
        -- count(*) always returns One row   
        t_counter := dbms_sql.execute(t_cursor);
        WHILE dbms_sql.fetch_rows(t_cursor) > 0 LOOP   
          dbms_sql.column_value(t_cursor, 1, t_count);
        END LOOP; 
   
        Tab2Print('There are '|| to_char(t_count) || ' Remittance Banks with null "' || p_typedesc ||  '" Account');
        IF t_count > 0 THEN 
           null_accounts_found := 'TRUE';
        END IF;
     END IF;
    
  END IF;

  -- handling standardLineFlag : check memolines and inventory items  

  IF p_standardLine_flag = 'Y' THEN 

     -- Checking memolines - count records with null Revenue Account 

     t_count := 0; 

     SELECT    count(*) 
     INTO      t_count 
     FROM      AR_MEMO_LINES_VL 
     WHERE     NVL( start_date, sysdate) <= sysdate
     AND       NVL( end_date, sysdate)   >=sysdate  
     AND       gl_id_rev IS NULL; 

     Tab2Print ('There are ' || to_char(t_count) || ' Standard Memo Lines with null "Revenue" Account'); 
     IF t_count > 0 THEN 
        null_accounts_found := 'TRUE';
     END IF;

     -- Pick up org_id from OE_SYSTEM_PARAMETERS  ( needed as input to check inventory items ) 
     -- when select from oe_system_parameters fails, we are unable to check inventory items 
      
     BEGIN 
       SELECT  master_organization_id 
       INTO    t_orgid
       FROM    OE_SYSTEM_PARAMETERS;
  
    -- Checking inventory Items - count records with null Sales Account 

       t_count := 0;
 
       SELECT  count(*)
       INTO    t_count
       FROM    MTL_SYSTEM_ITEMS
       WHERE   NVL( end_date_active, sysdate)   >= sysdate 
       AND     NVL( start_date_active, sysdate) <= sysdate
       AND     organization_id = t_orgid 
       AND     sales_account IS NULL ;

       Tab2Print('There are ' || to_char(t_count) || ' Inventory Items with null "Sales" Account" in Inventory '||
                 'Organization '|| to_char(t_orgid) ); 
       IF t_count > 0 THEN 
          null_accounts_found := 'TRUE';
       END IF;

     EXCEPTION 
       WHEN NO_DATA_FOUND THEN 
            null; 
     END;
     
  END IF;

  return null_accounts_found;

EXCEPTION 
  WHEN OTHERS THEN 
       Errorprint(sqlerrm||' occurred in test when calling "getAutoAccCcidDetails" ');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');
       return null_accounts_found;
END getAutoAccCcidDetails;

/*------------------------ Define procedure getAutoAccDetails -------------------------------------*/ 

Function getAutoAccDetails ( p_typedesc    varchar2, 
                             p_ccid        number, 
                             p_type        varchar2, 
                             p_lastupddate date ) return VARCHAR IS 

  t_tablename              varchar2(30) := 0;
   
  t_salesrep_flag          varchar2(1)  := 'N';
  t_site_flag              varchar2(1)  := 'N'; 
  t_standardline_flag      varchar2(1)  := 'N';
  t_transtype_flag         varchar2(1)  := 'N'; 
  t_tax_flag               varchar2(1)  := 'N';
  t_remittancebank_flag    varchar2(1)  := 'N'; 

  t_count                  number  := 0;
  t_sqltxt                 varchar2(32767);
  null_accounts_found      varchar2(5)  := 'FALSE';

  CURSOR C1 IS 
    SELECT    decode( e.table_name,'RA_CUST_TRX_TYPES',  'Transaction Types', 
                                   'RA_SITE_USES',       'Site',
                                   'RA_SALESREPS',       'Salesreps',
                                   'RA_TAXES',           'Taxes',
                                   'RA_STD_TRX_LINES',   'Standard Lines',
                                   'AR_RECEIPT_METHOD_ACCOUNTS', 'Remittance Banks', e.table_name ) TableName
    FROM      FND_ID_FLEX_SEGMENTS_VL b, 
              GL_SETS_OF_BOOKS_V c,
              AR_SYSTEM_PARAMETERS d , 
              RA_ACCOUNT_DEFAULT_SEGMENTS e
    WHERE     b.application_id = 101 
    AND       d.set_of_books_id = c.set_of_books_id 
    AND       b.id_flex_num = c.chart_of_accounts_id 
    AND       e.segment = b.application_column_name
    AND       e.gl_default_id = p_ccid;
   
BEGIN
  Tab1Print('AutoAccounting Set Up for "' || p_typedesc || '" Account   Last Update Date : '|| to_char(p_lastupdDate) );

  FOR C1_rec in C1 LOOP 
      IF c1_rec.TableName is NOT NULL THEN 
         IF c1_rec.TableName = 'Transaction Types' THEN  
            t_transtype_flag := 'Y';
         ELSIF c1_rec.TableName = 'Site' THEN 
            t_site_flag := 'Y'; 
         ELSIF c1_rec.TableName = 'Salesreps' THEN 
            t_salesrep_flag := 'Y';          
         ELSIF c1_rec.TableName = 'Taxes' THEN 
            t_tax_flag := 'Y';
         ELSIF  c1_rec.TableName = 'Standard Lines' THEN 
            t_standardline_flag := 'Y';
         ELSIF  c1_rec.TableName = 'Remittance Banks' THEN 
            t_remittancebank_flag := 'Y';
         END IF;
      END IF; 
      t_count := t_count + 1 ;
  END LOOP; 

  IF t_count = 0 THEN 
     ErrorPrint('AutoAccounting has not been set up for "' || p_typedesc || '"');
     ActionErrorPrint('Please set up AutoAccounting for "' || p_typedesc || '"');
  ELSE 

  -- display Autoaccounting detais in table format 
  
     t_sqltxt := 'SELECT    b.segment_name Segment ,' ||
                 '  decode( e.table_name, ''RA_CUST_TRX_TYPES'', ''Transaction Types'', '|| 
                 '          ''RA_SITE_USES'',        ''Site'', '||
                 '          ''RA_SALESREPS'',        ''Salesreps'', '||
                 '          ''RA_TAXES'',            ''Taxes'', '||
                 '          ''RA_STD_TRX_LINES'',    ''Standard Lines'', '||
                 '          ''AR_RECEIPT_METHOD_ACCOUNTS'', ''Remittance Banks'', e.table_name )   TableName,  '||
                 '          e.constant     Constant '||  
                 'FROM      FND_ID_FLEX_SEGMENTS_VL b, '|| 
                 '          GL_SETS_OF_BOOKS_V c, '||
                 '          AR_SYSTEM_PARAMETERS d , '||
                 '          RA_ACCOUNT_DEFAULT_SEGMENTS e '||
                 'WHERE     b.application_id = 101 ' ||
                 'AND       d.set_of_books_id = c.set_of_books_id '||
                 'AND       b.id_flex_num = c.chart_of_accounts_id '|| 
                 'AND       e.segment = b.application_column_name '||
                 'AND       e.gl_default_id = ' || to_char(p_ccid) ;

      Run_sql( null, t_sqltxt, 'N', null, 1 );
      BrPrint;
  END IF;   
  
  -- Whevever a table is referenced check that table for corresponding null accounts  

  null_accounts_found :=  getAutoaccCcidDetails ( p_typedesc, 
                                                  p_type, 
                                                  t_transType_Flag, 
                                                  t_site_Flag, 
                                                  t_salesrep_Flag,  
                                                  t_tax_Flag, 
                                                  t_standardLine_Flag, 
                                                  t_remittanceBank_Flag) ;
  Brprint;
  return null_accounts_found; 

EXCEPTION 
  WHEN OTHERS THEN 
       Errorprint(sqlerrm||' occurred in test when calling "getAutoAccDetails" ');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');
       return null_accounts_found;
END getAutoAccDetails;

/*-------------------------- Define procedure getARQuickCode  ------------------------------------------*/ 

procedure getARQuickCode  ( p_quickcodename    varchar2 ) IS 
  t_count      NUMBER; 
BEGIN 
  t_count := 0;

  SELECT   count(*) 
  INTO     t_count 
  FROM     FND_LOOKUP_TYPES_VL a,
           FND_LOOKUP_VALUES_VL b 
  WHERE    a.application_id = 222
  AND      a.lookup_type = p_quickcodename
  AND      a.lookup_type = b.lookup_type 
  AND      b.enabled_flag = 'Y'; 

  IF t_count = 0 THEN 
     WarningPrint('"' || p_quickcodename || '" has not been set up' );
     ActionWarningPrint('Set up QuickCode "'  || p_quickcodename || '"' );
  ELSE 
     Tab2Print('"'|| p_quickcodename || '" is set up' );
  END IF;

EXCEPTION 
  WHEN OTHERS THEN 
       Errorprint(sqlerrm||' occurred in test when calling "getARQuickcode" ');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');

END getARQuickCode;

/*------------------------------- Start Of the Main Program ( Part 2 )-----------------------------*/

BEGIN  -- begin 1
  DECLARE -- declare 2 
    p_username     varchar2(100);   
    p_respid       number;
    
    l_count        number  := 0;
    sqltxt         varchar2(32767);
    l_counter      integer;
    l_cursor       integer; 

    STOPEXECUTION  exception;

  BEGIN  -- begin2 

/* ----------------------------- Set Client again -------------------------------------------------*/

  -- The following line is needed for the included API - do NOT remove it, otherwise the test 
  -- will fail  
      
    DBMS_LOB.CREATETEMPORARY(:g_hold_output,TRUE,DBMS_LOB.SESSION);

  -- if the first block was aborted then this block needs to stop immediately 
 
    IF :v_abort = 'Y' THEN
       BrPrint;
       RAISE StopExecution ;
    END IF;

    p_username := :v_username;

    IF &v_respid IS NULL THEN
       p_respid := -10;     
    ELSE        
       p_respid := TO_NUMBER(&v_respid);
    END IF; 

    Set_Client(p_username, p_respid);
    Brprint; 
        
/* ------------------------------------- Auto Accounting SetUp -------------------------------------------- */ 

    DECLARE
      report_warning        VARCHAR2(5) := 'FALSE';
      null_accounts_found   VARCHAR2(5) := 'TRUE'; 
      CURSOR C1 IS 
        SELECT  decode(type, 'SUSPENSE',      'AutoInvoice Clearing',
                             'FREIGHT',       'Freight',
                             'REC',           'Receivable',
                             'TAX',           'Tax',
                             'UNBILL',        'Unbilled Receivable', 
                             'UNEARN',        'Unearned Revenue',
                             'BR_REC',        'Bills Receivable',
                             'REV',           'Revenue',
                             'BR_FACTOR',     'Factored Bills Receivable',
                             'BR_REMITTANCE', 'Remitted Bills Receivable',
                             'BR_UNPAID_REC', 'Unpaid Bills Receivable', type )  type_desc, 
                              gl_default_id                   ccid,
                              type,
                              last_update_date 
        FROM    RA_ACCOUNT_DEFAULTS;

    BEGIN 
      SectionPrint('AutoAccounting Set Up');

      l_count := 0;
      FOR c1_rec in C1 LOOP 
          null_accounts_found := getAutoAccDetails (c1_rec.type_desc, 
                                                    c1_rec.ccid, 
                                                    c1_rec.type, 
                                                    c1_rec.last_update_date);
          l_count := l_count + 1;  
          IF null_accounts_found = 'TRUE' THEN 
             report_warning := 'TRUE';
          END IF; 

      END LOOP; 

      IF l_count = 0 THEN 
         ErrorPrint('AutoAccounting is not set up' );
         ActionErrorPrint('Please Refer to AR Users Guide to set up AutoAccounting');
      END IF;
      BrPrint; 

      IF report_warning = 'TRUE' THEN 
         WarningPrint('Certain tables have null accounts and as such AutoAccounting will be unable to derive an account');
         ActionWarningLink('See Note : ','171516.1',' to assist in finding and resolving the records with null accounts');
      END IF; 

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Autoaccounting Set Up" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------------------- QuickCodes -------------------------------------------------------*/ 

    BEGIN 

      SectionPrint('QuickCodes');

      -- Receivables Quickcodes --

      Tab1Print('Customer QuickCodes');
      getARQuickCode('ADDRESS_CATEGORY');
      getARQuickCode('SITE_USE_CODE');
      getARQuickCode('CUSTOMER_CATEGORY');
      getARQuickCode('CUSTOMER CLASS');
      getARQuickCode('FOB');
      getARQuickCode('LANGUAGE');
      getARQuickCode('RESPONSIBILITY');
      getARQuickCode('CONTACT_TITLE');
      getARQuickCode('COMMUNICATION_TYPE');
	getARQuickCode('PHONE_LINE_TYPE');
	getARQuickCode('CONTACT_POINT_PURPOSE');
	getARQuickCode('EMAIL_FORMAT');
      getARQuickCode('RELATIONSHIP_TYPE');
      getARQuickCode('STATE');
      getARQuickCode('COUNTRY');

      -- Customer Profile QuickCodes --

      BrPrint;
      Tab1Print('Customer Profile QuickCodes');
      getARQuickCode('ACCOUNT_STATUS');
      getARQuickCode('CREDIT_RATING');
      getARQuickCode('RISK_CODE');
	getARQuickCode('PERIODIC_REVIEW_CYCLE');

      -- Transaction Quickcodes --

      BrPrint;
      Tab1Print('Transaction QuickCodes');
      getARQuickCode('ADJUST_REASON');
      getARQuickCode('APPROVAL_TYPE');
      getARQuickCode('BATCH_STATUS');
      getARQuickCode('AR_CANADIAN_PROVINCE');
      getARQuickCode('CREDIT_MEMO_REASON');
      getARQuickCode('INVOICING_REASON');
      getARQuickCode('ARTAXVDR_LOC_QUALIFIER');
      getARQuickCode('MAGNETIC_FORMAT_CODES');
      getARQuickCode('SPECIAL_INSTRUCTIONS');
      getARQuickCode('AR_TAX_CLASSIFICATION');
      getARQuickCode('TAX_REASON');
      getARQuickCode('TAX_EXCEPTION_REASON');
      getARQuickCode('TAX_TYPE');
      getARQuickCode('STANDARD_MSG_TYPES');
      getARQuickCode('STANDARD_TEXT');

      -- Collections Quickcodes --

      BrPrint;
      Tab1Print('Collections QuickCodes');
      getARQuickCode('ACTION');
      getARQuickCode('FOLLOW_UP');
      getARQuickCode('CUSTOMER_RESPONSE_REASON');
      getARQuickCode('CALL_OUTCOME');
      getARQuickCode('AGING_BUCKET_LINE_TYPE');

      -- Receipts Quickcodes --
    
      BrPrint;
      Tab1Print('Receipts QuickCodes');
      getARQuickCode('ARLPLB_MATCHING_OPTION');
      getARQuickCode('ARLPLB_USE_MATCHING_DATE');
      getARQuickCode('CASH_RECEIPT_TYPE');
      getARQuickCode('MANDATORY_FIELD_PROMPT');
      getARQuickCode('CKAJST_REASON');

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "QuickCodes" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* -------------------------------------- TAX Profile  Options -------------------------------------- */ 
/*   The profile options in comments are not in then user guide and will therefore not be listed      */
/*   Profile options that have become obsolete have their end_active_date set --> in that case        */
/*   they are automatically not reported by the API checkProfile                                      */    
/*----------------------------------------------------------------------------------------------------*/                     

    DECLARE 
      t_oeinvoicefreight        varchar2(240)    := NULL; 
      t_artaxusevendor          varchar2(240)    := NULL; 
      t_artaxvendor             varchar2(240)    := NULL;
      t_taxdatabaseviewset      varchar2(30)     := NULL; 
    BEGIN 
      SectionPrint('Tax Profile Options'); 
 
      -- Tax: Calculate tax on credit memos - Required, default is 'No'
      -- Obsolete since AR.H - 11.5.7 ( See Note 198214.1 ) - Moved to system Options
      -- Unfotunately this profile option has not become enddated 
      IF column_exists('AR_SYSTEM_PARAMETERS','CALC_TAX_ON_CREDIT_MEMO_FLAG') = 'N' THEN
         CheckProfile('AR_CALCULATE_TAX_ON_CM', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'W');
      END IF;  

      -- Tax: Invoice Freight as Revenue -- Optional, default 'No' 
      t_oeinvoicefreight := CheckProfile('OE_INVOICE_FREIGHT_AS_LINE', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' );
      IF t_oeinvoicefreight = 'Y' THEN 
      -- Tax: Inventory Item for Freight -- required, no default
         CheckProfile('OE_INVENTORY_ITEM_FOR_FREIGHT', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' ); 
      END IF;

      -- Tax: Allow Manual Tax Lines -- optional, default 'Yes' 
      CheckProfile('AR_ALLOW_MANUAL_TAX_LINES', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' ); 

      -- Tax: Allow Override of Tax Code -- optional, default 'No' 
      CheckProfile('AR_ALLOW_TAX_CODE_OVERRIDE', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 
      
      -- Tax: Allow Ad Hoc Tax Changes -- optional, default 'No' 
      CheckProfile('AR_ALLOW_TAX_UPDATE', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 

      -- Tax: Allow Override of Customer Exemptions -- optional, default 'No'
      CheckProfile('AR_ALLOW_TRX_LINE_EXEMPTIONS', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 

      -- Tax: Use Tax Vendor -- optional, default 'No'  
      t_artaxusevendor := CheckProfile('AR_TAX_USE_VENDOR', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 
 
      BEGIN
        SELECT decode(tax_database_view_set,'_A','Taxware',
                                            '_V','Vertex',
                                            'O','Oracle', tax_database_view_set )
        INTO   t_taxdatabaseviewset
        FROM   AR_SYSTEM_PARAMETERS;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN       
             ErrorPrint ('AR System Options have not been defined for this Operating Unit. '||
                         'Unable to verify how Tax Vendor Views are defined');
             ACtionErrorPrint ('Please refer to Users Guide and define AR System Options');
      END;

      IF t_artaxusevendor = 'Y' THEN 

         -- Tax: Use Tax PL/SQL Vendor -- optional, default 'Null' 
         t_artaxvendor := CheckProfile('AR_TAX_USE_PLSQL_VENDOR', g_user_id, g_resp_id, g_appl_id, '"Null"' , 2, 0, 'N' );

         IF UPPER(t_artaxvendor) =  UPPER(t_taxdatabaseviewset) then  

            IF t_taxdatabaseviewset = 'Taxware' THEN 
 
               -- Tax Taxware: Tax Selection -- Optional, no default, a value of null = 'Jurisdiction and Tax' 
               CheckProfile('TAXVDR_TAXSELPARAM', g_user_id, g_resp_id, g_appl_id, '"Jurisdiction and Tax"' , 2, 0, 'N' );

               -- Tax Taxware: Use Nexpro  -- optional, no default, a value of null = 'No'  
               CheckProfile('TAXVDR_USENEXPRO', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );
 
               -- Tax Taxware: Tax Type  -- optional, no default, a value of null = 'Sales' 
               CheckProfile('TAXVDR_TAXTYPE', g_user_id, g_resp_id, g_appl_id, '"Sales"', 2, 0, 'N' );
        
               -- Tax Taxware: Service Indicator--  optional, no default, a value of null = 'Non-service'   
               CheckProfile('TAXVDR_SERVICEIND', g_user_id, g_resp_id, g_appl_id, '"Non-service"', 2, 0, 'N' );
 
            ELSIF t_taxdatabaseviewset = 'Vertex' THEN  

               -- Tax Vertex: Secondary Taxes --optional, no default, a value of null = 'Use Secondary Taxes' 
               CheckProfile('TAXVDR_SECTAXS', g_user_id, g_resp_id, g_appl_id, '"Use Secondary Taxes"', 2, 0, 'N' );

               -- Tax Vertex: Case Sensitive -- Optional, no default 
               CheckProfile('TAXVDR_CASESENSITIVE', g_user_id, g_resp_id, g_appl_id, '"Yes"', 2, 0, 'N' );
            
            END IF; 

         ELSE
            ErrorPrint('"Tax Vendor Views" in System Options  is set to "'|| t_taxdatabaseviewset  || 
                       '" , but profile option "Tax: Use Tax PL/SQL Vendor" is set to "' || t_artaxvendor || '"' );
            ActionErrorPrint('Change either "Tax Vendor Views"  in System Options or change the profile option '||
                             '"Tax: Use Tax PL/SQL Vendor" so both values match'); 

         END IF; 
  
      ELSIF t_artaxusevendor = 'N' THEN 
 
           IF  t_taxdatabaseviewset IN ('Taxware', 'Vertex' ) THEN 
               ErrorPrint('"Tax Vendor Views" is set to ' || t_taxdatabaseviewset || ' in System '||
                          'Options but "Tax: Use Tax Vendor" profile option is not "Yes" ');
               ActionErrorPrint('Set "Tax: Use Tax Vendor" to "Yes" when using Vertex or Taxware'); 
           END IF; 

           Tab2Print('"Tax: Use Tax Vendor" is set to "No". Not checking Tax Vendor specific profile options');
           Tab2Print('Set the profile option to "Yes" when using Tax Vendor');
           Tab2Print('No action necessary when not using Tax vendor');
       
      END IF; 

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Profile Options - Tax" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ---------------------------------------- HZ  Profile  Options ----------------------------------------- */ 
/*       The profile options in comments are not in then user guide and will therefore not be listed       */
/* ------------------------------------------------------------------------------------------------------- */

    BEGIN 
      SectionPrint('HZ Profile Options');

      -- HZ: Generate Party Number -- optional, no default, a value of null = 'Yes'  
      CheckProfile('HZ_GENERATE_PARTY_NUMBER', g_user_id, g_resp_id, g_appl_id, '"Yes"' , 1, 0, 'N' );

      -- HZ: Generate Party Site Number -- required, no default
      CheckProfile('HZ_GENERATE_PARTY_SITE_NUMBER', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' );

      -- HZ: Generate Contact Number -- optional, no default, a value of null = 'Yes'
      CheckProfile('HZ_GENERATE_CONTACT_NUMBER', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' );

      -- HZ: Change Customer Name -- optional, default 'Yes'
      CheckProfile('AR_CHANGE_CUST_NAME', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' ); 

      -- HZ: Number of Workers Used by Customer Interface  -- optional, no default
      CheckProfile('HZ_CINTERFACE_NUM_OF_WORKERS', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );
 
      -- HZ: Address Key Length -- optional, no default
      CheckProfile('HZ_ADDRESS_KEY_LENGTH', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N'  );

      -- HZ: Key Word Count  -- optional, no default
      CheckProfile('HZ_KEY_WORD_COUNT', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- HZ: Postal Code Key Length -- optional, no default
      CheckProfile('HZ_POSTAL_CODE_KEY_LENGTH', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- HZ: Bypass Find/Enter Window -- optional, no default
      CheckProfile('HZ_BYPASS_FIND_ENTER', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- HZ: Execute API Callouts -- optional, no default
      CheckProfile('HZ_EXECUTE_API_CALLOUTS', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- HZ: Cleanse Fuzzy Key -- optional, default 'Yes'
      CheckProfile('HZ_CLEANSE_FUZZY_KEY', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' );

      -- HZ: Report Error on Obsolete Columns -- optional, no default
      CheckProfile('HZ_API_ERR_ON_OBSOLETE_COLUMN', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Profile Options - HZ" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* -------------------------------------- Other AR Profile  Options -------------------------------------- */ 
/*       The profile options in comments are not in then user guide and will therefore not be listed       */
/* ------------------------------------------------------------------------------------------------------- */

    DECLARE 
      t_defaultreceiptSource varchar2(255);
      t_defaultInvoiceSource varchar2(255);
    BEGIN 
      SectionPrint('Other AR Profile Options');

      -- AR: Use Invoice Accounting For Credit Memos -- optional, default 'Yes'
      CheckProfile('AR_USE_INV_ACCT_FOR_CM_FLAG', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' ); 

      -- AR: Cash - Allow Actions -- required, default 'Yes'
      CheckProfile('AR_POWERCASH_ALLOW_ACTIONS', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'W' );

      -- AR: Show Billing Number -- Required, default 'No'
      -- Obsolete since AR.H - 11.5.7 ( See Note 198214.1 ) - Moved to system Options
      CheckProfile('AR_SHOW_BILLING_NUMBER', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'W' ); 

      -- AR: Debug Level for PostBatch -- required, default is '3' 
      CheckProfile('AR_ARCABP_DEBUG_LEVEL', g_user_id, g_resp_id, g_appl_id, '"3"', 1, 0, 'W' ); 

      -- AR: Customer Merge Commit Size -- optional, default is '1000'
      CheckProfile('AR_CMERGE_SET_SIZE', g_user_id, g_resp_id, g_appl_id, '"1000"', 1, 0, 'N' ); 

      -- AR: Credit Limit Selection -- required, default is 'Single'
      CheckProfile('AR_CREDIT_LIMIT_SELECTION', g_user_id, g_resp_id, g_appl_id, '"Single"', 1, 0, 'W' ); 

      -- AR: Document Number Generation Level -- optional, default is 'when the transaction is committed'
      -- Obsolete since AR.H - 11.5.7 ( See Note 198214.1 ) - Moved to system Options
      CheckProfile('AR_DOC_SEQ_GEN_LEVEL', g_user_id, g_resp_id, g_appl_id, '"When the Transaction is Committed"', 1, 0, 'N' ); 

      -- AR: Transaction Flexfield QuickPick Attribute -- optional, default 'interface_header_attribute1'
      -- Obsolete since AR.H - 11.5.7 ( See Note 198214.1 ) - Moved to Transaction sources
      CheckProfile('AR_PA_CODE', g_user_id, g_resp_id, g_appl_id, '"Interface_header_attribute1"', 1, 0, 'N' );

      -- AR: Invoices with Unconfirmed Receipts -- optional, default 'None'  
      CheckProfile('AR_ADJUST_CREDIT_UNCONFIRMED_INVOICE', g_user_id, g_resp_id, g_appl_id, '"None"', 1, 0, 'N' ); 
      
      -- AR: Close Periods - Run Collections Effectiveness Report -- Required, default 'No'
      -- Obsolete since AR.H - 11.5.7 ( See Note 180214.1 )
      CheckProfile('AR_AUTO_ARXCER_FLAG', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'W' );

      -- AR: Receipt Batch Source  -- required, no default
      t_defaultreceiptSource  := CheckProfile('AR_BATCH_SOURCE', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' );
      IF t_defaultreceiptSource is NOT NULL THEN 
         BEGIN
           l_count := 0; 
           SELECT  1
           INTO    l_count   
           FROM    AR_BATCH_SOURCES 
           WHERE   name = t_defaultreceiptSource;
         EXCEPTION 
           WHEN NO_DATA_FOUND THEN 
        -- if no rows returned then the value of the profile option does not belong to this org
                WarningPrint('"AR: Receipt Batch Source" Profile option is set to '|| t_defaultreceiptSource || ' and this is not a valid Batch ' ||
                             'source for this Operating Unit. Batch source name will not automatically default when entering Receipt batches. ');
                ActionWarningPrint('For this Profile option please select a Receipt source which is valid for this Operating Unit');
         END; 
      END IF; 

      -- AR: Transaction Batch Source -- required, no default
      t_defaultInvoiceSource :=  CheckProfile('AR_RA_BATCH_SOURCE', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' );
      IF t_defaultInvoiceSource is NOT NULL THEN  
         BEGIN 
           l_count := 0;  
           SELECT   1
           INTO     l_count 
           FROM     RA_BATCH_SOURCES 
           WHERE    batch_source_id = t_defaultInvoiceSource;
         EXCEPTION 
           WHEN NO_DATA_FOUND THEN  
           -- if no rows returned then the value of the profile option does not belong to this org
                WarningPrint('"AR: Transaction Batch Source" Profile option is set to ' || t_defaultInvoiceSource || ' and this is not a valid ' || 
                             'Barch Source for this Operating Unit. Batch source name will not automatically default when entering Transactions');
                ActionwarningPrint('For this Profile option please select a Transaction source which is valid for this Operating Unit');
         END;
      END IF;
       
      -- AR: Change Customer on Transaction -- optional, default 'Yes'
      CheckProfile('AR_CHANGE_CUST_ON_TRX', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' ); 

      -- AR: Cash - Default Amount Applied -- required, default 'Unapplied amount of the Payment'
      -- Obsolete since AR.H - 11.5.7 ( See Note 180214.1 )
      CheckProfile('AR_DEFAULT_AMOUNT_APPLIED', g_user_id, g_resp_id, g_appl_id, '"Unapplied amount of the Payment"', 1, 0, 'W' ); 

      -- AR: GL Transfer Balance Test  --  optional, default 'Yes'
      CheckProfile('AR_GLPOST_BALANCE_CHECK_FLAG', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' ); 

      -- AR: Item Flexfield Mode  -- optional, default 'Concatenated Segment Entry' 
      CheckProfile('AR_ITEM_FLEXFIELD_MODE', g_user_id, g_resp_id, g_appl_id, '"Concatenated Segment Entry"', 1, 0, 'N' );

      -- AR: Override Adjustment Activity Account Option --  optional, 'Yes'
      CheckProfile('AR_OVERRIDE_ADJUSTMENT_ACTIVITY_ACCOUNT', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' );

      -- AR: Update Due Date -- Required, default 'Yes'
      CheckProfile('AR_UPDATE_DUE_DATE', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'W' );

      -- AR: Allow Update Of Existing Sales Credits -- Required, default 'yes'
      CheckProfile('AR_ALLOW_SALESCREDIT_UPDATE', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'W' ); 

      -- AR: Default Exchange Rate Type  -- Required, no default
      CheckProfile('AR_DEFAULT_EXCHANGE_RATE_TYPE', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' );

      -- AR: Customers - Enter Alternate Fields  -- Optional, default 'Yes'
      CheckProfile('RA_CUSTOMERS_ENTER_PHONETICS', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' ); 

      -- AR: Alternate Name Search  -- Optional, default 'No'
      -- Obsolete since AR.H - 11.5.7 ( See Note 180214.1 )
      CheckProfile('AR_ALT_NAME_SEARCH', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' );

      -- AR: Dunning Letter Remit-To Address Label Size -- Required, no default
      -- Obsolete since AR.H - 11.5.7 ( See Note 180214.1 )
      CheckProfile('AR_ARDLP_REMIT_SIZE', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' ); 

      -- AR: Create Bank Charges -- optional, default 'Yes'
      CheckProfile('AR_JG_CREATE_BANK_CHARGES', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1 , 0, 'N' ); 

      -- AR: Zengin Character Set-- Required, no default
      -- Obsolete since AR.H - 11.5.7 ( See Note 198214.1 ) - Moved to Transmission Formats
      CheckProfile('AR_ZENGIN_CHAR_SET', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' );

      -- AR: Sort Customer Reports by Alternate Fields  -- Required, no default
      -- see note 166442.1
      CheckProfile('RA_CUSTOMERS_SORT_BY_PHONETICS', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' );

      -- AR: Enable Cross Currency --  Optional, default  'No'
      -- Obsolete since AR.H - 11.5.7 ( See Note 180214.1 )
      CheckProfile('AR_ENABLE_CROSS_CURRENCY', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 

      -- AR: Application GL Date Default -- optional, default 'Later of Receipt GL Date and Invoice GL Date'
      CheckProfile('AR_APPLICATION_GL_DATE_DEFAULT', g_user_id, g_resp_id, g_appl_id, 
                   '"Later of Receipt GL Date and Invoice GL Date"', 1, 0, 'N' );

      -- AR: Cross Currency Rate Type  -- required, default 'Corporate'
      -- Obsolete since AR.H - 11.5.7 ( See Note 198214.1 ) - Moved to system Options
      CheckProfile('AR_CROSS_CURRENCY_RATE_TYPE', g_user_id, g_resp_id, g_appl_id, '"Corporate"', 1, 0, 'W' ); 

      -- AR: Allow Overapplication In Lockbox -- Required, default 'no' 
      CheckProfile('AR_ALLOW_OVERAPPLICATION_IN_LOCKBOX', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'W' );

      -- AR: Commit between validations in Lockbox -- optional, no default
      CheckProfile('AR_ARLPLB_COMMIT_OPTION', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' ); 

      -- AR: Enable Debug Message Output -- optional, default 'No'
      CheckProfile('AR_ENABLE_DEBUG_OUTPUT', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' );

      -- AR: Enable SQL trace -- optional, default 'No'
      CheckProfile('AR_ENABLE_SQL_TRACE', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 

      -- AR: Include Receipts At Risk In Customer Balance -- Required, no default
      CheckProfile('AR_INCL_RECEIPTS_AT_RISK', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E'); 

      -- AR: Mask Bank Account Numbers  -- optional, default 'Mask - First Four Digits Visible' 
      CheckProfile('AR_MASK_BANK_ACCOUNT_NUMBERS', g_user_id, g_resp_id, g_appl_id, '"Mask - First Four Digits Visible"', 1, 0, 'N' );

      -- AR: Bills Receivable Batch Source  -- optional, no default
      CheckProfile('AR_BR_BATCH_SOURCE', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- AR: Factor / Endorse Bills Receivables without Recourse -- optional, default 'No'
      CheckProfile('AR_BR_WO_RECOURSE', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 

      -- AR:Maximum lines per AutoInvoice worker - optional, no default 
      CheckProfile('AR_MAX_LINES_PER_AI_WORKER', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' ); 
 
      -- AR:Customer Text Last Successful Run -- no default, using 'Null'
      CheckProfile('AR_CUSTOMER_TEXT_LAST_SUCCESSFUL_RUN', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Profile Options - AR" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* -------------------------------- AR related Profile Options in GL,OM, AOL ----------------------------- */ 
/*       The profile options in comments are not in then user guide and will therefore not be listed       */
/* ------------------------------------------------------------------------------------------------------- */

    BEGIN 
      SectionPrint('AR related Profile Options in GL, OM, AOL');
  
      -- Sequential Numbering -- owned by AOL -- optional, default 'Not Used'
      CheckProfile('UNIQUE:SEQ_NUMBERS', g_user_id, g_resp_id, g_appl_id, '"Not Used"', 1, 0, 'N' ); 

      -- Default Country -- owned by AOL -- required, no default 
      CheckProfile('DEFAULT_COUNTRY', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' );

      -- OE: Item Flexfield profile option -- required, no default
      CheckProfile('OE_ID_FLEX_CODE', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'E' );

      -- MO: Operation Unit -- required, no default
      CheckProfile('ORG_ID', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'W' );

      -- MO: Top Reporting Level -- optional, default 'Operating Unit'
      CheckProfile('XLA_MO_TOP_REPORTING_LEVEL', g_user_id, g_resp_id, g_appl_id, '"Operating Unit"', 1, 0, 'N' );

      -- Indicate Attachments -- optional, default 'yes'
      CheckProfile('ATCHMT_SET_INDICATOR', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' );

      -- Journals: Display Inverse Rate --  owned by GL -- optional, default 'No'
      CheckProfile('DISPLAY_INVERSE_RATE', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 

      -- Currency: Allow Direct EMU/non-EMU user Rates -- owned by GL -- default 'Yes'
      CheckProfile('GL_ALLOW_USER_RATE_BETWEEN_EMU_AND_NONEMU', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1, 0, 'N' ); 

      -- Account Generator: Purge Runtime Date -- owned by AOL -- no default
      CheckProfile('ACCOUNT_GENERATOR:PURGE_DATA', g_user_id, g_resp_id, g_appl_id, '"Null ( no default value )"', 1, 0, 'N' );

      -- Concurrent: Hold Requests -- owned by AOL -- default 'No'
      CheckProfile('CONC_HOLD', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 

      -- Concurrent: Report Copies -- owned by AOL -- default 1
      CheckProfile('CONC_COPIES', g_user_id, g_resp_id, g_appl_id, '"1"', 1, 0, 'N' ); 

      -- Concurrent: Report access level -- owned by AOL -- no default
      CheckProfile('CONC_REPORT_ACCESS_LEVEL', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' ); 

      -- Currency: Negative Format -- owned by AOL, default '-' 
      CheckProfile('CURRENCY:NEGATIVE_FORMAT', g_user_id, g_resp_id, g_appl_id, '"-"', 1, 0, 'N' );

      -- Currency: Positive Format -- AOL -- default Null ( no specific character )
      CheckProfile('CURRENCY:POSITIVE_FORMAT', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- Currency: thousands separator -- AOL -- no default
      CheckProfile('CURRENCY:THOUSANDS_SEPARATOR', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- Flexfields:Autoskip -- owned by AOL -- no default
      CheckProfile('FLEXFIELDS:AUTOSKIP', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- Flexfields:Shorthand Entry -- owned by AOL -- no default
      CheckProfile('FLEXFIELDS:SHORTHAND_ENTRY', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- Flexfields:SHOW FULL VALUE -- owned by AOL -- no default
      CheckProfile('FLEXFIELDS:SHOW_FULL_VALUE', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- Quickpick: Autoreduction -- owned by AOL -- no default
      CheckProfile('QUICKPICK:AUTOREDUCTION', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

      -- QuickPick: AutoSelect- owned by AOL -- no default
      CheckProfile('QUICKPICK:AUTOSELECT', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Profile Options - AR Related" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ------------------------------------------ References --------------------------------------------------- */ 

    SectionPrint('References');
    

    Show_link('209936.1');
    ActionPrint(' : "Oracle Receivables User Guide Release lli". Please refer to  "Appendix B : Oracle Receivables ' || 
                ' Profile Options" to fix the Errors and Warnings in Profile Options Section' );
    Show_link('67189.1');
    ActionPrint(' : "Oracle Receivables Manuals and eTRMs"' );    
    Show_link( '131766.1' );   
    ActionPrint( ' : "Self-Service Toolkit Oracle Receivables and iReceivables"' ); 
    Show_link ('91556.1');    
    ActionPrint(' : "Latest AR News"' );      
    Show_link('149226.1'); 
    ActionPrint(' : "How to Find the Latest Patchset Using Metalink"' ); 

/* -------------------------------------------- Feedback --------------------------------------------------- */

    Brprint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo'); 

/* -------------------------------- Exception Section  - Main Program ( Part 2 ) --------------------------- */ 

  EXCEPTION -- begin 2 
    WHEN STOPEXECUTION THEN  
      -- If stopexecution was raised because the first main block was aborted do not 
      -- print the footer a second time, do nothing  
         IF :v_abort = 'N' THEN 
            brprint;
            Show_Footer('&v_scriptlongname', '&v_headerinfo');
            brprint;
         ELSE 
            null;
         END IF;
    WHEN OTHERS then -- exception begin 2
         brprint;
         ErrorPrint(sqlerrm||' occurred in diagnostic test');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
         brprint;
         Show_Footer('&v_scriptlongname', '&v_headerinfo');
         brprint; 
  END; -- end2 

EXCEPTION -- begin 1 
  WHEN OTHERS THEN   
       Brprint;
       Errorprint(sqlerrm||' occurred in diagnostic test');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');
       Brprint; 
       Show_Footer('&v_scriptlongname', '&v_headerinfo');
       Brprint;
END; 
/
  
REM  ==============SQL PLUS Environment setup===========================================================
Spool off
Set termout on
set feedback on
set verify off 
set echo off 
set trimout off
set trimspool off
set heading on
set autoprint off

PROMPT
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================
PROMPT 
