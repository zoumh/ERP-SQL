================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract           This diagnostic test verifies the setup of the Accounts 
                   Receivable application by capturing a snapshot of the Accounts 
                   Receivable general setup information.
================================================================================
PRODUCT:           Accounts Receivable (AR)   
SUBCOMPONENT:      Generic Setup Issues
PRODUCT VERSIONS:  Release 11.5.2 +
PLATFORM:          Generic 
DATE CREATED:      O1-JUL-2002
PARAMETERS:        User Name 
                   Responsibility Id 
                     
================================================================================
Instructions
================================================================================
Included Files:
     CoreApiHtml.sql     
     ARCheckSetup115.sql 
     ARCheckSetup115_readme.html
     ARCheckSetup115_readme.txt
     ARCheckSetup115_Sample_Output.html

Execution Environment:
     SQL*Plus

Access Privileges:
     Requires APPS user access

Usage:
     sqlplus apps/apps @ARCheckSetUp115

Instructions:

The files ARCheckSetup115.sql and CoreApiHtml.sql should be unzipped
to a common directory. From this directory run the file ARCheckSetup115.sql
in SQL*Plus in the APPS schema.

You will be prompted for an applications user name. 
You should then see a list of valid responsibilities for the user entered.

When prompted, enter a responsibility id which falls under Oracle Receivables. 

The diagnostic test will produce an outputfile named 
    ARCheckSetup115_[responsibility_id]_diag.html
This file can be viewed in a browser or uploaded for support analysis.

================================================================================
Description
================================================================================

This diagnostic test verifies the setup of the Accounts Receivable application 
by capturing a snapshot of your Accounts Receivable general setup information.

The purpose of the diagnostic test is to check the basic setup (as outlined in 'Setting Up' 
Chapter in the User's Guide) of Accounts Receivable. When setup information is 
missing or when the setup is invalid, the test will output error/warning 
messages, the action to be taken, and the impact of the missing setup. 

This diagnostic test collects and verifies the following : 

     System Options 
     Reporting Set of Books tied to this Primary Set of Books 
     Conversion Rates
     Open Periods in AR and GL 
     Accounting Flexfield 
     Sales Tax Location Flexfield 
     Territory Flexfield 
     System Item Flexfield 
     Line Transaction Flexfield 
     Item Validation Organization 
     Account Generator Process 
     Transaction Types 
     Transaction Sources 
     Payment Terms 
     Receipts Classes 
     Receipt Source 
     Tax Codes 
     Autocash Rules 
     Line Ordering Rules 
     Grouping Rules 
     Collectors 
     Remittance Banks 
     Salespersons 
     Unit of Measures 
     Standard Memo Lines 
     Lockbox Setup 
     Lockbox Transmission formats 
     Customer Profile Classes 
     Customer with active Bill-to sites in this Org 
     Remit to Address 
     Default Remit to Address 
     Approval Limits 
     Receivables Activities 
     Auto Accounting Setup 
     Quick codes 
     Tax Profile Options 
     HZ Profile Options 
     AR Profile Options 
     AR related Profile Options in GL,OM, AOL 
     References

================================================================================
References
================================================================================

None

================================================================================
Disclaimer
================================================================================
EXCEPT WHERE EXPRESSLY PROVIDED OTHERWISE, THE INFORMATION, SOFTWARE,
PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. ORACLE EXPRESSLY DISCLAIMS
ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NON-INFRINGEMENT. ORACLE MAKES NO WARRANTY THAT: (A) THE RESULTS
THAT MAY BE OBTAINED FROM THE USE OF THE SOFTWARE WILL BE ACCURATE OR
RELIABLE; OR (B) THE INFORMATION, OR OTHER MATERIAL OBTAINED WILL MEET YOUR
EXPECTATIONS. ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE DOWNLOADED OR
OTHERWISE OBTAINED IS DONE AT YOUR OWN DISCRETION AND RISK. ORACLE SHALL HAVE
NO RESPONSIBILITY FOR ANY DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT
RESULTS FROM THE DOWNLOAD OF ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE.

ORACLE RESERVES THE RIGHT TO MAKE CHANGES OR UPDATES TO THE SOFTWARE AT ANY
TIME WITHOUT NOTICE.

================================================================================
Limitation of Liability
================================================================================
IN NO EVENT SHALL ORACLE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL OR CONSEQUENTIAL DAMAGES, OR DAMAGES FOR LOSS OF PROFITS, REVENUE,
DATA OR USE, INCURRED BY YOU OR ANY THIRD PARTY, WHETHER IN AN ACTION IN
CONTRACT OR TORT, ARISING FROM YOUR ACCESS TO, OR USE OF, THE SOFTWARE.

SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY.
ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS MAY NOT APPLY TO YOU.

