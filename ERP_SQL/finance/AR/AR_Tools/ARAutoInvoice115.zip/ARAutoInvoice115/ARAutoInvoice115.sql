undefine v_headerinfo
Define   v_headerinfo   = '$Header: ARAutoInvoice115.sql 1.9 14-JUN-2004 support $'
undefine v_testlongname
Define   v_testlongname = ' Receivables (AR): AutoInvoice Setup Diagnostic Test'

REM   ================================================================================= 
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA 
REM   Oracle Support Services.  All rights reserved. 
REM   =================================================================================
REM   PURPOSE:                  AR - Autoinvoice Check Set Up   
REM   PRODUCT:                  Accounts Receivable (AR)    
REM   PRODUCT VERSIONS :        11.5.2 or higher
REM   PLATFORM:                 GENERIC
REM   PARAMETERS:               1. Apps username
REM                             2. Responsibility to be chosen from list 
REM                             3. Batch source to be chosen from list 
REM                                 
REM   =================================================================================

REM   =================================================================================
REM   USAGE:                    sqlplus apps/apps@appsdb 
REM                             @ARAutoInvoice115 
REM   EXAMPLE:  
REM   OUTPUT:                   ARAutoInvoice115_[batch_source_id]_diag.html 
REM   =================================================================================   

REM   ================================================================================= 
REM   CHANGE HISTORY: 
REM   02-AUG-2002 Created  Igovaert
REM   11-APR-2003 Modified Igovaert  changed SQL for ystem Options to work for Single Org
REM                                  use table MTL_SYSTEM_ITEMS_B iso view MTL_SYSTEM_ITEMS
REM                                  changed SQL in Show_Indexes as owner can also be GL or INV
REM                                  improved Error, Warning Reporting for Profile Options 
REM   03-JUN-2003 Modified Igovaert  changed Reference to Note 42286.1 to Note 143682.1   
REM   06-OCT-2003 Modified Igovaert  showing Profiles on level of user, resp, app and site 
REM                                  used indention in Run_sql      
REM   05-MAY-2004 Modified Igovaert  included version
REM                                  removed application check on responsibility
REM                                  improved error message for Item Validation Organization
REM 
REM   =================================================================================   

REM   ==============SQL PLUS Environment setup========================================= 

set serveroutput on size 1000000
set linesize 500 
set verify off 
set feedback off
set echo off
set verify off 
set autoprint off
set termout on 

REM ============== Define SQL Variables for input parameters ========================== 
VARIABLE    v_username       VARCHAR2(100); 
REM Undefine    Application_user_name
VARIABLE    v_abort          VARCHAR2(1); 

REM =========================Validate DATABASE Version =========================================
REM ======================NOTE - This section only needed for tests using HTML API's============

DECLARE 
  l_version           VARCHAR2(30);
BEGIN 

  SELECT MAX(version)
  INTO   l_version
  FROM   v$instance;

  IF l_version < '8.1.6.0.0' THEN 
     DBMS_OUTPUT.PUT_LINE(chr(10));
     DBMS_OUTPUT.PUT_LINE('ERROR - Invalid Database Version '||l_version || '. The test requires RDBMS version 8.1.6 or higher');
     DBMS_OUTPUT.PUT_LINE('ACTION - Type Ctrl-C <Enter> to exit the test.');
     DBMS_OUTPUT.PUT_LINE(chr(10));
  END IF;

EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - Database Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/
REM =========================Validate SQL*Plus Version Character Set Combination=================
REM ======================NOTE - This section only needed for tests using HTML API's=============

DECLARE
  l_nls_characterset    nls_database_parameters.value%TYPE;
  l_sql_release_int     INTEGER(20) :=  to_number('&_SQLPLUS_RELEASE');
  l_sql_release_chr     VARCHAR2(50) := '&_SQLPLUS_RELEASE';

BEGIN

  SELECT value 
  INTO  l_nls_characterset
  FROM  nls_database_parameters
  WHERE parameter = 'NLS_CHARACTERSET';
    
  FOR i IN 1..4 LOOP
    l_sql_release_chr := substr(l_sql_release_chr,1,(2*i)-1)||'.'||
      substr(l_sql_release_chr,(2*i)+1);
  END LOOP;
  
  IF l_nls_characterset LIKE 'UTF%' THEN
     IF l_sql_release_int IS null THEN 
        DBMS_OUTPUT.PUT_LINE(chr(10));
        DBMS_OUTPUT.PUT_LINE('ATTENTION - Cannot determine version of SQL*plus being used for test run.');
        DBMS_OUTPUT.PUT_LINE('.           This test may fail if not run using a version 8.1.X of SQL*plus or higher.');
        DBMS_OUTPUT.PUT_LINE('Attempting to run the test.......');
        DBMS_OUTPUT.PUT_LINE(chr(10));
     ELSIF l_sql_release_int < 801000000 THEN
        DBMS_OUTPUT.PUT_LINE(chr(10));
        DBMS_OUTPUT.PUT_LINE('ERROR - Invalid SQL*plus Version '||l_sql_release_chr);
        DBMS_OUTPUT.PUT_LINE('ACTION - On databases using the '||l_nls_characterset||' NLS characterset this test should not be run using this ');
        DBMS_OUTPUT.PUT_LINE('.        SQL*plus Version.  Please rerun this test using version 8.1.X of SQL*plus or higher.');
        DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
        DBMS_OUTPUT.PUT_LINE(chr(10));
     END IF;
  END IF;
EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - SQL*plus Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM ================Show Test Version==========================================
set heading off
select '&v_headerinfo'||chr(10) from dual;
set heading on
PROMPT

REM =================Get Username Parameter=====================================
undefine uname
accept uname char PROMPT 'Applications Username (required): ' 

REM ================ Show responsibilities assigned to given user ===================== 
DECLARE   
  l_applversion   fnd_product_groups.release_name%type;
  l_counter       integer;
  l_cursor        integer;
  sqltxt          varchar2(3000);
  l_resp_id       integer;
  l_resp_name     varchar2(300);  
BEGIN
  :v_abort := 'N';

  select nvl(rtrim(ltrim(upper('&uname'))), '<Null username>')
  into :v_username
  from dual;

  select substr(release_name,1,4)  
  into   l_applversion 
  from   fnd_product_groups;

  IF l_applversion = '11.5' then
     sqltxt := 'select to_char(a.responsibility_id) id, '||
               '       b.responsibility_name name '||
               'from   fnd_user_resp_groups a, '||
               '       fnd_responsibility_vl b, '||
               '       fnd_user u '||
               'where  a.user_id = u.user_id '||
               'and    a.responsibility_id = b.responsibility_id '||
               'and    a.responsibility_application_id = b.application_id '||
               'and    sysdate between '|| 
               '          a.start_date and nvl(a.end_date,sysdate+1) '||
               'and    upper(u.user_name) = '''||:v_username||''''||
               'order  by b.responsibility_name';
     

     DBMS_OUTPUT.PUT_LINE(chr(9));
     DBMS_OUTPUT.PUT_LINE('Following are the responsibilities assigned to user:  '|| :v_username );
     DBMS_OUTPUT.PUT_LINE('=================================================================');

     l_cursor := dbms_sql.open_cursor;
     dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
     dbms_sql.define_column(l_cursor, 1, l_resp_id);
     dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
     l_counter := dbms_sql.execute(l_cursor);
     l_counter := 0; 

     WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
           l_counter := l_counter + 1;
           dbms_sql.column_value(l_cursor, 1, l_resp_id);
           dbms_sql.column_value(l_cursor, 2, l_resp_name);
           DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
     END LOOP; 
 
     IF l_counter = 0 then
        raise no_data_found;
     END IF;   
     dbms_sql.close_cursor(l_cursor);
 
  ELSE  -- apps version is not 11.5
     DBMS_OUTPUT.PUT_LINE('ERROR  - This diagnostic test is not designed to run against version '|| l_applversion ||' of applications');
     DBMS_OUTPUT.PUT_LINE('ACTION - Please run the test against an 11i instance'  || chr(10) ||
                          '         Type Ctrl-C <Enter> to exit the test' || chr(10) );
  END IF; 

EXCEPTION
  WHEN NO_DATA_FOUND THEN 
     DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
     DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.'||chr(10)||
                          '         Type Ctrl-C <Enter> to exit the diagnostic test. Rerun the test with a valid user name.' || chr(10));
  WHEN OTHERS THEN 
     DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error: '|| sqlerrm);
     DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                          '         Type Ctrl-C <Enter> to exit the diagnostic test.'  || chr(10) );

END; 
/
 
PROMPT 
undefine v_respid
accept   v_respid number PROMPT  'Please choose a Responsibility ID from the list : '
PROMPT
PROMPT  

REM ================== Accept other Input Parameters ===============================

REM ================ Show list of all Batch Sources ( Type IMPORTED ) ============== 
DECLARE   
  p_userid       number; 
  p_respid       number;
  p_appid        number; 
  l_counter      integer;
  l_cursor       integer;
  sqltxt         varchar2(3000);
  l_batch_id     integer;
  l_batch_name   varchar2(50);  

BEGIN
-- set environment in order to select batch sources this user / responsibility sees

  IF :v_username = '<Null username>' THEN
     RAISE NO_DATA_FOUND;
  ELSE  
     BEGIN   
       SELECT user_id 
       INTO   p_userid
       FROM   fnd_user 
       WHERE  user_name = :v_username;
     EXCEPTION 
       WHEN OTHERS then
            RAISE NO_DATA_FOUND;
     END;
  END IF;
 
  IF &v_respid = 0 THEN
     RAISE NO_DATA_FOUND;     
  ELSE
     BEGIN         
       p_respid := &v_respid;
       SELECT responsibility_application_id 
       INTO   p_appid        
       FROM   fnd_user_resp_groups 
       WHERE  responsibility_id = p_respid
       AND    user_id = p_userid;
     EXCEPTION 
       WHEN OTHERS then
            RAISE NO_DATA_FOUND;
     END;
  END IF; 

  BEGIN 
    fnd_global.apps_initialize(p_userid, p_respid, p_appid );
  EXCEPTION
    WHEN OTHERS THEN 
         RAISE NO_DATA_FOUND;
  END; 

  sqltxt := 'SELECT  batch_source_id, '||
            '        name             '||                     
            'FROM    RA_BATCH_SOURCES '||
            'WHERE   batch_source_type = ''FOREIGN'' '|| 
            'AND     status = ''A''   '|| 
            'AND     NVL( start_date, sysdate) <= sysdate '||
            'AND     NVL( end_date, sysdate)   >= sysdate '||
            'ORDER   BY name ';
             
  
  DBMS_OUTPUT.PUT_LINE('Active Batch Sources of type IMPORT');
  DBMS_OUTPUT.PUT_LINE('===================================');

  l_cursor := dbms_sql.open_cursor;
  dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
  dbms_sql.define_column(l_cursor, 1, l_batch_id );
  dbms_sql.define_column(l_cursor, 2, l_batch_name, 50);
  l_counter := dbms_sql.execute(l_cursor);
  l_counter := 0; 

  WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
        l_counter := l_counter + 1;
        dbms_sql.column_value(l_cursor, 1, l_batch_id);
        dbms_sql.column_value(l_cursor, 2, l_batch_name);
        DBMS_OUTPUT.PUT_LINE(rpad(to_char(l_batch_id), 8, '.' ) ||'...'||l_batch_name);
  END LOOP; 

  IF l_counter = 0 then
     RAISE no_data_found;
  END IF;   
  dbms_sql.close_cursor(l_cursor);

EXCEPTION
  when NO_DATA_FOUND then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any active Imported Batch sources'); 
       DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User and Responsibility are valid ' || chr(10) || 
                            '         Ensure there is at least one active transaction source of Type Import'||chr(10)||
                            '         Type Ctrl-C <Enter> to exit the diagnostic test.'  || chr(10) );
  when OTHERS then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Batch Source List error: '||sqlerrm ); 
       DBMS_OUTPUT.PUT_LINE('ACTION - Report the above error to Oracle Support representative' || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the diagnostic test.' || chr(10) );  
END; 
/

PROMPT 
undefine v_batchid
accept   v_batchid number PROMPT  'Please choose a Batch Source ID from the list : '
define   v_batchidc = &v_batchid 

PROMPT 

REM ===================== Spooling the output file ========================================== 

Define   v_spoolfilename  = 'ARAutoInvoice115_&v_batchidc._diag.htm'

PROMPT  =======================================================================
PROMPT  Output will be spooled to &v_spoolfilename
PROMPT  =======================================================================
PROMPT 
PROMPT Running... Please be patient - this test may run longer than 5 minutes 
PROMPT 
spool   &v_spoolfilename

set     termout off

REM ============================== Run the Pl/SQL api file ================================== 
@@CoreApiHtml.sql

/*------------------------- Start Of the Main Program ( Part 1 ) -----------------------------*/

BEGIN  -- ( block 1, API and template )
  DECLARE -- ( block 2, script code ) 
    p_username            varchar2(100);   
    p_respid              number;
    p_batchid             number; 
    
    v_respname            varchar2(100)   := Null;
    v_batchname           varchar2(50)    := Null; 
    v_appid               number          := 0;
    v_ar_status           varchar2(50)    := Null;
    v_patch_level         varchar2(30)    := Null;   
    v_orgid               varchar2(15);
    v_orgname             varchar2(60)    := Null;    
    v_mrc_flag            varchar2(1)     := null;
    v_multi_org           varchar2(1)     := null;
   
    v_group_flag          varchar2(1)     := Null; 
    v_grouping_rule_id    number(15)      := Null; 
    v_grouping_rule_name  varchar2(40)    := Null; 
   
    v_sobid        number;
    v_sobname      varchar2(30);

    l_count        number  := 0;
    sqltxt         varchar2(32767);
    l_counter      integer;
    l_cursor       integer; 

    STOPEXECUTION  exception;

  BEGIN  -- ( block 2, script code )

/* ----------------------------- Set Client ( validate user and responsibility ) -----------------------*/
      
    p_username := :v_username;
  
    IF &v_respid = 0 THEN
       p_respid := -10;     
    ELSE        
       p_respid := &v_respid;
    END IF; 

    Set_Client(p_username, p_respid);
    Show_Header('204790.1', '&v_testlongname', '&v_headerinfo' );

/* ---------------------------------- Application information  -------------------------------------------- */ 
 
    SectionPrint('Application Information');
    
    v_orgid   := Get_profile_option('ORG_ID');

    -- pick up orgname 
    IF v_orgid is NOT Null THEN 
       BEGIN -- Level 4
         SELECT  name 
         INTO    v_orgname 
         FROM    HR_ALL_ORGANIZATION_UNITS
         WHERE   organization_id = v_orgid; 
       EXCEPTION
         WHEN NO_DATA_FOUND THEN 
              Null;
        END; -- level 4
    END IF; 

    -- pick up multi currency and multi org flag 
    BEGIN 
      SELECT multi_currency_flag,
             multi_org_flag  
      INTO   v_mrc_flag,
             v_multi_org  
      FROM   fnd_product_groups;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Null;
      WHEN TOO_MANY_ROWS THEN
           Errorprint( 'More than one row ( more than one installation ) found in FND_PRODUCT_GROUPS');
           ActionErrorPrint('Execution of the test will stop');
           RAISE StopExecution;
    END; 
   
    Tab1Print('MultiOrg Flag = '|| v_multi_org );
    Tab1Print('MultiCurrency Flag = '|| v_mrc_flag );
    IF v_multi_org = 'Y' THEN 
       Tab1Print('MO: Operating Unit = ' || v_orgid );
       Tab1Print('Operating Unit Name = '|| v_orgname );
    END IF; 

/* ---------------------------------- Product Status and Patch Level ----------------------------------------- */ 
  
    DECLARE 
      CURSOR C1 IS 
        SELECT  substr(a.application_name,1,25)        application,
                DECODE(p.status,'I','Installed', 
                                'N','Not Installed', 
                                'L','Custom',
                                'S','Shared', status ) status, 
                nvl (p.patch_level, 'Unknown' )        patchLevel 
                FROM    FND_APPLICATION_ALL_VIEW a, 
                        FND_PRODUCT_INSTALLATIONS p 
                WHERE   a.application_id = p.application_id 
                AND     a.application_id in ( 222, 275, 660 )
                ORDER   BY a.application_id; 

    BEGIN 
      SectionPrint('Product Status and Patch Level');
      FOR c1_rec IN C1 LOOP
          Tab1Print( c1_rec.application );
          Tab2Print( 'Install Status = ' || c1_rec.status );
          Tab2Print( 'Patch Level = '||  c1_rec.patchlevel );
      END LOOP;
    EXCEPTION 
     WHEN OTHERS THEN 
          Errorprint(sqlerrm||' occurred in test in section "Product Status and Patch Level"');
          ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

    /* ----------------------------- Show Parameters -------------------------------------------------------*/

    -- pick up responsibility name and application id assigned to this responsibility
    BEGIN 
      SELECT responsibility_name,
             application_id 
      INTO   v_respname,
             v_appid 
      FROM   fnd_responsibility_vl b
      WHERE  b.responsibility_id = p_respid;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN Null;
    END; 

    BEGIN
      IF &v_batchid = 0 THEN 
         p_batchid := -999;
      ELSE
         p_batchid := &v_batchid;    
      END IF;
      SELECT name 
      INTO   v_batchname
      FROM   RA_BATCH_SOURCES 
      WHERE  batch_source_id = p_batchid;
    EXCEPTION 
      WHEN OTHERS THEN 
           v_batchname := '??';
    END; 

    SectionPrint('Parameters');
    Tab1Print('Username         = '|| :v_username); 
    Tab1Print('Responsibility   = '|| v_respname || ' ( id = ' || to_char(&v_respid) || ' )');
    Tab1Print('Batch source     = '|| v_batchname || ' ( id = ' || to_char(&v_batchid) || ' )');

/* ------------------------------------     AR System Options  ------------------------------------------------ */ 

    DECLARE  -- level 3
      -- declare workfields for AR_system_parameters 
      t_default_grouping_rule_id         NUMBER(15)  := Null;     
      t_salesrep_required_flag           VARCHAR2(3) := Null;
      t_auto_rec_inv_per_commit          NUMBER(8)   := Null;
      t_auto_rec_rec_per_commit          NUMBER(8)   := Null;
      t_pay_unrelated_invoices_flag      VARCHAR2(3) := Null;
      t_print_home_country_flag          VARCHAR2(3) := Null;
      t_location_tax_account             NUMBER(15)  := Null;
      t_from_postal_code                 VARCHAR2(60):= Null;
      t_to_postal_code                   VARCHAR2(60):= Null;
      t_tax_registration_number          VARCHAR2(60):= Null;
      t_populate_gl_segments_flag        VARCHAR2(3) := Null;
      t_unallocated_revenue_ccid         NUMBER(15)  := Null;
      t_orgname                          VARCHAR2(60):= Null; 
      t_calc_discount_on_lines_flag      VARCHAR2(3) := Null;
      t_change_printed_invoice_flag      VARCHAR2(3) := Null;
      t_code_combination_id_loss         NUMBER(15)  := Null;
      t_create_reciprocal_flag           VARCHAR2(3) := Null;
      t_default_country                  VARCHAR2(60):= Null;
      t_default_territory                VARCHAR2(30):= Null;
      t_generate_customer_number         VARCHAR2(3) := Null;
      t_invoice_deletion_flag            VARCHAR2(3) := Null;
      t_id_flex_structure_name           VARCHAR2(30):= Null;
      t_site_required_flag               VARCHAR2(3) := Null;
      t_tax_allow_compound_flag          VARCHAR2(3) := Null;
      t_tax_invoice_print                VARCHAR2(30):= Null;
      t_tax_method                       VARCHAR2(30):= Null;
      t_tax_use_customer_exempt_flag     VARCHAR2(3) := Null;
      t_tax_use_cust_exc_rate_flag       VARCHAR2(3) := Null;
      t_tax_use_loc_exc_rate_flag        VARCHAR2(3) := Null;
      t_tax_use_product_exempt_flag      VARCHAR2(3) := Null;
      t_tax_use_prod_exc_rate_flag       VARCHAR2(3) := Null;
      t_tax_use_site_exc_rate_flag       VARCHAR2(3) := Null;
      t_ai_log_file_message_level        NUMBER(15)  := Null;
      t_ai_max_memory_in_bytes           NUMBER(15)  := Null;
      t_ai_acct_flex_key_left_prompt     VARCHAR2(80):= Null;
      t_ai_mtl_items_key_left_prompt     VARCHAR2(80):= Null;
      t_ai_territory_key_left_prompt     VARCHAR2(80):= Null;
      t_ai_purge_interface_tab_flag      VARCHAR2(3) := Null;
      t_ai_activate_sql_trace_flag       VARCHAR2(3) := Null;
      t_set_of_books_id                  NUMBER(15)  := Null;
      t_created_by                       NUMBER(15)  := Null;
      t_creation_date                    DATE := Null;
      t_last_updated_by                  NUMBER(15)  := Null;
      t_last_update_date                 DATE := Null;
      t_last_update_login                NUMBER(15)  := Null;
      t_accounting_method                VARCHAR2(30):= Null;
      t_accrue_interest                  VARCHAR2(3) := Null;
      t_unearned_discount                VARCHAR2(3) := Null;
      t_partial_discount_flag            VARCHAR2(3) := Null;
      t_print_remit_to                   VARCHAR2(3) := Null;
      t_default_cb_due_date              VARCHAR2(30):= Null;
      t_auto_site_numbering              VARCHAR2(3) := Null;
      t_cash_basis_set_of_books_id       NUMBER(15)  := Null;
      t_code_combination_id_gain         NUMBER(15)  := Null;
      t_autocash_hierarchy_id            NUMBER(15)  := Null;
      t_run_gl_journal_import_flag       VARCHAR2(3) := Null;
      t_cer_split_amount                 NUMBER(9)   := Null;
      t_cer_dso_days                     NUMBER(5)   := Null;
      t_posting_days_per_cycle           NUMBER(5)   := Null;
      t_address_validation               VARCHAR2(30):= Null;
      t_tax_code                         VARCHAR2(50):= Null;
      t_tax_currency_code                VARCHAR2(15):= Null;
      t_tax_header_level_flag            VARCHAR2(6) := Null;
      t_tax_minimum_accountable_unit     NUMBER      := Null;    
      t_tax_precision                    NUMBER(1)   := Null;
      t_tax_rounding_rule                VARCHAR2(30):= Null;
      t_tax_rounding_allow_override      VARCHAR2(3) := Null;
      t_rule_set_id                      NUMBER      := Null;
      t_tax_use_account_exc_rate_flg     VARCHAR2(3) := Null;
      t_tax_use_system_exc_rate_flag     VARCHAR2(3) := Null;
      t_tax_hier_site_exc_rate           VARCHAR2(15):= Null;
      t_tax_hier_cust_exc_rate           VARCHAR2(15):= Null;
      t_tax_hier_prod_exc_rate           VARCHAR2(15):= Null;
      t_tax_hier_account_exc_rate        VARCHAR2(15):= Null;
      t_tax_hier_system_exc_rate         VARCHAR2(15):= Null;
      t_tax_enforce_account_flag         VARCHAR2(3) := Null;
      t_tax_database_view_set            VARCHAR2(30):= Null;
      t_inclusive_tax_used               VARCHAR2(3) := Null;
      t_code_combination_id_round        NUMBER(15)  := Null;
      t_trx_header_level_rounding        VARCHAR2(3) := Null;
      t_trx_header_round_ccid            NUMBER(15)  := Null;
      t_trxname                          VARCHAR2(50):= Null;
      t_sales_tax_geocode                VARCHAR2(30):= Null;
      t_bills_receiv_enabled_flag        VARCHAR2(3) := Null;
      t_ta_installed_flag                VARCHAR2(3) := Null;
      t_sobname                          VARCHAR2(30):= Null;

      t_tax_printing_meaning             VARCHAR2(80):= Null;
      t_discount_basis_meaning           VARCHAR2(80):= Null;
      t_chargeback_due_date_meaning      VARCHAR2(80):= Null;
      t_grouping_rule_name               VARCHAR2(40):= Null;
      t_rule_set_name                    VARCHAR2(30):= Null; 
      t_hierarchy_name                   VARCHAR2(30):= Null; 

      -- declare workfields for columns added to ar_system_parameters after 11I base 
      t_sales_credit_pct_limit           NUMBER      := Null;
      t_rev_transfer_clear_ccid          NUMBER(15)  := Null;
      t_max_wrtoff_amount                NUMBER      := Null;
      t_irec_cc_receipt_method_id        NUMBER(15)  := Null;
      t_show_billing_number_flag         VARCHAR2(3) := Null;
      t_cross_currency_rate_type         VARCHAR2(30):= Null;
      t_document_seq_gen_level           VARCHAR2(80):= Null;
      t_calc_tax_on_credit_memo_flag     VARCHAR2(3) := Null;

      t_user_conversion_type             VARCHAR2(30):= Null; 
      t_currency_code                    VARCHAR2(15):= Null;
      t_precision                        VARCHAR2(1) := Null;

      t_new_columns                      VARCHAR2(1000):=Null;

    BEGIN  -- level 3
      SectionPrint('System Options');
      
   -- select ar_system_parameters  - columns in base 11I release 
      SELECT   a.default_grouping_rule_id, 
               a.salesrep_required_flag,
               a.auto_rec_invoices_per_commit,
               a.auto_rec_receipts_per_commit,
               a.pay_unrelated_invoices_flag,
               a.print_home_country_flag,
               a.location_tax_account,
               a.from_postal_code,
               a.to_postal_code,
               a.tax_registration_number,
               a.populate_gl_segments_flag, 
               a.unallocated_revenue_ccid,
               b.name, 
               a.calc_discount_on_lines_flag,
               a.change_printed_invoice_flag,
               a.code_combination_id_loss,
               a.create_reciprocal_flag,
               a.default_country,
               decode(a.default_territory, 'SALES', 'Salesrep',
                                           'BILL','Bill to Site',
                                           'NONE','None',
                                           'SHIP','Ship to Site', default_territory), 
               a.generate_customer_number,
               a.invoice_deletion_flag,
               c.id_flex_structure_name,
               a.site_required_flag,
               a.tax_allow_compound_flag,
               a.tax_invoice_print,
               decode( a.tax_method, 'SALES_TAX','Sales Tax', 'VAT', 'VAT', a.tax_method ),
               a.tax_use_customer_exempt_flag,
               a.tax_use_cust_exc_rate_flag,
               a.tax_use_loc_exc_rate_flag,
               a.tax_use_product_exempt_flag,
               a.tax_use_prod_exc_rate_flag,
               a.tax_use_site_exc_rate_flag, 
               a.ai_log_file_message_level,
               a.ai_max_memory_in_bytes,
               a.ai_acct_flex_key_left_prompt,
               a.ai_mtl_items_key_left_prompt,
               a.ai_territory_key_left_prompt,
               a.ai_purge_interface_tables_flag,
               a.ai_activate_sql_trace_flag,
               a.set_of_books_id,
               a.created_by,
               a.creation_date,
               a.last_updated_by,
               a.last_update_date,
               a.last_update_login,
               a.accounting_method,
               a.accrue_interest,
               a.unearned_discount,
               a.partial_discount_flag, 
               a.print_remit_to,
               a.default_cb_due_date,
               a.auto_site_numbering,
               a.cash_basis_set_of_books_id,
               a.code_combination_id_gain,
               a.autocash_hierarchy_id,
               a.run_gl_journal_import_flag, 
               a.cer_split_amount,
               a.cer_dso_days,
               a.posting_days_per_cycle,
               decode(a.address_validation,'NOVAL','No Validation',
                                           'ERR','Error',
                                           'WARN','Warning', a.address_validation ),
               a.tax_code,
               a.tax_currency_code,
               decode(a.tax_header_level_flag,'Y','Header','Line'),
               a.tax_minimum_accountable_unit,
               a.tax_precision,
               a.tax_rounding_rule,
               a.tax_rounding_allow_override,
               a.rule_set_id,
               a.tax_use_account_exc_rate_flag,
               a.tax_use_system_exc_rate_flag,
               a.tax_hier_site_exc_rate,
               a.tax_hier_cust_exc_rate,
               a.tax_hier_prod_exc_rate,
               a.tax_hier_account_exc_rate,
               a.tax_hier_system_exc_rate,
               a.tax_enforce_account_flag,
               decode(a.tax_database_view_set,'_A','Taxware',
                                              '_V','Vertex',
                                              'O','Oracle', a.tax_database_view_set ),
               a.inclusive_tax_used,
               a.code_combination_id_round,
               a.trx_header_level_rounding,
               a.trx_header_round_ccid,
               d.name, 
               a.sales_tax_geocode,
               a.bills_receivable_enabled_flag, 
               a.ta_installed_flag,
               e.name
      INTO     t_default_grouping_rule_id,     
               t_salesrep_required_flag,
               t_auto_rec_inv_per_commit,
               t_auto_rec_rec_per_commit,
               t_pay_unrelated_invoices_flag,
               t_print_home_country_flag, 
               t_location_tax_account,
               t_from_postal_code,
               t_to_postal_code,
               t_tax_registration_number,
               t_populate_gl_segments_flag,
               t_unallocated_revenue_ccid,
               t_orgname, 
               t_calc_discount_on_lines_flag,
               t_change_printed_invoice_flag,
               t_code_combination_id_loss,
               t_create_reciprocal_flag,
               t_default_country,
               t_default_territory, 
               t_generate_customer_number,
               t_invoice_deletion_flag,
               t_id_flex_structure_name,
               t_site_required_flag,
               t_tax_allow_compound_flag,
               t_tax_invoice_print,
               t_tax_method,
               t_tax_use_customer_exempt_flag,
               t_tax_use_cust_exc_rate_flag,
               t_tax_use_loc_exc_rate_flag,
               t_tax_use_product_exempt_flag,
               t_tax_use_prod_exc_rate_flag,
               t_tax_use_site_exc_rate_flag,
               t_ai_log_file_message_level,
               t_ai_max_memory_in_bytes,
               t_ai_acct_flex_key_left_prompt,
               t_ai_mtl_items_key_left_prompt,
               t_ai_territory_key_left_prompt,
               t_ai_purge_interface_tab_flag,
               t_ai_activate_sql_trace_flag,
               t_set_of_books_id,
               t_created_by,
               t_creation_date,
               t_last_updated_by,
               t_last_update_date,
               t_last_update_login,
               t_accounting_method,
               t_accrue_interest,
               t_unearned_discount,
               t_partial_discount_flag,
               t_print_remit_to,
               t_default_cb_due_date,
               t_auto_site_numbering,
               t_cash_basis_set_of_books_id,
               t_code_combination_id_gain,
               t_autocash_hierarchy_id,
               t_run_gl_journal_import_flag,
               t_cer_split_amount,
               t_cer_dso_days,
               t_posting_days_per_cycle,
               t_address_validation,
               t_tax_code,
               t_tax_currency_code,
               t_tax_header_level_flag,
               t_tax_minimum_accountable_unit,
               t_tax_precision,
               t_tax_rounding_rule,
               t_tax_rounding_allow_override,
               t_rule_set_id,
               t_tax_use_account_exc_rate_flg,
               t_tax_use_system_exc_rate_flag,
               t_tax_hier_site_exc_rate,
               t_tax_hier_cust_exc_rate,
               t_tax_hier_prod_exc_rate,
               t_tax_hier_account_exc_rate,
               t_tax_hier_system_exc_rate,
               t_tax_enforce_account_flag,
               t_tax_database_view_set,
               t_inclusive_tax_used,
               t_code_combination_id_round,
               t_trx_header_level_rounding,
               t_trx_header_round_ccid,
               t_trxname, 
               t_sales_tax_geocode,
               t_bills_receiv_enabled_flag,
               t_ta_installed_flag,
               t_sobname  
      FROM     AR_SYSTEM_PARAMETERS a, 
               HR_ALL_ORGANIZATION_UNITS b, 
               FND_ID_FLEX_STRUCTURES_VL c, 
               AR_RECEIVABLES_TRX d , 
               GL_SETS_OF_BOOKS e 
      WHERE    b.organization_id(+) = a.org_id 
      AND      c.id_flex_code = 'RLOC' 
      AND      c.id_flex_num  = a.location_structure_id
      AND      d.receivables_trx_id(+) = a.finchrg_receivables_trx_id 
      AND      e.set_of_books_id = a.set_of_books_id;

   -- select ar_system_parameters columns added after base release 
   -- dynamic sql depending on whether the column exists 

      IF column_exists('AR_SYSTEM_PARAMETERS','REV_TRANSFER_CLEAR_CCID') = 'Y' THEN
         t_new_columns := 'rev_transfer_clear_ccid ';
      ELSE 
         t_new_columns := ' Null ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','SALES_CREDIT_PCT_LIMIT') = 'Y' THEN
         t_new_columns := t_new_columns || ', sales_credit_pct_limit ';
      ELSE 
         t_new_columns := t_new_columns ||  ', Null ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','MAX_WRTOFF_AMOUNT') = 'Y' THEN
         t_new_columns := t_new_columns || ', max_wrtoff_amount ';
      ELSE 
         t_new_columns := t_new_columns ||  ', Null ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','IREC_CC_RECEIPT_METHOD_ID') = 'Y' THEN
         t_new_columns := t_new_columns || ', irec_cc_receipt_method_id ';
      ELSE 
         t_new_columns := t_new_columns ||  ', Null ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','SHOW_BILLING_NUMBER_FLAG') = 'Y' THEN
         t_new_columns := t_new_columns || ', show_billing_number_flag ';
      ELSE 
         t_new_columns := t_new_columns ||  ', Null ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','CROSS_CURRENCY_RATE_TYPE') = 'Y' THEN
         t_new_columns := t_new_columns || ', cross_currency_rate_type ';
      ELSE 
         t_new_columns := t_new_columns ||  ', Null ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','DOCUMENT_SEQ_GEN_LEVEL') = 'Y' THEN
         t_new_columns := t_new_columns || ', document_seq_gen_level ';
      ELSE 
         t_new_columns := t_new_columns ||  ', Null ';
      END IF; 
      IF column_exists('AR_SYSTEM_PARAMETERS','CALC_TAX_ON_CREDIT_MEMO_FLAG') = 'Y' THEN
         t_new_columns := t_new_columns || ', calc_tax_on_credit_memo_flag ';
      ELSE 
         t_new_columns := t_new_columns ||  ', Null ';
      END IF; 

      sqltxt := 'SELECT ' || t_new_columns ||
                'FROM        AR_SYSTEM_PARAMETERS';
 
      l_cursor := dbms_sql.open_cursor;
      dbms_sql.parse( l_cursor, sqltxt, dbms_sql.native);
      dbms_sql.define_column( l_cursor, 1, t_sales_credit_pct_limit );
      dbms_sql.define_column( l_cursor, 2, t_rev_transfer_clear_ccid ); 
      dbms_sql.define_column( l_cursor, 3, t_max_wrtoff_amount );
      dbms_sql.define_column( l_cursor, 4, t_irec_cc_receipt_method_id );
      dbms_sql.define_column( l_cursor, 5, t_show_billing_number_flag, 1 );
      dbms_sql.define_column( l_cursor, 6, t_cross_currency_rate_type, 30 );
      dbms_sql.define_column( l_cursor, 7, t_document_seq_gen_level, 80 );
      dbms_sql.define_column( l_cursor, 8, t_calc_tax_on_credit_memo_flag, 1 );

      l_counter := dbms_sql.execute(l_cursor);
      l_counter := 0; 

      WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
         l_counter := l_counter + 1;
         dbms_sql.column_value( l_cursor, 1, t_sales_credit_pct_limit );
         dbms_sql.column_value( l_cursor, 2, t_rev_transfer_clear_ccid );
         dbms_sql.column_value( l_cursor, 3, t_max_wrtoff_amount );
         dbms_sql.column_value( l_cursor, 4, t_irec_cc_receipt_method_id );
         dbms_sql.column_value( l_cursor, 5, t_show_billing_number_flag );
         dbms_sql.column_value( l_cursor, 6, t_cross_currency_rate_type );
         dbms_sql.column_value( l_cursor, 7, t_document_seq_gen_level );
         dbms_sql.column_value( l_cursor, 8, t_calc_tax_on_credit_memo_flag );
      END LOOP; 
      IF l_counter = 0 then
         RAISE NO_DATA_FOUND;
      END IF;   
      dbms_sql.close_cursor(l_cursor);

   -- System Options - accounting

      Tab1Print('Accounting');
      Tab2Print('Accounting Method = ' || t_accounting_method );
      Tab2Print('Organization Name = ' || t_orgname );
      Tab2Print('Set of Books Name = ' || t_sobname );
                                       
      v_sobid   := t_set_of_books_id; 
      v_sobname := t_sobname;
      
   -- Pick up currency and precision for currency of the set of books  
      BEGIN -- level 4
        SELECT  a.currency_code, 
                a.precision 
        INTO    t_currency_code,
                t_precision  
        FROM    FND_CURRENCIES_VL a, 
                GL_SETS_OF_BOOKS b
        WHERE   b.set_of_books_id = t_set_of_books_id
        AND     b.currency_code   = a.currency_code ;
      EXCEPTION 
        WHEN NO_DATA_FOUND THEN 
             ErrorPrint('No currency defined for set of books "' || v_sobname || '"' );
             ActionerrorPrint('Define currency for set of books "' || v_sobname || '"' );
      END;  -- level 4

      Tab3Print('Set of Books Id = ' || to_char(v_sobid)); 
      Tab3Print('Currency = ' || t_currency_code );
      Tab3Print('Currency Precision = ' || t_precision );

   -- System Options - Tax 
    
      IF column_exists('AR_SYSTEM_PARAMETERS','CALC_TAX_ON_CREDIT_MEMO_FLAG') = 'Y' THEN
         BrPrint;
         Tab1Print('Tax');
         IF t_calc_tax_on_credit_memo_flag  = 'Y' THEN 
            t_calc_tax_on_credit_memo_flag := 'Yes'; 
         ELSIF t_calc_tax_on_credit_memo_flag = 'N' THEN
            t_calc_tax_on_credit_memo_flag := 'No'; 
         END IF; 
         Tab2Print('Calculate Tax On Credit Memo During AutoInvoice = '|| t_calc_tax_on_credit_memo_flag );
      END IF;

   -- System Options : Transactions and Customers

      BrPrint; 
      Tab1Print('Transactions and Customers');
      Tab2Print('Allow Changes to Printed Transactions = ' || t_change_printed_invoice_flag );
      Tab2Print('Allow Payment of Unrelated Transactions = '  || t_pay_unrelated_invoices_flag );
      Tab2Print('Allow Transaction Deletion = ' || t_invoice_deletion_flag );

      IF column_exists('AR_SYSTEM_PARAMETERS','SHOW_BILLING_NUMBER_FLAG') = 'Y' THEN
         IF t_show_billing_number_flag  = 'Y' THEN
            t_show_billing_number_flag := 'Yes';
         ELSIF t_show_billing_number_flag = 'N' THEN
            t_show_billing_number_flag := 'No' ;
         END IF; 
         Tab2Print('Show Billing Number = '|| t_show_billing_number_flag ); 
      END IF; 

      IF column_exists('AR_SYSTEM_PARAMETERS','DOCUMENT_SEQ_GEN_LEVEL') = 'Y' THEN
         If    t_document_seq_gen_level  = 'WHEN_TRX_COMMITTED' THEN 
               t_document_seq_gen_level := 'When Saved'; 
         ELSIF t_document_seq_gen_level  = 'WHEN_TRX_COMPLETED' THEN 
               t_document_seq_gen_level := 'When Completed'; 
         ELSIF t_document_seq_gen_level IS Null THEN
               t_document_seq_gen_level := 'None';
         END IF;
         Tab2Print('Document Number Generation Level = '|| t_document_seq_gen_level ); 
      END IF; 

      Tab2Print('AutoInvoice');

      Tab3Print('Accounting Flex Tuning Segment = ' || t_ai_acct_flex_key_left_prompt );
      Tab3Print('System Item Tuning Segment = ' || t_ai_mtl_items_key_left_prompt );
      Tab3Print('Territory Tuning segment = ' || t_ai_territory_key_left_prompt ); 
      
      Tab3Print('Max Memory in Bytes = ' || t_ai_max_memory_in_bytes );
      IF t_ai_max_memory_in_bytes  < 3000000 THEN 
         WarningPrint('Max memory setting is less than 3MB. This decreases AutoInvoice performance when processing '||
              'a large volume of data');
         ActionWarningPrint('Suggested max memory setting for AutoInvoice is 3MB or higher if the machine has enough memory');
      END IF; 

      IF t_ai_max_memory_in_bytes  > 10000000 THEN 
         WarningPrint('Max memory setting is greater than 10MB. A too high setting can decrease AutoInvoice '||
              'performance just as well as a too low setting');
         ActionWarningPrint('Suggested Max Memory setting for AutoInvoice is 3MB or higher if the machine has enough memory');
      END IF; 

      Tab3Print('Log File Message Level = ' || t_ai_log_file_message_level  );
      IF t_ai_log_file_message_level > 1 THEN 
         WarningPrint('Log file message level is set to greater than 1. This decreases AutoInvoice performance');
         ActionWarningprint('Suggested Log File Message Level for day to day business is 1. Change the log file message '||
              'level to 3 or above only when troubleshooting AutoInvoice issues'); 
      END IF; 

      Tab3Print('SQL Trace = ' || t_ai_activate_sql_trace_flag );
      IF t_ai_activate_sql_trace_flag = 'Y' THEN 
         Warningprint('Sql trace is turned on. This decreases AutoInvoice performance');
         ActionWarningPrint('Uncheck the sql trace checkbox to improve AutoInvoice performance. '||
              'Check the sQL trace checkbox only when troubleshooting AutoInvoice issues.');
      END IF;

      Tab3Print('Purge Interface Table = ' ||  t_ai_purge_interface_tab_flag );

      Tab2Print('Customers');
      Tab3Print('Automatic Customer Numbering = '|| t_generate_customer_number );
      Tab3Print('Automatic Site Numbering = '    || t_auto_site_numbering );
      Tab3Print('Create Reciprocal Customer = '  || t_create_reciprocal_flag );

   -- 'Grouping Rule Name' -- not Null column -- Print associated name iso id 
      BEGIN
        SELECT name 
        INTO   t_grouping_rule_name 
        FROM   RA_GROUPING_RULES
        WHERE  grouping_rule_id = t_default_grouping_rule_id;  
        Tab3Print('Grouping Rule Name = ' || t_grouping_rule_name );
        v_grouping_rule_id   := t_default_grouping_rule_id;  
        v_grouping_rule_name := t_grouping_rule_name ;
        V_group_flag := 'S'; 
      EXCEPTION 
        WHEN NO_DATA_FOUND THEN 
             ErrorPrint( 'Grouping rule name is set to an invalid value');
             ACtionErrorPrint ('Redefine grouping rule name in system options');
      END; 
      
    EXCEPTION   
      WHEN NO_DATA_FOUND THEN   
           ErrorPrint ('AR system options have not been defined for this operating unit');
           ActionErrorPrint ('Please refer to the Users Guide to define AR system options');
           RAISE STOPEXECUTION;
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "System Options"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;   -- level 3 AR System Options 

/* ---------------------------------- Batch source ----------------------------------------------------- */ 

    DECLARE 
      t_batch_source_id             NUMBER(15)  := Null;
      t_batch_source_type           VARCHAR2(30):= Null;  
      t_name                        VARCHAR2(50):= Null;
      t_start_date                  DATE        := Null;
      t_end_date                    DATE        := Null;
      t_org_id                      NUMBER(15)  := Null;
      t_description                 VARCHAR2(240):=Null;
      t_status                      VARCHAR2(30):= Null;
      t_auto_batch_num_flag         VARCHAR2(4) := Null;
      t_last_batch_num              NUMBER(15)  := Null;
      t_auto_trx_num_flag           VARCHAR2(4) := Null;
      t_default_inv_trx_type        NUMBER(15)  := Null;
      t_credit_memo_batch_source_id NUMBER(15)  := Null;
      t_invalid_tax_rate_rule       VARCHAR2(30):= Null;
      t_invalid_lines_rule          VARCHAR2(30):= Null;
      t_gl_date_period_rule         VARCHAR2(30):= Null;
      t_grouping_rule_id            NUMBER(15)  := Null;
      t_create_clearing_flag        VARCHAR2(4) := Null;
      t_allow_sales_credit_flag     VARCHAR2(4) := Null;
      t_sold_customer_rule          VARCHAR2(30):= Null;
      t_bill_customer_rule          VARCHAR2(30):= Null;
      t_bill_address_rule           VARCHAR2(30):= Null;
      t_bill_contact_rule           VARCHAR2(30):= Null;
      t_ship_customer_rule          VARCHAR2(30):= Null;
      t_ship_address_rule           VARCHAR2(30):= Null;
      t_ship_contact_rule           VARCHAR2(30):= Null;
      t_receipt_method_rule         VARCHAR2(30):= Null;
      t_customer_bank_account_rule  VARCHAR2(30):= Null;
      t_invoicing_rule_rule         VARCHAR2(30):= Null;
      t_accounting_rule_rule        VARCHAR2(30):= Null;
      t_accounting_flexfield_rule   VARCHAR2(30):= Null;
      t_derive_date_flag            VARCHAR2(4) := Null;
      t_term_rule                   VARCHAR2(30):= Null;
      t_rev_acc_allocation_rule     VARCHAR2(30):= Null;
      t_cust_trx_type_rule          VARCHAR2(30):= Null;
      t_memo_reason_rule            VARCHAR2(30):= Null;
      t_agreement_rule              VARCHAR2(30):= Null;
      t_memo_line_rule              VARCHAR2(30):= Null;
      t_sales_territory_rule        VARCHAR2(30):= Null;
      t_inventory_item_rule         VARCHAR2(30):= Null;
      t_unit_of_measure_rule        VARCHAR2(30):= Null;
      t_fob_point_rule              VARCHAR2(30):= Null;
      t_ship_via_rule               VARCHAR2(30):= Null;
      t_related_document_rule       VARCHAR2(30):= Null;
      t_salesperson_rule            VARCHAR2(30):= Null;
      t_sales_credit_type_rule      VARCHAR2(30):= Null;
      t_sales_credit_rule           VARCHAR2(30):= Null;
  
      t_copy_doc_number_flag        VARCHAR2(1)   := Null;
      t_default_reference           VARCHAR2(80):= Null;
      t_trx_last_number             NUMBER      := Null;
      t_sequence_name               VARCHAR2(30):= Null;
      t_cache_size                  NUMBER      := Null;  
      t_trx_type_name               VARCHAR2(20):= 'null'; 
      t_default_ref_meaning         VARCHAR2(80):= 'null'; 
      t_credit_memo_batch_name      VARCHAR2(30):= 'null';
      t_grouping_rule_name          VARCHAR2(40):= 'null'; 

      t_new_columns                 VARCHAR2(1000):= Null;
    BEGIN 
      SectionPrint('Batch Source Set Up'); 
    
      SELECT    batch_source_id,
                decode(batch_source_type,'INV','Manual','FOREIGN','Imported', batch_source_type ), 
                name,
                start_date,
                end_date,
                org_id,
                NVL(description,'null'),
                decode (status,'A','Active','I','Inactive', status ), 
                NVL(auto_batch_numbering_flag,'null'),
                last_batch_num,
                NVL(auto_trx_numbering_flag,'null'), 
                default_inv_trx_type,
                credit_memo_batch_source_id,
                NVL(invalid_tax_rate_rule,'null'),
                decode(invalid_lines_rule,'Create','Create Invoice','Reject','Reject Invoice', invalid_lines_rule ),
                gl_date_period_rule, 
                grouping_rule_id,
                NVL(create_clearing_flag,'null'), 
                NVL(allow_sales_credit_flag,'null'), 
                NVL(sold_customer_rule,'null'), 
                NVL(bill_customer_rule,'null'), 
                NVL(bill_address_rule,'null'),
                NVL(bill_contact_rule,'null'),
                NVL(ship_customer_rule,'null'),
                NVL(ship_address_rule,'null'),
                NVL(ship_contact_rule,'null'),
                NVL(receipt_method_rule,'null'),
                NVL(customer_bank_account_rule,'null'),
                NVL(invoicing_rule_rule,'null'),
                NVL(accounting_rule_rule,'null'),
                NVL(accounting_flexfield_rule,'null'),
                NVL(derive_date_flag,'null'),
                NVL(term_rule,'null'),
                NVL(rev_acc_allocation_rule,'null'),
                NVL(cust_trx_type_rule,'null'),
                NVL(memo_reason_rule,'null'),
                NVL(agreement_rule,'null'),
                NVL(memo_line_rule,'null'),
                NVL(sales_territory_rule,'null'),
                NVL(inventory_item_rule,'null'),
                NVL(unit_of_measure_rule,'null'),
                NVL(fob_point_rule,'null'),
                NVL(ship_via_rule,'null'),
                NVL(related_document_rule,'null'), 
                NVL(salesperson_rule,'null'),
                NVL(sales_credit_type_rule,'null'),
                NVL(sales_credit_rule,'null')
      INTO      t_batch_source_id,
                t_batch_source_type, 
                t_name,
                t_start_date,
                t_end_date,
                t_org_id,
                t_description,
                t_status, 
                t_auto_batch_num_flag,
                t_last_batch_num,
                t_auto_trx_num_flag,
                t_default_inv_trx_type,
                t_credit_memo_batch_source_id,
                t_invalid_tax_rate_rule,
                t_invalid_lines_rule,
                t_gl_date_period_rule, 
                t_grouping_rule_id,
                t_create_clearing_flag,
                t_allow_sales_credit_flag,
                t_sold_customer_rule,
                t_bill_customer_rule,
                t_bill_address_rule,
                t_bill_contact_rule,
                t_ship_customer_rule,
                t_ship_address_rule,
                t_ship_contact_rule,
                t_receipt_method_rule,
                t_customer_bank_account_rule,
                t_invoicing_rule_rule,
                t_accounting_rule_rule,
                t_accounting_flexfield_rule,
                t_derive_date_flag,
                t_term_rule,
                t_rev_acc_allocation_rule,
                t_cust_trx_type_rule,
                t_memo_reason_rule,
                t_agreement_rule,
                t_memo_line_rule,
                t_sales_territory_rule,
                t_inventory_item_rule,
                t_unit_of_measure_rule,
                t_fob_point_rule,
                t_ship_via_rule,
                t_related_document_rule, 
                t_salesperson_rule,
                t_sales_credit_type_rule,
                t_sales_credit_rule
      FROM      RA_BATCH_SOURCES 
      WHERE     batch_source_id = p_batchid
      AND       status = 'A'
      AND       batch_source_type = 'FOREIGN' 
      AND       NVL( start_date, sysdate) <= sysdate 
      AND       NVL( end_date, sysdate)   >= sysdate;

  --  Derive with dynamic SQL columns added after base release  

      IF column_exists('RA_BATCH_SOURCES','COPY_DOC_NUMBER_FLAG') = 'Y' THEN
         t_new_columns := 'copy_doc_number_flag ';
      ELSE 
         t_new_columns := ' NULL ';
      END IF; 
      IF column_exists('RA_BATCH_SOURCES','DEFAULT_REFERENCE') = 'Y' THEN
         t_new_columns := t_new_columns || ', default_reference ';
      ELSE 
         t_new_columns := t_new_columns ||  ', NULL ';
      END IF; 

      sqltxt := 'SELECT ' || t_new_columns ||
                'FROM        RA_BATCH_SOURCES '||
                'WHERE       batch_source_id = ' || to_char(p_batchid ) ||
                ' AND        status = ''A'' '||
                ' AND        batch_source_type = ''FOREIGN''   '|| 
                ' AND        NVL( start_date, sysdate) <= sysdate '|| 
                ' AND        NVL( end_date, sysdate)   >= sysdate ';
 
      l_cursor := dbms_sql.open_cursor;
      dbms_sql.parse( l_cursor, sqltxt, dbms_sql.native);
      dbms_sql.define_column( l_cursor, 1, t_copy_doc_number_flag, 1 );
      dbms_sql.define_column( l_cursor, 2, t_default_reference, 80 ); 
  
      l_counter := dbms_sql.execute(l_cursor);
      l_counter := 0; 

      WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
         l_counter := l_counter + 1;
         dbms_sql.column_value( l_cursor, 1, t_copy_doc_number_flag );
         dbms_sql.column_value( l_cursor, 2, t_default_reference );
      END LOOP; 
      IF l_counter = 0 then
         RAISE NO_DATA_FOUND;
      END IF;   
      dbms_sql.close_cursor(l_cursor);

   -- start reporting batch source Info  
      Tab1Print('Name = '|| t_name || '( id = ' || p_batchid || ' )' );   
      Tab1Print('Type = '|| t_batch_source_type );

   -- Batch source Tab
      BrPrint;  
      Tab1Print('Batch Source');
      Tab2Print('Description = ' || t_description );
      Tab2Print('Status = '      || t_status );
      Tab2Print('Effective Start Date = '|| t_start_date || ' - Effective End Date = ' || t_end_date );
      Tab2Print('Automatic Batch Numbering = ' || t_auto_batch_num_flag );

      IF t_auto_batch_num_flag = 'Y' THEN 
         Tab3Print('Last Number = '|| to_char(t_last_batch_num) );
      END IF;

      Tab2Print('Automatic Transaction Number = ' || t_auto_trx_num_flag );

      IF t_auto_trx_num_flag = 'Y' THEN

        BEGIN 
          SELECT    last_number-1,
                  sequence_name,
                  cache_size       
          INTO    t_trx_last_number,
                  t_sequence_name,
                  t_cache_size
          FROM      ALL_SEQUENCES 
        WHERE   sequence_name like 'RA_TRX_NUMBER%'|| to_char(p_batchid) ||'%'|| v_orgid ||'%';
          Tab3Print('Last Number = '|| to_char(t_trx_last_number) ||' ( Sequence = '|| t_sequence_name ||' )' );
          IF t_cache_size > 0 THEN 
             WarningPrint('The sequence "' || t_sequence_name || '" has a cache size of ' || t_cache_size || 
                  '. Automatic transaction numbering might result in gaps in transaction numbers' );  
             ActionWarningLink('If the gapless transaction numbering is required, please review Note: ', '143682.1', 
                  'for detailed information.');
          END IF; 
        EXCEPTION 
          WHEN NO_DATA_FOUND THEN
               ErrorPrint('The sequence RA_TRX_NUMBER%' || to_char(p_batchid) || '%' || v_orgid ||
                          '% for batch ' || t_name || ' is not defined'); 
             ActionErrorPrint('Review this sequence');
          WHEN OTHERS THEN 
               Null;
        END;  
        END IF;

      IF column_exists('RA_BATCH_SOURCES','COPY_DOC_NUMBER_FLAG') = 'Y' THEN
         Tab2Print('Copy Document Number to Transaction Number = ' || t_copy_doc_number_flag );
      END IF; 
 
      IF column_exists('RA_BATCH_SOURCES','DEFAULT_REFERENCE') = 'Y' THEN
         IF t_default_reference  is Null THEN
            WarningPrint('Reference Field Default Value is not defined');
            ActionWarningPrint('Define Reference Field Default Value for Batch Source '|| t_name || 
                 ' in order not to use the default of "Interface_header_attribute1"');
         ELSE
            BEGIN 
              SELECT    meaning 
              INTO      t_default_ref_meaning 
              FROM      AR_LOOKUPS 
              WHERE     lookup_type = 'PA_CODE'
              AND       lookup_code = t_default_reference;
              Tab2Print('Reference Field Default value = ' || t_default_ref_meaning ); 
            EXCEPTION 
              WHEN NO_DATA_FOUND THEN 
                ErrorPrint('Reference field default value is set to an invalid value ');
                ActionErrorPrint ('Redefine reference field default value for batch source '|| t_name || '"');
            END; 
         END IF; 
      END IF; 

      IF t_default_inv_trx_type is NOT NULL THEN 
         BEGIN 
           SELECT       name 
           INTO         t_trx_type_name 
           FROM         RA_CUST_TRX_TYPES 
           WHERE        cust_trx_type_id = t_default_inv_trx_type; 
         EXCEPTION
           WHEN NO_DATA_FOUND THEN 
                ErrorPrint( 'Standard transaction type is set to an invalid value ');
                ActionErrorPrint ('Redefine standard transaction type for batch source '|| t_name );
         END;
      END IF;         
      Tab2Print('Standard Transaction Type = '|| t_trx_type_name ); 
 
      IF t_credit_memo_batch_source_id is NOT Null THEN 
         BEGIN 
           SELECT   name 
           INTO         t_credit_memo_batch_name 
           FROM         RA_BATCH_SOURCES 
           WHERE        batch_source_id = t_credit_memo_batch_source_id ;
         EXCEPTION 
           WHEN NO_DATA_FOUND THEN 
                ErrorPrint('Credit memo batch source is set to an invalid value ');
                ActionErrorPrint('Redefine credit memo batch source for batch source '|| t_name );
         END;
      END IF;
      Tab2Print('Credit Memo Batch Source = ' || t_credit_memo_batch_name ); 

   -- AutoInvoice Tab
      BrPrint; 
      Tab1Print('AutoInvoice Options');
      Tab2Print('Invalid Tax Rate = '|| t_invalid_tax_rate_rule );
      Tab2Print('Invalid Lines = '   || t_invalid_lines_rule );
      Tab2Print('GL Date in a Closed Period = '|| t_gl_date_period_rule );

      IF t_grouping_rule_id is NOT Null THEN 
       BEGIN
           SELECT   name 
           INTO         t_grouping_rule_name 
           FROM     RA_GROUPING_RULES
           WHERE  grouping_rule_id = t_grouping_rule_id;
           v_grouping_rule_id   := t_grouping_rule_id;
           v_grouping_rule_name := t_grouping_rule_name; 
           v_group_flag := 'B'; 
         EXCEPTION 
           WHEN NO_DATA_FOUND THEN 
                ErrorPrint( 'Grouping rule is set to an invalid value ');
                ACtionErrorPrint ('Redefine grouping rule for batch source '|| t_name );
         END; 
      END IF; 
      Tab2Print('Grouping Rule = '|| t_grouping_rule_name ); 
 
      Tab2Print('Create Clearing = ' || t_create_clearing_flag );
      Tab2Print('Allow Sales Credit ='|| t_allow_sales_credit_flag );

   -- Customer Information Tab
      BrPrint; 
      Tab1Print('Customer Information');
      Tab2Print('Sold to customer = '|| t_sold_customer_rule );
      Tab2Print('Bill to customer = '|| t_bill_customer_rule );
      Tab2Print('Bill to address = ' || t_bill_address_rule );
      Tab2Print('Bill to contact = ' || t_bill_contact_rule );
      Tab2Print('Ship to Customer = '|| t_ship_customer_rule );
      Tab2Print('Ship to Address = ' || t_ship_address_rule );
      Tab2Print('Ship to Contact = ' || t_ship_contact_rule );
      Tab2Print('Payment Method Rule = '  || t_receipt_method_rule );
      Tab2Print('Customer Bank Account = '|| t_customer_bank_account_rule );

   -- Accounting Information Tab
      BrPrint; 
      Tab1Print('Accounting Information');
      Tab2Print('Invoicing Rule = '    || t_invoicing_rule_rule );
      Tab2Print('Accounting Rule = '   || t_accounting_rule_rule );
      Tab2Print('Accounting Flexfield '|| t_accounting_flexfield_rule );
      Tab2Print('Derive Date = '       || t_derive_date_flag );
      Tab2Print('Payment Terms = '     || t_term_rule );
      Tab2Print('Revenue Account Allocation = '|| t_rev_acc_allocation_rule );
    
   -- Other Information Tab
      BrPrint; 
      Tab1Print('Other Information');
      Tab2Print('Transaction Type = '|| t_cust_trx_type_rule );
      Tab2Print('Memo Reason = '     || t_memo_reason_rule );
      Tab2Print('Agreement = '       || t_agreement_rule );
      Tab2Print('Memo Line Rule = '  || t_memo_line_rule ); 
      Tab2Print('Sales Territory = ' || t_sales_territory_rule );
      Tab2Print('Inventory Item = '  || t_inventory_item_rule );
      Tab2Print('Unit of Measure = ' || t_unit_of_measure_rule );
      Tab2Print('FOB Point = '       || t_fob_point_rule );
      Tab2Print('Freight Carrier = ' || t_ship_via_rule );
      Tab2Print('Related Document = '|| t_related_document_rule );

   -- Sales Credit Validation Tab
      BrPrint; 
      Tab1Print('Sales Credit Validation');
      Tab2Print('Salesperson = '      || t_salesperson_rule );
      Tab2Print('Sales Credit Type = '|| t_sales_credit_type_rule );
      Tab2Print('Sales Credit = '     || t_sales_credit_rule );

    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           ErrorPrint('The batch source specified does not exist, is no longer active or is not of type "Import"'); 
           ActionErrorPrint('Choose a batch id from the list');
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Batch Source"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;  

/* -------------------------------- Grouping rule Details ----------------------------------------------- */

    DECLARE 
      t_name                 VARCHAR2(40):= Null; 
      t_description          VARCHAR2(80):= Null;
      t_start_date           DATE;
      t_end_date             DATE;
      t_ordering_rule_id     NUMBER; 
      
      t_name1                VARCHAR2(40):= Null; 
      t_description1         VARCHAR2(80):= Null;
      t_start_date1          DATE;
      t_end_date1            DATE;
      t_count                NUMBER := Null;
      t_first                VARCHAR2(1) := 'Y'; 

      CURSOR C1 ( rule_id NUMBER ) IS 
        SELECT   a.order_by_sequence seq,
                 b.column_name       col,
                 decode(a.order_by_type, 'A', 'Ascending', 'D', 'Descending', order_by_type ) type
        FROM     RA_LINE_ORDER_BYS a,
                 RA_LINE_ORDER_BY_COLUMNS b
        WHERE    a.ordering_rule_id = rule_id 
        AND      a.column_id        = b.column_id
        ORDER BY a.order_by_sequence Asc;

      CURSOR C2 IS
        SELECT   a.grouping_trx_type_id    type_id,
                 b.meaning  
        FROM     RA_GROUPING_TRX_TYPES a,
                 AR_LOOKUPS b
        WHERE    a.grouping_rule_id = v_grouping_rule_id
        AND      b.lookup_code = a.class 
        AND      b.lookup_type = 'GROUPING_TRX_TYPE';
      
      CURSOR C3 ( type_id NUMBER ) IS  
        SELECT   replace(b.from_column_name, 'L.','')  col 
        FROM     RA_GROUP_BYS a,
                 RA_GROUP_BY_COLUMNS b
        WHERE    a.grouping_trx_type_id = type_id 
        AND      b.column_id = a.column_id ; 
        
    BEGIN
      SectionPrint('Grouping Rule Set Up');
      IF v_group_flag in ('B', 'S' ) THEN
         IF v_group_flag = 'B' THEN 
            Tab1Print('Details of the grouping rule assigned to batch source "'|| v_batchname || '"' ); 
         ELSE 
            WarningPrint('Grouping rule is not defined for batch source "'|| v_batchname || '"' );
            ActionWarningPrint('Define a grouping rule for batch source "'|| v_batchname ||'" in order for AutoInvoice '||
                 'not to derive the default grouping rule from the following hierarchy : '||
                 'customer site level, customer profile option, system options ');   
            Tab1Print('Details of the grouping rule defined in system options will be reported instead' );
         END IF; 
      -- get grouping rule data  
         SELECT   name,
                  description,
                  start_date,
                  end_date,
                  ordering_rule_id
         INTO     t_name,
                  t_description,
                  t_start_date,
                  t_end_date,
                  t_ordering_rule_id 
         FROM     RA_GROUPING_RULES
         WHERE    grouping_rule_id = v_grouping_rule_id
         AND      NVL( start_date, sysdate ) <= sysdate
         AND      NVL( end_date, sysdate )   >= sysdate ;

         Tab1Print('Name = ' || t_name || ' ( id = ' || to_char(v_grouping_rule_id) || ' )' );
         Tab1Print('Description = ' || t_description );
         Tab1Print('Start Date = '|| t_start_date || ' - End Date = ' || t_end_date );

      -- get associated line ordering rule date    
         IF t_ordering_rule_id  IS NOT NULL THEN 
            BEGIN 
              SELECT  name,
                      description,
                      start_date,
                      end_date
              INTO    t_name1,
                      t_description1,
                      t_start_date1,
                      t_end_date1
              FROM    RA_LINE_ORDERING_RULES
              WHERE   ordering_rule_id = t_ordering_rule_id  
              AND     NVL( start_date, sysdate ) <= sysdate
              AND     NVL( end_date, sysdate )   >= sysdate ;

              Tab1Print('Line Ordering Rule = '|| t_name1 || '( id = ' || to_char(t_ordering_rule_id) ||' )' );
              Tab2Print('Description = '|| t_description1 );
              Tab2Print('Start Date = '|| t_start_date1  || ' - End Date = '|| t_end_date1 ) ; 
          Tab2Print('Order by : ');

              l_count := 0;
              FOR C1_rec in C1 (  t_ordering_rule_id  ) LOOP 
                  Tab3Print( 'Sequence = ' || c1_rec.seq || ', Attribute = ' || c1_rec.col || ', Type = '|| c1_rec.type);                                   
                  l_count := l_count + 1; 
              END LOOP; 
              IF l_count = 0 then 
                 ErrorPrint('Line ordering rule "'|| t_name1 || '" has no "order by" data' );
                 ActionErrorPrint('Define "Order by" details for this line ordering rule' );
              END IF;

            EXCEPTION
              WHEN NO_DATA_FOUND THEN 
                   Errorprint('Ordering rule assigned to grouping rule "'|| t_name || '" is not valid or active '); 
                   ActionErrorPrint('Assign an active line ordering rule to this grouping rule');
            END;
         ELSE 
            WarningPrint('Line ordering rule is not defined for grouping rule "'|| t_name || '"');
            ActionWarningprint('Assign line ordering rule to this grouping rule to prevent AutoInvoice '||
                 'from ordering lines randomly on an invoice');
         END IF;

      -- get transaction classes belonging to the grouping rules 
         Tab1Print('Transaction Class' );
         l_count := 0;
         FOR C2_REC in C2 LOOP
             IF t_first = 'Y' THEN 
                t_first := 'N';
             ELSE
                BrPrint;
             END IF; 
             Tab2Print ('Class = '|| c2_rec.meaning );
             Tab2Print ('Optional Grouping Characteristics');
             t_count := 0;
             FOR C3_REC in C3 ( C2_REC.type_id ) LOOP 
                 Tab3Print( C3_rec.col );
                 t_count := t_count + 1; 
             END LOOP;
             IF t_count = 0 THEN
                Tab3Print('There are no optional grouping characteristics defined for this class ');   
             END IF;
             l_count := l_count +1; 
         END LOOP;     
         IF l_count = 0 THEN 
            Tab2Print ('There are no transaction classes defined for this grouping rule' ); 
         END IF; 
      ELSE 
         ErrorPrint('No valid grouping rule was defined for this batch source, nor in system options');
         ActionErrorprint('Define a grouping rule for batch source "'|| v_batchname || '"'); 
      END IF;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
          ErrorPrint('Grouping rule "'|| v_grouping_rule_name || '" is not valid or active');  
          ActionErrorPrint('Define a grouping rule for batch source "'|| v_batchname || '"'); 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Gouping Rule Set up"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* -------------------------------- Open Calender Periods AR -------------------------------------------- */ 

    BEGIN 
      IF v_sobid is NOT Null then 
         SectionPrint('Open Calendar Periods - AR');
         checkFinPeriod(v_sobid ,222);
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Open Calendar Periods" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------------ Accounting Flexfield -------------------------------------------- */ 

    DECLARE  
      t_chart_of_acc_id      NUMBER(15);
      t_chart_of_acc_name    VARCHAR2(30); 
      t_sqltxt       varchar2(32767);
    BEGIN
      SectionPrint('Accounting Flexfield');
      
      SELECT    a.chart_of_accounts_id,
                a.chart_of_accounts_name
      INTO      t_chart_of_acc_id, 
                t_chart_of_acc_name   
      FROM      gl_sets_of_books_v a, 
                ar_system_parameters b
      WHERE     a.set_of_books_id = b.set_of_books_id;

      Tab1Print('Organization "' || v_orgname || '" is using accounting flexfield "'|| t_chart_of_acc_name || '"');
      checkKeyFlexfield('GL#', t_chart_of_acc_id, true  );

    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('AR system options have not been defined for this operating unit. Unable '||
                'to check accounting flexfield.');
           ActionErrorPrint('Please refer to Users Guide and define AR system options');
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Accounting Flexfield"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ----------------------------- Sales Tax Location Flexfield Structure ---------------------------------- */ 

    DECLARE  
      t_location_structure_id     VARCHAR2(15);
      t_location_structure_name   VARCHAR2(30); 
    BEGIN
      SectionPrint('Sales Tax Location Flexfield Structure');
     
      SELECT    to_char(a.location_structure_id),
                c.id_flex_structure_name 
      INTO      t_location_structure_id,
                t_location_structure_name  
      FROM      AR_SYSTEM_PARAMETERS a, 
                FND_ID_FLEX_STRUCTURES_VL c 
      WHERE     c.id_flex_code = 'RLOC' 
      AND       c.id_flex_num  = a.location_structure_id; 

      Tab1Print('Location flexfield structure is set to "'|| t_location_structure_name || '" in system options' );
      -- checkKeyFlexfield('RLOC', to_number(t_location_structure_id), true );

      -- a valid Sales Tax Location Flexfield requires a contexts for each of the following 5 
      -- descriptive flexfields :
      -- 1) Descriptive flexfield Sales Tax Rate Assignment - name AR_SALES_TAX_RATES
      l_count     := 0; 
      SELECT      count(*)
      INTO        l_count  
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'AR_SALES_TAX_RATES' 
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         a.descriptive_flex_context_code = t_location_structure_id   
      AND         0 < ( SELECT  count(*)          FROM   FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE   b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND     b.enabled_flag = 'Y'  AND  b.descriptive_flexfield_name = 'AR_SALES_TAX_RATES');

      IF l_count = 1 THEN 
         Tab2Print ('The descriptive flexfield  "Sales Tax Rate Assigment" has one context enabled for "'||
              t_location_structure_name || '"');  
      ELSE 
         Errorprint('An enabled context for the descriptive flexfield  "Sales Tax Rate Assigment" has not been set '||
              'up for "' || t_location_structure_name  ||'"');
         ActionErrorPrint('Please see the Receivables Tax User Guide on how to define the sales tax location '||
              'flexfield structure. Chapter : Tax Calculation');
      END IF; 

      -- 2) Descriptive flexfield Item Exception Rate Assignment - name RA_ITEM_EXCEPTION_RATES_RATES
      l_count     := 0; 
      SELECT      count(*)
      INTO        l_count  
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'RA_ITEM_EXCEPTION_RATES_RATES'
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         a.descriptive_flex_context_code = t_location_structure_id   
      AND         0 < ( SELECT  count(*)          FROM   FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE   b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND     b.enabled_flag = 'Y'  AND  b.descriptive_flexfield_name = 'RA_ITEM_EXCEPTION_RATES_RATES');

      IF l_count = 1 THEN 
         Tab2Print ('The descriptive flexfield  "Item Exception Rate Assignment" has one context enabled for "'||
              t_location_structure_name || '"');  
      ELSE  
         Errorprint('An enabled context for the descriptive flexfield  "Item Exception Rate Assignment" has not '||
              'been set up for "' || t_location_structure_name || '"' );
         ActionErrorPrint('Please see the Receivables Tax User Guide on how to define the sales tax location '||
              'flexfield structure. Chapter : Tax Calculation');
      END IF; 

      -- 3) Descriptive flexfield Item Exception Rate Location - name RA_ITEM_EXCEPTION_RATES_LOC
      l_count     := 0; 
      SELECT      count(*)
      INTO        l_count  
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'RA_ITEM_EXCEPTION_RATES_LOC'
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         a.descriptive_flex_context_code = t_location_structure_id   
      AND         0 < ( SELECT  count(*)          FROM   FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE   b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND     b.enabled_flag = 'Y'  AND  b.descriptive_flexfield_name = 'RA_ITEM_EXCEPTION_RATES_LOC');

      IF l_count = 1 THEN 
         Tab2Print ('The descriptive flexfield  "Item Exception Rate Location" has one context enabled for "'||
              t_location_structure_name  || '"');  
      ELSE  
         Errorprint('An enabled context for the descriptive flexfield  "Item Exception Rate Location" has not '||
              'been set up for "' || t_location_structure_name || '"');
         ActionErrorPrint('Please see the Receivables Tax User Guide on how to define the sales tax location '||
              'flexfield structure. Chapter : Tax Calculation');
      END IF; 

      -- 4) Descriptive flexfield Exempt Regions - name RA_TAX_EXEMPTION_REGIONS
      l_count     := 0; 
      SELECT      count(*)
      INTO        l_count  
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'RA_TAX_EXEMPTION_REGIONS'
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         a.descriptive_flex_context_code = t_location_structure_id   
      AND         0 < ( SELECT  count(*)          FROM   FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE   b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND     b.enabled_flag = 'Y'  AND  b.descriptive_flexfield_name = 'RA_TAX_EXEMPTION_REGIONS');

      IF l_count = 1 THEN        
         Tab2Print ('The descriptive flexfield  "Exempt Regions" has one context enabled for "'||
             t_location_structure_name  || '"');  
      ELSE  
         Errorprint('An enabled context for the descriptive flexfield  "Exempt Regions" has not been set '||
              'up for "' || t_location_structure_name  || '"');
         ActionErrorPrint('Please see the Receivables Tax User Guide on how to define the sales tax location '||
              'flexfield structure. Chapter : Tax Calculation');
      END IF; 

      -- 5) Descriptive flexfield  Override Sales Tax Rates - name AR_LOCATION_RATES_OVERRIDE
      l_count     := 0;
      SELECT      count(*)
      INTO        l_count  
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'AR_LOCATION_RATES_OVERRIDE'
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         a.descriptive_flex_context_code = t_location_structure_id   
      AND         0 < ( SELECT  count(*)          FROM   FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE   b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND     b.enabled_flag = 'Y'  AND  b.descriptive_flexfield_name = 'AR_LOCATION_RATES_OVERRIDE');

      IF l_count = 1 THEN 
         Tab2Print ('The descriptive Flexfield  "Override Sales Tax Rates" has one context enabled for "'||
              t_location_structure_name  || '"');  
      ELSE  
         Errorprint('An enabled context for the descriptive flexfield  "Override Sales Tax Rates" has not been '||
              'set up for "' || t_location_structure_name  || '"');
         ActionErrorPrint('Please see the Receivables Tax User Guide on how to define the sales tax location '||
              'flexfield structure. Chapter : Tax Calculation');
      END IF; 

    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('AR system options have not been defined for this operating unit. Unable '||
                'to check sales tax location flexfield.');
           ActionErrorPrint('Please refer to Users Guide and define AR system options');
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Sales Tax Location Flexfield Structure"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------------ Territory Flexfield --------------------------------------------- */ 

    DECLARE  
      t_id_flex_structure_name     VARCHAR2(30);
    BEGIN
      SectionPrint('Territory Flexfield');
  
      SELECT     a.id_flex_structure_name 
      INTO       t_id_flex_structure_name 
      FROM       FND_ID_FLEX_STRUCTURES_VL a
      WHERE      a.ID_FLEX_CODE = 'CT#' 
      AND        a.enabled_flag = 'Y'
      AND        a.freeze_flex_definition_flag = 'Y' 
      AND        0 < (  SELECT count(*) 
                        FROM   FND_ID_FLEX_SEGMENTS_VL b 
                        WHERE  b.id_flex_code = 'CT#' 
                        AND    b.enabled_flag = 'Y' 
                        AND    b.id_flex_num = a.id_flex_num );
      
      Tab1Print('Territory flexfield structure is  "' || t_id_flex_structure_name || '". At least one segment '||
           'of this structure is enabled.'); 
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('Territory flexfield has not been set up');
           ActionErrorPrint('Please refer to Users Guide to define territory flexfield. Define, enable, '||
                'freeze a "Territory Flexfield" structure with at least one enabled segment. ');
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Territory Flexfield"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------ Line Transaction Flexfield ----------------------------------------- */ 

    DECLARE  
      t_total          NUMBER   := 0;
      t_header_printed VARCHAR2(1) := 'N';
     
      CURSOR C1 IS 
      SELECT      a.descriptive_flex_context_code   context_code 
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'RA_INTERFACE_LINES' 
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         0 < ( SELECT     count(*)  
                        FROM       FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE      b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND        b.enabled_flag = 'Y' 
                        AND        b.descriptive_flexfield_name = 'RA_INTERFACE_LINES' );
    BEGIN
      SectionPrint('Line Transaction Flexfield');  
      l_count := 0 ;
      
      FOR c1_rec in C1 LOOP
          IF t_header_printed = 'N' THEN 
             Tab1Print('The following line transaction flexfield contexts are enabled');
             t_header_printed := 'Y';
          END IF;       

          Tab2Print( '"' || c1_rec.context_code || '"');
          
          SELECT     count(*)
          INTO       t_total 
          FROM       FND_DESCR_FLEX_COL_USAGE_VL 
          WHERE      required_flag = 'N'
          AND        enabled_flag  = 'Y' 
          AND        descriptive_flexfield_name  = 'RA_INTERFACE_LINES'
          AND        descriptive_flex_context_code = c1_rec.context_code ;

          IF t_total > 0 THEN 
             Tab3Print('Required flag is not checked for '|| to_char(t_total) || ' segments of "'||
                       c1_rec.context_code ||'"');     
          END IF; 

          l_count := l_count + 1; 
      END LOOP; 

      IF l_count = 0 THEN 
         Errorprint('Line transaction flexfield has not been set up');
         ActionErrorPrint('Line transaction flexfield is a required descriptive flexfield to use AutoInvoice '||
              'functionality. Define and/or enable at least one context to use AutoInvoice functionality.');
      ELSE 
         NoticePrint('AutoInvoice requires all the enabled segments of the line transaction flexfield to be '||
              'populated irrespective of the "Required Flag" on the segments');     
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Line Transaction Flexfield" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------ Invoice Transaction Flexfield ------------------------------------------- */ 

    DECLARE  
      t_total       NUMBER   := 0;
      t_header_printed VARCHAR2(1) := 'N';

      CURSOR C1 IS 
      SELECT      a.descriptive_flex_context_code   context_code 
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'RA_INTERFACE_HEADER' 
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         0 < ( SELECT     count(*)  
                        FROM       FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE      b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND        b.enabled_flag = 'Y' 
                        AND        b.descriptive_flexfield_name = 'RA_INTERFACE_HEADER' );
    BEGIN
      SectionPrint('Invoice Transaction Flexfield');  
      l_count := 0 ;
    
      FOR c1_rec in C1 LOOP
          IF t_header_printed = 'N' THEN 
             Tab1Print('Following Invoice Transaction Flexfield Contexts are enabled');
             t_header_printed := 'Y';
          END IF;       

          Tab2Print( '"' || c1_rec.context_code || '"');
 
          l_count := l_count + 1; 
      END LOOP; 

      IF l_count = 0 THEN 
         Errorprint('Invoice transaction flexfield has not been set up');
         ActionErrorPrint('Invoice transaction flexfield is a required descriptive flexfield to use AutoInvoice '||
              'functionality. Define and/or enable at least one context to use AutoInvoice functionality.'); 
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Invoice Transaction Flexfield" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* -------------------------- Link-to Transaction Flexfield ( optional ) ------------------------------- */ 

    DECLARE  
      t_total          NUMBER   := 0;
      t_header_printed VARCHAR2(1) := 'N';

      CURSOR C1 IS 
      SELECT      a.descriptive_flex_context_code   context_code 
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'RA_INTERFACE_LINK_TO' 
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         0 < ( SELECT     count(*)  
                        FROM       FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE      b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND        b.enabled_flag = 'Y' 
                        AND        b.descriptive_flexfield_name = 'RA_INTERFACE_LINK_TO' );
    BEGIN
      SectionPrint('Link-to Transaction Flexfield');  
      l_count := 0 ;
           
      FOR c1_rec in C1 LOOP
          IF t_header_printed = 'N' THEN 
             Tab1Print('The following link-to transaction flexfield contexts are enabled');
             t_header_printed := 'Y';
          END IF;       
 
          Tab2Print( '"' || c1_rec.context_code || '"');
          l_count := l_count + 1; 
      END LOOP; 
  
      IF l_count = 0 THEN 
         Tab1Print('Link-to transaction flexfield has not been set up. The line transaction flexfield '||
              'structure will be used to link different lines.');
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Link-to Transaction Flexfield" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------- Reference Transaction Flexfield ( optional ) -------------------------------- */ 

    DECLARE  
      t_total           NUMBER   := 0;
      t_header_printed  VARCHAR2(1) := 'N';

      CURSOR C1 IS 
      SELECT      a.descriptive_flex_context_code   context_code 
      FROM        FND_DESCR_FLEX_CONTEXTS_VL a, 
                  FND_DESCRIPTIVE_FLEXS_VL c
      WHERE       a.descriptive_flexfield_name = 'RA_INTERFACE_REFERENCE' 
      AND         a.enabled_flag = 'Y'
      AND         c.freeze_flex_definition_flag = 'Y'
      AND         c.descriptive_flexfield_name = a.descriptive_flexfield_name
      AND         0 < ( SELECT     count(*)  
                        FROM       FND_DESCR_FLEX_COL_USAGE_VL b
                        WHERE      b.descriptive_flex_context_code = a.descriptive_flex_context_code
                        AND        b.enabled_flag = 'Y' 
                        AND        b.descriptive_flexfield_name = 'RA_INTERFACE_REFERENCE' );
    BEGIN
      SectionPrint('Reference Transaction Flexfield');  
      l_count := 0 ;
      
      FOR c1_rec in C1 LOOP
          IF t_header_printed = 'N' THEN 
             Tab1Print('The following reference transaction flexfield contexts are enabled');
             t_header_printed := 'Y';
          END IF;       

          Tab2Print( '"' || c1_rec.context_code || '"');
          l_count := l_count + 1; 
      END LOOP; 
  
      IF l_count = 0 THEN 
         Tab1Print('Reference transaction flexfield has not been set up. The line transaction flexfield '||
              'structure will be used to reference different lines.');
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Reference Transaction Flexfield" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* -------------------------------------- Profile  Options -------------------------------------- */ 


    BEGIN 

      SectionPrint('Profile Options');

      -- GL set of Books -- required, no default 
      CheckProfile('GL_SET_OF_BKS_ID', g_user_id, g_resp_id, g_appl_id, Null, 1, 0, 'E' ); 

      IF v_multi_org != 'N' THEN     
      -- MO: Operating Unit -- required, no default  
      Checkprofile('ORG_ID', g_user_id, g_resp_id, g_appl_id, Null, 1, 0, 'W' ); 
      END IF;

      -- AR: Item Flexfield Mode  -- optional, default 'Concatenated Segment Entry' 
      CheckProfile('AR_ITEM_FLEXFIELD_MODE', g_user_id, g_resp_id, g_appl_id, '"Concatenated Segment Entry"', 1, 0, 'N' );

      -- AR: Default Exchange Rate Type  -- Required, no default
      CheckProfile('AR_DEFAULT_EXCHANGE_RATE_TYPE', g_user_id, g_resp_id, g_appl_id, Null, 1, 0, 'E' );

      -- AR:Maximum lines per AutoInvoice worker - Optional, no default  
      CheckProfile('AR_MAX_LINES_PER_AI_WORKER', g_user_id, g_resp_id, g_appl_id, '"Null"', 1, 0, 'N'); 

      -- AR: Use Invoice Accounting For Credit Memos -- optional, default 'Yes'
      CheckProfile('AR_USE_INV_ACCT_FOR_CM_FLAG', g_user_id, g_resp_id, g_appl_id, '"Yes"', 1 , 0, 'N' ); 

      -- AR: Transaction Flexfield QuickPick Attribute -- optional, default 'interface_header_attribute1'
      -- Obsolete since AR.H - 11.5.7 ( See Note 198214.1 ) - Moved to Transaction sources
      CheckProfile('AR_PA_CODE', g_user_id, g_resp_id, g_appl_id, '"Interface_header_attribute1"', 1, 0, 'N' );
   
      -- AR: Enable Cross Currency --  Optional, default  'No'
      -- Obsolete since AR.H - 11.5.7 ( See Note 180214.1 )
      CheckProfile('AR_ENABLE_CROSS_CURRENCY', g_user_id, g_resp_id, g_appl_id, '"No"', 1, 0, 'N' ); 
 
      -- Sequential Numbering -- owned by AOL -- optional, default 'Not Used'
      CheckProfile('UNIQUE:SEQ_NUMBERS', g_user_id, g_resp_id, g_appl_id, '"Not Used"', 1, 0, 'N' ); 

      -- OE: Item Flexfield      required, no default 
      CheckProfile('SO_ID_FLEX_CODE', g_user_id, g_resp_id, g_appl_id, Null, 1, 0, 'E' );

      -- OM: Invoice numbering method    
      CheckProfile('WSH_INVOICE_NUMBERING_METHOD', g_user_id, g_resp_id, g_appl_id, Null, 1, 0, 'E' );

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Profile Options" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* -------------------------------------------- end block --------------------------------------------------- */

    -- removed call to end_block to not get </html> tag in the output ( excel stops when this is there )
    -- End_Block; 

/* ------------------------ Exception Section : Main Program ( Part 1 ) ----------------------------- */ 
/* Whenever an exception was raised set the variable v_abort to 'Y' so Part 2 of the MAin Program     */
/* also knows to do nothing                                                                           */
/*----------------------------------------------------------------------------------------------------*/

  EXCEPTION   -- begin 2 
    WHEN STOPEXECUTION THEN     
         brprint;
         :v_abort := 'Y'; 
         -- End_Block; 

    WHEN OTHERS THEN  
         brprint;
         ErrorPrint(sqlerrm||' occurred in the diagnostic test');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
         brprint;
         :v_abort := 'Y';
         -- End_Block; 
  END;   --end2 

EXCEPTION  --  begin 1  
  WHEN OTHERS then   -- exceptions begin 1
       Brprint;
       Errorprint(sqlerrm||' occurred in the diagnostic test');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');
       Brprint; 
       :v_abort := 'Y';
       -- End_Block; 

END; 
/

REM =========================================================================================
REM
REM    Because the above block became too big and resulted in a PLS-123 Program TOO Large 
REM    We needed to split up the original Main block in Two plsql Blocks 
REM     
REM =========================================================================================
REM ====================== Run the Pl/SQL api file again ==================================== 
@@CoreApiHtml.sql

/*------------------------ Define procedure getAutoAccCCidDetails -------------------------*/ 

  FUNCTION getAutoAccCcidDetails ( p_typedesc            varchar2, 
                                   p_type                varchar2, 
                                   p_transType_Flag      varchar2, 
                                   p_site_Flag           varchar2, 
                                   p_salesrep_Flag       varchar2, 
                                   p_tax_Flag            varchar2, 
                                   p_standardLine_Flag   varchar2, 
                                   p_remittanceBank_Flag varchar2 ) return VARCHAR IS
    t_count             number;
    t_whereclause       varchar2(200) := NULL;
    t_purpose           varchar2(10)  := NULL;
    t_accountname       varchar2(30)  := NULL;
    t_sqltxt            varchar2(3000);
    t_cursor            integer;
    t_counter           integer;
    t_orgid             Number; 
    null_accounts_found varchar2(5) := 'FALSE';

  BEGIN
  
    -- handling taxflag : check for taxcodes with null Tax accounts

    IF p_tax_flag = 'Y' THEN 
       t_count := 0;

       SELECT  count(*)
       INTO    t_count 
       FROM    AR_VAT_TAX
       WHERE   tax_type <> 'TAX_GROUP'
       AND     NVL( end_date,   sysdate ) >= sysdate
       AND     NVL( start_date, sysdate)  <= sysdate
       AND     enabled_flag = 'Y'
       AND     tax_account_id is null;
 
       Tab2Print('There are ' || to_char(t_count) || ' tax codes with null "Tax" account'); 
       IF t_count > 0 THEN 
          null_accounts_found := 'TRUE';
       END IF;
    END IF;

    -- handling transaction type flag : check for transaction types with null accounts
    -- Depending on the type of the transaction ( Bills receivable or not ) certain accounts
    -- are always null 

    IF p_transType_Flag = 'Y' THEN 
       t_whereclause := NULL;
       t_sqltxt      := NULL;
       t_count       := NULL;

       IF    p_type = 'REV' THEN 
          t_whereclause := 'gl_id_rev is NULL and type <> ''BR'' ';
       ELSIF p_type = 'REC' THEN 
          t_whereclause  := 'gl_id_rec is NULL and type <> ''BR'' ';
       ELSIF p_type = 'FREIGHT' THEN 
          t_whereclause  := 'gl_id_freight is NULL and type <> ''BR'' ';
       ELSIF p_type = 'SUSPENSE' THEN  
          t_whereclause  := 'gl_id_clearing  is NULL and type <> ''BR'' ';
       ELSIF p_type = 'TAX' THEN  
          t_whereclause  := 'gl_id_tax is NULL and type <> ''BR'' ';
       ELSIF p_type = 'UNBILL' THEN 
          t_whereclause  := 'gl_id_unbilled is NULL and type <> ''BR'' ';
       ELSIF p_type = 'UNEARN' THEN 
          t_whereclause  := 'gl_id_unearned  is NULL and type <> ''BR'' ';
       ELSIF p_type = 'BR_REC' THEN 
          t_whereclause  := 'gl_id_rec  is NULL and type = ''BR'' ';
       ELSIF p_type = 'BR_UNPAID_REC' THEN  
          t_whereclause  := 'gl_id_unpaid_rec is NULL and type = ''BR'' ';
       ELSIF p_type = 'BR_REMITTANCE' THEN 
          t_whereclause  := 'gl_id_remittance is NULL and type = ''BR'' ';
       ELSIF p_type = 'BR_FACTOR' THEN 
          t_whereclause  := 'gl_id_factor is NULL and type = ''BR'' ';
       END IF; 
  
       IF t_whereclause IS NOT NULL THEN 

          t_sqltxt := 'SELECT     count(*) ' ||
                      'FROM       RA_CUST_TRX_TYPES ' ||
                      'WHERE      NVL( start_date, sysdate ) <= sysdate  '|| 
                      'AND        NVL( end_date, sysdate)    >= sysdate '||
                      'AND        NVL( status,''A'') =''A''' ||
                      'AND '      || t_whereclause ;

          t_cursor := dbms_sql.open_cursor;
          dbms_sql.parse(t_cursor, t_sqltxt, dbms_sql.native);
          dbms_sql.define_column(t_cursor, 1, t_count);
          t_counter := dbms_sql.execute(t_cursor);
          WHILE dbms_sql.fetch_rows(t_cursor) > 0 LOOP   
          dbms_sql.column_value(t_cursor, 1, t_count);
          END LOOP; 
     
          Tab2Print('There are '|| to_char(t_count) || ' transaction types with null "' || 
                    p_typedesc || '" account');
          IF t_count > 0 THEN 
             null_accounts_found := 'TRUE'; 
          END IF;
       END IF;
    END IF;   

    -- handling customer site flag : check for customer sites with null accounts
    -- Bill-to sites must be checked for the normal accounts 
    -- Drawee sites must be checked for the bills Receivable accounts 

    IF p_site_flag = 'Y' THEN 
       t_whereclause := NULL;
       t_purpose     := 'Bill-To';
       t_sqltxt      := NULL;
       t_count       := NULL;
       IF p_type = 'REV' THEN 
          t_whereclause := 'gl_id_rev is NULL and site_use_code = ''BILL_TO'' ';
       ELSIF p_type = 'REC' THEN 
          t_whereclause  := 'gl_id_rec  is NULL and site_use_code = ''BILL_TO'' ';
       ELSIF p_type = 'FREIGHT' THEN 
          t_whereclause  := 'gl_id_freight is NULL and site_use_code = ''BILL_TO'' ';
       ELSIF p_type = 'SUSPENSE' THEN  
          t_whereclause  := 'gl_id_clearing is NULL and site_use_code = ''BILL_TO'' ';
       ELSIF p_type = 'TAX' THEN 
          t_whereclause  := 'gl_id_tax is NULL and site_use_code = ''BILL_TO'' ';
       ELSIF p_type = 'UNBILL' THEN  
          t_whereclause  := 'gl_id_unbilled is NULL and site_use_code = ''BILL_TO'' ';
       ELSIF p_type = 'UNEARN' THEN 
          t_whereclause  := 'gl_id_unearned is NULL and site_use_code = ''BILL_TO'' ';
       ELSIF p_type = 'BR_REC' THEN 
          t_whereclause  := 'gl_id_rec is NULL and site_use_code = ''DRAWEE'' ';
          t_purpose      := 'Drawee';
       ELSIF p_type = 'BR_UNPAID_REC' THEN  
          t_whereclause  := 'gl_id_unpaid_rec is NULL and site_use_code = ''DRAWEE'' ';
          t_purpose      := 'Drawee';
       ELSIF p_type = 'BR_REMITTANCE' THEN         
          t_whereclause  := 'gl_id_remittance is NULL and site_use_code = ''DRAWEE'' ';
          t_purpose      := 'Drawee';
       ELSIF p_type = 'BR_FACTOR' THEN  
          t_whereclause  := 'gl_id_factor is NULL and site_use_code = ''DRAWEE'' ';
          t_purpose      := 'Drawee';
       END IF; 
          
       IF t_whereclause is NOT NULL THEN  
  
          t_sqltxt := 'SELECT count(*) '||
                      'FROM   AR_SITE_USES_V ' ||
                      'WHERE  status =''A'' ' ||
                      'AND  ' || t_whereclause;

          t_cursor := dbms_sql.open_cursor;
          dbms_sql.parse(t_cursor, t_sqltxt, dbms_sql.native);
          dbms_sql.define_column(t_cursor, 1, t_count);
          -- count(*) always returns One row   
          t_counter := dbms_sql.execute(t_cursor);
          WHILE dbms_sql.fetch_rows(t_cursor) > 0 LOOP   
            dbms_sql.column_value(t_cursor, 1, t_count);
          END LOOP; 
      
          Tab2Print('There are ' || to_char(t_count) || ' ' || t_purpose || ' customer sites with null "'|| 
                    p_typedesc || '" account' );
          IF t_count > 0 THEN 
             null_accounts_found := 'TRUE';
          END IF;
       END IF;

    END IF;

    -- handling salesrep flag : check for salespersons with null accounts
    -- not used for Bill Receivables 

    IF p_salesrep_flag = 'Y' THEN 
       t_whereclause := NULL;
       t_accountname := NULL; 
       t_sqltxt      := NULL;
       t_count       := NULL;
       IF p_type IN ('REV', 'UNEARN', 'SUSPENSE', 'TAX' )  THEN 
          t_whereclause  := 'gl_id_rev';
          t_accountname  := 'Revenue';
       ELSIF p_type in ('REC','UNBILL') THEN 
          t_whereclause  := 'gl_id_rec';
          t_accountname  := 'Receivable';
       ELSIF p_type = 'FREIGHT' THEN
          t_whereclause  := 'gl_id_freight';
          t_accountname  := 'Freight';
       END IF;   

       IF t_whereclause is NOT NULL THEN 
          t_sqltxt := 'SELECT  count(*) '||
                      'FROM    jtf_rs_srp_vl '||
                      'WHERE   status = ''A'' '|| 
                      'AND     NVL( start_date_active, sysdate) <= sysdate '||
                      'AND     NVL( end_date_active,   sysdate) >= sysdate '||  
                      'AND '|| t_whereclause || ' IS NULL';

          t_cursor := dbms_sql.open_cursor;
          dbms_sql.parse(t_cursor, t_sqltxt, dbms_sql.native);
          dbms_sql.define_column(t_cursor, 1, t_count);
          -- count(*) always returns One row   
          t_counter := dbms_sql.execute(t_cursor);
          WHILE dbms_sql.fetch_rows(t_cursor) > 0 LOOP   
            dbms_sql.column_value(t_cursor, 1, t_count);
          END LOOP; 
   
          Tab2Print('There are '|| to_char(t_count) || ' salespersons with null "' || t_accountname ||  '" account');
          IF t_count > 0 THEN 
             null_accounts_found := 'TRUE';
          END IF;
       END IF;

    END IF;

    -- handling remittance  : check for remittance banks with null accounts
    -- only applies to Remitted and Factored Bills Receivable 
  
    IF p_remittanceBank_Flag = 'Y' THEN 
       t_whereclause := NULL;
       t_sqltxt      := NULL;
       t_count       := NULL;
 
       IF p_type = 'BR_REMITTANCE' THEN 
          t_whereclause := 'br_remittance_ccid';
       ELSIF p_type = 'BR_FACTOR' THEN 
          t_whereclause := 'br_factor_ccid';
       END IF; 
          
       IF t_whereclause is NOT NULL THEN  
          t_sqltxt := 'SELECT  count(*) FROM AR_RECEIPT_METHOD_ACCOUNTS '||
                      'WHERE   NVL( start_date, sysdate) <= sysdate '||
                      'AND     NVL( end_date, sysdate)   >= sysdate '||  
                      'AND '   || t_whereclause || ' IS NULL';

          t_cursor := dbms_sql.open_cursor;
          dbms_sql.parse(t_cursor, t_sqltxt, dbms_sql.native);
          dbms_sql.define_column(t_cursor, 1, t_count);
          -- count(*) always returns One row   
          t_counter := dbms_sql.execute(t_cursor);
          WHILE dbms_sql.fetch_rows(t_cursor) > 0 LOOP   
            dbms_sql.column_value(t_cursor, 1, t_count);
          END LOOP; 
   
          Tab2Print('There are '|| to_char(t_count) || ' remittance banks with null "' || p_typedesc ||  '" account');
          IF t_count > 0 THEN 
             null_accounts_found := 'TRUE';
          END IF;
       END IF;
    
    END IF;

    -- handling standardLineFlag : check memolines and inventory items  

    IF p_standardLine_flag = 'Y' THEN 
  
       -- Checking memolines - count records with null Revenue Account 

       t_count := 0; 

       SELECT    count(*) 
       INTO      t_count 
       FROM      AR_MEMO_LINES_VL 
       WHERE     NVL( start_date, sysdate) <= sysdate
       AND       NVL( end_date, sysdate)   >=sysdate  
       AND       gl_id_rev IS NULL; 

       Tab2Print ('There are ' || to_char(t_count) || ' standard memo lines with null "Revenue" account'); 
       IF t_count > 0 THEN 
          null_accounts_found := 'TRUE';
       END IF;

       -- Pick up org_id from OE_SYSTEM_PARAMETERS  ( needed as input to check inventory items ) 
       -- when select from oe_system_parameters fails, we are unable to check inventory items 
      
       BEGIN 
         SELECT  master_organization_id 
         INTO    t_orgid
         FROM    OE_SYSTEM_PARAMETERS;
  
         -- Checking inventory Items - count records with null Sales Account 

         t_count := 0;
 
         SELECT  count(*)
         INTO    t_count
         FROM    MTL_SYSTEM_ITEMS
         WHERE   NVL( end_date_active, sysdate)   >= sysdate 
         AND     NVL( start_date_active, sysdate) <= sysdate
         AND     organization_id = t_orgid 
         AND     sales_account IS NULL ;

         Tab2Print('There are ' || to_char(t_count) || ' inventory items with null "Sales" Account" in inventory '||
                   'organization '|| to_char(t_orgid) ); 
         IF t_count > 0 THEN 
            null_accounts_found := 'TRUE';
         END IF;

       EXCEPTION 
         WHEN NO_DATA_FOUND THEN 
              null; 
       END;
     
    END IF;

    return null_accounts_found;

  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint(sqlerrm||' occurred in test when calling "getAutoAccCcidDetails" ');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
         return null_accounts_found;
  END getAutoAccCcidDetails;

/*------------------------ Define procedure getAutoAccDetails -------------------------------------*/ 

  FUNCTION getAutoAccDetails ( p_typedesc    varchar2, 
                               p_ccid        number, 
                               p_type        varchar2, 
                               p_lastupddate date ) return VARCHAR IS 

    t_tablename              varchar2(30) := 0;
    
    t_salesrep_flag          varchar2(1)  := 'N';
    t_site_flag              varchar2(1)  := 'N'; 
    t_standardline_flag      varchar2(1)  := 'N';
    t_transtype_flag         varchar2(1)  := 'N'; 
    t_tax_flag               varchar2(1)  := 'N';
    t_remittancebank_flag    varchar2(1)  := 'N'; 

    t_count                  number  := 0;
    t_sqltxt                 varchar2(32767);
    null_accounts_found      varchar2(5)  := 'FALSE';

    CURSOR C1 IS 
      SELECT    decode( e.table_name,'RA_CUST_TRX_TYPES',  'Transaction Types', 
                                     'RA_SITE_USES',       'Site',
                                     'RA_SALESREPS',       'Salesreps',
                                     'RA_TAXES',           'Taxes',
                                     'RA_STD_TRX_LINES',   'Standard Lines',
                                     'AR_RECEIPT_METHOD_ACCOUNTS', 'Remittance Banks', e.table_name ) TableName
      FROM      FND_ID_FLEX_SEGMENTS_VL b, 
                GL_SETS_OF_BOOKS_V c,
                AR_SYSTEM_PARAMETERS d , 
                RA_ACCOUNT_DEFAULT_SEGMENTS e
      WHERE     b.application_id = 101 
      AND       d.set_of_books_id = c.set_of_books_id 
      AND       b.id_flex_num = c.chart_of_accounts_id 
      AND       e.segment = b.application_column_name
      AND       e.gl_default_id = p_ccid;
   
  BEGIN
    Tab1Print('AutoAccounting set up for "' || p_typedesc || '" account   Last Update Date : '|| to_char(p_lastupdDate) );

    FOR C1_rec in C1 LOOP 
        IF c1_rec.TableName is NOT NULL THEN 
           IF c1_rec.TableName = 'Transaction Types' THEN  
              t_transtype_flag := 'Y';
           ELSIF c1_rec.TableName = 'Site' THEN 
              t_site_flag := 'Y'; 
           ELSIF c1_rec.TableName = 'Salesreps' THEN 
              t_salesrep_flag := 'Y';          
           ELSIF c1_rec.TableName = 'Taxes' THEN 
              t_tax_flag := 'Y';
           ELSIF  c1_rec.TableName = 'Standard Lines' THEN 
              t_standardline_flag := 'Y';
           ELSIF  c1_rec.TableName = 'Remittance Banks' THEN 
              t_remittancebank_flag := 'Y';
           END IF;
        END IF; 
        t_count := t_count + 1 ;
    END LOOP; 

    IF t_count = 0 THEN 
       ErrorPrint('Autoaccounting has not been set up for "' || p_typedesc || '"');
       ActionErrorPrint('Please set up autoaccounting for "' || p_typedesc || '"');
    ELSE 

       -- display Autoaccounting detais in table format 
  
       t_sqltxt := 'SELECT    b.segment_name Segment ,' ||
                   '  decode( e.table_name, ''RA_CUST_TRX_TYPES'', ''Transaction Types'', '|| 
                   '          ''RA_SITE_USES'',        ''Site'', '||
                   '          ''RA_SALESREPS'',        ''Salesreps'', '||
                   '          ''RA_TAXES'',            ''Taxes'', '||
                   '          ''RA_STD_TRX_LINES'',    ''Standard Lines'', '||
                   '          ''AR_RECEIPT_METHOD_ACCOUNTS'', ''Remittance Banks'', e.table_name )   TableName,  '||
                   '          e.constant     Constant '||  
                   'FROM      FND_ID_FLEX_SEGMENTS_VL b, '|| 
                   '          GL_SETS_OF_BOOKS_V c, '||
                   '          AR_SYSTEM_PARAMETERS d , '||
                   '          RA_ACCOUNT_DEFAULT_SEGMENTS e '||
                   'WHERE     b.application_id = 101 ' ||
                   'AND       d.set_of_books_id = c.set_of_books_id '||
                   'AND       b.id_flex_num = c.chart_of_accounts_id '|| 
                   'AND       e.segment = b.application_column_name '||
                   'AND       e.gl_default_id = ' || to_char(p_ccid) ;

        Run_sql( null, t_sqltxt, 'N', null, 1 );
        BrPrint;
    END IF;   
  
    -- Whevever a table is referenced check that table for corresponding null accounts  

    null_accounts_found :=  getAutoaccCcidDetails ( p_typedesc, 
                                                    p_type, 
                                                    t_transType_Flag, 
                                                    t_site_Flag, 
                                                    t_salesrep_Flag,  
                                                    t_tax_Flag, 
                                                    t_standardLine_Flag, 
                                                    t_remittanceBank_Flag) ;
    Brprint; 
    return null_accounts_found; 

  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint(sqlerrm||' occurred in test when calling "getAutoAccDetails" ');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
         return null_accounts_found;
  END getAutoAccDetails;

/*-------------------------------------- Define Procedure showIndexes  -------------------------------------*/ 

  PROCEDURE showIndexes ( p_tablename  varchar2, p_column varchar2 ) IS  
    l_count        number  := 0;
    sqltxt         varchar2(32767);
  BEGIN 
  
    SectionPrint( 'Indexes on '|| p_tablename ); 

    -- this query is a bit slow because no indexes exist on dba_indexes 

    sqltxt := 'SELECT        a.Index_name        index_name, '||
              '              a.Owner             owner, '||
              '              a.Status            status, '||
              '              b.column_position   column_position, '|| 
              '              b.column_name       column_name '||
              'FROM          DBA_INDEXES     a ,'||
              '              DBA_IND_COLUMNS b  '||
              'WHERE         a.table_name = ''' || p_tablename || ''' ' ||
              'AND           a.owner IN ( ''AR'', ''GL'', ''INV'', user ) '||
              'AND           a.owner = b.index_owner '||
              'AND           a.index_name = b.index_name      '||
              'ORDER BY      a.index_name, b.column_position ';
  
    l_count := run_sql ( Null , sqltxt, 'N', null, 1 );
    IF l_count = 0 THEN 
       Tab1Print( 'There are no indexes defined on table '|| p_tablename );
    END IF; 

    IF l_count >  0  AND p_column is NOT NULL THEN 
       SELECT     COUNT(*)
       INTO       l_count        
       FROM       DBA_INDEXES  a,
                  DBA_IND_COLUMNS b  
       WHERE      a.table_name = p_tablename   
       AND        a.owner IN ( 'AR', 'GL', 'INV', user ) 
       AND        a.owner = b.index_owner 
       AND        a.index_name = b.index_name
       AND        b.column_name like p_column;
    END IF;    

    IF l_count = 0 and p_column is NOT NULL THEN 
       BrPrint;      
       WarningPrint('The table "' || p_tablename || '" does not have indexes on any of the "' || p_column ||
            '" columns. This decreases the performance of AutoInvoice.');
       IF ( p_tablename = 'RA_INTERFACE_DISTRIBUTIONS_ALL' or p_tablename = 'RA_INTERFACE_SALESCREDITS_ALL' ) THEN 
          ActionWarningPrint('See the AR User guide on how to index the transaction flexfields. Define unique, concatenated '||
                'indexes on the table "' || p_tablename || '" on the columns which make up the line/header transaction '||
                'flexfield that is used. Ignore this warning if this table is not being populated/used in AutoInvoice.');
       ELSE 
          ActionWarningPrint('See the AR User guide on how to index the transaction flexfields. Define unique, concatenated '||
                'indexes on the table "' || p_tablename || '" on the columns which make up the line/header '||
                'transaction flexfield that is used.');
       END IF; 
    END IF; 
          
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint(sqlerrm||' occurred in test when calling "showIndexes" ');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
      
  END showIndexes;

/*------------------------------------ Define procedure showTriggers  -------------------------------------*/ 

  PROCEDURE showTriggers ( p_tablename  varchar2 ) IS  
    sqltxt         varchar2(32767);
    l_count        number := 0;
  BEGIN 
  
    SELECT COUNT(*) INTO l_count 
    FROM   DBA_TRIGGERS 
    WHERE  table_name = p_tablename;

    IF l_count = 0 THEN 
       Tab1Print('There are no database triggers defined on table '|| p_tablename );
    ELSE 
       Tab1Print( 'Database triggers on '|| p_tablename ); 

       sqltxt  := 'SELECT owner, trigger_name, status '||
                  'FROM   DBA_TRIGGERS '||
                  'WHERE  table_name = ''' || p_tablename || ''' ORDER BY owner';
       Run_Sql( Null , sqltxt, 'N', null, 2 );
       BrPrint;
    END IF; 

  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint(sqlerrm||' occurred in test when calling "showTriggers" ');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');

  END showTriggers;

/*------------------------------- Start Of the Main Program ( Part 2 )-----------------------------*/

BEGIN  -- begin 1
  DECLARE -- declare 2 
    p_username            varchar2(100);   
    p_respid              number;
    p_batchid             number; 
     
    v_batchname           varchar2(50) := Null; 
    v_accounting_method   varchar2(30) := Null;
    v_orgid               varchar2(15) := Null; 
 

    l_count               number  := 0;
    sqltxt                varchar2(32767);
    l_counter             integer;
    l_cursor              integer; 

    STOPEXECUTION         exception;

  BEGIN  -- begin2 

/* ----------------------------- Set Client again -------------------------------------------------*/

    Init_block; 

 -- if the first block was aborted then this block needs to stop immediately 
 
    IF :v_abort = 'Y' THEN
       BrPrint;
       RAISE StopExecution ;
    END IF;

    p_username := :v_username;

    IF &v_respid IS NULL THEN
       p_respid := -10;     
    ELSE        
       p_respid := TO_NUMBER(&v_respid);
    END IF; 

    Set_Client(p_username, p_respid);
    Brprint;
    v_orgid   := Get_profile_option('ORG_ID');
 
    BEGIN
      IF &v_batchid = 0 THEN 
         p_batchid := -999;
      ELSE
         p_batchid := &v_batchid;    
      END IF;
      SELECT name 
      INTO   v_batchname
      FROM   RA_BATCH_SOURCES 
      WHERE  batch_source_id = p_batchid;
    EXCEPTION 
      WHEN OTHERS THEN 
           v_batchname := '??';
    END; 

/* --------------------------------- Application Set up, item validation ----------------------------------- */ 

    DECLARE  
      t_org_id                    NUMBER; 
      t_item_validation_org_id    NUMBER;
      t_item_validation_org_name  VARCHAR2(60); 
    BEGIN
      SectionPrint('Application Set Up');
      SELECT   a.org_id,                  
               a.master_organization_id,
               b.name
      INTO     t_org_id,
               t_item_validation_org_id,
               t_item_validation_org_name  
      FROM     OE_SYSTEM_PARAMETERS a,   
               HR_ALL_ORGANIZATION_UNITS b 
      WHERE    b.organization_id = a.master_organization_id;

      Tab1Print('Item validation organization has been set to "'|| t_item_validation_org_name ||
                '" ( org id = '|| to_char(t_item_validation_org_id) || ' )');  

    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Errorprint('Item validation organization is not defined. AutoInvoice will error out' );
           ActionErrorLink('Define item validation organization in Order Management. See Note ', '176205.1',
                ' for more information');
      WHEN OTHERS THEN 
           Errorprint(sqlerrm ||' occurred in test in section "Application Set Up, Item Validation" '); 
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ----------------------------- Application Set Up, Transaction Types ----------------------------------- */ 

    DECLARE  
      CURSOR C1 IS 
        SELECT DECODE(type, 'CM'  , 'Creditmemo',
                            'BR'  , 'Bills Receivables',
                            'CB'  , 'Chargeback',
                            'DEP' , 'Deposit',
                            'DM'  , 'Debitmemo',
                            'GUAR', 'Guarantee',
                            'INV',  'Invoice', type )   type, 
               count(*)                                 total
        FROM   RA_CUST_TRX_TYPES
        WHERE  NVL ( start_date, sysdate ) <= sysdate
        AND    NVL ( end_date,   sysdate ) >= sysdate
        GROUP  BY type;
    BEGIN
      Tab1Print('Transaction Types Set Up');
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    RA_CUST_TRX_TYPES
      WHERE   NVL( start_date, sysdate ) <= sysdate
      AND     NVL( end_date, sysdate )    >= sysdate ;

      IF l_count = 0 THEN 
         ErrorPrint('Transaction types have not been set up. There are no active transaction types');
         ActionErrorPrint('Define transaction types with valid active dates');
      ELSE
         Tab2Print( to_char(l_count) || ' active transaction types have been set up. They are classified as :');

         -- list the different transaction types 

         FOR c1_rec in C1 LOOP
             Tab3Print ( to_char(c1_rec.total) || ' transaction types with class "' || c1_rec.type || '"' );
         END LOOP;

         -- show how many transaction types require tax calculation 

         l_count := 0;
         SELECT  count(*)
         INTO    l_count 
         FROM    RA_CUST_TRX_TYPES
         WHERE   NVL( start_date, sysdate) <= sysdate
         AND     NVL( end_date, sysdate)   >= sysdate
         AND     tax_calculation_flag ='Y';

         Tab2Print('Calculate tax flag is checked on ' || to_char(l_count) || ' transaction types'); 
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Transaction Types" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;  

/* --------------------------------- Application Set Up, Payment Terms ------------------------------------ */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    RA_TERMS_VL
      WHERE   NVL( start_date_active, sysdate ) <= sysdate
      AND     NVL( end_date_active, sysdate)    >= sysdate;
  
      IF l_count = 0 THEN 
         ErrorPrint('Payment terms have not been set up. There are no active payment terms');
         ActionErrorPrint('Set up payment terms with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || ' active payment terms have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Payment Terms" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* --------------------------------- Application Set Up, Salespersons ------------------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    JTF_RS_SRP_VL 
      WHERE   NVL( start_date_active, sysdate )   <= sysdate
      AND     NVL( end_date_active, sysdate )     >= sysdate
      AND     status ='A';

      IF l_count = 0 THEN 
         ErrorPrint('Salespersons have not been set up. There are no active salespersons' );
         ActionErrorPrint('Define a salesperson with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || ' active salespersons are defined');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Application Set Up, SalesPersons" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------------- Application Set Up, Unit of Measures ----------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    MTL_UNITS_OF_MEASURE_VL
      WHERE   NVL( disable_date, sysdate ) >= sysdate;

      IF l_count = 0 THEN 
         WarningPrint('Unit of measures have not been set up' );
         ActionWarningPrint('Define unit of measures with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || ' active unit of measures have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Unit of measures" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------------- Application Set up, FOB quickcode-------------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT   count(*) 
      INTO     l_count 
      FROM     FND_LOOKUP_TYPES_VL a,
               FND_LOOKUP_VALUES_VL b 
      WHERE    a.application_id = 222
      AND      a.lookup_type = 'FOB'
      AND      a.lookup_type = b.lookup_type 
      AND      b.enabled_flag = 'Y'; 

      IF l_count = 0 THEN 
         WarningPrint('QuickCode "FOB" has not been set up' );
         ActionWarningPrint('Set up quickCode "FOB" ');
      ELSE
         Tab1Print( to_char(l_count) || ' FOB quickCodes have been set up');
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Application Set Up, FOB QuickCode" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------------- Application Set up, Freight Carriers ---------------------------- */ 

    BEGIN 
      l_count := 0;
  
      SELECT  count(*)
      INTO    l_count 
      FROM    ORG_FREIGHT_VL a,
              AR_SYSTEM_PARAMETERS b
      WHERE   NVL( disable_date, sysdate ) >= sysdate
      AND     a.organization_id = b.org_id;

      IF l_count = 0 THEN 
         WarningPrint('Freight carriers have not been set up' );
         ActionWarningPrint('Define freight carriers with valid active dates');
      ELSE
         Tab1Print( to_char(l_count) || ' active freight carriers have been set up');
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Freight Carriers" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
  END;

/* -------------------------------- Application Set up, Remit to Address --------------------------------- */ 

    BEGIN 
      Tab1Print('Remit to Address Set Up');
  
      l_count := 0;
      SELECT  count(*)
      INTO    l_count 
      FROM    AR_REMIT_TO_ADDRESSES_V a
      WHERE   a.status = 'A' 
      AND     a.address_id in ( SELECT b.address_id 
                                FROM   RA_REMIT_TOS b 
                                WHERE  b.address_id = a.address_id );

      IF l_count = 0 THEN 
         ErrorPrint('Remit to address has not been set up' );
         ActionErrorPrint('Define a remit to address with active status and assign a country');
      ELSE
         Tab2Print( ''|| to_char(l_count) || ' remit to addresses have been set up with countries assigned to it');
      END IF;

      -- checking for remit to address with default country and default state

      l_count := 0;      
      SELECT   count(*) 
      INTO     l_count 
      FROM     RA_REMIT_TOS 
      WHERE    country = 'DEFAULT' 
      and      state   = 'DEFAULT';

      IF l_count = 0 THEN 
         WarningPrint('A Default remit to address has not been set up');
         ActionWarningPrint('Define a default remit to address. Receivables can use this address if the bill-to '||
              'location on the transaction is not covered by any other remit-to address assignment. This may happen, '||
              'for example, when creating transactions for a new customer'); 
      ELSE
         Tab2Print( to_char(l_count) || ' Remit to addresses have been set up with "Default Country" '||
              'and "Default State" assignments');

      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Remit to address" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------------- Application Set up, Invoice Rules  ---------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT    count(*)
      INTO      l_count 
      FROM      RA_RULES
    WHERE   type = 'I'
    AND         status  = 'A';

      SELECT    accounting_method
      INTO      v_accounting_method
      FROM      AR_SYSTEM_PARAMETERS;

      IF v_accounting_method = 'ACCRUAL' THEN 
         IF l_count = 0 THEN 
            WarningPrint('Invoice rules have not been set up' );
            ActionWarningPrint('Define invoice rules with valid active dates if needed');
         ELSE
            Tab1Print( to_char(l_count) || ' active invoice rules have been set up');
         END IF;
      ELSE  -- Cash basis accounting  
         IF l_count = 0 THEN 
            Tab1Print( 'No invoice rules have been set up. No need to define them since system option - '||
                 'accounting method is "Cash Basis"');
         ELSE 
            Warningprint( to_char(l_count) || ' active invoice rules have been set up');
            ActionwarningPrint('System option - accounting method is "Cash Basis", AutoInvoice will reject '||
                 'any transaction lines associated with invoicing and accounting rules'); 
         END IF;
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Invoice Rules" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------------- Application Set up, Accounting Rules --------------------------- */ 

    BEGIN 
      l_count := 0;
      SELECT    count(*)
      INTO      l_count 
      FROM      RA_RULES
    WHERE   type = 'A'
    AND         status  = 'A';
    
      IF v_accounting_method = 'ACCRUAL' THEN 
         IF l_count = 0 THEN 
            WarningPrint('Accounting rules have not been set up' );
            ActionWarningPrint('Define accounting rules with valid active dates if needed');
         ELSE
            Tab1Print( ''|| to_char(l_count) || ' active accounting rules have been set up');
         END IF;
      ELSE  -- Cash basis accounting  
         IF l_count = 0 THEN 
            Tab1Print( 'No accounting rules have been set up. No need to define them since system option - '||
                 'accounting method is "Cash Basis"');
         ELSE 
            Warningprint( to_char(l_count) || ' active accounting rules have been set up');
            ActionwarningPrint('Be aware that system option - accounting method is "Cash Basis", AutoInvoice '||
                 'will reject any transaction lines associated with invoicing and accounting rules'); 
         END IF;
      END IF; 
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Application Set Up, Accounting Rules" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

      
/* ---------------------------------- Batch source Type Import ----------------------------------------- */ 

    BEGIN
      SectionPrint('Active batch sources of type "Import"');

      l_count := 0; 
      sqltxt  := 'SELECT      org_id             OrgId,      '||
                 '            batch_source_id    BatchId,    '|| 
                 '            name               Name,       '||
                 '      description        Decription  '||
                 'FROM      RA_BATCH_SOURCES         '||
                 'WHERE     batch_source_type = ''FOREIGN''  '||
                 'AND       status = ''A''   '||
                 'AND       NVL( start_date, sysdate) <= sysdate '|| 
                 'AND       NVL( end_date, sysdate)   >= sysdate '||
                 'ORDER BY    batch_source_id' ;

      l_count := Run_sql ( Null, sqltxt, 'N', null, '1' ); 

      IF l_count = 0 THEN 
         ErrorPrint('Import transaction sources have not been set up. There are no active import transaction sources');
         ActionErrorPrint('Set up transaction source with type "Import".  Please refer to Users Guide for setting '||
              'up transaction sources');
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Batch source Type Import" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------------- Auto Accounting Set Up -------------------------------------------- */ 

    DECLARE
      report_warning        VARCHAR2(5) := 'FALSE';
      null_accounts_found   VARCHAR2(5) := 'TRUE'; 
      CURSOR C1 IS 
        SELECT  decode(type, 'SUSPENSE',      'AutoInvoice Clearing',
                             'FREIGHT',       'Freight',
                             'REC',           'Receivable',
                             'TAX',           'Tax',
                             'UNBILL',        'Unbilled Receivable', 
                             'UNEARN',        'Unearned Revenue',
                             'BR_REC',        'Bills Receivable',
                             'REV',           'Revenue',
                             'BR_FACTOR',     'Factored Bills Receivable',
                             'BR_REMITTANCE', 'Remitted Bills Receivable',
                             'BR_UNPAID_REC', 'Unpaid Bills Receivable', type )  type_desc, 
                              gl_default_id                   ccid,
                              type,
                              last_update_date 
        FROM    RA_ACCOUNT_DEFAULTS;

    BEGIN 
      SectionPrint('AutoAccounting Set Up');

      l_count := 0;
      FOR c1_rec in C1 LOOP 
          null_accounts_found := getAutoAccDetails (c1_rec.type_desc, 
                                                    c1_rec.ccid, 
                                                    c1_rec.type, 
                                                    c1_rec.last_update_date);
          l_count := l_count + 1;  
          IF null_accounts_found = 'TRUE' THEN 
             report_warning := 'TRUE';
          END IF; 

      END LOOP; 

      IF l_count = 0 THEN 
         ErrorPrint('AutoAccounting is not set up' );
         ActionErrorPrint('Please refer to AR Users Guide to set up AutoAccounting');
      END IF;
      BrPrint; 

      IF report_warning = 'TRUE' THEN 
         WarningPrint('Certain tables have null accounts and as such AutoAccounting will be unable to derive an account');
         ActionWarningLink('See Note : ','171516.1',' to assist in finding and resolving the records with null accounts');
      END IF; 

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Autoaccounting Set Up" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ------------------------------------ AutoInvoice Unprocessed Records ---------------------------------- */ 
   
    DECLARE 
      CURSOR C1 IS 
         SELECT     batch_source_name        batch, 
            interface_line_context   context, 
            count(*)                 total 
         FROM       RA_INTERFACE_LINES
         WHERE      NVL(interface_status, 'x') != 'P'
         GROUP      BY batch_source_name, interface_line_context;
 
    BEGIN 
      SectionPrint('Unprocessed Records in RA_INTERFACE_LINES ( Org Id = '|| v_orgid || ' )');
      l_count := 0; 
      FOR c1_rec in C1 LOOP 
          Tab1Print('There are '|| to_char(c1_rec.total) ||' unprocessed records for '||
               'batch source "' || c1_rec.batch || '" and interface line context "'|| c1_rec.context ||'"'); 
          l_count := l_count + 1; 
      END LOOP;
      IF l_count = 0 THEN 
         Tab1Print('The table RA_INTERFACE_LINES_ALL contains no unprocessed records for organization "' || v_orgid );
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
            Errorprint( sqlerrm ||' occurred in test in section "Autoinvoice Unprocessed Records" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;

/* ---------------------------------------AutoInvoice Processed Records --------------------------------------*/

    DECLARE
      t_purge      varchar2(1)  := 'N';
    BEGIN
      SectionPrint('Processed records that still exist in AutoInvoice interface tables');

      -- RA_INTERFACE
      l_count := 0;
      SELECT count(*) 
      INTO   l_count 
      FROM   RA_INTERFACE_LINES
      WHERE  NVL(interface_status, 'x') = 'P';
      Tab1Print('There are '|| to_char(l_count) || ' processed records in RA_INTERFACE_LINES ( org id = '|| v_orgid ||' )');
      IF l_count > 5000 THEN 
         t_purge := 'Y';
      END IF;

      l_count := 0;
      SELECT count(*) 
      INTO   l_count 
      FROM   RA_INTERFACE_DISTRIBUTIONS
      WHERE  NVL(interface_status, 'x') = 'P';
      Tab1Print('There are '|| to_char(l_count) || ' processed records in RA_INTERFACE_DISTRIBUTIONS ( org id = '|| v_orgid ||' )');
      IF l_count > 5000 THEN 
         t_purge := 'Y';
      END IF;

      l_count := 0;
      SELECT count(*) 
      INTO   l_count 
      FROM   RA_INTERFACE_SALESCREDITS
      WHERE  NVL(interface_status, 'x') = 'P';
      Tab1Print('There are '|| to_char(l_count) || ' processed records in RA_INTERFACE_SALESCREDITS ( org id = '|| v_orgid ||' )');
      IF l_count > 5000 THEN  
         t_purge := 'Y';
      END IF; 
       
      IF t_purge = 'Y' THEN 
         WarningPrint('At least one of the 3 AutoInvoice interface tables contain a large number of processed records. '||
              'As these records have been succesfully interfaced to Receivables they should be purged'); 
         ActionWarningPrint('Submit the concurrent request "AutoInvoice Purge Program" to remove processed records '||
              'from the AutoInvoice interface tables');
      END IF;  

      BrPrint;
      l_count := 0;      
      SELECT  count(*) 
      INTO    l_count 
      FROM    RA_INTERFACE_ERRORS_ALL  a 
      WHERE   NOT EXISTS 
            ( SELECT    b.interface_line_id 
              FROM      RA_INTERFACE_LINES_ALL b
              WHERE     a.interface_line_id = b.interface_line_id );   

      Tab1Print('There are '|| to_char(l_count) || ' records in the table RA_INTERFACE_ERRORS_ALL which no longer '||
           'exist in the RA_INTERFACE_LINES_ALL table.');
      Tab2Print('This count is NOT specific to organization ' || v_orgid || ' , but to all organizations');
      IF l_count > 500 THEN  
         WarningPrint('AutoInvoice purge does not purge the table RA_INTERFACE_ERRORS_ALL.');
         ActionWarningLink('Errored records which have been corrected and succesfully processed afterwards must be '||
              'removed manually from the table RA_INTERFACE_ERRORS_ALL. See Note : ', '169879.1', ' for assistance' );  
      END IF;       

    EXCEPTION
        WHEN OTHERS THEN 
           Errorprint( sqlerrm ||' occurred in test in section "AutoInvoice Processed Records"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------------------ Indexes    --------------------------------------------------- */ 

    showIndexes('RA_CUSTOMER_TRX_ALL', 'INTERFACE_HEADER_ATTRIBUTE%');
    showIndexes('RA_CUSTOMER_TRX_LINES_ALL', 'INTERFACE_LINE_ATTRIBUTE%');
    showIndexes('RA_INTERFACE_LINES_ALL','INTERFACE_LINE_ATTRIBUTE%');
    showIndexes('RA_INTERFACE_DISTRIBUTIONS_ALL','INTERFACE_LINE_ATTRIBUTE%');
    showindexes('RA_INTERFACE_SALESCREDITS_ALL', 'INTERFACE_LINE_ATTRIBUTE%');

/* ------------------------------------- Indexes versus Tuning Segments ------------------------------------ */ 
    
    DECLARE 
      t_accountflex_tuning      VARCHAR2(80):= Null;
      t_itemflex_tuning         VARCHAR2(80):= Null;
      t_territoryflex_tuning    VARCHAR2(80):= Null;
      t_apps_column             VARCHAR2(30):= Null;
    BEGIN 
      SELECT    ai_acct_flex_key_left_prompt,
                ai_mtl_items_key_left_prompt,
                ai_territory_key_left_prompt
      INTO        t_accountflex_tuning,
                  t_itemflex_tuning,
                  t_territoryflex_tuning
      FROM        AR_SYSTEM_PARAMETERS;
      
   -- GL_CODE_COMBINATIONS - Accounting Flex Tuning Segment  
    
      showIndexes('GL_CODE_COMBINATIONS', null );
      IF t_accountflex_tuning is NOT NULL THEN
         BrPrint; 
         Tab1Print('System Options : Accounting Flex Tuning Segment is set to "'|| t_accountflex_tuning || '"' );         

      -- find the physical column that corresponds with the tuning segment     
         BEGIN 
           SELECT  b.application_column_name
           INTO    t_apps_column 
           FROM    FND_ID_FLEX_STRUCTURES_VL a,
                   FND_ID_FLEX_SEGMENTS_VL b,
                   AR_SYSTEM_PARAMETERS c,
                   GL_SETS_OF_BOOKS_V d
           WHERE   a.id_flex_code = 'GL#' 
           AND     a.enabled_flag = 'Y'
           AND     a.freeze_flex_definition_flag = 'Y' 
           AND     b.id_flex_code = a.id_flex_code 
           AND     b.enabled_flag = 'Y' 
           AND     b.segment_name = t_accountflex_tuning
           AND     b.id_flex_num  = a.id_flex_num
           AND     a.id_flex_num  = d.chart_of_accounts_id 
           AND     c.set_of_books_id = d.set_of_books_id;

           Tab1Print('This corresponds with the physical column "' || t_apps_column || '" in the table GL_CODE_COMBINATIONS');         
         EXCEPTION 
           WHEN NO_DATA_FOUND THEN 
                ErrorPrint( 'The accounting flexfield tuning segment is not set to an enabled segment of the '||
                     'accounting flexfield' );
                ActionErrorPrint('Go to system options and update the accounting flexfield tuning segment by selecting '||
                     'a value from the list of values');     
           WHEN TOO_MANY_ROWS THEN 
                Tab1Print( 'Unable to show the physical column with matches with this tuning segment. The accounting ' ||
                     'flexfield tuning segment matches with more than one enabled segment of the accounting flexfield' );
           WHEN OTHERS THEN 
                Errorprint( sqlerrm||' occurred in test in section "Indexes versus Tuning Segments" - Unable to '||
                     'show the physical column with matches with the accounting flexfield tuning segment' );
                ActionErrorPrint('Please report the above error to Oracle Support Services.');
         END;

      ELSE   -- tuning segment is null 
        Tab1Print('System Options : Accounting Flex Tuning Segment is not defined' );         
      END IF;

      WarningPrint('The value of the tuning segment can have an impact on the performance of AutoInvoice');
      ActionWarningPrint('Verify the following : in case indexes already exist for the table GL_CODE_COMBINATIONS '||
           'make sure the accounting flex tuning segment matches the value of that index. When it is '||
           'a concatenated index use the first column of the concatenated index as tuning segment. '||
           'If no indexes exist for the table GL_CODE_COMBINATIONS table, enter the segment with the most '||
           'distinct values for the accounting flexfield tuning segment.'); 
       
   -- MTL_SYSTEM_ITEMS_B - System Item Tuning Segment 

      showIndexes('MTL_SYSTEM_ITEMS_B', null );
      IF t_itemflex_tuning is NOT NULL THEN 
         BrPrint; 
         Tab1Print('System Options : System Item Tuning Segment is set to "'|| t_itemflex_tuning || '"' ); 

      -- find the physical column that corresponds with the tuning segment     
         BEGIN 
           t_apps_column := Null; 

           SELECT  b.application_column_name
           INTO    t_apps_column 
           FROM    FND_ID_FLEX_STRUCTURES_VL a,
                   FND_ID_FLEX_SEGMENTS_VL b
           WHERE   a.ID_FLEX_CODE = 'MSTK' 
           AND     a.enabled_flag = 'Y'
           AND     a.freeze_flex_definition_flag = 'Y' 
           AND     b.id_flex_code = a.ID_FLEX_CODE 
           AND     b.id_flex_num  = a.id_flex_num
           AND     b.enabled_flag = 'Y'
           AND     b.segment_name = t_itemflex_tuning ;

           Tab1Print('This corresponds with the physical column "' || t_apps_column || '" in the table MTL_SYSTEM_ITEMS');         
         EXCEPTION 
           WHEN NO_DATA_FOUND THEN 
                ErrorPrint( 'The system item flexfield tuning segment is not set to an enabled segment of the'||
                     'system item flexfield' );
                ActionErrorPrint('Go to system options and update the system item flexfield tuning segment by selecting '||
                     'a value from the list of values');     
           WHEN TOO_MANY_ROWS THEN 
                Tab1Print( 'Unable to show the physical column with matches with this tuning segment. The system item ' ||
                     'flexfield tuning segment matches with more than one enabled segment of the system item flexfield' );
           WHEN OTHERS THEN 
                Errorprint( sqlerrm||' occurred in test in section "Indexes versus Tuning Segments" - Unable to '||
                     'show the physical column with matches with the system item flexfield tuning segment' );
                ActionErrorPrint('Please report the above error to Oracle Support Services.');
         END;

      ELSE  -- Tuning Segment is Null 
         Tab1Print('System Options : System Item Tuning Segment is not defined' ); 
      END IF;

      WarningPrint('The value of the tuning segment can have an impact on the performance of AutoInvoice');
      ActionWarningPrint('Verify the following : in case indexes already exist for the table MTL_SYSTEM_ITEMS '||
           'make sure the system item flexfield tuning segment matches the value of that index. When it is '||
           'a concatenated index use the first column of the concatenated index as tuning segment. '||
           'If no indexes exist for the table MTL_SYSTEM_ITEMS table, enter the segment with the most '||
           'distinct values for the system items flexfield tuning segment.'); 

   -- RA_TERRITORIES - Territory Tuning Segment 

      showIndexes('RA_TERRITORIES', null );
      IF t_territoryflex_tuning is NOT NULL THEN 
         BrPrint; 
         Tab1Print('System Options : Territory Tuning Segment is set to "'|| t_territoryflex_tuning || '"' ); 

      -- find the physical column that corresponds with the tuning segment     
         BEGIN 
           t_apps_column := Null; 

         SELECT  b.application_column_name
           INTO    t_apps_column 
           FROM    FND_ID_FLEX_STRUCTURES_VL a,
                   FND_ID_FLEX_SEGMENTS_VL b
           WHERE   a.id_flex_code = 'CT#' 
           AND     a.enabled_flag = 'Y'
           AND     a.freeze_flex_definition_flag = 'Y' 
           AND     b.id_flex_code = a.id_flex_code  
           AND     b.id_flex_num = a.id_flex_num
           AND     b.enabled_flag = 'Y'
           AND     b.segment_name =  t_territoryflex_tuning ;

           Tab1Print('This corresponds with the physical column "' || t_apps_column || '" in the table RA_TERRITORIES');         
         EXCEPTION 
           WHEN NO_DATA_FOUND THEN 
                ErrorPrint( 'The territory flexfield tuning segment is not set to an enabled segments of the '||
                     'territory flexfield' );
                ActionErrorPrint('Go to system options and update the territory flexfield tuning segment by selecting '||
                     'a value from the list of values');     
           WHEN TOO_MANY_ROWS THEN 
                Tab1Print( 'Unable to show the physical column with matches with this tuning segment. The territory '||
                     'flexfield tuning segment matches with more than one enabled segment of the territory flexfield' );
           WHEN OTHERS THEN 
                Errorprint( sqlerrm||' occurred in test in section "Indexes versus Tuning Segments" - Unable to '||
                     'show the physical column with matches with the territory flexfield tuning segment' );
                ActionErrorPrint('Please report the above error to Oracle Support Services.');
         END;

      ELSE  -- Tuning segment is null
         Tab1Print('System Options : Territory Tuning Segment is not defined' ); 
      END IF;  

      WarningPrint('The value of this tuning segment can have an impact on the performance of AutoInvoice');
      ActionWarningPrint('Verify the following : in case indexes already exist for the table RA_TERRITORIES '||
           'make sure the territory flexfield tuning segment matches the value of that index. When it is '||
           'a concatenated index use the first column of the concatenated index as tuning segment. '||
           'If no indexes exist for the table RA_TERRITORIES table, enter the segment with the most '||
           'distinct values for the territory flexfield tuning segment.'); 

    EXCEPTION
      WHEN NO_DATA_FOUND THEN 
           Errorprint('AR system options have not been defined for this operating unit. Unable to check tuning segments');
           ActionErrorPrint('Please refer to Users Guide to define AR system options');
        WHEN OTHERS THEN 
           Errorprint( sqlerrm||' occurred in test in section "Indexes versus Tuning Segments" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END; 

/* ------------------------------------------ Triggers  --------------------------------------------------- */ 

    SectionPrint('Database Triggers');
    showTriggers('RA_INTERFACE_LINES_ALL');
    showTriggers('RA_INTERFACE_DISTRIBUTIONS_ALL');
    showTriggers('RA_INTERFACE_SALESCREDITS_ALL');
 
/* ------------------------------------------ Related Packages ---------------------------------------------- */ 

    -- only checking this if v_orgid is not null ( multi org ) 
    IF v_orgid is NOT NULL THEN     
 
       BEGIN   
  
         SectionPrint('Related packages ARP_ADDS_'|| v_orgid || ' and APP_STAX_'|| v_orgid );     

         sqltxt := 'SELECT   owner,        '||
                   '         object_name,  '||
                   '         object_type,  '||
                   '         status        '||
                   'FROM     DBA_OBJECTS   '||
                   'WHERE    object_name = ''ARP_ADDS_'|| rtrim(ltrim(v_orgid)) || '''' ||
                   ' OR      object_name = ''ARP_STAX_'|| rtrim(ltrim(v_orgid)) || '''' ; 
   
         Run_sql ( Null, sqltxt, 'N', null, 1 );
    
         l_count := 0;

         SELECT  count(*) 
         INTO    l_count 
         FROM    DBA_OBJECTS
         WHERE   OBJECT_NAME = 'ARP_ADDS_'||rtrim(ltrim(v_orgid))
         AND     OBJECT_TYPE LIKE 'PACKAGE%'
         AND     STATUS = 'VALID' 
         AND     OWNER  = user;

         IF l_count < 2 THEN 
            ErrorPrint('The package or/and package header ARP_ADDS_'|| v_orgid || ' do not exist, are not valid or '||
                 'do not have the right owner');
            ActionErrorLink('Please make sure the package and package header ARP_ADDS_'|| v_orgid || ' exist, are '||
                 'compiled succesfully and are owned by the APPS account. See Note :','160972.1' ,' for assistance' ); 
         END IF;

         l_count := 0;

         SELECT  count(*) 
         INTO    l_count 
         FROM    DBA_OBJECTS
         WHERE   OBJECT_NAME = 'ARP_STAX_'||rtrim(ltrim(v_orgid))
         AND     OBJECT_TYPE LIKE 'PACKAGE%'
         AND     STATUS = 'VALID' 
         AND     OWNER  = user;

         IF l_count < 2 THEN 
            ErrorPrint('The package or/and package header ARP_STAX_'|| v_orgid || ' do not exist, are not valid or '||
                       'do not have the right owner');
            ActionErrorPrint('Please make sure the package and package header ARP_STAX_'|| v_orgid || ' exist, are compiled '||
                       'succesfully and are owned by the APPS account' ); 
         END IF; 

       EXCEPTION 
         WHEN OTHERS THEN 
              Errorprint(sqlerrm||' occurred in test in section "Related Packages" ');
              ActionErrorPrint('Please report the above error to Oracle Support Services.');
       END;

    END IF;

/* ------------------------------------------ References --------------------------------------------------- */ 

    SectionPrint('References');
    Show_link('67189.1');
    ActionPrint(' : "Oracle Receivables Manuals and eTRMs". Refer to  "Appendix B : Oracle Receivables ' || 
                ' Profile Options" in the 11i User Guide to fix the errors and warnings in the profile options section' );
    Show_link( '131766.1' );   
    ActionPrint( ' : "Self-Service Toolkit Oracle Receivables and iReceivables"' ); 
    Show_link ('91556.1');    
    ActionPrint(' : "Latest AR News"' );      
    Show_link('149226.1'); 
    ActionPrint(' : "How to Find the Latest Patchset Using Metalink"' ); 

/* -------------------------------------------- Feedback --------------------------------------------------- */

    Brprint;
    Show_Footer('&v_testlongname', '&v_headerinfo'); 

/* -------------------------------- Exception Section  - Main Program ( Part 2 ) --------------------------- */ 

  EXCEPTION --  exception section ( block 2 ) 
    WHEN STOPEXECUTION THEN  
          brprint;
          Show_Footer('&v_testlongname', '&v_headerinfo');
          brprint;
     WHEN OTHERS THEN 
         brprint;
         ErrorPrint(sqlerrm||' occurred in the diagnostic test');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
         brprint;
         Show_Footer('&v_testlongname', '&v_headerinfo');
         brprint; 
  END; -- ( block 2, script code ) 

EXCEPTION -- exception section ( block 1 )
  WHEN OTHERS THEN   
       Brprint;
       Errorprint(sqlerrm||' occurred in the diagnostic test');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');
       Brprint; 
       Show_Footer('&v_testlongname', '&v_headerinfo');
       Brprint;
END;   -- ( Block 1, API and template )  
/
  
REM  ==============SQL PLUS Environment setup===========================================================
Spool off
Set termout on
set feedback on
set verify off 
set echo off 
set trimout off
set trimspool off
set heading on
set autoprint off

PROMPT
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================
PROMPT 
