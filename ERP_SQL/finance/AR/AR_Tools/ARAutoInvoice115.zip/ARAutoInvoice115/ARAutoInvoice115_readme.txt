================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract           Oracle Receivables - AR AutoInvoice test
================================================================================
PRODUCT:           Accounts Receivable (AR) 
SUBCOMPONENT:      AUTO 
PRODUCT VERSIONS:  Release 11.5.2 or higher
DATABASE VERSIONS: 8.1.6 or higher
PLATFORM:          Generic 
DATE CREATED:      12-Aug-2002
PARAMETERS:        Username 
                   Responsibility Id 
                   Batch Source Id     
                     
                  
================================================================================
Instructions
================================================================================
Included Files:
     CoreApiHtml.sql      
     ARAutoInvoice115.sql
     ARAutoInvoice115_readme.htm
     ARAUtoInvoice115_readme.txt  
     ARAutoInvoice115_Sample_Output.htm


Execution Environment:
     SQL*Plus


Access Privileges:
     Requires APPS user access


Usage:
     sqlplus apps/apps @ARAutoinvoice115 


Instructions:

The files ARAutoinvoice115.sql and CoreApiHtml.sql should be unzipped
to a common directory. From this directory run the file ARAutoInvoice115.sql
in SQL*Plus in the APPS schema.

You will be prompted for an applications user name. 
You should then see a list of valid responsibilities for the user entered.

When prompted, enter a responsibility id which falls under Oracle Receivables 
as the test is checking the set up for AutoInvoice.

Next you will see a list of active batch sources of type Import.
When prompted for batch source id, enter an id you see in the list. 

The test will produce an output file named ARAutoInvoice115_[batch_source_id]_diag.htm
This file can be viewed in a browser or uploaded for support analysis.

================================================================================
Description
================================================================================

This test verifies the set up of AutoInvoice by capturing a snapshot of your 
current set up.

The purpose of the test is to check the basic set up (as outlined in 'Setting Up' 
chapter in the User's Guide) of AutoInvoice. When set up information is 
missing or when the set up is invalid, the test will output error/warning 
messages, the action to be taken, and the impact of the missing setup. 

This test collects and verifies the following : 

     Product Status and Patch Level 
     System Options related with AutoInvoice  
     Batch source Set Up for the batch_source_id specified 
     Grouping Rule Set Up ( derived form Batch Source Id ) 
     Open Calendar Period in AR  
     Accounting Flexfield 
     Sales Tax Location Flexfield 
     Territory Flexfield 
     Line Transaction Flexfield 
     Invoice Transaction Flexfield 
     Link-to Transaction Flexfield
     Reference Transaction Flexfield
     Profile Options related with AutoInvoice  
     Item Validation Organization 
     Transaction types 
     Payment terms 
     Salespersons  
     Unit of measures  
     FOB codes 
     Freight Carrier codes 
     Remit to address 
     Invoice rules
     Accounting Rules    
     Transaction sources of Type 'Import'
     AutoAccounting Set Up  
     Unprocessed records in RA_INTERFACE_LINES
     Processed records in the AutoInvoice interface tables 
     Indexes
     Database Triggers 
   

================================================================================
References
================================================================================
none

================================================================================
Disclaimer
================================================================================
EXCEPT WHERE EXPRESSLY PROVIDED OTHERWISE, THE INFORMATION, SOFTWARE,
PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. ORACLE EXPRESSLY DISCLAIMS
ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NON-INFRINGEMENT. ORACLE MAKES NO WARRANTY THAT: (A) THE RESULTS
THAT MAY BE OBTAINED FROM THE USE OF THE SOFTWARE WILL BE ACCURATE OR
RELIABLE; OR (B) THE INFORMATION, OR OTHER MATERIAL OBTAINED WILL MEET YOUR
EXPECTATIONS. ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE DOWNLOADED OR
OTHERWISE OBTAINED IS DONE AT YOUR OWN DISCRETION AND RISK. ORACLE SHALL HAVE
NO RESPONSIBILITY FOR ANY DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT
RESULTS FROM THE DOWNLOAD OF ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE.

ORACLE RESERVES THE RIGHT TO MAKE CHANGES OR UPDATES TO THE SOFTWARE AT ANY
TIME WITHOUT NOTICE.

================================================================================
Limitation of Liability
================================================================================
IN NO EVENT SHALL ORACLE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL OR CONSEQUENTIAL DAMAGES, OR DAMAGES FOR LOSS OF PROFITS, REVENUE,
DATA OR USE, INCURRED BY YOU OR ANY THIRD PARTY, WHETHER IN AN ACTION IN
CONTRACT OR TORT, ARISING FROM YOUR ACCESS TO, OR USE OF, THE SOFTWARE.

SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY.
ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS MAY NOT APPLY TO YOU.

