undefine v_headerinfo
Define   v_headerinfo     =  '$Header: ARTransactionInfo115.sql  1.6 20-JUN-2003 support $'
undefine v_scriptlongname
Define   v_scriptlongname = 'Transaction Data Collection 11.5'

REM   ===========================================================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM   Oracle Support Services.  All rights reserved.
REM   ===========================================================================================
REM    PURPOSE:             Transaction Data Collection
REM    PRODUCT:             Accounts Receivable (AR)
REM    PRODUCT VERSIONS:    11.5.X
REM    PLATFORM:            Generic
REM    PARAMETERS:          1. Apps username
REM                         2. Responsibility to be chosen from list 
REM                         3. Column Output ( All/Limited )
REM                         4. Transaction Number 
REM                         5. Customer_trx_id
REM   ===========================================================================================

REM   ===========================================================================================
REM   USAGE:        sqlplus apps/apps@ARTransactionInfo115.sql
REM                 Diagnostic test will prompt for parameters
REM   OUTPUT:       ARTransactionInfo115_[Customer_trx_id]_diag.html
REM   ===========================================================================================

REM   ===========================================================================================
REM   CHANGE HISTORY:
REM   DATE  09-DEC-2002   Created      igovaert
REM         04-MAR-2003   Modified     igovaert   added AX Set Up, AR_MC_ADJUSTMENTS and 
REM                                               AR_MC_DISTRIBUTIONS_ALL (ADJ)     
REM         14-JUN-2003   Modified     igovaert   added Column Output Parameter : Limited or All
REM                       Modified     igovaert   added Transaction Number Parameter  
REM                       Modified     igovaert   added 3 GL tables, resulting in a code split                       
REM   
REM ============================================================================================
        
REM   
REM   ===========================================================================================

REM  ==============SQL PLUS Environment setup====================================================
set serveroutput on size 1000000
set linesize 500 
set verify off 
set feedback off
set echo off
set verify off 
set autoprint off
set termout on 

REM ========================== Define SQL Variables for input parameters ========================
VARIABLE    v_username VARCHAR2(100);
VARIABLE    v_abort    VARCHAR2(1); 

REM =========================Validate DATABASE Version =========================================
REM ======================NOTE - This section only needed for tests using HTML API's============

DECLARE 
  l_version           VARCHAR2(30);
BEGIN 

  SELECT MAX(version)
  INTO   l_version
  FROM   v$instance;

  IF l_version < '8.1.6.0.0' THEN 
     DBMS_OUTPUT.PUT_LINE(chr(10));
     DBMS_OUTPUT.PUT_LINE('ERROR - Invalid Database Version '||l_version || '. The test requires RDBMS version 8.1.6 or higher');
     DBMS_OUTPUT.PUT_LINE('ACTION - Type Ctrl-C <Enter> to exit the test.');
     DBMS_OUTPUT.PUT_LINE(chr(10));
  END IF;

EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - Database Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM =========================Validate SQL*Plus Version Character Set Combination=================
REM ======================NOTE - This section only needed for tests using HTML API's=============

DECLARE
  l_nls_characterset    nls_database_parameters.value%TYPE;
  l_sql_release_int     INTEGER(20) :=  to_number('&_SQLPLUS_RELEASE');
  l_sql_release_chr     VARCHAR2(50) := '&_SQLPLUS_RELEASE';

BEGIN

  SELECT value 
    INTO  l_nls_characterset
    FROM  nls_database_parameters
    WHERE parameter = 'NLS_CHARACTERSET';
    
  FOR i IN 1..4 LOOP
    l_sql_release_chr := substr(l_sql_release_chr,1,(2*i)-1)||'.'||
      substr(l_sql_release_chr,(2*i)+1);
  END LOOP;
  
  IF l_nls_characterset LIKE 'UTF%' THEN
     IF l_sql_release_int IS null THEN 
        DBMS_OUTPUT.PUT_LINE(chr(10));
        DBMS_OUTPUT.PUT_LINE('ATTENTION - Cannot determine version of SQL*plus being used for test run.');
        DBMS_OUTPUT.PUT_LINE('.           This test may fail if not run using a version 8.1.X of SQL*plus or higher.');
        DBMS_OUTPUT.PUT_LINE('Attempting to run the test.......');
        DBMS_OUTPUT.PUT_LINE(chr(10));
     ELSIF l_sql_release_int < 801000000 THEN
        DBMS_OUTPUT.PUT_LINE(chr(10));
        DBMS_OUTPUT.PUT_LINE('ERROR - Invalid SQL*plus Version '||l_sql_release_chr);
        DBMS_OUTPUT.PUT_LINE('ACTION - On databases using the '||l_nls_characterset||' NLS characterset this test should not be run using this ');
        DBMS_OUTPUT.PUT_LINE('.        SQL*plus Version.  Please rerun this test using version 8.1.X of SQL*plus or higher.');
        DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
        DBMS_OUTPUT.PUT_LINE(chr(10));
     END IF;
  END IF;
EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - SQL*plus Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM ========================== Show responsibilities assigned to given user =====================
DECLARE
  l_applversion  fnd_product_groups.release_name%type;
  l_counter      integer;
  l_cursor       integer;
  sqltxt         varchar2(3000);
  l_resp_id      integer;
  l_resp_name    varchar2(300);

BEGIN
  :v_abort := 'N';

  select nvl(rtrim(ltrim(upper('&Application_user_name'))), '<NULL username>')
  into   :v_username
  from   dual;
  
  select substr(release_name,1,4) into l_applversion from fnd_product_groups;
  
  IF l_applversion = '11.5' THEN 
    sqltxt := 'select to_char(a.responsibility_id) id, '||
              '       b.responsibility_name name '||
              'from   fnd_user_resp_groups a, '||
              '       fnd_responsibility_vl b, '||
              '       fnd_user u '||
              'where  a.user_id = u.user_id '||
              'and    a.responsibility_id = b.responsibility_id '||
              'and    a.responsibility_application_id = b.application_id '||
              'and    sysdate between '||
              '          a.start_date and nvl(a.end_date,sysdate+1) '||
              'and    upper(u.user_name) = '''|| :v_username ||''''||
              'order  by b.responsibility_name';
  

    DBMS_OUTPUT.PUT_LINE(chr(10) || 'Responsibilities assigned to User:  '|| :v_username);
    DBMS_OUTPUT.PUT_LINE('=================================================================' || chr(10) );
  
    l_cursor := dbms_sql.open_cursor; 
    dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
    dbms_sql.define_column(l_cursor, 1, l_resp_id);
    dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
    l_counter := dbms_sql.execute(l_cursor); 
    l_counter := 0;
    WHILE  dbms_sql.fetch_rows(l_cursor) > 0 LOOP
      l_counter := l_counter + 1;
      dbms_sql.column_value(l_cursor, 1, l_resp_id);
      dbms_sql.column_value(l_cursor, 2, l_resp_name);
      DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
    END LOOP;
  
    DBMS_OUTPUT.PUT_LINE(' ');
  
    IF l_counter = 0 THEN
      raise no_data_found;
    END IF;
    dbms_sql.close_cursor(l_cursor);

  ELSE 
    DBMS_OUTPUT.PUT_LINE('ERROR  - Invalid Applications Version '|| l_applversion);
    DBMS_OUTPUT.PUT_LINE('ACTION - This Diagnostic Test is intended for Oracle Applications version 11i only.'  || chr(10) || 
                         '         Type Ctrl-C <Enter> to exit the test.');
  END IF;

EXCEPTION
  when no_data_found then
    DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
    DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.' || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.  Rerun the test with a valid user name.' || chr(10));
  when others then
    DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error: '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                         '         Type Ctrl-C <Enter> to exit the test.'  || chr(10) );
END;
/

PROMPT 
undefine v_respid
accept v_respid number PROMPT  'Please choose an Accounts Receivable Responsibility ID from the list : '


REM ========================= Accept other Input Parameters ===============================
PROMPT 
PROMPT Column Output Values  
PROMPT =================================================== 
PROMPT 
PROMPT A ... ALL, select ALL columns
PROMPT L ... Limited, Select only a limited set of columns
PROMPT  
undefine ColumnOutput
accept   ColumnOutput char PROMPT 'Column Output (default L) : ' 
PROMPT 

PROMPT The optional parameter 'Transaction Number' is only an aid to determine the Customer Trx Id, 
PROMPT which needs to be entered next. Leave it blank when the Customer Trx Id of the transaction 
PROMPT to be analyzed is already known.     
PROMPT  
undefine trxNumber
accept   trxNumber char PROMPT 'Transaction Number (optional) : '

REM ================ Show list of Transactions matching the Transaction Number entered ============== 
DECLARE   
  p_userid       number; 
  p_respid       number;
  p_appid        number; 
  l_counter      integer;
  l_cursor       integer;
  sqltxt         varchar2(3000);
  p_trx          varchar2(50);
  l_trxid        integer;
  l_custref      varchar2(50);
  l_source       varchar2(30);
  l_type         varchar2(30);  

BEGIN
-- set environment in order to select matching transactions in the right organization
 
  p_trx := ltrim(rtrim('&trxNumber')); 

  IF length(p_trx) > 0 THEN   

     IF :v_username = '<NULL username>' THEN
        RAISE NO_DATA_FOUND;
     ELSE  
       BEGIN   
         SELECT user_id 
         INTO   p_userid
         FROM   fnd_user 
         WHERE  user_name = :v_username;
       EXCEPTION 
         WHEN OTHERS then
              RAISE NO_DATA_FOUND;
       END;
     END IF;
 
     IF &v_respid = 0 THEN
        RAISE NO_DATA_FOUND;     
     ELSE
       BEGIN         
         p_respid := &v_respid;
         SELECT responsibility_application_id 
         INTO   p_appid        
         FROM   fnd_user_resp_groups 
         WHERE  responsibility_id = p_respid
         AND    user_id = p_userid;
       EXCEPTION 
         WHEN OTHERS then
              RAISE NO_DATA_FOUND;
       END;
     END IF; 

     BEGIN 
       fnd_global.apps_initialize(p_userid, p_respid, p_appid );
     EXCEPTION
       WHEN OTHERS THEN 
            RAISE NO_DATA_FOUND;
     END; 
     
     sqltxt := 'SELECT  a.customer_trx_id,    '||
               '        a.customer_reference, '||  
               '        c.name,               '||
               '        b.name                '||                   
               'FROM    RA_CUSTOMER_TRX a,    '||
               '        RA_CUST_TRX_TYPES b,  '||
               '        RA_BATCH_SOURCES c    '||
               'WHERE   a.trx_number = '''|| p_trx || ''' ' || 
               'AND     b.cust_trx_type_id = a.cust_trx_type_id  ' ||
               'AND     c.batch_source_id = a.batch_source_id ';            
  
     DBMS_OUTPUT.PUT_LINE( chr(10) || 'Transaction Number '|| p_trx || ' identifies : ' );
     
     l_cursor := dbms_sql.open_cursor;
     dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
     dbms_sql.define_column(l_cursor, 1, l_trxid );
     dbms_sql.define_column(l_cursor, 2, l_custref, 50 );
     dbms_sql.define_column(l_cursor, 3, l_source, 30 );
     dbms_sql.define_column(l_cursor, 4, l_type, 30 );
     l_counter := dbms_sql.execute(l_cursor);
     l_counter := 0; 


     WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
           l_counter := l_counter + 1;
           dbms_sql.column_value(l_cursor, 1, l_trxid);
           dbms_sql.column_value(l_cursor, 2, l_custref);
           dbms_sql.column_value(l_cursor, 3, l_source);
           dbms_sql.column_value(l_cursor, 4, l_type);
           DBMS_OUTPUT.PUT_LINE( chr(10) || '   Customer Trx Id = '|| to_char(l_trxid) ||', Customer Ref = '||l_custref||', Source = '||
                                 l_source||', Type = '||l_type );
     END LOOP; 

     IF l_counter = 0 then
        RAISE no_data_found;
     END IF;   
     dbms_sql.close_cursor(l_cursor);

  END IF;

EXCEPTION
  when NO_DATA_FOUND then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any Transactions matching the Transaction Number specified'); 
       DBMS_OUTPUT.PUT_LINE('ACTION - Continue execution by entering a valid Customer Trx Id afterall OR '  || chr(10) ||
                            '         Choose to exit and ensure User, Responsibility and Transaction Number are valid.' || chr(10) || 
                            '         To exit the diagnostic test type Ctrl-C <Enter>.'  || chr(10) );
  when OTHERS then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Receipt List error: '||sqlerrm ); 
       DBMS_OUTPUT.PUT_LINE('ACTION - Report the above error to Oracle Support representative' || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the diagnostic test.' || chr(10) );  
END; 
/

PROMPT
undefine trxid
accept trxid number PROMPT   'Customer Trx Id (required) : '
define trxidc = &trxid


REM ========================= Spooling the output file =============================================
Define v_spoolfilename  = 'ARTransactionInfo115_&trxidc._diag.html'

PROMPT 
PROMPT ============================================================================
PROMPT Output will be spooled to &v_spoolfilename
PROMPT ============================================================================
PROMPT
PROMPT Running.....
PROMPT 
spool  &v_spoolfilename

set termout on
REM =========================== Run the Pl/SQL api file ============================================
@@CoreApiHtml.sql

BEGIN -- begin1
  DECLARE -- declare 2

/*==================================================================================================
 *
 * START DECLARATIONS 
 * 
 *=================================================================================================*/

--  variables for input parameters
    p_username              varchar2(100);
    p_respid                number;
    p_columnOutput          varchar2(8)    := NULL; 
    p_trxId                 varchar2(25)   := NULL; 
    v_respname              varchar2(100)  := NULL;
    v_appid                 number         := 0;

--  variables for quick link table
    ql_markers              V2T;
    ql_titles               V2T;
    sqltxt                  varchar2(32767);

--  general variables 
    v_orgid                 varchar2(15)   := null;
    v_orgname               varchar2(60)   := null;    
    v_mrc_flag              varchar2(1)    := 'N';
    v_multi_org             varchar2(1)    := 'N';
    v_prim_sobid            number         := null; 
    v_sobname               varchar2(30)   := null;
    v_currency              varchar2(30)   := null; 
    v_report_mrc            varchar2(1)    := 'N';
    v_patch_level           varchar2(30)   := null;   
  
--  variables for transaction header
    h_trxId                 number(15)     := null;  
    h_trxNum		    varchar2(100)  := null;
    h_reference             varchar2(100)  := null;
    h_batchDsp              varchar2(100)  := null;
    h_typeId                number(15)     := null;  
    h_typeDsp               varchar2(100)  := null;
    h_trxDate               varchar2(30)   := null;
    h_complete              varchar2(100)  := null;
    h_currency              varchar2(100)  := null;
    h_exchangeRate          varchar2(100)  := null;
    h_class                 varchar2(100)  := null; 
    h_termDsp               varchar2(100)  := null; 
    h_dueDate               varchar2(100)  := null;       
    h_ruleDsp               varchar2(100)  := null; 
    h_statusTrx             varchar2(100)  := null;
    h_initialCustomerTrxId  number(15)     := null;
    h_sobId                 number(15)     := null;
    h_creditedCustomerTrxId number(15)     := null;
    h_requestId             number(15)     := null;
    
 -- variables for transaction type  
  
    t_name                  varchar2(20)   := null;
    t_desc                  varchar2(100)  := null;
    t_type                  varchar2(20)   := null;
    t_terms                 number(15)     := null;  
    t_openRec               varchar2(1)    := null;
    t_postGl                varchar2(1)    := null;
    t_printing              varchar2(20)   := null;
    t_defaultStatus         varchar2(20)   := null;
    t_allowFreight          varchar2(1)    := null;
    t_taxCalc               varchar2(1)    := null;
    t_sign                  varchar2(30)   := null;
    t_naturalApp            varchar2(1)    := null;
    t_ruleSetId             number(30)     := null;
    t_allowOverApp          varchar2(1)    := null;
    t_status                varchar2(30)   := null;
    t_start                 varchar2(30)   := null;
    t_end                   varchar2(30)   := null;
    t_subTypeId             number(15)     := null;
    t_sobId                 number(15)     := null;

 -- EXCEPTIONS  
    STOPEXECUTION  exception;

/* ===================================================================================================
 * Definition of Quick Link Procedures 
 * ==================================================================================================*/

/*---------------------------------- Define procedure TAG -------------------------------------------*/ 

  PROCEDURE  Tag( p_txt varchar2 ) is
  BEGIN 
    Insert_HTML('<a NAME='||p_txt||'></a>');
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "Tag"' );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END Tag;

/*---------------------------------- Define procedure TOP -------------------------------------------*/ 

  PROCEDURE Top is
  BEGIN
    Insert_HTML('<a HREF=#quicklinks>Back to Quick Links</a><BR>');
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "Top"' );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END Top;

/*----------------------------------- Define procedure Show_Quicklink_Row ----------------------------*/ 

  PROCEDURE Show_Quicklink_Row( p_ql_titles in V2T, p_ql_markers in V2T ) is
    l_row_values V2T;
  BEGIN 
    IF p_ql_titles.count = p_ql_markers.count THEN  
       l_row_values := V2T();
       FOR i in 1..p_ql_titles.count LOOP
         l_row_values.extend;
         l_row_values(i) := '<a href=#'||p_ql_markers(i)||'>' || p_ql_titles(i)||'</a>';
       END LOOP;
       Show_table_row( l_row_values, null );
    END IF;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "Show_Quicklink_Row"' );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END Show_Quicklink_Row;

/* ===================================================================================================
 * Definition of AR Data Collection Procedures for Base AR tables  
 * =================================================================================================*/

/*------------------------------- Define procedure getTransaction -----------------------------*/ 

  PROCEDURE getTransaction( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt 	varchar2(10000) := null;
  BEGIN 
    tag('getTransaction');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   customer_trx_id		"Trx Id", '   
   	        || '	   trx_number			"Trx Num", '         
	        || '	   status_trx                 "Status", '        
	        || '	   previous_customer_trx_id   "Previous|Trx Id", '    
	        || '	   initial_customer_trx_id	"Initial|Trx Id", '         
	        || '	   trx_date				"Trx Date", '          
	        || '	   term_due_date             	"Due Date", '   
              || '	   complete_flag              "Complete", '           
	        || '	   invoice_currency_code  	"Curr", '                               
              || '         exchange_rate_type        	"Exchg|Type", '                
              || '         exchange_rate             	"Rate", '       
              || '         exchange_date             	"Exchg|Date", '    
              || '         mrc_exchange_rate_type   	"Mrc|Exchg Type ", '  
              || '         mrc_exchange_rate        	"Mrc|Rate", '  
              || '         mrc_exchange_date        	"Mrc|Exchg Date", ' 
              || '         request_id               	"Req Id", '  
              || '         set_of_books_id          	"Sob", '      
              || '         org_id                   	"Org", '
              || '         to_char( last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created"  '     
 	        || 'FROM	   RA_CUSTOMER_TRX_ALL '   
	        || 'WHERE    customer_trx_id = ' || p_customerTrxId ; 
    ELSE 
	 sqltxt := 'SELECT   * FROM	RA_CUSTOMER_TRX_ALL '   
	        || 'WHERE    customer_trx_id = ' || p_customerTrxId ; 
    END IF;

    SectionPrint( 'RA_CUSTOMER_TRX_ALL' );   
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getTransaction". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getTransaction;

/*---------------------------- Define procedure getTransactionLines -------------------------------*/ 

  PROCEDURE getTransactionLines( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(10000) := null;
  BEGIN
    tag('getTransactionLines');

    IF p_columnOutput = 'Limited' THEN 
       sqltxt := 'SELECT   customer_trx_id		"Trx Id", ' 
  	        || '	   customer_trx_line_id		"Line Id", ' 
	        || '	   line_number			"Line Num", ' 
	        || '	   line_type			"Type", ' 
	        || '	   link_to_cust_trx_line_id	"Link To|Line Id", ' 
	        || '	   quantity_invoiced 		"Qty INV", '
	        || '	   quantity_credited		"Qty CM", '
	        || '	   unit_selling_price		"Unit|Price", ' 
	        || '	   extended_amount            "Ext|Amt", ' 
	        || '	   revenue_amount 		"Rev|Amt", '
	        || '	   tax_rate				"Tax|Rate", ' 
	        || '	   item_exception_rate_id	"Exception|Rate Id", ' 
	        || '	   tax_exemption_id		"Tax|Exempt Id", ' 
	        || '	   tax_exempt_flag		"Tax|Exempt", '
	        || '	   vat_tax_id			"Vat|Tax Id", ' 
	        || '	   autotax				"Autotax", ' 
	        || '	   rule_start_date		"Rule|Start|Date", ' 
	        || '	   autorule_complete_flag     "Rule|Complete", ' 
	        || '	   accounting_rule_duration   "Rule|Duration", ' 
	        || '	   autorule_duration_processed "Rule|Duration|Processed", '
              || '         request_id               	"Req Id", '  
              || '         set_of_books_id          	"Sob", '      
              || '         org_id                   	"Org", '
              || '         to_char( last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created"  '     
              || 'FROM 	   RA_CUSTOMER_TRX_LINES_ALL   ' 
	        || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
	        || 'ORDER BY customer_trx_line_id'; 
    ELSE
       sqltxt := 'SELECT   * FROM 	   RA_CUSTOMER_TRX_LINES_ALL   ' 
	        || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
	        || 'ORDER BY customer_trx_line_id'; 
    END IF; 

    SectionPrint( 'RA_CUSTOMER_TRX_LINES_ALL' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getTransactionLines". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.'); 
  END getTransactionLines;

/*------------------------------- Define procedure getLinesGlDist -----------------------------*/ 

  PROCEDURE getLinesGlDist( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(10000) := null;
  BEGIN
    tag('getLinesGlDist');
  
    IF p_columnOutput = 'Limited' THEN 
       sqltxt := 'SELECT   cust_trx_line_gl_dist_id	"Gl Dist Id", '
	        || '	   customer_trx_id		"Trx Id", '
	        || '	   customer_trx_line_id		"Line Id", '
	        || '	   cust_trx_line_salesrep_id	"Sales Id", '
	        || '	   account_set_flag		"Account|Set", '
	        || '	   latest_rec_flag		"Latest|Rec", '
	        || '	   percent				"Percent", '
	        || '	   account_class			"Account|Class", '
	        || '	   amount				"Amt", '
	        || ' 	   acctd_amount			"Acctd|Amt", ' 
	        || '	   gl_date				"Gl Date", '
	        || '	   code_combination_id		"CcId", '
	        || '	   posting_control_id		"PcId", '
	        || '	   gl_posted_date			"Posted|Date", '
              || '         mrc_account_class          "Mrc Account|Class", ' 
              || '         mrc_customer_trx_id        "Mrc|Trx Id", '
              || '         mrc_amount                 "Mrc|Amt", ' 
              || '         mrc_acctd_amount           "Mrc|Acctd Amt", ' 
              || '         mrc_posting_control_id     "Mrc|PcId", '  
              || '         mrc_gl_posted_date         "Mrc|Posted Date", '
              || '         request_id               	"Req Id", '  
              || '         set_of_books_id          	"Sob", '      
              || '         org_id                   	"Org", '
              || '         to_char( last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created"  '     
 	        || 'FROM 	   RA_CUST_TRX_LINE_GL_DIST_ALL '
	        || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
	        || 'ORDER BY cust_trx_line_gl_dist_id' ;
    ELSE  
       sqltxt := 'SELECT   * FROM 	   RA_CUST_TRX_LINE_GL_DIST_ALL '
	        || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
	        || 'ORDER BY cust_trx_line_gl_dist_id' ;
    END IF;

    SectionPrint( 'RA_CUST_TRX_LINE_GL_DIST_ALL' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getLinesGlDist". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getLinesGlDist;

/*------------------------------- Define procedure getLinesGlDistTotals -----------------------------*/ 

  PROCEDURE getLinesGlDistTotals( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getLinesGlDistTotals');

    sqltxt := 'SELECT	SUM(amount)			"Sum of|Amt", ' 
	     || '		SUM(acctd_amount)		"Sum of|Acctd Amt", ' 
	     || '		SUM(percent)		"Sum of|Percent" ' 
  	     || 'FROM	RA_CUST_TRX_LINE_GL_DIST_ALL ' 
	     || 'WHERE 	account_set_flag = ''N'' '   	
    	     || 'AND 	customer_trx_id  = '  || p_customerTrxId ; 
 
    SectionPrint( 'RA_CUST_TRX_LINE_GL_DIST_ALL All Totals' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getLinesGlDistTotals". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getLinesGlDistTotals;

/*------------------------------- Define procedure getLinesGlDistTotalsClass ---------------------------*/ 

  PROCEDURE getLinesGlDistTotalsClass( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getLinesGlDistTotalsClass');

    sqltxt := 'SELECT	account_class 		"Account|Class",' 
	     || '		SUM(amount)			"Sum of|Amt", ' 
	     || '		SUM(acctd_amount)		"Sum of|Acctd Amt", ' 
	     || '		SUM(percent)		"Sum of|Percent" ' 
	     || 'FROM	RA_CUST_TRX_LINE_GL_DIST_ALL '
	     || 'WHERE 	account_set_flag = ''N'' '   	
	     || 'AND 	customer_trx_id  = '  || p_customerTrxId || ' ' 
           || 'GROUP BY account_class'; 
 
    SectionPrint( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by Class' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getLinesGlDistTotalsClass". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getLinesGlDistTotalsClass;

/*------------------------------- Define procedure getLinesGlDistTotalsGlDate ---------------------------*/ 

  PROCEDURE getLinesGlDistTotalsGlDate( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getLinesGlDistTotalsGlDate');

    sqltxt := 'SELECT	gl_date			"Gl date", ' 
	     || '		SUM(amount)			"Sum of|Amt", ' 
	     || '		SUM(acctd_amount)		"Sum of|Acctd Amt", ' 
	     || '		SUM(percent) 		"Sum of|Percent" '
   	     || 'FROM	RA_CUST_TRX_LINE_GL_DIST_ALL ' 
	     || 'WHERE 	account_set_flag = ''N'' '   	
	     || 'AND 	customer_trx_id  = '  || p_customerTrxId || ' ' 
           || 'GROUP BY gl_date'; 
 
    SectionPrint( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by Gl Date' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getLinesGlDistTotalsGlDate". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getLinesGlDistTotalsGlDate;

/*------------------------------- Define procedure getLinesGlDistTotalsCombined -------------------------*/ 

  PROCEDURE getLinesGlDistTotalsCombined( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getLinesGlDistTotalsCombined');

    sqltxt := 'SELECT	gl_date			"GL Date", ' 
	     || '		account_class		"Account|Class", ' 
	     || '		SUM(amount)			"Sum of|Amt", '	 
	     || '		SUM(acctd_amount)		"Sum of|Acctd Amt", ' 
	     || '		SUM(percent)		"Sum of|Percent" ' 
  	     || 'FROM	RA_CUST_TRX_LINE_GL_DIST_ALL ' 
	     || 'WHERE 	account_set_flag = ''N'' '   	
	     || 'AND 	customer_trx_id  = '  || p_customerTrxId || ' '  
           || 'GROUP BY gl_date, account_class'; 
 
    SectionPrint( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by Gl Date and Class' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getLinesGlDistTotalsCombined". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getLinesGlDistTotalsCombined;

/*------------------------------- Define procedure getLinesGlDistTotalsUnposted -------------------------*/ 

  PROCEDURE getLinesGlDistTotalsUnposted( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getLinesGlDistTotalsUnposted');

    sqltxt := 'SELECT	gl_date			"Gl Date", ' 
	     || '		account_class		"Account|Class", ' 
	     || '		SUM(amount)			"Sum of|Amt", ' 
	     || '		SUM(acctd_amount)		"Sum of|Acctd Amt", ' 
	     || '		SUM(percent)		"Sum of|Percent" ' 
  	     || 'FROM	RA_CUST_TRX_LINE_GL_DIST_ALL ' 
	     || 'WHERE 	account_set_flag = ''N'' ' 
	     || 'AND 	posting_control_id = -3 '   	
	     || 'AND 	customer_trx_id  = '  || p_customerTrxId || ' '  
           || 'GROUP BY gl_date, account_class'; 
 
    SectionPrint( 'RA_CUST_TRX_LINE_GL_DIST_ALL Unposted Totals by Gl Date and Class' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getLinesGlDistTotalsUnposted". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getLinesGlDistTotalsUnposted;


/*---------------------------------- Define procedure getReceivableApplications -------------------------*
 *
 * Double usage 
 * 1. p_whereColumn = 'applied_customer_trx_id'   ( used for Invoice and CreditMemo )
 * 2. p_whereColumn = 'customer_trx_id'           ( used for Creditmemo )
 *
 *-------------------------------------------------------------------------------------------------------*/

  PROCEDURE getReceivableApplications( p_whereColumn   in varchar2, 
                                       p_customerTrxId in varchar2,
                                       p_columnOutput in varchar2 ) is
    sqltxt  varchar2(10000) := null;
  BEGIN
    tag('getReceivableApplications'||p_whereColumn );

    IF p_columnOutput = 'Limited' THEN 
       sqltxt := 'SELECT   receivable_application_id      "App Id", '  
              || '         cash_receipt_id                "Cr Id", ' 
              || '         cash_receipt_history_id        "Cr|Hist Id", '  
              || '         customer_trx_id                "Trx Id", '  
              || '         applied_customer_trx_id        "Applied|Trx Id", '
              || '         payment_schedule_id            "Ps Id", ' 
              || '         applied_payment_schedule_id    "Applied|Ps Id", '  
              || '         status                         "Status", ' 
              || '         display                        "Disp", ' 
              || '         confirmed_flag                 "Confirm", ' 
              || '         application_type               "Type", '  
              || '         amount_applied                 "Amt|App", ' 
              || '         line_applied                   "Line|App", ' 
              || '         tax_applied                    "Tax|App", ' 
              || '         freight_applied                "Freight|App", ' 
              || '         receivables_charges_applied    "Charge|App", '  
              || '         acctd_amount_applied_from      "Acctd Amt|App From", ' 
              || '         acctd_amount_applied_to        "Acctd Amt|App To", ' 
              || '         posting_control_id             "PcId", ' 
              || '         gl_date                        "Gl Date", ' 
              || '         gl_posted_date                 "Posted|Date", ' 
              || '         apply_date                     "Apply|Date", '     
              || '         reversal_gl_date               "Rev|Gl Date", '
              || '         code_combination_id            "Ccid", '  
              || '         earned_discount_taken          "E Disc", '  
              || '         acctd_earned_discount_taken    "Acctd|E Disc", '  
              || '         unearned_discount_taken        "U Disc", '  
              || '         acctd_unearned_discount_taken  "Acctd|U Disc", '  
              || '         mrc_amount_applied             "Mrc|Amt App", ' 
              || '         mrc_amount_applied_from        "Mrc Amt|App From", '  
              || '         mrc_acctd_amount_applied_from  "Mrc Acctd|Amt App From", '  
              || '         mrc_acctd_amount_applied_to    "Mrc Acctd|Amt App To", '  
              || '         mrc_acctd_earned_disc_taken    "Mrc Acctd|E Disc", ' 
              || '         mrc_acctd_unearned_disc_taken  "Mrc Acctd|U Disc", ' 
              || '         mrc_status                     "Mrc|Status", '
              || '         mrc_posting_control_id         "Mrc|PcId", '       
              || '         mrc_gl_posted_date             "Mrc|Posted Date", ' 
              || '         request_id                     "Req Id", ' 
              || '         set_of_books_id                "Sob", '      
              || '         org_id                         "Org", '        
              || '         to_char( last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created" '   
              || 'FROM     AR_RECEIVABLE_APPLICATIONS_ALL '
              || 'WHERE '  || p_whereColumn || ' = ' || p_customerTrxId || ' '
              || 'ORDER BY receivable_application_id' ;
    ELSE
       sqltxt := 'SELECT    * FROM AR_RECEIVABLE_APPLICATIONS_ALL '
              || 'WHERE '  || p_whereColumn || ' = ' || p_customerTrxId || ' '
              || 'ORDER BY receivable_application_id' ;
    END IF;   

    SectionPrint( 'AR_RECEIVABLE_APPLICATIONS_ALL ( '|| p_whereColumn ||' = ' || p_customerTrxId  || ' )' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getReceivableApplications". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getReceivableApplications;

/*------------------------------- Define procedure getRecAppTotals -----------------------------------------*
 *
 * Double usage 
 * 1. p_whereColumn = 'applied_customer_trx_id'   ( used for Invoice and CreditMemo )
 * 2. p_whereColumn = 'customer_trx_id'           ( used for Creditmemo )
 *
 *----------------------------------------------------------------------------------------------------------*/
 
  PROCEDURE getRecAppTotals( p_whereColumn in varchar2, p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getRecAppTotals'||p_whereColumn);

    sqltxt := 'SELECT   application_type, '
           || '         SUM(amount_applied)                "Sum of|Applied", ' 
	     || '		SUM(amount_applied_from)           "Sum of|Applied From", '
           || '         SUM(acctd_amount_applied_from)     "Sum of|Acctd Applied From", '
           || '         SUM(acctd_amount_applied_to)       "Sum of|Acctd Applied To", '   
           || '         SUM(acctd_earned_discount_taken)   "Sum of|Acctd Earned Disc", '
           || '         SUM(acctd_unearned_discount_taken) "Sum of|Acctd Unearned Disc" '      
           || 'FROM     AR_RECEIVABLE_APPLICATIONS_ALL '
           || 'WHERE '  || p_whereColumn || ' = ' || p_customerTrxId || ' '
           || 'GROUP BY application_type';
  
    SectionPrint( 'AR_RECEIVABLE_APPLICATIONS_ALL Totals ( '|| p_whereColumn || ' = ' || p_customerTrxId  || ' )' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getRecAppTotals". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getRecAppTotals;

/*-------------------------------- Define procedure getDistributionsRA --------------------------------*/ 

  PROCEDURE getDistributionsRA( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(10000) := null;
  BEGIN
    tag('getDistributionsRA');

    IF p_columnOutput = 'Limited' THEN 
       sqltxt := 'SELECT   dis.line_id               "Line Id", ' 
              || '         dis.source_id             "Source|Id", '   
              || '         dis.source_table          "Source|Table", '  
              || '         dis.source_type           "Source|Type", '  
              || '         dis.code_combination_id   "CcId", '   
              || '         dis.amount_dr             "Amt DR", '   
              || '         dis.amount_cr             "Amt CR", '  
              || '         dis.acctd_amount_dr       "Acctd|Amt DR", '  
              || '         dis.acctd_amount_cr       "Acctd|Amt CR", '  
              || '         dis.org_id                "Org", '  
              || '         to_char( dis.last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '
              || '         to_char( dis.creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created"  '   
              || 'FROM     AR_DISTRIBUTIONS_ALL dis, '
              || '         AR_RECEIVABLE_APPLICATIONS_ALL app '
              || 'WHERE    app.customer_trx_id = ' || p_customerTrxId || ' '
              || 'AND      dis.source_table    = ''RA'' '
              || 'AND      dis.source_id       = app.receivable_application_id';
    ELSE 
       sqltxt := 'SELECT   dis.*  ' 
              || 'FROM     AR_DISTRIBUTIONS_ALL dis, '
              || '         AR_RECEIVABLE_APPLICATIONS_ALL app '
              || 'WHERE    app.customer_trx_id = ' || p_customerTrxId || ' '
              || 'AND      dis.source_table    = ''RA'' '
              || 'AND      dis.source_id       = app.receivable_application_id';
    END IF;

    SectionPrint( 'AR_DISTRIBUTIONS_ALL ( Source = Receivable Applications )' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getDistributionsRA". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getDistributionsRA ;


/*-------------------------------- Define procedure getDistTotalsRA ---------------------------------*/ 

  PROCEDURE getDistTotalsRA( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getDistTotalsRA');

    sqltxt := 'SELECT SUM(dis.amount_dr)        "Sum of|Amount DR",'
           || '       SUM(dis.amount_cr)        "Sum of|Amount CR",'
           || '       SUM(dis.acctd_amount_dr)  "Sum of|Acctd Amt DR", '
           || '       SUM(dis.acctd_amount_cr)  "Sum of|Acctd Amt CR"  '
           || 'FROM   AR_DISTRIBUTIONS_ALL dis, '
           || '       AR_RECEIVABLE_APPLICATIONS_ALL app '
           || 'WHERE  app.customer_trx_id = ' || p_customerTrxId || ' '
           || 'AND    dis.source_table    = ''RA'' ' 
           || 'AND    dis.source_id       = app.receivable_application_id';

    SectionPrint( 'AR_DISTRIBUTIONS_ALL Totals ( Source = Receivable Applications ) '); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getDistTotalsRA". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getDistTotalsRA;

/*-------------------------------- Define procedure getDistTotalsUnpostedRA --------------------------------*/ 

  PROCEDURE getDistTotalsUnpostedRA( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getDistTotalsUnpostedRA');

    sqltxt := 'SELECT SUM(dis.amount_dr)        "Sum of|Amount DR",'
           || '       SUM(dis.amount_cr)        "Sum of|Amount CR",'
           || '       SUM(dis.acctd_amount_dr)  "Sum of|Acctd Amt DR", '
           || '       SUM(dis.acctd_amount_cr)  "Sum of|Acctd Amt CR"  '
           || 'FROM   AR_DISTRIBUTIONS_ALL dis, '
           || '       AR_RECEIVABLE_APPLICATIONS_ALL app '
           || 'WHERE  app.customer_trx_id = ' || p_customerTrxId || ' '
           || 'AND    app.posting_control_id = -3 ' 
           || 'AND    dis.source_table       = ''RA'' ' 
           || 'AND    dis.source_id          = app.receivable_application_id';

    SectionPrint( 'AR_DISTRIBUTIONS_ALL Unposted Totals ( Source = Receivable Applications )'); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getDistTotalsUnpostedRA". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getDistTotalsUnpostedRA;


/*------------------------------ Define procedure getPaymentSchedules -------------------------------*/ 

  PROCEDURE getPaymentSchedules( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(10000) := null;
  BEGIN
    tag('getPaymentSchedules');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   payment_schedule_id             "Ps Id", ' 
              || '         customer_trx_id                 "Trx id", ' 
              || '         trx_number                      "Trx Number", '      
              || '         associated_cash_receipt_id      "Ass Cr Id", '   
              || '         class                           "Class", ' 
              || '         status                          "Status", '       
              || '         number_of_due_dates             "Num|Due|Dates", '  
              || '         due_date                        "Due Date", '  
              || '         gl_date                         "Gl Date", '  
              || '         actual_date_closed              "Date Closed", '  
              || '         gl_date_closed                  "Gl Date|Closed", '  
              || '         amount_due_original             "Amt Org", ' 
              || '         amount_due_remaining            "Amt Rem", ' 
              || '         acctd_amount_due_remaining      "Acctd|Amt Rem", ' 
              || '         amount_line_items_original      "Amt|Line Org", ' 
              || '         amount_line_items_remaining     "Amt|Line Rem", ' 
              || '         tax_original			     "Tax|Org", '
              || '         tax_remaining			     "Tax|Rem", '
              || '         freight_original		     "Freight|Org", '                  
              || '         freight_remaining		     "Freight|Rem", '    
              || '         receivables_charges_charged     "Charges", '
              || '         receivables_charges_remaining   "Charges|Rem", '                         
              || '         discount_original		     "Disc|Org", '             
              || '         discount_remaining		     "Disc|Rem", '         
              || '         discount_taken_earned           "Disc|Earned", '
              || '         discount_taken_unearned         "Disc|Unearned", '               
              || '         amount_adjusted                 "Amt Adj", '              
              || '         amount_adjusted_pending         "Amt Adj|Pending", '  
              || '         amount_applied                  "Amt App", '  
              || '         amount_credited                 "Amt Cred", '  			
              || '         mrc_customer_trx_id             "Mrc|Trx Id", '  
              || '         mrc_acctd_amount_due_remaining  "Mrc Acctd|Amt Rem", '        
              || '         mrc_exchange_rate_type          "Mrc|Exchg Type", '  
              || '         mrc_exchange_rate               "Mrc Rate", ' 
              || '         mrc_exchange_date               "Mrc|Exchg Date", '  
              || '         request_id                      "Req Id", '     
              || '         org_id                          "Org", '         
              || '         to_char( last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created"  '        
              || 'FROM     AR_PAYMENT_SCHEDULES_ALL '
              || 'WHERE    customer_trx_id = ' || p_customerTrxId ;
    ELSE 
       sqltxt := 'SELECT * FROM  AR_PAYMENT_SCHEDULES_ALL '
              || 'WHERE   customer_trx_id = ' || p_customerTrxId ;
    END IF;  
 
    SectionPrint( 'AR_PAYMENT_SCHEDULES_ALL' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getPaymentSchedules". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getPaymentSchedules;


/*-------------------------------- Define procedure getAdjustment ---------------------------------------*/ 

  PROCEDURE getAdjustment( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(10000) := null;
  BEGIN
    tag('getAdjustment');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   adjustment_id			   "Adj Id", '
 	        || '	   adjustment_number		   "Adj Num", '
	        || '	   amount				   "Amt", '
	        || '	   acctd_amount			   "Acctd|Amt", '
	        || '	   line_adjusted			   "Line|Adj", '
	        || '	   tax_adjusted			   "Tax|Adj", '
	        || '	   freight_adjusted		   "Freight|Adj", '
	        || '	   receivables_charges_adjusted  "Charges|Adj", '
	        || '	   gl_date				   "Gl Date", '
	        || '	   apply_date			   "Apply|Date", '
	        || '	   gl_posted_date			   "Posted|Date", '
 	        || '	   code_combination_id		   "CcId", '
	        || '	   payment_schedule_id		   "Ps Id", '
	        || '	   chargeback_customer_trx_id	   "Cb|Trx Id", '
 	        || '	   customer_trx_id		   "Trx Id", '
	        || '	   customer_trx_line_id		   "Trx|Line Id", '
	        || '	   associated_cash_receipt_id	   "Ass|Cr Id", '
	        || '	   subsequent_trx_id		   "Sub|Trx Id", '
	        || '	   status				   "Status", '
	        || '	   postable				   "Postable", ' 
	        || '	   type				   "Type", '
	        || '	   adjustment_type		   "Adj|Type", ' 
	        || '	   posting_control_id		   "PcId", '
	        || '	   mrc_gl_posted_date		   "Mrc|Posted Date", '
	        || '	   mrc_posting_control_id	   "Mrc|PcId", '
	        || '	   mrc_acctd_amount		   "Mrc|Acctd Amt", '
	        || '         request_id                    "Req Id", ' 
              || '         set_of_books_id               "Sob", '      
              || '         org_id                        "Org", '        
              || '         to_char( last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created" '   
	        || 'FROM	   AR_ADJUSTMENTS_ALL '
	        || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
	        || 'ORDER BY adjustment_id ';
    ELSE 
       sqltxt := 'SELECT   * FROM AR_ADJUSTMENTS_ALL '
	        || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
	        || 'ORDER BY adjustment_id ';
    END IF;

    SectionPrint( 'AR_ADJUSTMENTS_ALL'); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getAdjustment". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getAdjustment;

/*-------------------------------- Define procedure getDistributionsADJ -----------------------*/ 

  PROCEDURE getDistributionsADJ( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(10000) := null;
  BEGIN 
    tag('getDistributionsADJ');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   dis.line_id               "Line Id", ' 
              || '         dis.source_id             "Source|Id", '   
              || '         dis.source_table          "Source|Table", '  
              || '         dis.source_type           "Source|Type", '  
              || '         dis.code_combination_id   "CcId", '   
              || '         dis.amount_dr             "Amt DR", '   
              || '         dis.amount_cr             "Amt CR", '  
              || '         dis.acctd_amount_dr       "Acctd|Amt DR", '  
              || '         dis.acctd_amount_cr       "Acctd|Amt CR", '  
              || '         dis.org_id                "Org", '  
              || '         to_char( dis.last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '
              || '         to_char( dis.creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created"  '   
              || 'FROM     AR_DISTRIBUTIONS_ALL dis, '
              || '         AR_ADJUSTMENTS_ALL   adj '
              || 'WHERE    adj.customer_trx_id = ' || p_customerTrxId || ' '
              || 'AND      dis.source_table = ''ADJ'' '
              || 'AND      dis.source_id    = adj.adjustment_id';
    ELSE
       sqltxt := 'SELECT   dis.* ' 
              || 'FROM     AR_DISTRIBUTIONS_ALL dis, '
              || '         AR_ADJUSTMENTS_ALL   adj '
              || 'WHERE    adj.customer_trx_id = ' || p_customerTrxId || ' '
              || 'AND      dis.source_table = ''ADJ'' '
              || 'AND      dis.source_id    = adj.adjustment_id';
    END IF;
   
    SectionPrint( 'AR_DISTRIBUTIONS_ALL ( Source = Adjustment )' );  
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getDistributionsADJ". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getDistributionsADJ;


/* ===================================================================================================
 * Definition of AR Data Collection Procedures for MRC AR tables  
 * =================================================================================================*/

/*-------------------------------- Define procedure getMcTransaction -------------------------------*/ 

  PROCEDURE getMcTransaction( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getMcTransaction');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   customer_trx_id	"Trx Id", '
	        || '	   set_of_books_id 	"Sob", '
	        || '	   exchange_rate_type 	"Exchg|Type", '
	        || '	   exchange_rate 		"Rate", '
	        || '	   exchange_date 		"Exchg|Date" '
              || 'FROM     RA_MC_CUSTOMER_TRX '
              || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
              || 'ORDER BY set_of_books_id' ;
    ELSE 
       sqltxt := 'SELECT   * FROM RA_MC_CUSTOMER_TRX '
              || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
              || 'ORDER BY set_of_books_id' ;
    END IF;

    SectionPrint( 'RA_MC_CUSTOMER_TRX' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcTransaction". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcTransaction;

/*------------------------------- Define procedure getMcLinesGlDist ----------------------------------*/ 

  PROCEDURE getMcLinesGlDist( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getMcLinesGlDist');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   cust_trx_line_gl_dist_id	"Gl Dist Id", ' 
	        || '	   set_of_books_id		"Sob", '  
 	        || '	   customer_trx_id		"Trx Id", '     
	        || '	   account_class 			"Account|Class", '  
	        || '	   amount				"Amt", '
	        || '	   acctd_amount			"Acctd|Amt", '
	        || '	   gl_posted_date			"Posted Date", '
	        || '	   posting_control_id		"PcId" '
              || 'FROM     RA_MC_TRX_LINE_GL_DIST '
              || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' ' 
              || 'ORDER BY set_of_books_id, cust_trx_line_gl_dist_id' ;
    ELSE 
       sqltxt := 'SELECT   * FROM RA_MC_TRX_LINE_GL_DIST '
              || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' ' 
              || 'ORDER BY set_of_books_id, cust_trx_line_gl_dist_id' ;
    END IF;

    SectionPrint( 'RA_MC_TRX_LINE_GL_DIST' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcLinesGlDist". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcLinesGlDist;

/*------------------------------- Define procedure getMcLinesGlDistTotals ----------------------------------*/ 

  PROCEDURE getMcLinesGlDistTotals( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getMcLinesGlDistTotals');

    sqltxt := 'SELECT   account_class		"Account|Class", '
	     || '	      set_of_books_id		"Sob", '
	     || '	      SUM(amount)			"Sum of|Amt", '
	     || '	      SUM(acctd_amount)		"Sum of|Acctd Amt" '
           || 'FROM     RA_MC_TRX_LINE_GL_DIST '
           || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' '
	     || 'GROUP BY set_of_books_id, account_class ' 
           || 'ORDER BY set_of_books_id' ;

    SectionPrint( 'RA_MC_TRX_LINE_GL_DIST Totals' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcLinesGlDistTotals". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcLinesGlDistTotals;


/*----------------------------------- Define procedure getMcReceivableApps ------------------------------ 
 *
 * Double usage 
 * 1. p_whereColumn = 'applied_customer_trx_id'   ( used for Invoice and CreditMemo )
 * 2. p_whereColumn = 'customer_trx_id'           ( used for Creditmemo )
 *
 *-------------------------------------------------------------------------------------------------------*/

  PROCEDURE getMcReceivableApps( p_whereColumn in varchar2, 
                                 p_customerTrxId in varchar2,
                                 p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getMcReceivableApps'||p_whereColumn );

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   a.receivable_application_id	"App Id", '           
              || '         a.set_of_books_id    		"Sob", ' 
   		  || '         a.display				"Disp", '  
              || '         a.status					"Status", '
              || '         a.payment_schedule_id		"Ps Id", ' 
              || '         a.cash_receipt_id			"Cr Id", ' 
              || '         a.cash_receipt_history_id		"Cr Hist Id",' 
              || '         a.posting_control_id			"PcId", ' 
              || '         a.gl_posted_date			"Posted Date", '
              || '         a.amount_applied			"Amt App", '
              || '         a.amount_applied_from		"Amt App From", ' 
              || '         a.acctd_amount_applied_from	"Acctd Amt|App From", ' 
              || '         a.acctd_amount_applied_to		"Acctd Amt|App To", ' 
              || '         a.acctd_earned_discount_taken	"Acctd|E Disc", ' 
              || '         a.acctd_unearned_discount_taken	"Acctd|U Disc" ' 
              || 'FROM     AR_MC_RECEIVABLE_APPS a, '
	        || '         AR_RECEIVABLE_APPLICATIONS_ALL b ' 
              || 'WHERE '  || p_whereColumn || ' = ' || p_customerTrxId || ' '
	        || 'AND      a.receivable_application_id = b.receivable_application_id ' 
              || 'ORDER BY a.set_of_books_id, a.receivable_application_id' ;
    ELSE 
       sqltxt := 'SELECT   a.* ' 
              || 'FROM     AR_MC_RECEIVABLE_APPS a, '
	        || '         AR_RECEIVABLE_APPLICATIONS_ALL b ' 
              || 'WHERE '  || p_whereColumn || ' = ' || p_customerTrxId || ' '
	        || 'AND      a.receivable_application_id = b.receivable_application_id ' 
              || 'ORDER BY a.set_of_books_id, a.receivable_application_id' ;
    END IF;

    SectionPrint( 'AR_MC_RECEIVABLE_APPS ( '|| p_whereColumn || ' = ' || p_customerTrxId  || ' )' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcReceivableApps". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcReceivableApps;

/*------------------------------- Define procedure getMcPaymentSchedules -------------------------------*/ 

  PROCEDURE getMcPaymentSchedules( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getMcPaymentSchedules');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   payment_schedule_id			"Ps Id", ' 
	        || '	   set_of_books_id			"Sob", '
	        || '	   customer_trx_id			"Trx Id", '
	        || '	   acctd_amount_due_remaining		"Acctd|Amt Rem", '
	        || ' 	   exchange_rate_type			"Exchg|Type", '
	        || '	   exchange_rate				"Rate",  ' 	
        	  || '	   exchange_date				"Exchg|Date" '
              || 'FROM     AR_MC_PAYMENT_SCHEDULES '
              || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' ' 
              || 'ORDER BY set_of_books_id, payment_schedule_id' ;
    ELSE 
       sqltxt := 'SELECT   * FROM AR_MC_PAYMENT_SCHEDULES '
              || 'WHERE    customer_trx_id = ' || p_customerTrxId || ' ' 
              || 'ORDER BY set_of_books_id, payment_schedule_id' ;
    END IF;

    SectionPrint( 'AR_MC_PAYMENT_SCHEDULES' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcPaymentSchedules". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcPaymentSchedules;

/*---------------------- Define procedure getMcDistributionsRA -----------------------------------*/ 

  PROCEDURE getMcDistributionsRA( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getMcDistributionsRA');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   dis.line_id               "Line Id", '  
              || '         dis.set_of_books_id       "Sob", '   
              || '         dis.source_id             "Source|Id", '  
              || '         dis.source_table          "Source|Table", '   
              || '         dis.source_type           "Source|Type", '  
              || '         dis.code_combination_id   "CcId", '  
              || '         dis.amount_dr             "Amt DR", '  
              || '         dis.amount_cr             "Amt CR", '  
              || '         dis.acctd_amount_dr       "Acctd|Amt DR", '   
              || '         dis.acctd_amount_cr       "Acctd|Amt CR", '  
              || '         dis.org_id                "Org" '   
              || 'FROM     AR_MC_DISTRIBUTIONS_ALL        dis, '
              || '         AR_RECEIVABLE_APPLICATIONS_ALL app '
              || 'WHERE    app.customer_trx_id = ' || p_customerTrxId || ' '
              || 'AND      dis.source_table = ''RA'' '
              || 'AND      dis.source_id = app.receivable_application_id '
              || 'ORDER BY dis.set_of_books_id, dis.line_id ';
    ELSE
       sqltxt := 'SELECT   dis.*  '
              || 'FROM     AR_MC_DISTRIBUTIONS_ALL dis, '
              || '         AR_RECEIVABLE_APPLICATIONS_ALL app '
              || 'WHERE    app.customer_trx_id = ' || p_customerTrxId || ' '
              || 'AND      dis.source_table = ''RA'' '
              || 'AND      dis.source_id = app.receivable_application_id '
              || 'ORDER BY dis.set_of_books_id, dis.line_id ';
    END IF;
  
    SectionPrint( 'AR_MC_DISTRIBUTIONS_ALL ( Source = Receivable Applications )' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcDistributionsRA". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcDistributionsRA;

/*------------------------------ Define procedure getMcDistTotalsRA ----------------------------------------*/ 

  PROCEDURE getMcDistTotalsRA( p_customerTrxId in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getMcDistTotalsRA');

    sqltxt := 'SELECT   dis.set_of_books_id       "Sob", ' 
           || '         SUM(dis.amount_dr)        "Sum of|Amount DR", '
           || '         SUM(dis.amount_cr)        "Sum of|Amount CR", '
           || '         SUM(dis.acctd_amount_dr)  "Sum of|Acctd Amt DR", '
           || '         SUM(dis.acctd_amount_cr)  "Sum of|Acctd Amt CR"  '
           || 'FROM     AR_MC_DISTRIBUTIONS_ALL dis, '
           || '         AR_RECEIVABLE_APPLICATIONS_ALL  app '
           || 'WHERE    app.customer_trx_id = ' || p_customerTrxId || ' ' 
           || 'AND      dis.source_table = ''RA'' '
           || 'AND      dis.source_id    = app.receivable_application_id '
           || 'GROUP BY dis.set_of_books_id ' 
           || 'ORDER BY dis.set_of_books_id ' ;

    SectionPrint( 'AR_MC_DISTRIBUTIONS_ALL Totals ( Source = Receivable Applications )' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcDistTotalsRA". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcDistTotalsRA;

/*------------------------------- Define procedure getMcAdjustment -------------------------------*/ 

  PROCEDURE getMcAdjustment ( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getMcAdjustment');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   a.adjustment_id  	   "Adj Id", ' 
	        || '	   a.set_of_books_id	   "Sob", '
	        || '	   a.gl_posted_date 	   "Posted Date", '
	        || '	   a.posting_control_id    "PcId", '
	        || '	   a.acctd_amount		   "Acctd Amt" '
              || 'FROM     AR_MC_ADJUSTMENTS  a, ' 
              || '         AR_ADJUSTMENTS_ALL b  '  
              || 'WHERE    b.customer_trx_id = ' || p_customerTrxId || ' ' 
              || 'AND      a.adjustment_id   = b.adjustment_id '  
              || 'ORDER BY a.set_of_books_id, a.adjustment_id' ;
    ELSE
       sqltxt := 'SELECT   a.* '
              || 'FROM     AR_MC_ADJUSTMENTS  a, ' 
              || '         AR_ADJUSTMENTS_ALL b  '  
              || 'WHERE    b.customer_trx_id = ' || p_customerTrxId || ' ' 
              || 'AND      a.adjustment_id   = b.adjustment_id '  
              || 'ORDER BY a.set_of_books_id, a.adjustment_id' ;
    END IF;

    SectionPrint( 'AR_MC_ADJUSTMENTS' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcAdjustment". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcAdjustment;

/*---------------------- Define procedure getMcDistributionsADJ -----------------------------------*/ 

  PROCEDURE getMcDistributionsADJ( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt 	varchar2(5000) := null;

  BEGIN
    tag('getMcDistributionsADJ');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   dis.line_id               "Line Id", '  
              || '         dis.set_of_books_id       "Sob", '   
              || '         dis.source_id             "Source|Id", '  
              || '         dis.source_table          "Source|Table", '   
              || '         dis.source_type           "Source|Type", '  
              || '         dis.code_combination_id   "CcId", '  
              || '         dis.amount_dr             "Amt DR", '  
              || '         dis.amount_cr             "Amt CR", '  
              || '         dis.acctd_amount_dr       "Acctd|Amt DR", '   
              || '         dis.acctd_amount_cr       "Acctd|Amt CR", '  
              || '         dis.org_id                "Org" '  
              || 'FROM     AR_MC_DISTRIBUTIONS_ALL dis, '
              || '         AR_ADJUSTMENTS_ALL      adj  '
              || 'WHERE    adj.customer_trx_id = ' || p_customerTrxId || ' '
              || 'AND      dis.source_table = ''ADJ'' '
              || 'AND      dis.source_id = adj.adjustment_id '
              || 'ORDER BY dis.set_of_books_id, dis.line_id ';
    ELSE 
       sqltxt := 'SELECT   dis.* '
              || 'FROM     AR_MC_DISTRIBUTIONS_ALL dis, '
              || '         AR_ADJUSTMENTS_ALL      adj  '
              || 'WHERE    adj.customer_trx_id = ' || p_customerTrxId || ' '
              || 'AND      dis.source_table = ''ADJ'' '
              || 'AND      dis.source_id = adj.adjustment_id '
              || 'ORDER BY dis.set_of_books_id, dis.line_id ';
    END IF;

    SectionPrint( 'AR_MC_DISTRIBUTIONS_ALL ( Source = Adjustment )' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getMcDistributionsADJ". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getMcDistributionsADJ;

/* ===================================================================================================
 * Definition of single-row table output procedures  
 * =================================================================================================*/

/*--------------------------------- Define procedure ar_start_table ---------------------------------*/ 

  PROCEDURE ar_start_table(p_header varchar2) is
  BEGIN
    Insert_HTML('<table cellspacing=0  summary="'||p_header||'">');
  EXCEPTION
    WHEN OTHERS THEN
      Errorprint(sqlerrm||' occurred in test in section "ar_start_table" ');
      ActionErrorPrint('Please report the above error to Oracle Support Services');
  END;

/*--------------------------------- Define procedure ar_end_table -----------------------------------*/ 

  PROCEDURE ar_end_table is
  BEGIN
    Insert_HTML('</table>');
  EXCEPTION
  WHEN OTHERS THEN
    Errorprint(sqlerrm||' occurred in test in section "ar_end_table" ');
    ActionErrorPrint('Please report the above error to Oracle Support Services');
  END;

/*--------------------------------- Define procedure ar_table_row -----------------------------------*/ 

  PROCEDURE ar_table_row (p_id varchar2, p_title varchar2, p_value varchar2)is
  BEGIN 
    Insert_html('<tr>');
    Insert_HTML('<th class=rowh align=LEFT id="'||p_id||'" nowrap>'||p_title ||'</th>'); 
    Insert_HTML('<td align=left headers="'||p_id||'" nowrap>'|| p_value||' </td>');
    Insert_HTML('</tr>');
  EXCEPTION
  WHEN OTHERS THEN
    Errorprint(sqlerrm||' occurred in test in section "ar_table_row" ');
    ActionErrorPrint('Please report the above error to Oracle Support Services');
  END;

/* ===================================================================================================
 *
 * END DECLARATIONS 
 * 
 * =================================================================================================*/

/* ----------------------------- Start Main Program ------------------------------------------------*/

  BEGIN --begin2

/* ----------------------------- Set Client ( validate user and responsibility ) -------------------*/

    p_username := :v_username;

    IF &v_respid IS NULL THEN
       p_respid := -10;
    ELSE
       p_respid := &v_respid;
    END IF;

    Show_Header('223834.1', ' : Transaction Data Collection');
    Set_Client( p_username, p_respid );

/* ----------------------------- Show Parameters ---------------------------------------------------*/

    -- pick up responsibility name and application id assigned to this responsibility
    BEGIN 
      SELECT responsibility_name,
             application_id 
      INTO   v_respname,
             v_appid 
      FROM   fnd_responsibility_vl b
      WHERE  b.responsibility_id = p_respid;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN Null;
    END; 

    p_trxId := &trxid;

    IF substr( UPPER('&columnOutput'), 1, 1 ) = 'A' THEN 
       p_columnOutput := 'All';
       g_sql_date_format := 'DD-MON-YYYY HH24:MI:SS';
    ELSE 
       p_columnOutput := 'Limited';
       g_sql_date_format := 'DD-MON-YYYY';
    END IF;

    SectionPrint('Parameters');
    Tab1Print('Username         = '|| upper(:v_username) ); 
    Tab1Print('Responsibility   = '|| v_respname || ' ( ID = ' || p_respid || ' )');
    Tab1Print('Column Output    = '|| p_columnOutput);
    Tab1Print('Customer Trx Id  = '|| p_trxId);  

    IF v_appid <> 222 THEN 
       ErrorPrint('This diagnostic test collects data for an Accounts Receivable Transaction. The entered responsibility is not '||
                  'for the application being tested');
       ActionErrorPrint('Please run the test for an Oracle Receivables responsibility');
       RAISE StopExecution;
    END IF;   

/* ---------------------------------- Application information  -------------------------------------*/ 
 
    SectionPrint('Application Information');
    
    v_orgid   := Get_profile_option('ORG_ID');

    -- pick up orgname 
    IF v_orgid is NOT Null THEN 
       BEGIN -- Level 4
         SELECT  name 
         INTO    v_orgname 
         FROM    HR_ALL_ORGANIZATION_UNITS
         WHERE   organization_id = v_orgid; 
       EXCEPTION
         WHEN NO_DATA_FOUND THEN 
              Null;
        END; -- level 4
    END IF; 

    -- pick up multi currency and multi org flag 
    BEGIN 
      SELECT multi_currency_flag,
             multi_org_flag  
      INTO   v_mrc_flag,
             v_multi_org  
      FROM   fnd_product_groups;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Null;
      WHEN TOO_MANY_ROWS THEN
           Errorprint( 'More than one row ( more than one installation ) found in FND_PRODUCT_GROUPS');
           ActionErrorPrint('Execution of the diagnostic test will stop');
           RAISE StopExecution;
    END; 
   
    -- pick up installation status of AR 
    BEGIN 
      SELECT   patch_level     
      INTO     v_patch_level  
      FROM     FND_PRODUCT_INSTALLATIONS  
      WHERE    application_id = 222;
    EXCEPTION 
      WHEN OTHERS THEN 
           null;
    END;  

    Tab1Print('MultiOrg Flag = '|| v_multi_org );
    Tab1Print('MultiCurrency Flag = '|| v_mrc_flag );
    Tab1Print('MO: Operating Unit profile option = ' || v_orgid );
    Tab1Print('Operating Unit = '|| v_orgname );
    Tab1Print('Accounts Receivable Patch Level = '|| v_patch_level ); 

/*--------------------------------- Get primary set of books --------------------------------------------- */
      
    BEGIN
      SELECT a.set_of_books_id,
             a.short_name,  
             a.currency_code 
      INTO   v_prim_sobid,
             v_sobname,
             v_currency
      FROM   GL_SETS_OF_BOOKS a,
             AR_SYSTEM_PARAMETERS b
      WHERE  b.set_of_books_id = a.set_of_books_id; 

      SectionPrint( 'Primary Set of Books' );
      Tab1Print('Name = ' || v_sobname || ', ID = '|| to_char(v_prim_sobid) || ', Currency = '|| v_currency );
            
    EXCEPTION   
       WHEN NO_DATA_FOUND THEN   
           ErrorPrint ('AR System Options have not been defined for this Operating Unit');
           ACtionErrorPrint ('Please refer to Users Guide and define AR System Options');
    END; 

/* -------------------------------- Reporting set of books ----------------------------------------------- */ 

    DECLARE  
      l_count        Number := 0;  
      CURSOR C1 IS 
      SELECT rep.name              sobname,
             rep.currency_code    currency,
             rep.set_of_books_id     sobid 
      FROM   GL_SETS_OF_BOOKS rep, 
             GL_SETS_OF_BOOKS prim,
             GL_MC_BOOK_ASSIGNMENTS_V d 
      WHERE  prim.set_of_books_id = v_prim_sobid 
      AND    prim.mrc_sob_type_code = 'P' 
      AND    d.primary_set_of_books_id = prim.set_of_books_id  
      AND    rep.set_of_books_id = d.reporting_set_of_books_id     
      AND    rep.mrc_sob_type_code = 'R';  
        
    BEGIN    
      IF v_prim_sobid is NOT NULL and v_mrc_flag = 'Y' THEN 
         SectionPrint('Reporting Sets of Books');
         l_count := 0;
         FOR c1_rec in C1 LOOP 
             IF l_count = 0 THEN 
                TAB1Print('Following Reporting Sets Of Books are tied to Primary Set of Books "'|| v_sobname || '"' );
             END IF;
             Tab2Print('Name = ' || c1_rec.sobname || ', ID = '|| to_char(c1_rec.sobid) || ', Currency = '|| 
                       c1_rec.currency  );
             l_count := l_count + 1 ;
         END LOOP;
         IF  l_count = 0 THEN   
             Tab1PRint('MRC is enabled, but there are no Reporting Sets of Books tied to Primary Set of Books "'|| 
                        v_sobname || '"' );
         ELSE 
             -- enable Mrc reporting 
             v_report_mrc := 'Y';
         END IF;
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN
           Errorprint(sqlerrm||' occurred in test in section "Reporting Sets of Books" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;      
 
/* ------------------------------------------- AX Info -------------------------------------------------*/

    DECLARE 
      l_count 	number 	   := 0;
      Cursor C1 IS 
      SELECT 	main_set_of_books_id		main_sob,
                  source_org_id			org_id,
                  posting_set_of_books_id 	post_sob 
      FROM		AX_SETUP_POSTING_BOOKS 
      WHERE       application_id = 222
      AND         main_set_of_books_id = v_prim_sobid;    

    BEGIN
      IF v_prim_sobid is NOT NULL THEN 
         SectionPrint( 'AX Set Up' );
         FOR C1_rec In C1 LOOP 
             IF l_count = 0 THEN 
                TAB1Print('AX_SETUP_POSTING_BOOKS contains the following set up for Application Accounts Receivables' );
             END IF;
             Tab2Print('Main SOB = ' || to_char(c1_rec.main_sob) || ', Source Org_Id = '|| to_char(c1_rec.org_id) ||
                       ', Posting SOB = '|| c1_rec.post_sob );
             l_count := l_count + 1 ;
         END LOOP;
         IF l_count = 0 THEN 
            Tab1Print( 'Global Accounting Engine is not used. AX_SETUP_POSTING_BOOKS contains no set up ' ||
                       'for main SOB = ' || to_char(v_prim_sobid) || ' and application Accounts Receivables' ); 
         END IF;  
      END IF; 

    EXCEPTION 
      WHEN OTHERS THEN
           Errorprint(sqlerrm||' occurred in test in section "AX Set Up" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;

/* ------------------------------- Get Transaction Info -------------------------------------------------*/

    BEGIN    
      SectionPrint( 'Details of Customer Trx Id : ' || &trxid );

	SELECT	trx.customer_trx_id, 
			trx.trx_number,
                  trx.customer_reference,
      		bat.name,    
                  trx.cust_trx_type_id,
       		typ.name,
    			trx.trx_date,
      		trx.complete_flag,
			trx.invoice_currency_code,
       		trx.exchange_rate,
                  typ.type, 
                  pay.name, 
                  trx.term_due_date,       
                  rul.name, 
 		      trx.status_trx,
			trx.initial_customer_trx_id,
       		trx.set_of_books_id,
      		trx.previous_customer_trx_id,
			trx.request_id
      INTO  	h_trxId,
       		h_trxNum,
                  h_reference,
      		h_batchDsp,  
                  h_typeId,  
       		h_typeDsp,
    			h_trxDate,
      		h_complete,
			h_currency,
       		h_exchangeRate,
                  h_class, 
                  h_termDsp, 
                  h_dueDate,       
                  h_ruleDsp, 
 		      h_statusTrx,
			h_initialCustomerTrxId,
       		h_sobId,
      		h_creditedCustomerTrxId,
			h_requestId
 	FROM 		RA_CUSTOMER_TRX    trx,
       		RA_CUST_TRX_TYPES  typ,
       		RA_BATCH_SOURCES   bat,
 			RA_TERMS           pay,
			RA_RULES           rul 
	WHERE		trx.customer_trx_id  = p_trxId
	AND   	typ.cust_trx_type_id = trx.cust_trx_type_id
	AND   	trx.batch_source_id  = bat.batch_source_id
      AND         pay.term_id (+)      = trx.term_id 
	AND		rul.rule_id (+)      = trx.invoicing_rule_id;

      ar_start_table( 'Transaction Header');
      ar_table_row( 'trxid'     , 'Customer Trx Id'         , h_trxId );
      ar_table_row( 'trxnum'    , 'Transaction Number'      , h_trxNum );
      ar_table_row( 'custref'   , 'Customer Reference'      , h_reference );
      ar_table_row( 'batch'     , 'Source'                  , h_batchDsp );
      ar_table_row( 'type'      , 'Type'                    , h_typeDsp );
      ar_table_row( 'trtxdate'  , 'Date'                    , h_trxDate );
      ar_table_row( 'complete'  , 'Complete'                , h_complete );
      ar_table_row( 'currency'  , 'Currency'                , h_currency );
      ar_table_row( 'rate'      , 'Exchange Rate'           , h_exchangeRate );
      ar_table_row( 'class'     , 'Class'                   , h_class );
      ar_table_row( 'terms'     , 'Payment Terms'           , h_termDsp );
      ar_table_row( 'duedate'   , 'Due Date'                , h_dueDate );
      ar_table_row( 'rule'      , 'Invoicing Rule'          , nvl(h_ruleDsp, 'Null' ));
      ar_table_row( 'status'    , 'Status'                  , h_statusTrx );
      ar_table_row( 'Initialtrx', 'Original Customer Trx Id', h_initialCustomerTrxId );
      ar_table_row( 'Credittrx' , 'Credited Customer Trx Id', h_creditedCustomerTrxId );
      ar_table_row( 'requestid' , 'Request Id'              , h_requestId );
      ar_end_table;

      BEGIN  -- begin Transaction Type details 
        SectionPrint( 'Transaction Type details of "' || h_typeDsp || '"' );  
 
        SELECT	name,
                  description,
                  type, 
                  default_term,
			accounting_affect_flag,
                  post_to_gl,
       		default_printing_option,
			default_status,
			allow_freight_flag,
			tax_calculation_flag,			
			creation_sign,	
			natural_application_only_flag,
 	            rule_set_id,
			allow_overapplication_flag,
                  decode( status, 'A', 'Active', 'I', 'Inactive', status ), 
			start_date,
                  end_date,  
			subsequent_trx_type_id,
			set_of_books_id
        INTO      t_name,
                  t_desc,
                  t_type,
                  t_terms,
                  t_openRec,
                  t_postGl,
                  t_printing,
                  t_defaultStatus,
           		t_allowFreight,
			t_taxCalc,
			t_sign,
			t_naturalApp,
 			t_ruleSetId,
 			t_allowOverApp,
			t_status,
			t_start,
			t_end,
			t_subTypeId,
 			t_sobId
        FROM    	RA_CUST_TRX_TYPES  
        WHERE    	cust_trx_type_id = h_typeId ;

        ar_start_table( 'Transaction Type Details');
       
        ar_table_row( 'name'      , 'Name'                    , t_name );
        ar_table_row( 'desc'      , 'Description'             , t_desc );
        ar_table_row( 'class'     , 'Class'                   , t_type );
        ar_table_row( 'terms'     , 'Terms'                   , t_terms );
	  ar_table_row( 'openRec'   , 'Open Receivable'         , t_openRec );
        ar_table_row( 'postGl'    , 'Post to Gl'              , t_postGl  );
        ar_table_row( 'printing'  , 'Printing Option'         , t_printing );
        ar_table_row( 'defstatus' , 'Transaction Status'      , t_defaultStatus );
        ar_table_row( 'freight'   , 'Allow Freight'           , t_allowFreight );
        ar_table_row( 'tax'       , 'Tax Calculation'         , t_taxCalc );
        ar_table_row( 'sign'      , 'Creation Sign'           , t_sign );
        ar_table_row( 'natural'   , 'Natural Application Only', t_naturalApp );
        ar_table_row( 'ruleset'   , 'Application Rule Set'    , t_ruleSetId  );
        ar_table_row( 'overapp'   , 'Allow Overapplication'   , t_allowOverApp );
        ar_table_row( 'status'    , 'Status'                  , t_status );
        ar_table_row( 'startdate' , 'Start Date'              , t_start );
        ar_table_row( 'enddate'   , 'End Date'                , t_end  );
        ar_table_row( 'sobid'     , 'Set of Books Id'         , t_sobId  );

        ar_end_table;

      EXCEPTION 
        WHEN others then -- exception getting transaction type details
             ErrorPrint( sqlerrm || ' occurred when Getting Transaction Type Details for Customer Trx Id ' || p_trxId );
             ActionErrorPrint( 'Please check Transaction Type ' || h_typeDsp || ' of Customer Trx Id ' || p_trxId);
      END;   -- end getting Transaction Type details

    EXCEPTION 
      WHEN OTHERS THEN -- exception getting Transaction information
           ErrorPrint( 'Customer Trx Id "'|| &trxid|| '" is invalid for Organization '||v_orgname|| ' ( Org Id = '|| v_orgid || ' )' );
           ActionErrorPrint( 'Enter a valid Customer Trx Id');
           RAISE STOPEXECUTION; 
    END;   

/* ------------------------------- Show table Info -----------------------------------------------------*/

    -- CASE 1 : MRC INVOICE  

    IF (( t_type != 'CM' ) AND ( v_report_mrc = 'Y' )) THEN

       -- quick links table
       tag( 'quicklinks' );
       SectionPrint( 'Quick Links to Data' );

       Start_Table( 'Quick Links to Data Collection' );

       ql_markers := V2T( 'getTransaction', 'getMcTransaction' );
       ql_titles  := V2T( 'RA_CUSTOMER_TRX_ALL','RA_MC_CUSTOMER_TRX' );
       Show_Quicklink_Row( ql_titles, ql_markers );
      
       ql_markers := V2T( 'getTransactionLines', 'getLinesGlDist' );
       ql_titles  := V2T( 'RA_CUSTOMER_TRX_LINES_ALL', 'RA_CUST_TRX_LINE_GL_DIST_ALL' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotals', 'getLinesGlDistTotalsClass' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL All Totals', 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by Class' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotalsGlDate', 'getLinesGlDistTotalsCombined' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by GL Date', 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by GL Date and Class' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotalsUnposted', 'getMcLinesGlDist' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL Unposted Totals by GL Date and Class', 'RA_MC_TRX_LINE_GL_DIST' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getMcLinesGlDistTotals', 'getReceivableApplicationsapplied_customer_trx_id' ); 
       ql_titles  := V2T( 'RA_MC_TRX_LINE_GL_DIST Totals', 'AR_RECEIVABLE_APPLICATIONS_ALL ( applied_customer_trx_id )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getRecAppTotalsapplied_customer_trx_id', 'getMcReceivableAppsapplied_customer_trx_id' );
       ql_titles  := V2T( 'AR_RECEIVABLE_APPLICATIONS_ALL Totals ( applied_customer_trx_id )', 'AR_MC_RECEIVABLE_APPS ( applied_customer_trx_id )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getPaymentSchedules', 'getMcPaymentSchedules' );
       ql_titles  := V2T( 'AR_PAYMENT_SCHEDULES_ALL', 'AR_MC_PAYMENT_SCHEDULES' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getAdjustment', 'getMcAdjustment' );
       ql_titles  := V2T( 'AR_ADJUSTMENTS_ALL', 'AR_MC_ADJUSTMENTS' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getDistributionsADJ', 'getMcDistributionsADJ'  );
       ql_titles  := V2T( 'AR_DISTRIBUTIONS_ALL ( Source = ADJ )', 'AR_MC_DISTRIBUTIONS_ALL ( Source = ADJ )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getInvRules', 'getAccRules' );
       ql_titles  := V2T( 'Invoicing Rules',  'Accounting Rules' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       ql_markers := V2T( 'getRulePeriods', 'getGLInterface' );
       ql_titles  := V2T( 'Accounting Rule Periods', 'GL_INTERFACE' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       ql_markers := V2T( 'getGLJELines', 'getGLImportReferences' );
       ql_titles  := V2T( 'GL_JE_LINES', 'GL_IMPORT_REFERENCES' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 
       End_Table;
    
       -- TRANSACTION
       getTransaction( p_trxId, p_columnOutput );
       getMcTransaction( p_trxId, p_columnOutput ); 

       -- TRANSACTION LINES 
       getTransactionLines( p_trxId, p_columnOutput );
    
       -- TRX DISTRIBUTION LINES 
       getLinesGlDist( p_trxId, p_columnOutput );
       getLinesGlDistTotals( p_trxId );
       getLinesGlDistTotalsClass( p_trxId );
       getLinesGlDistTotalsGlDate( p_trxId );
       getLinesGlDistTotalsCombined( p_trxId );
       getLinesGlDistTotalsUnposted( p_trxId );
       getMcLinesGlDist( p_trxId, p_columnOutput );
       getMcLinesGlDistTotals( p_trxId ); 

       -- RECEIVABLE APPLICATIONS
       getReceivableApplications( 'applied_customer_trx_id', p_trxId, p_columnOutput );
       getRecAppTotals( 'applied_customer_trx_id', p_trxId );
       getMcReceivableApps( 'applied_customer_trx_id', p_trxId, p_columnOutput );

       -- PAYMENT SCHEDULES
       getPaymentSchedules( p_trxId, p_columnOutput );
       getMcPaymentSchedules( p_trxId, p_columnOutput );

       -- ADJUSTMENTS
       getAdjustment( p_trxId, p_columnOutput );
       getMcAdjustment( p_trxId, p_columnOutput );

       -- DISTRIBUTIONS ( ADJ)
       getDistributionsADJ( p_trxId, p_columnOutput );
       getMcDistributionsADJ( p_trxId, p_columnOutput ); 


    -- CASE 2 : non-MRC INVOICE  
    ELSIF (( t_type != 'CM' ) AND ( v_report_mrc = 'N' )) THEN
 
       -- quick links table
       tag( 'quicklinks' );
       SectionPrint( 'Quick Links to Data' );

       Start_Table( 'Quick Links to Data Collection' );

       ql_markers := V2T( 'getTransaction', 'getTransactionLines' );
       ql_titles  := V2T( 'RA_CUSTOMER_TRX_ALL', 'RA_CUSTOMER_TRX_LINES_ALL' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDist', 'getLinesGlDistTotals' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL', 'RA_CUST_TRX_LINE_GL_DIST_ALL All Totals' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotalsClass', 'getLinesGlDistTotalsGlDate' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by Class', 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by GL Date' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotalsCombined', 'getLinesGlDistTotalsUnposted' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by GL Date and Class', 'RA_CUST_TRX_LINE_GL_DIST_ALL Unposted Totals by GL Date and Class' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getReceivableApplicationsapplied_customer_trx_id', 'getRecAppTotalsapplied_customer_trx_id' );
       ql_titles  := V2T( 'AR_RECEIVABLE_APPLICATIONS_ALL ( applied_customer_trx_id )', 'AR_RECEIVABLE_APPLICATIONS_ALL ( applied_customer_trx_id ) Totals' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getPaymentSchedules', 'getAdjustment' );
       ql_titles  := V2T( 'AR_PAYMENT_SCHEDULES_ALL', 'AR_ADJUSTMENTS_ALL' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getDistributionsADJ', 'getInvRules' );
       ql_titles  := V2T( 'AR_DISTRIBUTIONS_ALL ( Source = ADJ )', 'Invoicing Rules' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getAccRules', 'getRulePeriods' );
       ql_titles  := V2T( 'Accounting Rules', 'Accounting Rule Periods');
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       ql_markers := V2T( 'getGLInterface', 'getGLJELines' );
       ql_titles  := V2T( 'GL_INTERFACE', 'GL_JE_LINES' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       ql_markers := V2T( 'getGLImportReferences' );
       ql_titles  := V2T( 'GL_IMPORT_REFERENCES' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       End_Table;
    
       -- TRANSACTION
       getTransaction( p_trxId, p_columnOutput );

       -- TRANSACTION LINES
       getTransactionLines( p_trxId, p_columnOutput );

       -- TRX DISTRIBUTION LINES
       getLinesGlDist( p_trxId, p_columnOutput );
       getLinesGlDistTotals( p_trxId );
       getLinesGlDistTotalsClass( p_trxId );
       getLinesGlDistTotalsGlDate( p_trxId );
       getLinesGlDistTotalsCombined( p_trxId );
       getLinesGlDistTotalsUnposted( p_trxId );

       -- RECEIVABLE APPLICATIONS
       getReceivableApplications( 'applied_customer_trx_id', p_trxId, p_columnOutput );
       getRecAppTotals( 'applied_customer_trx_id', p_trxId );

       -- PAYMENT SCHEDULES
       getPaymentSchedules( p_trxId, p_columnOutput );

       -- ADJUSTMENTS
       getAdjustment( p_trxId, p_columnOutput );

       -- DISTRIBUTIONS ( Adjustments )
       getDistributionsADJ( p_trxId, p_columnOutput ); 

    -- CASE 3 : MRC CREDITMEMO
    ELSIF (( t_type = 'CM' ) AND ( v_report_mrc = 'Y' )) THEN
 
       -- quick links table
       tag( 'quicklinks' );
       SectionPrint( 'Quick Links to Data' );

       Start_Table( 'Quick Links to Data Collection' );

       ql_markers := V2T( 'getTransaction', 'getMcTransaction' );
       ql_titles  := V2T( 'RA_CUSTOMER_TRX_ALL','RA_MC_CUSTOMER_TRX' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getTransactionLines', 'getLinesGlDist' );
       ql_titles  := V2T( 'RA_CUSTOMER_TRX_LINES_ALL', 'RA_CUST_TRX_LINE_GL_DIST_ALL' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotals', 'getLinesGlDistTotalsClass' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL All Totals', 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by Class' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotalsGlDate', 'getLinesGlDistTotalsCombined' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by GL Date', 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by GL Date and Class' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotalsUnposted', 'getMcLinesGlDist' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL Unposted Totals by GL Date and Class', 'RA_MC_TRX_LINE_GL_DIST' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getMcLinesGlDistTotals', 'getReceivableApplicationscustomer_trx_id' ); 
       ql_titles  := V2T( 'RA_MC_TRX_LINE_GL_DIST Totals', 'AR_RECEIVABLE_APPLICATIONS_ALL ( customer_trx_id )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getRecAppTotalscustomer_trx_id', 'getReceivableApplicationsapplied_customer_trx_id' );
       ql_titles  := V2T( 'AR_RECEIVABLE_APPLICATIONS_ALL Totals ( customer_trx_id )', 'AR_RECEIVABLE_APPLICATIONS_ALL ( applied_customer_trx_id )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getRecAppTotalsapplied_customer_trx_id', 'getMcReceivableAppscustomer_trx_id' );
       ql_titles  := V2T( 'AR_RECEIVABLE_APPLICATIONS_ALL Totals ( applied_customer_trx_id )', 'AR_MC_RECEIVABLE_APPS ( customer_trx_id )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getDistributionsRA', 'getDistTotalsRA' );
       ql_titles  := V2T( 'AR_DISTRIBUTIONS_ALL ( Source = RA )', 'AR_DISTRIBUTIONS_ALL Totals ( Source = RA )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getDistTotalsUnpostedRA', 'getMcDistributionsRA' );
       ql_titles  := V2T( 'AR_DISTRIBUTIONS_ALL Unposted Totals ( Source = RA )', 'AR_MC_DISTRIBUTIONS_ALL ( Source = RA )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getMcDistTotalsRA', 'getPaymentSchedules' );
       ql_titles  := V2T( 'AR_MC_DISTRIBUTIONS_ALL Totals ( Source = RA )', 'AR_PAYMENT_SCHEDULES_ALL' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getMcPaymentSchedules', 'getAdjustment'  );
       ql_titles  := V2T( 'AR_MC_PAYMENT_SCHEDULES', 'AR_ADJUSTMENTS_ALL' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getMcAdjustment', 'getDistributionsADJ'  );
       ql_titles  := V2T( 'AR_MC_ADJUSTMENTS', 'AR_DISTRIBUTIONS_ALL ( Source = ADJ )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getMcDistributionsADJ', 'getInvRules' );
       ql_titles  := V2T( 'AR_MC_DISTRIBUTIONS_ALL ( Source = ADJ )', 'Invoicing Rules' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getAccRules', 'getRulePeriods' );
       ql_titles  := V2T( 'Accounting Rules', 'Accounting Rule Periods' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       ql_markers := V2T( 'getGLInterface', 'getGLJELines' );
       ql_titles  := V2T( 'GL_INTERFACE', 'GL_JE_LINES' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       ql_markers := V2T( 'getGLImportReferences' );
       ql_titles  := V2T( 'GL_IMPORT_REFERENCES' );
       Show_Quicklink_Row( ql_titles, ql_markers );    

       End_Table;
    
       -- TRANSACTION 
       getTransaction( p_trxId, p_columnOutput );
       getMcTransaction( p_trxId, p_columnOutput ); 

       -- TRANSACTION LINES 
       getTransactionLines( p_trxId, p_columnOutput );
  
       -- TRX DISTRIBUTION LINES 
       getLinesGlDist( p_trxId, p_columnOutput );
       getLinesGlDistTotals( p_trxId );
       getLinesGlDistTotalsClass( p_trxId );
       getLinesGlDistTotalsGlDate( p_trxId );
       getLinesGlDistTotalsCombined( p_trxId );
       getLinesGlDistTotalsUnposted( p_trxId );
       getMcLinesGlDist( p_trxId, p_columnOutput );
       getMcLinesGlDistTotals( p_trxId ); 

       -- RECEIVABLE APPLICATIONS
       getReceivableApplications( 'customer_trx_id', p_trxId, p_columnOutput );
       getRecAppTotals( 'customer_trx_id', p_trxId );
       getReceivableApplications( 'applied_customer_trx_id', p_trxId, p_columnOutput );
       getRecAppTotals( 'applied_customer_trx_id', p_trxId );
       getMcReceivableApps( 'customer_trx_id', p_trxId, p_columnOutput );

       -- DISTRIBUTIONS ( Receivable Applications )
       getDistributionsRA( p_trxId, p_columnOutput );
       getDistTotalsRA( p_trxId );
       getDistTotalsUnpostedRA( p_trxId );
       getMcDistributionsRA( p_trxId, p_columnOutput );
       getMcDistTotalsRA( p_trxId );

       -- AR_PAYMENT_SCHEDULES_ALL
       getPaymentSchedules( p_trxId, p_columnOutput );
       getMcPaymentSchedules( p_trxId, p_columnOutput );

       -- ADJUSTMENTS
       getAdjustment( p_trxId, p_columnOutput );
       getMcAdjustment( p_trxId, p_columnOutput );

       -- DISTRIBUTIONS ( Adjustment )
       getDistributionsADJ( p_trxId, p_columnOutput ); 
       getMcDistributionsADJ( p_trxId, p_columnOutput ); 

    -- CASE 4 : non-MRC CREDITMEMO  
    ELSIF (( t_type = 'CM' ) AND ( v_report_mrc = 'N' )) THEN
 
       -- quick links table
       tag( 'quicklinks' );
       SectionPrint( 'Quick Links to Data' );

       Start_Table( 'Quick Links to Data Collection' );

       ql_markers := V2T( 'getTransaction', 'getTransactionLines'  );
       ql_titles  := V2T( 'RA_CUSTOMER_TRX_ALL', 'RA_CUSTOMER_TRX_LINES_ALL' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDist', 'getLinesGlDistTotals' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL', 'RA_CUST_TRX_LINE_GL_DIST_ALL All Totals');
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotalsClass', 'getLinesGlDistTotalsGlDate' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by Class', 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by GL Date' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getLinesGlDistTotalsCombined', 'getLinesGlDistTotalsUnposted' );
       ql_titles  := V2T( 'RA_CUST_TRX_LINE_GL_DIST_ALL Totals by GL Date and Class', 'RA_CUST_TRX_LINE_GL_DIST_ALL Unposted Totals by GL Date and Class' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getReceivableApplicationscustomer_trx_id', 'getRecAppTotalscustomer_trx_id' );
       ql_titles  := V2T( 'AR_RECEIVABLE_APPLICATIONS_ALL ( customer_trx_id )', 'AR_RECEIVABLE_APPLICATIONS_ALL Totals ( customer_trx_id )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getReceivableApplicationsapplied_customer_trx_id', 'getRecAppTotalsapplied_customer_trx_id' );
       ql_titles  := V2T( 'AR_RECEIVABLE_APPLICATIONS_ALL ( applied_customer_trx_id )', 'AR_RECEIVABLE_APPLICATIONS_ALL Totals ( applied_customer_trx_id )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getDistributionsRA', 'getDistTotalsRA' );
       ql_titles  := V2T( 'AR_DISTRIBUTIONS_ALL ( Source = RA )', 'AR_DISTRIBUTIONS_ALL Totals ( Source = RA )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getDistTotalsUnpostedRA', 'getPaymentSchedules' );
       ql_titles  := V2T( 'AR_DISTRIBUTIONS_ALL Unposted Totals ( Source = RA )', 'AR_PAYMENT_SCHEDULES_ALL'   );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getAdjustment', 'getDistributionsADJ' );
       ql_titles  := V2T( 'AR_ADJUSTMENTS_ALL', 'AR_DISTRIBUTIONS_ALL ( Source = ADJ )' );
       Show_Quicklink_Row( ql_titles, ql_markers );

       ql_markers := V2T( 'getInvRules', 'getAccRules' );
       ql_titles  := V2T( 'Invoicing Rules', 'Accounting Rules' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       ql_markers := V2T( 'getRulePeriods', 'getGLInterface' );
       ql_titles  := V2T( 'Accounting Rule Periods', 'GL_INTERFACE' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       ql_markers := V2T( 'getGLJELines', 'getGLImportReferences' );
       ql_titles  := V2T( 'GL_JE_LINES', 'GL_IMPORT_REFERENCES' );
       Show_Quicklink_Row( ql_titles, ql_markers ); 

       End_Table;
    
       -- TRANSACTION 
       getTransaction( p_trxId, p_columnOutput );
 
       -- TRANSACTION LINES 
       getTransactionLines( p_trxId, p_columnOutput );

       -- TRX DISTRIBUTION LINES     
       getLinesGlDist( p_trxId, p_columnOutput );
       getLinesGlDistTotals( p_trxId );
       getLinesGlDistTotalsClass( p_trxId );
       getLinesGlDistTotalsGlDate( p_trxId );
       getLinesGlDistTotalsCombined( p_trxId );
       getLinesGlDistTotalsUnposted( p_trxId );

       -- AR_RECEIVABLE_APPLICATIONS_ALL
       getReceivableApplications( 'customer_trx_id', p_trxId, p_columnOutput );
       getRecAppTotals( 'customer_trx_id', p_trxId );
       getReceivableApplications( 'applied_customer_trx_id', p_trxId, p_columnOutput );
       getRecAppTotals( 'applied_customer_trx_id', p_trxId );

       -- AR_DISTRIBUTIONS_ALL (RA)
       getDistributionsRA( p_trxId, p_columnOutput );
       getDistTotalsRA( p_trxId );
       getDistTotalsUnpostedRA( p_trxId );

       -- AR_PAYMENT_SCHEDULES_ALL
       getPaymentSchedules( p_trxId, p_columnOutput );

       -- AR_ADJUSTMENTS_ALL
       getAdjustment( p_trxId, p_columnOutput );

       -- AR_DISTRIBUTIONS_ALL (ADJ)
       getDistributionsADJ( p_trxId, p_columnOutput ); 

    END IF; 

/* -------------------------------------------- end block --------------------------------------------------- */

    End_Block; 

/* ------------------------ Exception Section : Main Program ( Part 1 ) ----------------------------- */ 
/* Whenever an exception was raised set the variable v_abort to 'Y' so Part 2 of the MAin Program     */
/* also knows to do nothing                                                                           */
/*----------------------------------------------------------------------------------------------------*/

  EXCEPTION   -- begin 2 
    WHEN STOPEXECUTION THEN     
         brprint;
         :v_abort := 'Y'; 
         End_Block; 

    WHEN OTHERS THEN  
         brprint;
         ErrorPrint(sqlerrm||' occurred in diagnostic test');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
         brprint;
         :v_abort := 'Y';
         End_Block; 
  END;   --end2 

EXCEPTION  --  begin 1  
  WHEN OTHERS then   -- exceptions begin 1
       Brprint;
       Errorprint(sqlerrm||' occurred in diagnostic test');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');
       Brprint; 
       :v_abort := 'Y';
       End_Block; 

END; 
/

REM =========================================================================================
REM
REM    Because the above block became too big and resulted in a PLS-123 Program TOO Large 
REM    We needed to split up the original Main block in Two plsql Blocks 
REM     
REM =========================================================================================
REM ====================== Run the Pl/SQL api file again ==================================== 
@@CoreApiHtml.sql

/*---------------------------------- Define procedure TAG -------------------------------------------*/ 

  PROCEDURE  Tag( p_txt varchar2 ) is
  BEGIN 
    Insert_HTML('<a NAME='||p_txt||'></a>');
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "Tag"' );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END Tag;

/*---------------------------------- Define procedure TOP -------------------------------------------*/ 

  PROCEDURE Top is
  BEGIN
    Insert_HTML('<a HREF=#quicklinks>Back to Quick Links</a><BR>');
  EXCEPTION 
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "Top"' );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END Top;

/*----------------------------------- Define procedure getInvRules ------------------------------------*/

  PROCEDURE getInvRules( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getInvRules');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   a.rule_id			"Rule Id", '
	        || '    	   a.name				"Name", '                                       
	        || '	   a.description			"Desc", '                                   
	        || '	   a.type				"Type", '                              
	        || '	   a.status				"Status", '                                   
	        || '	   a.frequency			"Freq", '                                       
	        || '	   a.occurrences			"Occur", '                                    
	        || '	   a.deferred_revenue_flag	"Def Rev|Flag", '                          
              || '         to_char( a.last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( a.creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created" '   
              || 'FROM	   RA_RULES a, '
  	        || '	   RA_CUSTOMER_TRX_ALL b '
	        || 'WHERE    a.rule_id = b.invoicing_rule_id '
	        || 'AND      b.invoicing_rule_id is NOT NULL '
	        || 'AND 	   b.customer_trx_id = ' || p_customerTrxId ;
    ELSE 
       sqltxt := 'SELECT   a.* '
              || 'FROM	   RA_RULES a, '
  	        || '	   RA_CUSTOMER_TRX_ALL b '
	        || 'WHERE    a.rule_id = b.invoicing_rule_id '
	        || 'AND      b.invoicing_rule_id is NOT NULL '
	        || 'AND 	   b.customer_trx_id = ' || p_customerTrxId ; 
    END IF;

    SectionPrint( 'Invoicing Rules' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getInvRules". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getInvRules;

/*----------------------------------- Define procedure getAccRules ------------------------------------*/

  PROCEDURE getAccRules(  p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getAccRules');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   a.rule_id			"Rule Id", '
	        || '    	   a.name				"Name", '                                       
	        || '	   a.description			"Desc", '                                   
	        || '	   a.type				"Type", '                              
	        || '	   a.status				"Status", '                                   
	        || '	   a.frequency			"Freq", '                                       
	        || '	   a.occurrences			"Occur", '                                    
	        || '	   a.deferred_revenue_flag	"Def Rev|Flag", '                        
              || '         to_char( a.last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( a.creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created" '   
              || 'FROM	   RA_RULES a, '
  	        || '	   RA_CUSTOMER_TRX_LINES_ALL b '
	        || 'WHERE    a.rule_id = b.accounting_rule_id '
	        || 'AND      b.accounting_rule_id is NOT NULL '
	        || 'AND 	   b.customer_trx_id = ' || p_customerTrxId ;
    ELSE
       sqltxt := 'SELECT   a.* '
              || 'FROM	   RA_RULES a, '
  	        || '	   RA_CUSTOMER_TRX_LINES_ALL b '
	        || 'WHERE    a.rule_id = b.accounting_rule_id '
	        || 'AND      b.accounting_rule_id is NOT NULL '
	        || 'AND 	   b.customer_trx_id = ' || p_customerTrxId ;
    END IF;

    SectionPrint( 'Accounting Rules' ); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getAccRules". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getAccRules;

/*-------------------------------- Define procedure getRulePeriods ----------------------------------*/ 

  PROCEDURE getRulePeriods( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000) := null;
  BEGIN
    tag('getRulePeriods');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT   a.rule_id			"Rule Id", '
	        || '	   a.period_number		"Period Num", '
	        || '   	   a.percent			"Percent", '
	        || '	   a.rule_date			"Rule Date", '
              || '         to_char( a.last_update_date, ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '        
              || '         to_char( a.creation_date,    ''DD-MON-YYYY HH24:MI:SS'' )  "Created" '   
              || 'FROM	   RA_RULE_SCHEDULES a, '
  	        || '	   RA_CUSTOMER_TRX_LINES_ALL b '
	        || 'WHERE    a.rule_id = b.accounting_rule_id '
	        || 'AND      b.accounting_rule_id is NOT NULL '
	        || 'AND 	   b.customer_trx_id = ' || p_customerTrxId ;
    ELSE
       sqltxt := 'SELECT   a.* '
              || 'FROM	   RA_RULE_SCHEDULES a, '
  	        || '	   RA_CUSTOMER_TRX_LINES_ALL b '
	        || 'WHERE    a.rule_id = b.accounting_rule_id '
	        || 'AND      b.accounting_rule_id is NOT NULL '
	        || 'AND 	   b.customer_trx_id = ' || p_customerTrxId ;
    END IF; 

    SectionPrint( 'Accounting Rule Periods'); 
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getRulePeriods". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
  END getRulePeriods;

/*---------------------------- Define procedure getGLInterface -------------------------------------*/ 
/* reference22 : cash_receipt_id, in some case other info is concatenated                           */  
/* reference24 : receipt_number                                                                     */
/* reference25 : Cash Receipt: null, Misc Receipt : cash_receipt_history_id                         */
/* reference26 : null                                                                               */
/* reference27 : pay_from_customer                                                                  */
/*--------------------------------------------------------------------------------------------------*/

  PROCEDURE getGLInterface( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000);
  BEGIN 
    tag('getGLInterface');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT  substr(reference22,1,10)     "Trx Id|(Ref22)", ' 
              || '        group_id                     "Group Id", '
              || '        substr(status,1,10)          "Status", '
              || '        substr(set_of_books_id,1,3)  "Sob", '
              || '        entered_dr                   "Amt DR", '
              || '        accounted_dr                 "Acctd|Amt DR", '                     
              || '        entered_cr                   "Amt CR", '
              || '        accounted_cr                 "Acctd|Amt CR", '
              || '        user_je_source_name          "Source", '
              || '        code_combination_id          "CcId", ' 
              || '        substr(reference21,1,10)     "PcId|(Ref21)", '
              || '        substr(reference23,1,10)     "Gl Date|(Ref23)", '
	        || '        substr(reference24,1,10)     "Trx Number|(Ref24)", '
              || '	  substr(reference25,1,10)     "Ref25", '
              || '        substr(reference26,1,10)     "Customer|(Ref26)", '
              || '        substr(reference27,1,10)     "Bill To Customer|(Ref27)", '
              || '        substr(reference28,1,10)     "Trx Type|(Ref28)", '
              || '        substr(reference29,1,10)     "Source Type|(Ref29)", '
              || '        substr(reference30,1,25)     "Source Table|(Ref30)", '
              || '        to_char( date_created,       ''DD-MON-YYYY HH24:MI:SS'' )  "Created" '
              || 'FROM    GL_INTERFACE ' 
              || 'WHERE   reference22 = ''' || p_customerTrxId || ''' ' 
              || 'AND     substr(reference30, 1, 2 ) = ''RA'' ';
    ELSE 
       sqltxt := 'SELECT  * FROM  GL_INTERFACE ' 
              || 'WHERE   reference22 = ''' || p_customerTrxId || ''' ' 
              || 'AND     substr(reference30, 1, 2 ) = ''RA'' ';
    END IF;

    SectionPrint( 'GL_INTERFACE' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getGLInterface". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getGLInterface;

/*---------------------------- Define procedure getGLJELines  --------------------------------------*/ 
/* In detail mode :                                                                                 */
/* GL_INTERFACE columns REFERENCE 21-30 populate GL_JE_LINES columns REFERENCE 1-10                 */
/*--------------------------------------------------------------------------------------------------*/

  PROCEDURE getGLJELines( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000);
  BEGIN 
    tag('getGLJELines');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT  je_header_id                 "Je Header Id", '
              || '        je_line_num                  "Je Line Num", '
              || '        substr(reference_2,1,25)     "Trx Id|(Ref2)", '
              || '        substr(set_of_books_id,1,3)  "Sob", '
              || '        entered_dr                   "Amt DR", '
              || '        accounted_dr                 "Acctd|Amt DR", '                     
              || '        entered_cr                   "Amt CR", '
              || '        accounted_cr                 "Acctd|Amt CR", '
              || '        code_combination_id          "CcId", ' 
              || '        substr(description,1,30)     "Description", '
              || '        period_name                  "Period|Name", '
              || '        substr(reference_1,1,10)     "PcId", '
              || '        substr(reference_3,1,10)     "Source Id|(Ref3)", '
              || '        substr(reference_4,1,10)     "Trx Number|(Ref4)", '
              || '        substr(reference_8,1,10)     "Trx Type|(Ref8)", '
              || '        substr(reference_9,1,10)     "Source Type|(Ref9)", '
              || '        substr(reference_10,1,25)    "Source Table|(Ref10)", '
              || '        to_char( last_update_date,   ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '
              || '        to_char( creation_date,      ''DD-MON-YYYY HH24:MI:SS'' )  "Created" '
              || 'FROM    GL_JE_LINES '    
              || 'WHERE   reference_2 = ''' || p_customerTrxId || ''' ' 
              || 'AND     substr(reference_10, 1, 2 ) = ''RA'' ';
    ELSE 
       sqltxt := 'SELECT  * FROM GL_JE_LINES '    
              || 'WHERE   reference_2 = ''' || p_customerTrxId || ''' ' 
              || 'AND     substr(reference_10, 1, 2 ) = ''RA'' ';
    END IF;
             
    SectionPrint( 'GL_JE_LINES' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getGLJELines". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getGLJELines;


/*---------------------------- Define procedure getGLImportReferences ------------------------------*/ 
/* In summary mode :                                                                                */
/* GL_INTERFACE columns REFERENCE 21-30 populate GL_IMPORT_REFERENCES columns REFERENCE 1-10        */
/* For a Misc  Receipt Reference_2 = Cash_receipt_id                                                */ 
/* For a Trade Receipt Reference_2 contains Cash_receipt_id || 'C' ||Crh_id                         */
/*                                       or Cash_receipt_id || 'C' ||ra_id                          */
/*--------------------------------------------------------------------------------------------------*/

  PROCEDURE getGLImportReferences( p_customerTrxId in varchar2, p_columnOutput in varchar2 ) is
    sqltxt  varchar2(5000);
  BEGIN 
    tag('getGLImportReferences');

    IF p_columnOutput = 'Limited' THEN
       sqltxt := 'SELECT  je_batch_id                 "Je Batch Id", '
              || '        je_header_id                "Je Header Id", '
              || '        je_line_num                 "Je Line Num", ' 
              || '        substr(reference_1,1,10)    "PcId", '
              || '        substr(reference_2,1,25)    "Trx Id|(Ref2)", '
              || '        substr(reference_3,1,10)    "Source Id|(Ref3)", '
              || '        substr(reference_4,1,10)    "Trx Number|(Ref4)", '
              || '	  substr(reference_5,1,10)    "Ref5", '
              || '        substr(reference_6,1,10)    "Customer|(Ref6)", '
              || '        substr(reference_7,1,10)    "Bill To Customer|(Ref7)", '
              || '        substr(reference_8,1,10)    "Trx Type|(Ref8)", '
              || '        substr(reference_9,1,10)    "Source Type|(Ref9)", '
              || '        substr(reference_10,1,25)   "Source Table|(Ref10)", '
              || '        to_char( last_update_date,  ''DD-MON-YYYY HH24:MI:SS'' )  "Updated", '
              || '        to_char( creation_date,     ''DD-MON-YYYY HH24:MI:SS'' )  "Created" '
              || 'FROM    GL_IMPORT_REFERENCES ' 
              || 'WHERE   reference_2 = ''' || p_customerTrxId || ''' ' 
              || 'AND     substr(reference_10, 1, 2 ) = ''RA'' ';
    ELSE 
       sqltxt := 'SELECT  * FROM GL_IMPORT_REFERENCES ' 
              || 'WHERE   reference_2 = ''' || p_customerTrxId || ''' ' 
              || 'AND     substr(reference_10, 1, 2 ) = ''RA'' '; 
    END IF;  

    SectionPrint( 'GL_IMPORT_REFERENCES' );
    Run_SQL( null, sqltxt );
    top;
    BRPrint;
  EXCEPTION
    WHEN OTHERS THEN 
         Errorprint( sqlerrm ||' occurred when calling "getGLImportReferences". Sql-statement  = '|| sqltxt );
         ActionErrorPrint( 'Please report the above error to Oracle Support Services.');
  END getGLImportReferences;

/*------------------------------- Start Of the Main Program ( Part 2 )-----------------------------*/

BEGIN  -- begin 1
  DECLARE -- declare 2 
    p_username            varchar2(100);   
    p_respid              number;
    p_columnOutput        varchar2(8)    := NULL; 
    p_trxId               varchar2(25)   := NULL; 
     
    STOPEXECUTION         exception;

  BEGIN  -- begin2 

/* ----------------------------- Set Client again -------------------------------------------------*/

    Init_block; 

 -- if the first block was aborted then this block needs to stop immediately 
 
    IF :v_abort = 'Y' THEN
       BrPrint;
       RAISE StopExecution ;
    END IF;

    p_username := :v_username;

    IF &v_respid IS NULL THEN
       p_respid := -10;     
    ELSE        
       p_respid := TO_NUMBER(&v_respid);
    END IF; 

    Set_Client(p_username, p_respid);
    Brprint;

    p_trxId := &trxid;

    IF substr( UPPER('&columnOutput'), 1, 1 ) = 'A' THEN 
       p_columnOutput := 'All';
       g_sql_date_format := 'DD-MON-YYYY HH24:MI:SS';
    ELSE 
       p_columnOutput := 'Limited';
       g_sql_date_format := 'DD-MON-YYYY';
    END IF;

/* ----------------------------------- Data collection Continued -------------------------------------- */

    -- RA_RULES
    getInvRules( p_trxId, p_columnOutput  );
    getAccRules( p_trxId, p_columnOutput  );
    getRulePeriods( p_trxId, p_columnOutput  );
    
    -- GL
    getGLInterface( p_trxId, p_columnOutput );
    getGLJELines( p_trxId, p_columnOutput );
    getGLImportReferences( p_trxId, p_columnOutput );

/* -------------------------------------------- Feedback ---------------------------------------------- */

    Brprint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo');
 
/* -------------------------------- Exception Section  - Main Program ( Part 2 ) ---------------------- */ 

  EXCEPTION --  exception section ( block 2 ) 
    WHEN STOPEXECUTION THEN  
          brprint;
          Show_Footer('&v_scriptlongname', '&v_headerinfo');
          brprint;
    WHEN OTHERS THEN 
         brprint;
         ErrorPrint( sqlerrm || ' occurred in this test');
         ActionErrorPrint( 'Please report the above error to Oracle Support Services');
         brprint;
         Show_Footer( '&v_scriptlongname', '&v_headerinfo');
         brprint; 
   END; -- ( block 2, script code ) 

EXCEPTION -- exception section ( block 1 )
  WHEN OTHERS THEN   
       Brprint;
       Errorprint( sqlerrm || ' occurred in this test');
       ActionErrorPrint( 'Please report the above error to Oracle Support Services');
       Brprint; 
       Show_Footer('&v_scriptlongname', '&v_headerinfo');
       Brprint;
END;   -- ( Block 1, API and template )  
/

REM  ==============SQL PLUS Environment setup============================================================
Spool off
Set termout on
set feedback on
set verify off 
set echo off 
set trimout off
set trimspool off
set heading on
set autoprint off

PROMPT
PROMPT  ===========================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  ===========================================================================
PROMPT 
