================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract          Oracle Receivables - Transaction Data Collection
================================================================================
PRODUCT:               Accounts Receivable (AR)
SUBCOMPONENT:          ARXTW
PRODUCT VERSIONS:      Release 11.5
DATABASE VERSIONS:     8.1.6 or higher
PLATFORM:              Generic
DATE CREATED:          20-DEC-2002
PARAMETERS:            Username
                       Responsibility Id
                       Column Output ( Limited / All columns ) 
                       Trx Number 
                       Customer Trx Id 
================================================================================
Instructions
================================================================================
Included Files:
     CoreApiHtml.sql
     ARTransactionInfo115.sql
     ARTransactionInfo115_readme.html
     ARTransactionInfo115_readme.txt

Execution Environment:
     SQL*Plus

Access Privileges:
     Requires APPS user access

Usage:
     sqlplus <apps user>/<apps pw> @ARTransactionInfo115

Instructions:

The files ARTransactionInfo115.sql and CoreApiHtml.sql should be unzipped
to a common directory. From this directory, start SQLPLUS in the APPS schema,
and run the file ARTransactionInfo115.sql 

An applications user name will be prompted for followed by a list of valid 
responsibilities for the user just entered.

When prompted, enter the responsibility id of the responsibility used when
the problem occurs. An Accounts Receivable responsibility should be entered here.

Next, you will be prompted for the column output. Possible Values : L(imited) or A(ll) 
L(imited) is the default and will only select the most relevant columns of each table. 
A(ll) will select all the columns of each table. 
In most cases a value of L is sufficient when running this diagnostic test. 
Only use the A(ll) option on specific request of support. 

Next, you can optionally enter the transaction number of the transaction to be analyzed. 
Enter the transaction number only when the corresponding customer trx id is unknown. A list 
of matching transactions will be returned on the screen. As transaction numbers are not 
unique it could be more than one transaction is found.

Finally you will be prompted for the customer trx id. 

The test will produce an output file named 
    ARTransactionInfo115_[customer_trx_id]_diag.html

This file can be viewed in a browser or uploaded for support analysis.

================================================================================
Description
================================================================================

This test will list for a given customer trx id the data stored in the following 
AR and GL tables/views : 

RA_CUSTOMER_TRX    
RA_CUST_TRX_TYPES    
RA_CUSTOMER_TRX_ALL
RA_CUSTOMER_TRX_LINES_ALL
RA_CUST_TRX_LINE_GL_DIST_ALL 
AR_RECEIVABLE_APPLICATIONS_ALL 
AR_DISTRIBUTIONS_ALL 
AR_PAYMENT_SCHEDULES_ALL   
AR_ADJUSTMENTS_ALL 
RA_RULES 
RA_RULE_SCHEDULES 
GL_INTERFACE
GL_JE_LINES
GL_IMPORT_REFERENCES 

In addition when Mrc is enabled and reporting set of books have been defined 
also the contents of following AR MRC tables will be listed :

RA_MC_CUSTOMER_TRX
RA_MC_TRX_LINE_GL_DIST
AR_MC_RECEIVABLE_APPS        
AR_MC_PAYMENT_SCHEDULES
AR_MC_DISTRIBUTIONS_ALL
AR_MC_ADJUSTMENTS

In case the transaction is a credit memo the output will be slightly different.  
The output of this test is very useful for support and development in case 
there is an issue with one of the transactions. 

================================================================================
References
================================================================================


================================================================================
Disclaimer
================================================================================
Except where expressly provided otherwise, the information, software, provided 
on an "AS IS" and "AS AVAILABLE" basis. Oracle expressly disclaims all 
warranties of any kind, whether express or implied, including, but not limited 
to, the implied warranties of merchantability, fitness for a particular purpose 
and non-infringement.  Oracle makes no warranty that: (A) the results that may 
be obtained from the use of the software will be accurate or reliable; or (B) 
the information, or other material obtained will meet your expectations.  Any 
content, materials, information or software downloaded or otherwise obtained is 
done at your own discretion and risk.  Oracle shall have no responsibility for 
any damage to your computer system or loss of data that results from the 
download of any content, materials, information or software.

Oracle reserves the right to make changes or updates to the software at any time
without notice.

================================================================================
Limitation of Liability
================================================================================
In no event shall Oracle be liable for any direct, indirect, incidental, special
or consequential damages, or damages for loss of profits, revenue, data or use, 
incurred by you or any third party, whether in an action in contract or tort, 
arising from your access to, or use of, the software.

Some jurisdictions do not allow the limitation or exclusion of liability.
Accordingly, some of the above limitations may not apply to you.
