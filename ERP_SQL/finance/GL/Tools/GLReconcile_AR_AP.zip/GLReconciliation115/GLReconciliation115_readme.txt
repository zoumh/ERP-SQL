================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract          Reconciles General Ledger balances with Accounts Payable and
                  Receivables balances for a specific period
================================================================================
PRODUCT:          General Ledger (GL) 
SUBCOMPONENT:     Balances
PRODUCT VERSIONS: 11.5.X
PLATFORM:         Generic
DATE CREATED:     21-Nov-2002
PARAMETERS:       Username
                  Responsibility id (LOV)
                  Period Name (defaults to latest open period)
================================================================================
Instructions
================================================================================
Included Files:
     CoreApiHtml.sql
     GLReconciliation115.sql
     GLReconciliation115_readme.txt
     GLReconciliation115_readme.html
     GLReconciliation115_Sample_Output.html
    
          
Execution Environment: 
     SQL*Plus
    
Access Privileges:
     Requires APPS user access
    
Usage:
     sqlplus <apps user>/<apps pw>  GLReconciliation115.sql 


Instructions:

The files GLReconciliation115.sql and CoreApiHtml.sql should be unzipped
to a common directory. From this directory, run GLReconciliation115.sql 
in SQL*Plus in the APPS schema.

You will be prompted for an applications user name. Enter a valid user name.
You should then see a list of valid responsibilities for the user entered.

When prompted, enter the responsibility id of the responsibility used when
the problem is occuring.

When you are prompted with "Please enter period name [default is the latest 
opened GL period]:", you should enter a valid period name or accept the 
default as the latest open period.

The test will produce an output file named 
    GLReconciliation115_<Responisibility ID>_diag.html.
This file can be viewed in a browser or uploaded for support analysis.

================================================================================
Description
================================================================================
This diagnostic test is designed to check and explain inconsistencies between GL 
and subledger (AP and AR) balances for a given period. 

Please note, this test may take a while to run, depending on the data for the 
period requested.

================================================================================
References 
================================================================================
None

================================================================================
Disclaimer
================================================================================
Except where expressly provided otherwise, the information, software, provided 
on an "AS IS" and "AS AVAILABLE" basis. Oracle expressly disclaims all 
warranties of any kind, whether express or implied, including, but not limited 
to, the implied warranties of merchantability, fitness for a particular purpose 
and non-infringement.  Oracle makes no warranty that: (A) the results that may 
be obtained from the use of the software will be accurate or reliable; or (B) 
the information, or other material obtained will meet your expectations.  Any 
content, materials, information or software downloaded or otherwise obtained is 
done at your own discretion and risk.  Oracle shall have no responsibility for 
any damage to your computer system or loss of data that results from the 
download of any content, materials, information or software.

Oracle reserves the right to make changes or updates to the software at any time
without notice.

================================================================================
Limitation of Liability
================================================================================
In no event shall Oracle be liable for any direct, indirect, incidental, special
or consequential damages, or damages for loss of profits, revenue, data or use, 
incurred by you or any third party, whether in an action in contract or tort, 
arising from your access to, or use of, the software.

Some jurisdictions do not allow the limitation or exclusion of liability.
Accordingly, some of the above limitations may not apply to you.

