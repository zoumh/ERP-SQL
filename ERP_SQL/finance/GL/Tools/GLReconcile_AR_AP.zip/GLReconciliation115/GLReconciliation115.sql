undefine v_headerinfo
Define   v_headerinfo     =  '$Header: GLReconciliation115.sql 1.8 24-Apr-2003 support $'
undefine v_Testlongname
Define   v_Testlongname = 'General Ledger Period End Reconciliation Test '

REM   ==================================================================== 
REM   Copyright � 2002  Corporation Redwood Shores, California, USA 
REM    Support Services.  All rights reserved. 
REM   ====================================================================
REM   PURPOSE:             To reconcile General Ledger Balances with Accounts 
REM                        Payable and Receivables Balances for a specific period. 
REM   PRODUCT:             General Ledger (GL)
REM   PRODUCT VERSIONS:    11.5.X 
REM   PLATFORM:            Generic
REM   PARAMETERS           1. Apps username
REM                        2. Responsibility to be chosen from list
REM                        3. Period name (Default = latest open GL period)
REM   ====================================================================
REM   ====================================================================
REM   USAGE:                sqlplus apps/apps@appsdb 
REM                         start GLReconciliation115.sql
REM   EXAMPLE:  
REM   OUTPUT:               GLReconciliation115_<Responsibility ID>_diag.html 
REM   ====================================================================   
REM   ==================================================================== 
REM   CHANGE HISTORY: 
REM   30-SEP-2002      bbrown      created v1.0
REM   30-SEP-2002      azwarren    modified v1.0
REM   02-OCT-2002      eracher     contributor
REM   16-DEC-2002      bbrown      modified v1.1
REM   06-Jan-2003      bbrown      modified v1.2
REM   19-Feb-2003      bbrown      modified v1.5 -- Parameters in CheckProfile API 
REM   31-Mar-2003      bbrown      modified v1.6 -- As per Final QA Round 1 suggestions
REM   23-Apr-2003      bbrown      modified v1.7 -- As per Final QA Round 2 suggestions

REM   ====================================================================   
REM   ==============SQL PLUS Environment setup============================ 

set serveroutput on size 1000000 
set verify off 
set echo off
set autoprint off
set termout on 
set feedback off

REM ============== Define SQL Variables for input parameters ============= 
VARIABLE    v_username       VARCHAR2(100); 
VARIABLE    v_respid         VARCHAR2(100);
VARIABLE    v_periodname     VARCHAR2(15);
VARIABLE    v_orig_periodname     VARCHAR2(15);

PROMPT 
undefine uname
accept uname char PROMPT  'Application User Name (required) : '
PROMPT 

REM ============Validate SQL*Plus Version Character Set Combination============
REM =======NOTE - This section only needed for tests using HTML API's==========

DECLARE
  l_nls_characterset    nls_database_parameters.value%TYPE;
  l_sql_release_int     INTEGER(20) :=  to_number('&_SQLPLUS_RELEASE');
  l_sql_release_chr     VARCHAR2(50) := '&_SQLPLUS_RELEASE';

BEGIN

  SELECT value 
    INTO  l_nls_characterset
    FROM  nls_database_parameters
    WHERE parameter = 'NLS_CHARACTERSET';
    
  FOR i IN 1..4 LOOP
    l_sql_release_chr := substr(l_sql_release_chr,1,(2*i)-1)||'.'||
      substr(l_sql_release_chr,(2*i)+1);
  END LOOP;
  
 
  IF l_nls_characterset LIKE 'UTF%' THEN
    IF l_sql_release_int IS null THEN 
      DBMS_OUTPUT.PUT_LINE(chr(10));
      DBMS_OUTPUT.PUT_LINE('ATTENTION - Cannot determine version of SQL*plus being used for test run');
      DBMS_OUTPUT.PUT_LINE('            This test may fail if not run using a version 8.1.X of SQL*plus or higher');
      DBMS_OUTPUT.PUT_LINE('Attempting to run the test.......');
      DBMS_OUTPUT.PUT_LINE(chr(10));
    ELSIF l_sql_release_int < 801000000 THEN
      DBMS_OUTPUT.PUT_LINE(chr(10));
      DBMS_OUTPUT.PUT_LINE('ERROR - Invalid SQL*plus Version '||l_sql_release_chr);
      DBMS_OUTPUT.PUT_LINE('ACTION - On databases using the '||l_nls_characterset||' NLS characterset this test should not be run using this ');
      DBMS_OUTPUT.PUT_LINE('.        SQL*plus Version.  Please rerun this test using version 8.1.X of SQL*plus or higher.');
      DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
      DBMS_OUTPUT.PUT_LINE(chr(10));
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - SQL*plus Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM ================ Show responsibilities assigned to given user ======== 
DECLARE   
  p_username_l    varchar2(100);
  l_applversion   fnd_product_groups.release_name%type;
  l_counter       integer;
  l_cursor        integer;
  sqltxt          varchar2(3000);
  l_resp_id       integer;
  l_resp_name     varchar2(300);  
  invalid_apps   exception; --exception when run on incorrect Test

BEGIN
  select nvl(rtrim(ltrim(upper('&uname'))), '<NULL username>')
  into :v_username
  from dual;

  select substr(release_name,1,4)  
  into   l_applversion 
  from   fnd_product_groups;

  IF l_applversion = '11.5' then
     BEGIN 
       sqltxt := 'select to_char(a.responsibility_id) id, '||
                 '       b.responsibility_name name '||
                 'from   fnd_user_resp_groups a, '||
                 '       fnd_responsibility_vl b, '||
                 '       fnd_user u '||
                 'where  a.user_id = u.user_id '||
                 'and    a.responsibility_id = b.responsibility_id '||
                 'and    a.responsibility_application_id = b.application_id '||
                 'and    sysdate between '|| 
                 '          a.start_date and nvl(a.end_date,sysdate+1) '||
                 'and    upper(u.user_name) = '''||:v_username||''''||
                 'order  by b.responsibility_name';
     

       DBMS_OUTPUT.PUT_LINE(chr(9));
       DBMS_OUTPUT.PUT_LINE('Following are the Responsibilities assigned to User:  '|| :v_username );
       DBMS_OUTPUT.PUT_LINE('=================================================================');

       l_cursor := dbms_sql.open_cursor;
       dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
       dbms_sql.define_column(l_cursor, 1, l_resp_id);
       dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
       l_counter := dbms_sql.execute(l_cursor);
       l_counter := 0; 

       WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
             l_counter := l_counter + 1;
             dbms_sql.column_value(l_cursor, 1, l_resp_id);
             dbms_sql.column_value(l_cursor, 2, l_resp_name);
             DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
       END LOOP; 
       DBMS_OUTPUT.PUT_LINE(chr(9));

       IF l_counter = 0 then
          raise no_data_found;
       END IF;   
       dbms_sql.close_cursor(l_cursor);
  
     EXCEPTION
     when NO_DATA_FOUND then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
       DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.' || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the test.  Rerun the test with a valid user name.' || chr(10));
     when OTHERS then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error: '|| sqlerrm);
       DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the test.'  || chr(10) );
     END; 
  ELSE  -- apps version is not 11.5
     DBMS_OUTPUT.PUT_LINE('ERROR  - This test is not designed to run against version '|| l_applversion ||' of applications');
     DBMS_OUTPUT.PUT_LINE('ACTION - Please run the test against an 11I instance'  || chr(10) ||
                          '         Type Ctrl-C <Enter> to exit the test'  || chr(10) );
  END IF; 

EXCEPTION
     when NO_DATA_FOUND then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve application version for this User');
       DBMS_OUTPUT.PUT_LINE('ACTION - Please ensure that the test is run against the correct instance.' || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the test.  Rerun the test against a valid instance.' || chr(10));
END; 
/

REM ===================== Accept Responsibility ====================================

PROMPT 
undefine v_respid
accept v_respid number PROMPT  'Please choose a Responsibility ID from the list : '
define v_respidc = &v_respid 
PROMPT 

REM ===================== Accept Period name input parameters ===============================
PROMPT
undefine Period_Name
accept Period_Name char prompt -
'Enter period name [default is the latest opened GL period]: ' 

BEGIN
  select nvl(rtrim(ltrim(upper('&Period_Name'))), 'NONE')
  into :v_periodname
  from dual;
  
DBMS_OUTPUT.PUT_LINE(chr(9));
  EXCEPTION
      when others then
      DBMS_OUTPUT.PUT_LINE('ERROR - Unexpected error occurred when period name was entered');
      DBMS_OUTPUT.PUT_LINE('ACTION - Please report this error using the feedback option on this test');
END;
/

BEGIN
  select nvl(rtrim(ltrim('&Period_Name')), 'NONE')
  into :v_orig_periodname
  from dual;
DBMS_OUTPUT.PUT_LINE(chr(9));
  EXCEPTION
      when others then
      DBMS_OUTPUT.PUT_LINE('ERROR - Unexpected error occurred when period name was entered');
      DBMS_OUTPUT.PUT_LINE('ACTION - Please report this error using the feedback option on this test');
END;
/


REM ===================== Spooling the output file ================================== 
Define v_spoolfilename  = 'GLReconciliation115_&v_respidc._diag.html'

PROMPT  =======================================================================
PROMPT  Output will be spooled to &v_spoolfilename
PROMPT  =======================================================================
PROMPT
PROMPT Running... Please be patient - this may take a while to run
PROMPT 

spool  &v_spoolfilename

REM ====================== Run the Pl/SQL api file ================================== 
@@CoreApiHtml.sql

BEGIN  -- begin API

  DECLARE -- declare main program
    -- parameter variables 
    p_username                  varchar2(100);   
    p_respid                    number;
    p_respname                  varchar2(100);
    p_applversion               varchar2(10);
    p_periodname                varchar2(15);

    -- gl sobs
    v_sobid                     number;
    v_sobname                   varchar2(30);
    v_appid                     number;
    v_SET_OF_BOOKS_ID           NUMBER(15) :=null;
    v_CURRENCY_CODE             VARCHAR2(15) := null;              
    v_CHART_OF_ACCOUNTS_ID      NUMBER(15) := null;        
    v_NAME                      VARCHAR2(30) := null;                        
    v_SUSPENSE_ALLOWED_FLAG     VARCHAR2(1) := null;       
    v_ACCOUNTED_PERIOD_TYPE     VARCHAR2(15) := null;        
    v_MRC_SOB_TYPE_CODE         VARCHAR2(1):= null;          
    v_TRACK_ROUNDING_IMBAL_FLAG VARCHAR2(1) := null;
    v_ROUNDING_CCID             NUMBER(15):= null;
    v_USER_PERIOD_TYPE          VARCHAR2(15):= null;
    v_CHART_OF_ACCOUNTS_NAME    VARCHAR2(30):=null;
    v_SUSPENSE_CCID             NUMBER(15):= null;
    v_CONSOLIDATION_SOB_FLAG    VARCHAR2(1) := null;
    v_enable_flag               VARCHAR2(1);
    v_chart_name                VARCHAR2(30);
    v_dynamic_flag              VARCHAR2(1);
    v_cross_seg_val_flag        VARCHAR2(1);
    p_userid                    number(15);
    v_liabilityAccount          number(15);
    v_apinstalled               varchar2(1);
    v_arinstalled               varchar2(1);

    -- gl periods
    v_PERIOD_SET_NAME           VARCHAR2(15) := null;             
    v_LATEST_OPENED_PERIOD_NAME VARCHAR2(15):= null;  
    p_prev_period               varchar2(10);
    p_previous_period           varchar2(10);


    -- gl_balances 
    Begin_dr                    number(15,2):=0;
    Begin_cr                    number(15,2):=0;
    Period_dr                   number(15,2):=0;
    Period_cr                   number(15,2):=0;
    End_dr                      number(15,2):=0;
    End_cr                      number(15,2):=0;

    -- sql variables
    l_count                     number  := 0;
    sqltxt                      varchar2(32767);
    count00                     Number(15) := null;
    p_profile                   varchar2(150);
    p_mo_org_id                 number(15);
    p_mo_orgname                hr_all_organization_units.name%type;
    v_mrc_count                 number(15):=null;
    rsob_count                  number;
    v_chart_count               number;
    counter                     integer;
    counter2                    integer;
    counter3                    integer;
    aptranscounter              integer;
    Transfer_mode               varchar2(1);
    checkcount                  integer;
    paymentcount                integer;
    invoicecount                integer;

    -- exceptions
    gl_set_of_books_name        exception;
    gl_set_of_books_id          exception;
    period_name                 exception;
    STOPEXECUTION               exception; 
    default_category            exception;
    leav_prog                   exception;

    --Program Units

    /*------- Function to check if a given Code Combination is valid --------------------*/

    Function  CheckCCID (p_ccid varchar2,p_sob_id number) return boolean
    Is
    valid_ccid  integer;
    is_valid boolean := TRUE;
    BEGIN
      select count(*)  into valid_ccid
      from   gl_code_combinations a, gl_sets_of_books b
      where  a.CHART_OF_ACCOUNTS_ID =b.CHART_OF_ACCOUNTS_ID
      and    NVL(a.start_date_active, sysdate ) <= sysdate
      and    NVL( a.end_date_active , sysdate ) >= sysdate
      and    a.code_combination_id = p_ccid
      and    a.enabled_flag = 'Y'
      and    b.set_of_books_id = p_sob_id;
      if valid_ccid = 1
        then return(is_valid);
      else 
        ErrorPrint('An Invalid Code Combination id was detected');
        ActionErrorPrint('This CCID is either invalid, disabled or End dated. Please review the Code combination and make the necessary corrections');
        return(FALSE);
      end if;
    EXCEPTION
      when others then
      ErrorPrint('Unexpected error occurred during Function CheckCCID');
      ActionErrorPrint('Please report this error using the feedback option on this test');
    END;

    /*----------- Function to check and validate period names entered ---------------*/

    Function CheckPeriod(p_period varchar2, p_sobid number) return boolean
    is
    v_period_count integer;
    is_valid boolean := TRUE;
    BEGIN
      IF :v_periodname = 'NONE'
      THEN 
      :v_periodname := upper(v_LATEST_OPENED_PERIOD_NAME);
      END IF; 
      select count(*) into v_period_count
      from   gl_period_statuses
      where  set_of_books_id = p_sobid
      and    application_id = 101
      and    upper(period_name) = :v_periodname
      and    closing_status <> 'N'
      ;
      if v_period_count= 1 
        then return is_valid;
      else
        return(FALSE);
      end if;
    EXCEPTION 
      when others then
      WarningPrint('Invalid Period Name was detected');
      ActionWarningPrint('Please ensure that this period exist in the calendar '||
      'and have status of Open or Future enterable');
    END; -- end check period 

    /*------------ Function to check and validate Currency code --------------------*/

    Function  CheckCurrency (p_currcode varchar2) return boolean
    Is
    valid_currency number(15);
    is_valid boolean := TRUE;
    BEGIN
      select count(*)  into valid_currency
      from fnd_currencies a
      where a.currency_code = p_currcode 
      and NVL(a.start_date_active, sysdate ) <= sysdate
      and    NVL( a.end_date_active , sysdate ) >= sysdate
      and    a.enabled_flag = 'Y';
      if valid_currency= 1
        then return(is_valid);
      else
        ErrorPrint('Invalid Currency code was detected');
        ActionErrorPrint('Please review the Code combination and make the necessary corrections');
        return(FALSE);
      end if;
    EXCEPTION
      when others then
      WarningPrint('Unable to retrieve currency information');
      ActionWarningPrint('Please ensure that this currency '||p_currcode||' exists');
    END;
    
    FUNCTION Previous_Period(p_current_period varchar2, p_appl_id number,
        p_sob_id number) return varchar2 is
    
        p_prev_period varchar2(10);
        p_period_counter  number;
        p_period_num number;
        p_max_num number;
    
    BEGIN    
        select EFFECTIVE_PERIOD_NUM, period_num into p_period_counter
        , p_period_num
        from  gl_period_statuses
        where application_id = p_appl_id
        and   set_of_books_id = p_sob_id
        and   closing_status <> 'N'
        and   upper(period_name) = p_current_period;
        
        select max(period_num) into p_max_num
        from  gl_period_statuses
        where application_id = p_appl_id
        and   set_of_books_id = p_sob_id;
        
        if (p_period_num >1)
         then 
          select period_name into p_prev_period
          from  gl_period_statuses
          where application_id = p_appl_id
          and   set_of_books_id = p_sob_id
          and closing_status <> 'N'
          and   effective_period_num = (p_period_counter - 1);
         else
          select period_name into p_prev_period
          from  gl_period_statuses
          where application_id = p_appl_id
          and   set_of_books_id = p_sob_id
          and closing_status <> 'N'
          and   effective_period_num = (p_period_counter - 10001 + p_max_num);
        end if;
    
     return (p_prev_period); 
    
    EXCEPTION when others then
            ErrorPrint('Failed to get previous period name');
            ActionErrorPrint('Please enter a valid period name');
    
    END;


    -- END Declare Section for Main Program

  BEGIN  -- main program

    -- Set Client ( validate user and responsibility )   
    Show_Header('205624.1','&v_Testlongname');
    IF :v_username is null THEN
      p_username := 'DUMMY';
    ELSE  
      p_username := :v_username;
    END IF;

    IF &v_respid IS NULL THEN
      p_respid := -10;     
    ELSE        
      p_respid := &v_respid;
    END IF;      

    BEGIN
      SELECT user_id into p_userid
      FROM   fnd_user where user_name = p_username;
    EXCEPTION when no_data_found then
      ErrorPrint('Username does not exist');
      ActionErrorPrint('Please enter a valid Username');
    END;
   
    Set_Client(p_username, p_respid);

    BEGIN
      SELECT b.responsibility_name
      INTO   p_respname
      FROM   fnd_responsibility_vl b
      WHERE  b.responsibility_id = p_respid;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           p_respname := Null;
    END;


    /******* Provide Parameter Information on output ***************************/
    SectionPrint('Running Diagnostics for');
    BRPrint;
    Tab0Print('Username          = '|| p_username || ' (ID ='||p_userid||')'); 
    Tab0Print('Responsibility    = '|| p_respname || ' (ID ='||p_respid||')');

    /* -- Check GL Set of Books Name and ID Profiles--*/
    BEGIN
      v_sobname:=CheckProfile('GL_SET_OF_BKS_NAME',p_userid, p_respid, 101, NULL,0);
      IF v_sobname is null then
        raise gl_set_of_books_name;
      END IF;

      
      v_sobid:=CheckProfile('GL_SET_OF_BKS_ID',p_userid, p_respid, 101, NULL,0);
      IF v_sobid is null then
        raise gl_set_of_books_id;
      END IF;
      EXCEPTION
      WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in Test when trying to retrieve '||
        'General Ledger Set of Books Profile Options');
        ActionErrorPrint('Please use the Feedback option to contact support');
      raise STOPEXECUTION;
    END;

    /*-- ---------------Get and validate GL SET OF BOOKS Settings -----------------*/
    BEGIN --Validation of Set of Books and return data
      Select 
      SET_OF_BOOKS_ID,
      CURRENCY_CODE,
      CHART_OF_ACCOUNTS_ID,
      NAME,
      PERIOD_SET_NAME,
      SUSPENSE_ALLOWED_FLAG,
      ACCOUNTED_PERIOD_TYPE,
      LATEST_OPENED_PERIOD_NAME,
      MRC_SOB_TYPE_CODE,
      TRACK_ROUNDING_IMBALANCE_FLAG,
       ROUNDING_CCID,
      CHART_OF_ACCOUNTS_NAME,
      USER_PERIOD_TYPE,
      SUSPENSE_CCID,
      CONSOLIDATION_SOB_FLAG
      into
      v_SET_OF_BOOKS_ID, 
      v_CURRENCY_CODE,
      v_CHART_OF_ACCOUNTS_ID,
      v_NAME,
      v_PERIOD_SET_NAME,
      v_SUSPENSE_ALLOWED_FLAG,
      v_ACCOUNTED_PERIOD_TYPE,
      v_LATEST_OPENED_PERIOD_NAME,
      v_MRC_SOB_TYPE_CODE,
      v_TRACK_ROUNDING_IMBAL_FLAG,
      v_ROUNDING_CCID,
      v_CHART_OF_ACCOUNTS_NAME,
      v_USER_PERIOD_TYPE,
      v_SUSPENSE_CCID,
      v_CONSOLIDATION_SOB_FLAG
      FROM gl_sets_of_books_v
      WHERE set_of_books_id = v_sobid;

      /* -- Get and validate period name. If no period name is entered then the latest
      open period name will be used for the anlaysis -- */

     
     IF :v_periodname = 'NONE' THEN
        p_periodname := upper(v_LATEST_OPENED_PERIOD_NAME);
      ELSIF :v_periodname IS NOT NULL THEN 
        p_periodname := :v_periodname; 
        IF CheckPeriod(p_periodname, v_sobid) = FALSE then
         Tab0Print('Invalid period name entered       = '||:v_orig_periodname); 
          BrPrint;
          raise period_name;

        END IF;
      END IF;
      IF :v_periodname = 'NONE' THEN
      Tab0Print('Period Name       = '||v_LATEST_OPENED_PERIOD_NAME);
      :v_orig_periodname := v_LATEST_OPENED_PERIOD_NAME;
      ELSE
      Tab0Print('Period Name       = '||:v_orig_periodname);
      END IF;
        
      p_previous_period := Previous_Period(p_periodname, 101 , v_sobid);

      /* -- Display MO Information in parameters ----------------------------------- */
      p_mo_org_id := Get_Profile_Option('ORG_ID');
      if p_mo_org_id is null then
        Tab0Print('Operating Unit    = Not set for this responsibility');
      else
        select name
        into   p_mo_orgname
        from   HR_ALL_ORGANIZATION_UNITS
        where  organization_id = p_mo_org_id;
        if p_mo_orgname is null then
          Tab0Print('Operating Unit    = '|| p_mo_org_id);
        else
          Tab0Print('Operating Unit    = '||p_mo_orgname||' (ID = '||p_mo_org_id||')');
        end if;       
      end if;    

      BEGIN
       select  distinct nvl(GL_TRANSFER_MODE, 'NONE') into Transfer_Mode
       from ap_system_parameters 
       where set_of_books_id = v_sobid
       and  org_id  =p_mo_org_id;
       EXCEPTION
      when others then
      DBMS_OUTPUT.PUT_LINE('ERROR - Unexpected error occurred when validating transfer mode');
      DBMS_OUTPUT.PUT_LINE('ACTION - Please report this error using the feedback option on this test');
      END;
 
      /*******************End Parameter Validation Section***************************/

      SectionPrint('General Ledger Setup Information for Set of Books '||v_sobname);
      BRPrint;
      Tab0Print('Set of Books - General Information');
      Tab1Print('Chart of Accounts    = '||v_CHART_OF_ACCOUNTS_NAME); 
      Tab1Print('Functional Currency  = '||v_CURRENCY_CODE); 
      Tab1Print('Calendar Name        = '||v_PERIOD_SET_NAME);
      Tab1Print('Period Type          = '||v_USER_PERIOD_TYPE);
      Tab1Print('Latest Opened Period = '||v_LATEST_OPENED_PERIOD_NAME);
     -- Tab1Print('GL Transfer Mode     = '||Transfer_Mode);
      BRPrint;
      Tab0Print('Set of Books - Account Information');
      if v_SUSPENSE_ALLOWED_FLAG = 'N' then
        Tab1Print('Suspense Accounting is not enabled for this Set of Books');
      elsif (v_SUSPENSE_ALLOWED_FLAG ='Y') and (v_SUSPENSE_CCID is null) then
        ErrorPrint('Suspense Accounting is enabled for this set of books but a '||
	'Suspense Account has not been defined');
        ActionErrorPrint('Please enter a valid suspense account in the General Ledger '||
	'Sets of Books Define Screen');
      elsif (v_SUSPENSE_ALLOWED_FLAG ='Y') and (v_SUSPENSE_CCID is not null) and
        CheckCCID(v_suspense_ccid,v_sobid) = false then
        ErrorPrint('The suspense account code combination entered for this Set of '||
	'Books is either disabled, or end dated');
        ActionErrorPrint('Please review the Suspense Accounts code combination in '||
	'GL Accounts screen in General Ledger to ensure it is not end dated, it '||
	'is enabled and the start date falls before todays date '||sysdate);
      elsif (v_SUSPENSE_ALLOWED_FLAG = 'Y') and (v_SUSPENSE_CCID is not null) and CheckCCID(v_suspense_ccid,v_sobid) = true then
        Tab1Print('Suspense Accounting is enabled for this set of books');
	Tab1Print('The Suspense Account (CCID = '||v_SUSPENSE_CCID||') in use for the set of books is enabled');
	Tab1Print(' and todays date = '||sysdate||' falls inside the start and end dates '||
	'for this combination');
      end if; 

      BEGIN --Suspense Accounting category and sources check 
        counter := 0;
        select count(*) into counter
        from gl_suspense_accounts_v
        where  set_of_books_id = v_sobid;

        if (counter = 0) and (v_SUSPENSE_ALLOWED_FLAG = 'Y')
          then
          WarningPrint('Suspense Accounting is enabled but Suspense Account Categories '||
	  'are not defined for this Set of Books');
          ActionWarningPrint('Please define Suspense Accounts Categories when the Suspense '||
	  'Accounting flag is checked');
        elsif (counter > 0) and (v_SUSPENSE_ALLOWED_FLAG <> 'Y')
          then
          WarningPrint('Suspense Account Categories are defined but Suspense '||
	  'Accounting is not enabled for this Set of Books');
          ActionWarningPrint('If required, please enable Suspense Accounting for this Set '||
	  'of Books');
        elsif (counter > 0) and (v_SUSPENSE_ALLOWED_FLAG = 'Y')
          then
          Tab1Print('Suspense Accounts are set up for the following Journal Source '||
	  'Names and Categories');
          sqltxt :=
          ' select user_je_source_name "User|Source|Name" '||
          ', je_category_name "Category|Name" '||
          ' from gl_suspense_accounts_v '||
          ' where '||
          ' set_of_books_id = '||v_sobid|| 
          ' and 1=1';
          Run_SQL(null,sqltxt);
        end if;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        v_liabilityAccount := -1;
        ErrorPrint('Suspense Accounts are not setup');
        ActionErrorPrint('Please verify whether Suspense Accounting should be setup');
        WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in Test when trying to retrieve Suspense '||
	'Account information');
        ActionErrorPrint('Please use the Feedback option to contact support');
      END; --Suspense Accounting check


      if v_TRACK_ROUNDING_IMBAL_FLAG = 'N' then
        Tab1Print('Rounding Difference Account Option is not enabled for this Set of Books');
      elsif (v_TRACK_ROUNDING_IMBAL_FLAG = 'Y') and (v_ROUNDING_CCID is null) then
       BRPrint;
        ErrorPrint('Rounding Differences is enabled for this set of books but a '||
	'Rounding Differences Account has not been defined');
        ActionErrorPrint('Please enter a valid Rounding Differences account in '||
	'the General Ledger Sets of Books Define Screen');
      elsif (v_TRACK_ROUNDING_IMBAL_FLAG = 'Y') and (v_ROUNDING_CCID is null) and CheckCCID(v_ROUNDING_CCID,v_sobid) = false then
        BRPrint;
        ErrorPrint('The Rounding Differences account code combination entered for '||
	'this Set of Books is either not enabled, or system date = '||sysdate||
	'falls outside of the start and end dates for the code combination');
        ActionErrorPrint('Please review the Rounding Differences Accounts code '||
	'combination in GL Accounts screen in General Ledger to ensure it is not end dated,it '||
	'is enabled and the start date falls before system date = '||sysdate);
      elsif (v_TRACK_ROUNDING_IMBAL_FLAG = 'Y') and (v_ROUNDING_CCID is not null)
        and CheckCCID(v_ROUNDING_CCID,v_sobid) = true then
        BRPrint;
        Tab1Print('Rounding Differences Account is enabled for this set of books');
        Tab1Print('The Rounding Differences Account is enabled and not end dated');
	Tab1print(' The CCID for the Rounding Differences Account Code Combination = '||v_ROUNDING_CCID);
      end if;

      BRPrint;
      Tab0Print('Set of Books - Consolidation');
      if v_CONSOLIDATION_SOB_FLAG = 'Y'
        then
        Tab1Print('This is a Consolidation Set of Books');
      else
        Tab1Print('This is not a Consolidation Set of Books'); 
      end if;

      -- Get AP liability Account 
      BRPrint;
      Tab0Print('Payables - Account Information');
      BEGIN
        select  distinct 
         ACCTS_PAY_CODE_COMBINATION_ID into
         v_liabilityAccount
        from ap_system_parameters
        where set_of_books_id = v_sobid;
      EXCEPTION 
        WHEN NO_DATA_FOUND THEN 
        v_liabilityAccount := -1;
        ErrorPrint('Liability Account is not defined');
        ActionErrorprint('Please setup a valid AP liability account');
        WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in Test when trying to retrieve General '||
	'Ledger Set of Books Profile Options');
        ActionErrorPrint('Please use the Feedback option to contact support');
        raise STOPEXECUTION;
      END;

      IF CheckCCID (v_liabilityAccount,v_sobid) = true then
        Tab1Print('The Payables Liability Account has been entered in '||
        'Payables Parameters screen');
        Tab1print('The account is enabled in General Ledger and the current system date = '||sysdate||', falls inside '||
        'the start and end dates for this combination');
        Tab1print('The CCID for the Payables Liability Account code combination = '||v_LiabilityAccount);
      ELSE
        ErrorPrint('The Payables Liability account code combination '||
        'is either not entered in Payables Options screen, not enabled, or '||
        'system date = '||sysdate||', falls outside of the start and end dates for '||
        'the code combination');
        ActionErrorPrint('Please review the Payables Liability Accounts code '||
        'combination in GL Accounts screen in General Ledger to ensure it is not end dated,it '||
        'is enabled and the start date falls before system date = '||sysdate);
      END IF;

      BRPrint;
      Tab0Print('Set of Books - Multiple Reporting Currencies');
      BEGIN
        select count(*) into v_mrc_count
        from fnd_product_groups 
        where multi_currency_flag = 'Y' ;

        IF v_mrc_count = 0
          then 
          Tab1Print('Multiple Reporting Currencies is not enabled for this Environment');
        ELSE 
          Tab1Print('Multiple Reporting Currencies is enabled for this Environment');
        END IF; 
      EXCEPTION 
        WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in Test when trying to retrieve MRC '||
        'Environment setup');
        ActionErrorPrint('Please use the Feedback option to contact support ');
        raise STOPEXECUTION;
      END;  -- Check for Multi Currencies

      IF v_mrc_count <> 0 then
        IF v_MRC_SOB_TYPE_CODE = 'R'
          then 
          Tab1Print('This is a Reporting Set of Books');
        ELSIF v_MRC_SOB_TYPE_CODE = 'P' then
          Tab1Print(v_sobname||' is a Primary Set of Books');
          -- Check for Multi Currencies  
          BEGIN --Reporting set of books 
            select count(*) into rsob_count
            from gl_mc_reporting_options a, gl_sets_of_books b 
            where a.primary_set_of_books_id = b.set_of_books_id
            and a.primary_set_of_books_id = v_sobid
            and a.enabled_flag = 'Y'
            ;
            IF rsob_count = 0 then 
              --Warning here as if a primary book, there should be a
              --reporting sobs associated
              WarningPrint('MRC is enabled but there are no Reporting Set of '||
              'Books associated to this Primary Set of Books');
              ActionWarningPrint('If required, assign a Reporting Set of Books '||
              'to this Primary Set of Books');
            ELSE
              Tab2Print('List of Reporting Sets of Books associated to '||
              'this Primary Set of Books');
              sqltxt := 
              'select a.reporting_set_of_books_id "Reporting|Set Of|Books ID" '||
              ', b.name "Name" '||
              ',a.reporting_currency_code "Reporting|Currency|Code" '||
              ' from gl_mc_reporting_options a, gl_sets_of_books b '||
              ' where a.primary_set_of_books_id = b.set_of_books_id '||
              ' and a.enabled_flag = ''Y''  '|| 
              ' and a.primary_set_of_books_id = '||v_sobid||
              ' group by a.reporting_set_of_books_id, b.name, reporting_currency_code' ;
              Run_SQL(null,sqltxt);
            END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
            ErrorPrint('Unable to determine MRC Reporting Set of Books information');
            ActionErrorprint('Please ensure that the MRC option table has at least one record');
          END; --Reporting set of books
        ELSE
          Tab1Print('This is not a MRC Set of Books');
        END IF;
        /**************** End Validation of MRC and Multi CurrencyInformation *************/
      END IF;
    EXCEPTION 
      WHEN NO_DATA_FOUND then
      ErrorPrint('Unable to determine Set of Books Information for Set of Books Name '||
      v_sobname||' set in Profile GL: Set of Books Name');
      ActionErrorPrint('Please use the Feedback option to contact support ');
      raise STOPEXECUTION;
      
	WHEN period_name then
      ErrorPrint('The period name entered is either invalid or has a status of Never Opened');
      ActionErrorprint('Please enter a valid period name for this calendar making sure that the'||
    ' the period does not have a Never Opened status');
      raise STOPEXECUTION; 

      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in Test when trying to retrieve General Ledger Set of '||
      'Books information');
      ActionErrorPrint('Please use the Feedback option to contact support');
      raise STOPEXECUTION;
    END; --validation of Set of books Information

    /******************* End Validation of Set of Books Information ******************/

    BEGIN
      select nvl(status, 'I')  into v_apinstalled
      from
      fnd_product_installations a, fnd_application aa 
      where a.application_id = 200 -- AP
      and a.application_id = aa.application_id
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      WarningPrint('No entry was found on the Production Installation table for product '||
      'Accounts Payable. No further Payables to General Ledger '||
      'reconciliation will be done');
      ActionWarningPrint('Please verify whether Payables is installed and make '||
      'the necessary adjustment in this table');
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in Test when trying to retrieve Payables '||
      'Installation information');
      ActionErrorPrint('Please use the Feedback option to contact support');
      raise STOPEXECUTION;
    END;

    BEGIN
      select NVL(status,'I')  into v_arinstalled
      from
      fnd_product_installations a, fnd_application aa
      where a.application_id = 222  -- AR
      and a.application_id = aa.application_id
      ;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      WarningPrint('No entry was found on the Production Installation table for '||
      'the product Accounts Receivable. No further Receivable to General Ledger '||
      'reconciliation will be done');
      ActionWarningPrint('Please verify whether Receivables is installed and make '||
      'the necessary adjustment in this table');
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in Test when trying to retrieve Receivables '||
      'Installation information');
      ActionErrorPrint('Please use the Feedback option to contact support');
      raise STOPEXECUTION;
    END;

    /******************* End Validation Installation status of AP and AR ******************/

    BRPrint;
    Sectionprint('Reconcile General Ledger Balances');
     BRPrint;
    -- First check that sum of the begin, period and end balances match in both debits
    -- and credits in GL_Balances.
    BEGIN
      SELECT round(sum(nvl(begin_balance_dr,0)),2)   
      ,      round(sum(nvl(begin_balance_cr,0)),2) 
      ,      round(sum(nvl(period_net_dr,0)),2) 
      ,      round(sum(nvl(period_net_cr,0)),2) 
      ,      round(sum(nvl(begin_balance_dr,0)) + sum(nvl(period_net_dr,0)),2) 
      ,      round(sum(nvl(begin_balance_cr,0)) + sum(nvl(period_net_cr,0)),2) 
      into   Begin_dr
      ,      Begin_cr
      ,      Period_dr
      ,      Period_cr
      ,      End_dr
      ,      End_cr
      FROM   gl_balances
      WHERE  set_of_books_id = v_sobid
      AND    upper(period_name) = p_periodname
      AND    template_id is null
      AND    actual_flag = 'A' 
      AND    currency_code = v_CURRENCY_CODE
      ;

      --Table output for gl balances as easier to read
      sqltxt :=  'select '
      ||'       round(sum(nvl(begin_balance_dr,0)),2) "Begin|Balance|Debit"  '
      ||',      round(sum(nvl(begin_balance_cr,0)),2) "Begin|Balance|Credit" '
      ||',      round(sum(nvl(period_net_dr,0)),2) "Period|Balance|Debit" '
      ||',      round(sum(nvl(period_net_cr,0)),2) "Period|Balance|Credit" '
      ||',      round(sum(nvl(begin_balance_dr,0)) + sum(nvl(period_net_dr,0)),2)
"Ending|Balance|Debit" '
      ||',      round(sum(nvl(begin_balance_cr,0)) + sum(nvl(period_net_cr,0)),2)
"Ending|Balance|Credit" '
      ||'FROM   gl_balances '
      ||'WHERE  set_of_books_id = '||v_sobid||' '
      ||'AND    upper(period_name) = '''||p_periodname||''' '
      ||'AND    template_id is null '
      ||'AND    actual_flag = ''A'' '
      ||'AND    currency_code = '''||v_CURRENCY_CODE||''' ';
      Tab0Print('General Ledger Balances for '||:v_orig_periodname);
      Run_SQL(null,sqltxt,'N');
      BRPrint;

      --changed format and wording of statements
      --Check that beginning balances agree credits/debits
      if begin_dr <> begin_cr then
        Errorprint('The General Ledger beginning actual debit balance for Set of Books '||
        v_sobname||' does not equal the total beginning actual credit balance '||
        'for currency = '||v_CURRENCY_CODE);
        ActionErrorPrint('Please log an TAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('Begin Debit and Credit Balances for '||:v_orig_periodname||' are equal');
      end if;

      --Check whether the beginning balances are zero..
      if begin_dr = 0 or begin_cr = 0 then
        WarningPrint('The Beginning debit and/or credit General Ledger balances are '||
        'equal to zero');
        ActionWarningPrint('If required, check that all transactions for the previous period '||
        'are posted');
      end if;

      --Check whether period debits equal period credits
      if Period_dr <> Period_cr then 
        Errorprint('The transactions debit balance is not equal to the credit balance '||
        'for Set of Book '||v_sobname);
        ActionErrorPrint('Please log an TAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('Debits equal Credits for the Balances for  '||:v_orig_periodname);
      end if;

      --Check whether any period movement occurred
      if  period_dr = 0 and period_cr =0 then 
        Tab1Print('Transactions have not been posted during for '||:v_orig_periodname);
      end if;

      --Check whether ending balances agree
      if end_dr <> end_cr then
        Errorprint('The total General Ledger ending actual debit balance not equal to the total '||
        ' ending actual credit balance for  currency = '||v_CURRENCY_CODE||' and '||
        'period = '||:v_orig_periodname);
        ActionErrorPrint('Please log an TAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('Debits equal Credits for the ending balances  '||:v_orig_periodname);
      end if;      

      -- check for zeros in end balances
      if begin_dr = 0 or begin_cr = 0 then
        WarningPrint('The total actual General Ledger ending debit and credit balances equal '||
        'to zero ');
        ActionWarningPrint('Please ensure that all transactions from the previous period are '||
        'posted properly and brought over to this period');
      end if;

      -- check that open balance + period transact = ending balance for debits
      if (begin_dr + period_dr) <> end_dr then
        ErrorPrint('The Beginning and period balances do not total to the ending balance');
        ActionErrorPrint('Please log a TAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('The beginning and period debit balance sum to the ending balance for  '||
        :v_orig_periodname);
      end if;

      -- check that open balance + period transact = ending balance for credits
      if (begin_cr + period_cr) <> end_cr then
        ErrorPrint('The beginning and period balances to not total the ending balance');
        ActionErrorPrint('Please log a TAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('The beginning and period credit balance sum to the ending balance for  '||
        :v_orig_periodname);
      end if;
    EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in Test when trying to retrieve GL_BALANCES information '||
      'for '||:v_orig_periodname);
      ActionErrorPrint('Please use the Feedback option to contact support');
      raise STOPEXECUTION;
    END;

    DECLARE
      cursor  c_getrecinfo10 is
      select  code_combination_id, currency_code,
              actual_flag, template_id, translated_flag, 
              budget_version_id,encumbrance_type_id
      from    gl_balances
      where   set_of_books_id = v_sobid
      and     upper(period_name) = p_periodname
      and     currency_code = v_currency_code
      group by set_of_books_id, code_combination_id, currency_code, period_name,
              actual_flag, template_id, translated_flag, budget_version_id,
              encumbrance_type_id
      having  count(*) > 1;
      v_getrecinfo10 c_getrecinfo10%ROWTYPE;

    BEGIN
      brprint; 
      Sectionprint('Duplicate Records in GL_Balances Table');
      brprint; 
      open  c_getrecinfo10;
      fetch c_getrecinfo10 into v_getrecinfo10;
      if c_getrecinfo10%NOTFOUND then
        Tab1Print('There are no duplicate transactions in the GL_BALANCES table for this period');   
      else
        ErrorPrint('There are duplicate transactions in the GL_BALANCES table for this period');
        ActionErrorPrint('Please review the following duplicate transactions in the '||
        'GL_BALANCES table and make the necessary corrections');
        sqltxt :=
        ' select  code_combination_id "CCID", currency_code "Currency|Code" '||
        ' ,sum(BEGIN_BALANCE_DR) "Begin|Balance|Debit" ,'||
        ' sum(BEGIN_BALANCE_CR) "Begin|Balance|Credit" '|| 
        ' from   gl_balances '||
        ' where set_of_books_id = '||v_sobid||
        ' and upper(period_name) ='''||p_periodname||''''||
        ' and actual_flag = ''A'' '||
        ' and currency_code = '''||v_currency_code||''''||
        ' group by set_of_books_id, code_combination_id, currency_code, period_name,'||
        ' actual_flag, template_id, translated_flag, budget_version_id,'||
        ' encumbrance_type_id'||
        ' having count(*) > 1'
        ;
        Run_Sql(null,sqltxt);
      end if;
    EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in Test when trying to retrieve Posted Transactions for '||:v_orig_periodname);
      ActionErrorPrint('Please use the Feedback option to contact support');
      raise STOPEXECUTION;
    END;

    --Check Further Balance information previously in GL Balance Check - for previous period

    BEGIN  -- begin balance check
     --p_previous_period := Previous_Period(p_periodname, 101, v_sobid);

     BRPrint;
     Sectionprint('General Ledger Balances for '||:v_orig_periodname||' and '||p_previous_period);
         
      sqltxt := 'select '
      ||'a.code_combination_id "CCID" '
      ||',      decode(c.account_type, ''A'',''Asset'',''E'',''Expense'',''L'', '
      ||'       ''Liability'',''R'',''Revenue'',''O'',''Owners/Equity'',''Unknown'') "TYPE" '
      ||',      b.period_num p_num '
      ||',      a.BEGIN_BALANCE_DR - a.BEGIN_BALANCE_CR + a.PERIOD_NET_DR - a.PERIOD_NET_CR '
      ||'       "END|PREVIOUS|PERIOD" '
      ||',      b.BEGIN_BALANCE_DR - b.BEGIN_BALANCE_CR  "BEGIN|NEXT|PERIOD" '
      ||'from   gl_balances a '
      ||',      gl_balances b '
      ||',      gl_code_combinations c '
      ||'where  a.set_of_books_id = '''||v_sobid||''' '
      ||'and    a.set_of_books_id = b.set_of_books_id '
      ||'and    a.code_combination_id = b.code_combination_id '
      ||'and    a.code_combination_id = c.code_combination_id '
      ||'and    a.actual_flag = b.actual_flag '
      ||'and    a.actual_flag = ''A'' '
      ||'and    a.currency_code = b.currency_code '
      ||'and    a.currency_code <> ''STAT'' '
      ||'and    a.template_id is null '
      ||'and    b.template_id is null '
      ||'and   (a.translated_flag = ''R'' or a.translated_flag is null) '
      ||'and   (b.translated_flag = ''R'' or b.translated_flag is null) '
      ||'and    upper(a.period_name) = '''||p_previous_period||''' '
      ||'and    upper(b.period_name) = '''||p_periodname||''' '
      ||'and    a.BEGIN_BALANCE_DR - a.BEGIN_BALANCE_CR + a.PERIOD_NET_DR - a.PERIOD_NET_CR '
      ||'       != b.BEGIN_BALANCE_DR - b.BEGIN_BALANCE_CR '
      ||'and         NOT EXISTS '
      ||'       (SELECT ''x'' ' 
      ||'       FROM    GL_CODE_COMBINATIONS c '
      ||'       where   a.code_combination_id = c.code_combination_id '
      ||'       and     c.account_type in (''E'', ''R'', ''O'') '
      ||'       and     b.period_num = 1) '
      ||'order by 1 ';
      
      counter := 0;
      counter := Run_SQL(null,sqltxt,'N');
      
      IF counter = 0 then
        Tab1Print('The beginning and ending balances for ALL CCIDS for the entered and previous periods were checked '||
        'and found to be correct according to the GL balance equation');
      ELSE
        ErrorPrint('The above CCIDS have wrong balances for the entered period.' ||
        'The GL_balances table may be corrupted.');
        ActionErrorPrint('Please ensure that all batches are posted correctly in General Ledger.' ||
        'If there are several CCIDS that are affected even after all batches are posted then '||
        'please log an iTAR with Oracle Support providing the output of this report');
      END IF;
    EXCEPTION 
      when others then
      ErrorPrint(sqlerrm||' occurred in Test when trying retrieve information '||
      'from beginning and ending balances from the GL_BALANCES table');
      ActionErrorPrint('Please use the Feedback option to contact support');
    END; -- Balance checks 
  

    BEGIN
      SectionPrint('GL_Balances and GL_JE_Lines Tables Information for '||:v_orig_periodname);
      -- Pick up all relevant invalid transactions
      -- Check for each ccid that exists in the journals tables for the period entered 
      -- in parameters, that the journals balance agrees with the gl_balances table.
      -- Also in reverse, the gl_balances matches the gl_journals.  This will mean that
      -- the Test also picks up ccids that exist in gl_journals but not in gl_balances
      -- and vice versa. 

      sqltxt := 'SELECT '
      ||'All_val.Currency, '
      ||'All_Val.CCID, '
      ||'DECODE(Jnl_Dr,Null,0, Jnl_Dr) "Journal|Debit", '
      ||'DECODE(Jnl_Cr,Null,0, Jnl_Cr) "Journal|Credit", '
      ||'DECODE(Bal_Dr,Null,0, Bal_Dr) "Balance|Debit", '
      ||'DECODE(Bal_Cr,Null,0, Bal_Cr) "Balance|Credit" '
      ||'FROM '
      /*  This selects all the CCIDs used for the period by 
      //  both Actual Journals, it excludes STAT, and the 
      //  Gl_Balances.
      */
      ||'(SELECT code_combination_Id  CCID, '
      ||'jh.CURRENCY_CODE Currency, '
      ||'jh.period_name Period, '
      ||'glSob.name Sob_Name, '
      ||'glSob.Set_of_books_id SOB_Id '
      ||'FROM  gl_je_lines jl, '
      ||'gl_je_headers jh, '
      ||'gl_sets_of_books glSob '
      ||'WHERE  upper(jh.period_name) = '''||p_periodname||''' '
      ||'AND  jh.SET_OF_BOOKS_ID = glSoB.SET_OF_BOOKS_ID '
      ||'AND  glSob.NAME LIKE '''||v_sobname||''' '
      ||'AND  jh.JE_HEADER_ID = jl.JE_HEADER_ID '
      ||'AND  jh.BUDGET_VERSION_ID IS NULL '
      ||'AND  jh.CURRENCY_CODE != ''STAT'' '
      ||'UNION  '
      ||'SELECT code_combination_id, '
      ||'bal.currency_code, '
      ||'bal.period_name Per_Name, '
      ||'glSob.name, '
      ||'glSob.Set_of_books_id '
      ||'FROM gl_balances bal, '
      ||'gl_sets_of_books glSob '
      ||'WHERE upper(bal.period_name) = '''||p_periodname||''' '
      ||'AND bal.SET_OF_BOOKS_ID = glSoB.SET_OF_BOOKS_ID '
      ||'AND glSob.NAME LIKE '''||v_sobname||''' '
      ||'AND bal.actual_flag = ''A'' '
      ||'AND bal.template_id IS NULL) All_val, '
      /* The first half selects the non-base currency lines using the entered amounts
      // and masks out for ENTERED Amount on those actual journals entered in
      // Currency other than the Set of Books base currency.
      */
      ||'(SELECT jeLine.PERIOD_NAME Period, '
      ||'glSoB.Set_of_Books_ID SoB_ID, '
      ||'glSoB.NAME Sob_Name, '
      ||'jeHead.Currency_CODE Currency, '
      ||'jeLine.CODE_COMBINATION_ID CCID, '
      ||'SUM(NVL(jeLine.ENTERED_DR,0)) Jnl_Dr, '
      ||'SUM(NVL(jeLine.ENTERED_CR,0)) Jnl_Cr '
      ||'FROM  GL.GL_JE_LINES jeLine, '
      ||'GL.GL_JE_HEADERS jeHead,  '
      ||'GL.GL_SETS_OF_BOOKS glSoB '
      ||'WHERE ( jeHead.JE_HEADER_ID=jeLine.JE_HEADER_ID ) '
      ||'AND ( glSoB.SET_OF_BOOKS_ID=jeLine.SET_OF_BOOKS_ID ) '
      ||'AND  glSoB.NAME LIKE '''||v_sobname||''' ' 
      ||'AND jeHead.ACTUAL_FLAG = ''A'' '
      ||'AND (Abs(jeLine.ENTERED_DR) != 0 '
      ||'OR  ABS(jeLine.ENTERED_CR) != 0) '
      ||'AND    jeHead.Currency_Code != glSob.Currency_Code '
      ||'AND jeHead.Currency_Code != ''STAT'' '
      ||'AND jeLine.STATUS = ''P'' '
      ||'AND upper(jeLine.PERIOD_NAME) = '''||p_periodname||''' ' 
      ||'GROUP BY  '
      ||'jeLine.CODE_COMBINATION_ID, '
      ||'jeLine.PERIOD_NAME, '
      ||'glSoB.Set_of_Books_ID, '
      ||'glSoB.NAME, ' 
      ||'jeHead.Currency_CODE ' 
      /*   This part selects for all the Journals affecting the Base Currency
      //  and so counts on those actual journals where the ACCOUNTED amount 
      //   is not equal to zero.
      */
      ||'UNION '
      ||'SELECT jeLine.PERIOD_NAME Period_Name, '
      ||'glSoB.Set_of_Books_ID SoB_ID, '
      ||'glSoB.NAME Sob_Name, '
      ||'glSob.CURRENCY_CODE, '
      ||'jeLine.CODE_COMBINATION_ID Jnl_Line_Count, '
      ||'SUM(nvl(jeLine.ACCOUNTED_DR,0)), '
      ||'SUM(NVL(jeLine.ACCOUNTED_CR,0)) '
      ||'FROM  GL.GL_JE_LINES jeLine, '
      ||'GL.GL_JE_HEADERS jeHead, '
      ||'GL.GL_SETS_OF_BOOKS glSoB '
      ||'WHERE ( jeHead.JE_HEADER_ID=jeLine.JE_HEADER_ID ) '
      ||'AND ( glSoB.SET_OF_BOOKS_ID=jeLine.SET_OF_BOOKS_ID ) '
      ||'AND  glSoB.NAME LIKE '''||v_sobname||''' ' 
      ||'AND jeHead.ACTUAL_FLAG = ''A'' '
      ||'AND jeHead.currency_code != ''STAT'' '
      ||'AND (Abs(jeLine.ACCOUNTED_DR) != 0 '
      ||'OR  ABS(jeLine.ACCOUNTED_CR) != 0) '
      ||'AND jeLine.STATUS = ''P'' '
      ||'AND upper(jeLine.PERIOD_NAME)= '''||p_periodname||''' '  
      ||'GROUP BY   '
      ||'jeLine.CODE_COMBINATION_ID, '
      ||'jeLine.PERIOD_NAME, '
      ||'glSoB.Set_of_Books_ID, '
      ||'glSoB.NAME, '
      ||'glSob.CURRENCY_CODE  '
      ||') Jnls, ' 
      /*  This inline view picks up the balances for the Balance Lines
      //  which are not translated and are do not belong to Summary Templates.
      */     
      ||'(SELECT glBal.CODE_COMBINATION_ID CCID, ' 
      ||'glSoB.NAME Sob_Name, '
      ||'glSOB.SET_OF_BOOKS_ID Sob_Id, '
      ||'glBal.CURRENCY_CODE Currency, '
      ||'glBal.PERIOD_NAME Period, '
      ||'SUM(NVL(glBal.PERIOD_NET_DR,0)) Bal_DR, ' 
      ||'SUM(NVL(glBal.PERIOD_NET_CR,0)) Bal_CR '
      ||'FROM  GL.GL_BALANCES glBal, '
      ||'GL.GL_SETS_OF_BOOKS glSoB '
      ||'WHERE ( glSoB.SET_OF_BOOKS_ID=glBal.SET_OF_BOOKS_ID ) '
      ||'AND upper(glBal.PERIOD_NAME) = '''||p_periodname||''' '
      ||'AND  glSoB.NAME Like '''||v_sobname||'''  ' 
      ||'AND (ABS(glBal.PERIOD_NET_DR) !=0 '
      ||'OR ABS(glBal.PERIOD_NET_CR) != 0) '
      ||'AND   glBal.TEMPLATE_ID IS NULL '
      ||'AND (glBal.TRANSLATED_FLAG IS NULL OR '
      ||'   glBal.TRANSLATED_FLAG = ''R'') '
      ||'AND  glBal.ACTUAL_FLAG = ''A'' '
      ||'AND glBal.currency_code != ''STAT'' '
      ||'GROUP BY  glBal.CODE_COMBINATION_ID,'
      ||'  glSoB.NAME, '
      ||'glSOB.SET_OF_BOOKS_ID, '
      ||'glBal.CURRENCY_CODE, '
      ||'glBal.Period_NAME) Bal ' 
      /*  The outer joins from the All_val In_line view to both the 
      //  Journals and Balances means that any missing values are 
      //  recorded.
      */
      ||'WHERE  All_Val.Currency = Jnls.Currency (+) '
      ||'AND  All_Val.Currency = Bal.Currency (+) '
      ||'AND  All_Val.CCID = jnls.CCID (+) '
      ||'AND  All_Val.CCID = Bal.CCID (+) '
      ||'AND  All_Val.Period = Jnls.Period (+) '
      ||'AND  All_Val.Period = Bal.Period (+) '
      ||'AND  All_Val.CCID= Jnls.CCID  (+) '
      ||'AND  All_Val.CCID= Bal.CCID  (+) '
      ||'AND  All_Val.sob_ID = Bal.sob_ID (+) '
      ||'AND  All_val.Sob_Id = Jnls.Sob_Id (+) '
      ||'AND (DECODE(Bal.Bal_DR, Null, 0, Bal.Bal_DR) != DECODE(Jnls.Jnl_Dr, NULL, 0,
Jnls.Jnl_DR) '
      ||'OR DECODE(Bal.Bal_CR, Null, 0, Bal.Bal_CR) != DECODE(Jnls.Jnl_CR, NULL, 0,
Jnls.Jnl_CR)) '
      ||'ORDER BY Currency '; 

      counter := 0;
      counter :=  Run_SQL(null,sqltxt,'N'); 

      if counter > 0 then
        ErrorPrint('There are discrepancies between Journals posted in General Ledger and '||
        'the General Ledger Balances for Set of Books = '||v_sobname||'  for '||:v_orig_periodname);
        ActionErrorPrint('Please review the above output and log an iTAR with Oracle Support '||
        'providing the output of this report');
      else
        Tab1Print('The Balances in the Journals tables match the Balance in the Balances '||
        'table for each currency and code combination recorded for '||:v_orig_periodname);
       end if;
    EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in Test when trying to retrieve Posted Transactions for '||:v_orig_periodname);
      ActionErrorPrint('Please use the Feedback option to contact support');
      raise STOPEXECUTION;
    END;  


    SectionPrint('General Ledger Interface Table Analysis for '||:v_orig_periodname);
    BRPrint;
    
      DECLARE
      v_startdate date;
      v_enddate date;

    BEGIN
      select a.START_DATE, a.END_DATE
      into   v_startdate, v_enddate
      from   gl_period_statuses a, gl_periods b
      where  a.period_name= b.period_name
      and    a.START_DATE =b.START_DATE
      and    a.END_DATE =b.END_DATE
      and    a.set_of_books_id =v_sobid
      and    a.application_id = 101
      and    upper(a.period_name) = p_periodname
      and    a.PERIOD_TYPE =b.PERIOD_TYPE
      and    a.PERIOD_YEAR= b.PERIOD_YEAR
      and    a.PERIOD_NUM = b.PERIOD_NUM
      and    a.closing_status <> 'N'
      ;
       
      DECLARE
        a number;
        cursor c_getglinterface is
        select  code_combination_id ccid
        ,       user_je_source_name source
        ,       user_je_category_name category
        ,       status
        ,       currency_code
        ,       upper(period_name) period_name
        ,       ACCOUNTING_DATE
        from    gl_interface a
        where   a.set_of_books_id = v_sobid
        and     a.ACCOUNTING_DATE >= v_startdate 
        and     a.ACCOUNTING_DATE <= v_enddate
        ;
        v_getglinterface c_getglinterface%ROWTYPE;

      BEGIN
        select count(*) into counter
        from gl_interface a
        where a.set_of_books_id = v_sobid
        and a.ACCOUNTING_DATE >= v_startdate 
        and a.ACCOUNTING_DATE <= v_enddate
        ;

      /* Validate Code Combination Ids in the GL Interface table  */

        if counter >0 then
          BEGIN
            a:=0;
            open c_getglinterface;
            fetch c_getglinterface into v_getglinterface;
            loop
              exit when c_getglinterface%NOTFOUND;
              if  v_getglinterface.CCID is not null then
                if  (CheckCCID(v_getglinterface.CCID,v_sobid) = FALSE) then
                  Tab1Print('Transaction with Source ='||v_getglinterface.source||
                  '  ,Category =  '||v_getglinterface.category||'  ,Status =  '||
                  v_getglinterface.status||'  and Period Name =  '
                  ||v_getglinterface.period_name||'  has invalid CCID = '
                  ||v_getglinterface.ccid);
                  a:=a+1;
                end if;
              end if;
              fetch c_getglinterface into v_getglinterface;
            end loop;

            if a = 0 then
              Tab1Print('Unposted records exist in the GL_INTERFACE table '||
              'for this Set of Books  but none of the CCIDS are disabled or end dated ');
            end if;
            close c_getglinterface ;
          EXCEPTION
            when others then
            ErrorPrint(sqlerrm||' occurred in Test when trying check for invalid ccids '||
            'in the GL_INTERFACE table.');
            ActionErrorPrint('Please use the Feedback option to contact support');
          END;


          /* Validate transactions in the GL Interface table for invalid period names  */
          BEGIN
            a:=0;
            open c_getglinterface;
            fetch c_getglinterface into v_getglinterface;
            loop
              exit when c_getglinterface%NOTFOUND;
              if v_getglinterface.period_name is not null then 
                if (CheckPeriod(v_getglinterface.period_name, v_sobid) = FALSE) 
                 /* Or (v_getglinterface.ACCOUNTING_DATE < v_startdate) 
                  Or (v_getglinterface.ACCOUNTING_DATE > v_enddate) */ 
                 then
                  Tab1Print('Transaction with Source = '||v_getglinterface.source||
                  '  ,Category =  '||v_getglinterface.category||
                  '  ,Status =  '||v_getglinterface.status||
                  '   and CCID =  '||v_getglinterface.ccid||
                  '  has invalid Period name = '||:v_orig_periodname);
                  a:=a+1;
                end if;
              end if;
              fetch c_getglinterface into v_getglinterface;
            end loop;

            if a = 0 then
              Tab1Print ('Unposted records exist in the GL_INTERFACE table '||
              'for this Set of Books  but none of the records have any invalid '||
              'period names');
            end if;
            close c_getglinterface ;
          EXCEPTION
            when others then
            ErrorPrint(sqlerrm||' occurred in Test when trying retrieve invalid period '||
            'information from the GL_INTERFACE table.');
            ActionErrorPrint('Please use the Feedback option to contact support');
          END;

          BEGIN
            a:=0;
            open c_getglinterface;
            fetch c_getglinterface into v_getglinterface;
            loop
              exit when c_getglinterface%NOTFOUND;
              if CheckCurrency(v_getglinterface.currency_code) = FALSE then
                Tab1Print('Transaction with Source = '||v_getglinterface.source||
                '  ,Category =  '||v_getglinterface.category||'  ,Status =  '||
                v_getglinterface.status||'  ,CCID =  '||v_getglinterface.ccid||
                '  and Period name =  '||v_getglinterface.period_name||
                '  has invalid Currency = '||v_getglinterface.currency_code);
                a:=a+1;
              end if;
              fetch c_getglinterface into v_getglinterface;
            end loop;

            if a = 0 then
              Tab1Print('Unposted records exist in the GL_INTERFACE table '||
              'for this Set of Books but none of the records have any invalid '||
              'Currency Codes');
            end if;
          EXCEPTION
            when others then
            ErrorPrint(sqlerrm||' occurred in Test when trying retrieve currency '||
            'information from the GL_INTERFACE table.');
            ActionErrorPrint('Please use the Feedback option to contact support');
          END;

        else
          Tab1Print('There are no records in the GL_INTERFACE table');
        end if;
      EXCEPTION
        when others then
        ErrorPrint('It is not possible to access the GL_INTERFACE table');
        ActionErrorPrint('Please check permissions on the table or whether '||
        'the table has been dropped');
      END;
    EXCEPTION
      when others then
      ErrorPrint(sqlerrm||' occurred in Test when trying retrieve information '||
      'from the GL_INTERFACE table');
      ActionErrorPrint('Please use the Feedback option to contact support');
    END;

    IF v_apinstalled = 'I' then -- AP is installed 
      --If AP is installed then run the AP Reconciliation section otherwise, do not run
      SectionPrint('Payables to General Ledger Reconciliation for '||:v_orig_periodname);
      BRPrint;
      --Check if there are any transactions in AP for the period entered in the parameters
      BEGIN
        aptranscounter := 0;
        select count(*)
        into   aptranscounter
        from   ap_ae_headers aeh
        ,      ap_ae_lines ael
        where  ael.ae_header_id = aeh.ae_header_id
        and    aeh.SET_OF_BOOKS_ID = v_sobid
        and    upper(aeh.PERIOD_NAME) = p_periodname
        and    source_table <> 'AP_INVOICE_DISTRIBUTIONS';

        IF aptranscounter > 0 then
          Tab1Print('Transactions are entered in Payables for '||:v_orig_periodname);

          --check the status of the transactions in Payables to determine
          --whether the transactions are transferred or not.
          counter2 := 0;
          select count(*)
          into   counter2
          from   ap_ae_headers aeh
          ,      ap_ae_lines ael
          where  ael.ae_header_id = aeh.ae_header_id
          and    aeh.SET_OF_BOOKS_ID = v_sobid
          and    upper(aeh.PERIOD_NAME) = p_periodname
          and    aeh.gl_transfer_flag = 'Y'
          and    source_table <> 'AP_INVOICE_DISTRIBUTIONS';


            --Check if the number of transferred ap transactions is
            --zero or if it is less than than the total number or 
            --transactions accounted for in period. If either are true
            --then print confirmation that not all the transactions
            --which have been accounted in AP have been transferred to
            --GL for the period entered in parameters or latest opened period
          IF counter2 = 0 or counter2 < aptranscounter then
           counter3 := aptranscounter-counter2;
            Tab1Print('There are '||counter3||' Payables '||
            'Transactions not yet transferred to General Ledger');
            -- display all Payables Transactions where Create Accounting Process
            -- has been run but not transferred to GL

-- For Checks
           
   	select count(*) into checkcount 
	from   ap_ae_headers aeh ,
	ap_ae_lines ael,
	ap_checks ch
	where  ael.ae_header_id = aeh.ae_header_id 
	and    ael.source_table = 'AP_CHECKS'
	and    ael.source_id = ch.check_id 
	and    aeh.SET_OF_BOOKS_ID = v_sobid
	and    upper(aeh.PERIOD_NAME) = p_periodname
	and    aeh.gl_transfer_flag <> 'Y'
	;

if checkcount = 0 then
Tab2Print('There are no UNTRANSFERRED Cheque Transactions ');
else
            sqltxt := 'select '
            ||'       count(ch.check_number) "No of|Checks" '
            ||',      aeh.ae_category "Category" '
            ||',      ael.ae_line_type_code "Line|Type" '
            ||',      decode(aeh.gl_transfer_flag,''Y'',''Transferred'', '
            ||'       ''N'',''Not Transferred'',''E'',''Error'',''Unknown'') "GL|Transfer" '
            ||'from   ap_ae_headers aeh '
            ||',      ap_ae_lines ael '
            ||',      ap_checks ch '
            ||'where  ael.ae_header_id = aeh.ae_header_id '
            ||'and    ael.source_table = ''AP_CHECKS'' '
            ||'and    ael.source_id = ch.check_id '
            ||'and    aeh.SET_OF_BOOKS_ID = '||v_sobid||' '
            ||'and    upper(aeh.PERIOD_NAME) = '''||p_periodname||''' '
            ||'and    aeh.gl_transfer_flag <> ''Y'' '
            ||'group by aeh.ae_category, ael.ae_line_type_code, '
            ||'       aeh.gl_transfer_flag ';
            Brprint;
            Tab2Print('The Following Payables - Checks Transactions are not yet Transferred to General Ledger');
            Run_SQL(null,sqltxt);
            Brprint;
 end if;

-- For AP Payments

	select count(app.invoice_payment_id) into paymentcount 
	from
	ap_ae_headers aeh,
	ap_ae_lines ael, 
	ap_invoice_payments app 
	where  ael.ae_header_id = aeh.ae_header_id 
	and    ael.source_table = 'AP_INVOICE_PAYMENTS'
	and    ael.source_id = app.invoice_payment_id 
	and    aeh.SET_OF_BOOKS_ID = v_sobid
	and    upper(aeh.PERIOD_NAME) = p_periodname
	and    aeh.gl_transfer_flag <>'Y' 
	;

if paymentcount  = 0 then
Tab2Print('There are no UNTRANSFERRED Payment Transactions ');

else

            sqltxt := 'select '
            ||'       count(app.invoice_payment_id) "No of|Payments" '
            ||',      aeh.ae_category "Category" '
            ||',      ael.ae_line_type_code "Line|Type" '
            ||',      decode(aeh.gl_transfer_flag,''Y'',''Transferred'', '
            ||'       ''N'',''Not Transferred'',''E'',''Error'',''Unknown'') "GL|Transfer" '
            ||'from   ap_ae_headers aeh '
            ||',      ap_ae_lines ael '
            ||',      ap_invoice_payments app '
            ||'where  ael.ae_header_id = aeh.ae_header_id '
            ||'and    ael.source_table = ''AP_INVOICE_PAYMENTS'' '
            ||'and    ael.source_id = app.invoice_payment_id '
            ||'and    aeh.SET_OF_BOOKS_ID = '||v_sobid||' '
            ||'and    upper(aeh.PERIOD_NAME) = '''||p_periodname||''' '
            ||'and    aeh.gl_transfer_flag <> ''Y'' '
            ||'group by aeh.ae_category, ae_line_type_code, '
            ||'       aeh.gl_transfer_flag ';

            Tab2Print('The Following Payables - Payments Transactions are not yet Transferred to General Ledger');
            Run_SQL(null,sqltxt);
            brprint;
end if;


-- For AP Invoices

	select 
	count(api.invoice_num) into invoicecount
	from   ap_ae_headers aeh ,
	ap_ae_lines ael ,
	ap_invoices api 
	where  ael.ae_header_id = aeh.ae_header_id 
	and    ael.source_table = 'AP_INVOICES'
	and    ael.source_id = api.invoice_id 
	and    aeh.SET_OF_BOOKS_ID = v_sobid
	and    upper(aeh.PERIOD_NAME) = p_periodname
	and    aeh.gl_transfer_flag <> 'Y' 
	;

if invoicecount  = 0 then
Tab2Print('There are no UNTRANSFERRED Invoice Transactions ');

else
            sqltxt := 'select '
            ||'       count(api.invoice_num) "No of|Invoices" '
            ||',      aeh.ae_category "Category" '
            ||',      ael.ae_line_type_code "Line|Type" '
            ||',      decode(aeh.gl_transfer_flag,''Y'',''Transferred'', '
            ||'       ''N'',''Not Transferred'',''E'',''Error'',''Unknown'') "GL|Transfer" '
            ||'from   ap_ae_headers aeh '
            ||',      ap_ae_lines ael '
            ||',      ap_invoices api '
            ||'where  ael.ae_header_id = aeh.ae_header_id '
            ||'and    ael.source_table = ''AP_INVOICES'' '
            ||'and    ael.source_id = api.invoice_id '
            ||'and    aeh.SET_OF_BOOKS_ID = '||v_sobid||' '
            ||'and    upper(aeh.PERIOD_NAME) = '''||p_periodname||''' '
            ||'and    aeh.gl_transfer_flag <> ''Y'' '
            ||'group by aeh.ae_category, ae_line_type_code, '
            ||'       aeh.gl_transfer_flag ';
            Tab2Print('The Following Payables - Invoices Transactions are not yet Transferred to General Ledger');
            Run_SQL(null,sqltxt);
            BrPrint;
end if;
          END IF;         

          IF counter2 = 0 then
            WarningPrint('Transactions have been entered in Payables '||
            'and accounted but have not as yet been transferred to  '||
            'General Ledger');
            ActionWarningPrint('Run Payables - Payables Transfer to '||
            'General Ledger process through the Submit Request screen to '||
            'transfer all accounted  Payables transactions to  '||
            'General Ledger');
             BrPrint;
          ELSIF counter2 < aptranscounter then
            WarningPrint(counter2||' of the '||aptranscounter||' entered and '||
            'accounted in Payables have been transferred to  '||
            'General Ledger');
            ActionWarningPrint('Run Payables - Payables Transfer to '||
            'General Ledger process through the Submit Request screen to '||
            'transfer all accounted Payables transactions to  '||
            'General Ledger');
             BrPrint;
          ELSIF counter2 = aptranscounter then
            Tab1Print('All transactions entered and accounted in '||
            'Payables have been transferred to General Ledger');
             BrPrint;
          END IF;

          IF counter2 > 0 then
            --Run checks on the transactions which have status of Transferred to GL
            --for this period.

            --Check whether any of the transferred transactions are in the Interface
            BEGIN
              counter := 0;
              select count(*) 
              into   counter
              from   gl_interface 
              where  SET_OF_BOOKS_ID = v_sobid
              and    upper(USER_JE_SOURCE_NAME) = 'PAYABLES'
              and    upper(period_name) = p_periodname
              ;

              IF counter  = 0 then
                Tab1Print('The General Ledger Interface table does not contain '||
                'any Payables transactions');
                BrPrint;
              ELSE
                WarningPrint('The General Ledger Interface table contains Payables '||
                'transactions which have not yet been imported into General Ledger');
                ActionWarningPrint('Run Journal Import to Import the following Payables '||
                'batches into General Ledger');
                BrPrint;
                sqltxt :=
                ' select  USER_JE_CATEGORY_NAME "Category" , '||
                ' STATUS "Status",  GROUP_ID "Group|ID" , count(*) "Total|Lines" , '||
                ' sum(entered_dr) "Total|Debit" ,sum(entered_cr) "Total|Credit" '|| 
                ' from gl_interface  '||
                ' where  SET_OF_BOOKS_ID ='|| v_sobid||
                ' and upper(USER_JE_SOURCE_NAME) = ''PAYABLES'' '||
                ' and upper(period_name) ='''|| p_periodname||''''|| --***
                ' group by USER_JE_CATEGORY_NAME, STATUS ,  GROUP_ID '
                ;
                            
                Run_Sql(null,sqltxt);
                BRPrint;
              END IF;
            EXCEPTION 
              WHEN OTHERS then   
              Errorprint(sqlerrm||' occurred in Test when trying to retrieve transactions in '||
              'GL_INTERFACE for '||:v_orig_periodname);
              ActionErrorPrint('Please use the Feedback option to contact support');
              raise STOPEXECUTION;
            END;

           
	    IF Transfer_Mode = 'D'
	    then
            --Check whether AP Transactions that are status transferred for the period
            --entered in parameters actually exist in GL.  Provide error output if transactions
            --are found to not exist in GL
            BEGIN
              counter := 0;
              select count(*)
              into   counter
              from   ap_ae_headers aeh,
                     ap_ae_lines ael
              where  ael.ae_header_id = aeh.ae_header_id
              and    upper(aeh.period_name) = p_periodname
              and    aeh.GL_TRANSFER_FLAG = 'Y'
              and    aeh.SET_OF_BOOKS_ID = v_sobid
              and    ael.gl_sl_link_id  not in 
                     (select jl.gl_sl_link_id  
                     from    gl_je_lines jl
                     where   jl.gl_sl_link_id is not null 
                     and     jl.SET_OF_BOOKS_ID = v_sobid)
              and    ael.gl_sl_link_id not in 
                     (select ji.gl_sl_link_id  
                     from    gl_interface ji
                     where   upper(period_name) = p_periodname
                     and     ji.gl_sl_link_id is not null   
                     and     SET_OF_BOOKS_ID = v_sobid)
              and    ael.gl_sl_link_id is not null
              ;

              IF counter = 0 then
                Tab1Print('Payables transactions with status = TRANSFERRED '||
                'in Payables exist in General Ledger for '||:v_orig_periodname);
              ELSE
                Tab1Print('The following transactions are posted in Payables '||
                'but are not in General Ledger');
                sqltxt :=
                ' select sum(ael.entered_dr) "Payables|Debit" , '||
                ' sum(ael.entered_cr) "Payables|Credit" , '||
                ' aeh.AE_CATEGORY "Category" , '|| 
                ' aeh.CREATION_DATE "Creation|Date", '||
                ' aeh.GL_TRANSFER_RUN_ID "Transfer|Run|Id" '||
                ' from   ap_ae_headers aeh, '||
                ' ap_ae_lines ael '||
                ' where ael.ae_header_id =aeh.ae_header_id '||
                ' and upper(aeh.period_name) ='''|| p_periodname||''''||
                ' and aeh.GL_TRANSFER_FLAG = ''Y'' '||
                ' and aeh.SET_OF_BOOKS_ID ='|| v_sobid ||
                ' and ael.gl_sl_link_id  not in (select jl.gl_sl_link_id  from gl_je_lines jl'||
                ' where jl.gl_sl_link_id is not null '||
                ' and jl.SET_OF_BOOKS_ID ='||v_sobid ||
                ' ) and ael.gl_sl_link_id not in (select ji.gl_sl_link_id  from gl_interface ji '||
                '                    where  upper(ji.period_name) = '''||p_periodname||''''||
                ' and ji.gl_sl_link_id is not null '||  
                ' and SET_OF_BOOKS_ID = '||v_sobid|| 
                ' ) and ael.gl_sl_link_id is not null '||
                ' group by aeh.AE_CATEGORY, aeh.CREATION_DATE, aeh.GL_TRANSFER_RUN_ID'
                ;
                Run_Sql(null,sqltxt);
              END IF;
            EXCEPTION 
              WHEN OTHERS then   
              ErrorPrint(sqlerrm||' occurred in Test when checking for missing Payables '||
              'posted transactions in General Ledger for '||:v_orig_periodname);
              ActionErrorPrint('Please use the Feedback option to contact support');
              raise STOPEXECUTION;
            END;

            -- Check that all the transactions transferred to GL are posted.
            BEGIN
              counter := 0;
              select count(*) into counter
              from   gl_je_lines jl, gl_je_headers jh
              where  jl.je_header_id = jh.je_header_id
              and    jh.period_name =jl.period_name
              and    jh.set_of_books_id =jl.set_of_books_id
              and    jh.actual_flag = 'A'
              and    jl.status != 'P'
              and    upper(jl.period_name) = p_periodname
              and    jl.gl_sl_link_id in 
                     (select ael.gl_sl_link_id 
                     from    ap_ae_headers aeh,ap_ae_lines ael
                     where   ael.ae_header_id =aeh.ae_header_id
                     and     upper(aeh.period_name) = p_periodname
                     and     aeh.GL_TRANSFER_FLAG = 'Y');

              IF counter = 0 then
                Tab1Print('Payables batches transferred to General Ledger in this period '||
                'are all successfully posted'); 
              ELSE
              BRprint;
                WarningPrint('The Following Payables Batches were Transferred but are still '||
                'not yet posted in GL');
                ActionWarningPrint('Please run Journals Post program in General Ledger to '||
                'post the following Payables batches');
                sqltxt :=
                ' select jh.name "Name",jh.je_category "Category", '||
                ' sum(entered_dr) "Total|Debit" , '||
                ' sum(entered_cr) "Total|Credit" '||
                ' from gl_je_lines jl, gl_je_headers jh '||
                ' where jl.je_header_id =jh.je_header_id '||
                ' and jh.period_name =jl.period_name '||
                ' and jh.set_of_books_id =jl.set_of_books_id '||
                ' and jh.actual_flag = ''A'' '||
                ' and jl.status != ''P'' '||
                ' and upper(jl.period_name) ='''||p_periodname||''''||
                ' and jl.gl_sl_link_id in (select ael.gl_sl_link_id  '||
                '                        from   ap_ae_headers aeh,ap_ae_lines ael '||
                '                        where ael.ae_header_id =aeh.ae_header_id '||
                '                         and upper(aeh.period_name) ='''||p_periodname||''''||
                '                         and aeh.GL_TRANSFER_FLAG = ''Y'' '||
                ') group by jh.name,jh.je_category' 
                ;
                Run_Sql(null,sqltxt);
              END IF;
            EXCEPTION 
              WHEN OTHERS then   
              Errorprint(sqlerrm||' occurred in Test when trying to retrieve confirm if Payables '||
              'transactions transfer to General Ledger have been posted in the General Ledger');
              ActionErrorPrint('Please use the Feedback option to contact support');
              raise STOPEXECUTION;
            END ;

            --Check that the Payables transactions have not had the period changed in GL
            BEGIN
              counter := 0;
              select count(*) 
              into   counter
              from   ap_ae_headers aeh, gl_je_lines jl,
                     gl_je_headers jh, ap_ae_lines ael
              where  ael.ae_header_id = aeh.ae_header_id
              and    ael.gl_sl_link_id = jl.gl_sl_link_id
              and    jl.je_header_id = jh.je_header_id
              and    upper(jh.je_source) = 'PAYABLES'
              and    upper(aeh.PERIOD_NAME) = p_periodname
              and    jl.period_name != aeh.period_name 
              and    aeh.GL_TRANSFER_FLAG = 'Y'
              and    jh.actual_flag = 'A'
              and    aeh.SET_OF_BOOKS_ID = v_sobid;

              IF counter = 0 then
                BrPrint;
                Tab1Print('Payables Batches Transferred to General Ledger are assigned to the '||
                'original period posted to in Payables');
              ELSE
                BrPrint;
                WarningPrint('The period originally associated to the following Payables batches '||
                'has been changed in General Ledger');
                ActionWarningPrint('Please make sure that the correct period is reflected '||
                'for each of the following batches');
                sqltxt := 
                ' select jh.name "Journal", jl.period_name "General|Ledger|Period", '||
                '        aeh.period_name "Payables|Period",  '||
                '        substr(ael.reference6,1,10) "Transaction" '||
                ' from   ap_ae_headers aeh, gl_je_lines jl, '||
                '        gl_je_headers jh, ap_ae_lines ael '||
                ' where  ael.ae_header_id =aeh.ae_header_id '||
                ' and    ael.gl_sl_link_id =jl.gl_sl_link_id '||
                ' and    jl.je_header_id =jh.je_header_id '||
                ' and    upper(jh.je_source) = ''PAYABLES'' '||
                ' and    upper(aeh.PERIOD_NAME) = '''||p_periodname||''''||
                ' and    jl.period_name != aeh.period_name '||
                ' and    aeh.GL_TRANSFER_FLAG = ''Y'' '||
                ' and    jh.actual_flag = ''A'' '||
                ' and    aeh.SET_OF_BOOKS_ID ='||v_sobid
                ;
                Run_Sql(null,sqltxt);
              END IF;
            EXCEPTION 
              WHEN OTHERS then   
              Errorprint(sqlerrm||' occurred in Test when trying to retrieve Payables Transactions '||
              'which have had a period change in General Ledger for '||:v_orig_periodname);
              ActionErrorPrint('Please use the Feedback option to contact support');
              raise STOPEXECUTION;
            END;

            --Check that the transactions agree between GL journals and AP
            DECLARE
              ok boolean :=TRUE;
              a number;

              cursor c_getbatches3 is
              select jh.name Journal,jl.PERIOD_NAME Period ,
                     ael.currency_code curr, sum(jl.ENTERED_DR) gl_debit,
                     sum(ael.entered_dr) ap_debit, sum(jl.entered_cr) gl_credit,  
                     sum(ael.entered_cr) ap_credit,
                     count(*) tran_count
              from   ap_ae_headers aeh, gl_je_lines jl,
                     gl_je_headers jh, ap_ae_lines ael
              where  ael.ae_header_id = aeh.ae_header_id
              and    ael.gl_sl_link_id = jl.gl_sl_link_id
              and    ael.gl_sl_link_id is not null
              and    jl.gl_sl_link_id is not null
              and    jl.je_header_id =jh.je_header_id
              and    upper(jh.je_source) = 'PAYABLES'
              and    jl.period_name = aeh.period_name 
              and    jh.actual_flag = 'A'
              and    aeh.SET_OF_BOOKS_ID = v_sobid
              and    upper(jl.PERIOD_NAME) = p_periodname
              and    aeh.GL_TRANSFER_FLAG = 'Y'
              group by jh.name,jl.PERIOD_NAME,ael.CURRENCY_CODE 
              ;
              v_getbatches3 c_getbatches3%ROWTYPE;

            BEGIN
              open c_getbatches3;
              fetch c_getbatches3 into v_getbatches3;
              IF c_getbatches3%NOTFOUND then
                BrPrint;
                WarningPrint('Transactions have not been posted to General Ledger from the '||
                'Payables for this period');
                ActionWarningPrint('If appropriate, please ensure that all Payables '||
                'transactions for this period are successfully processed and posted '||
                'to General Ledger');
              ELSE
                loop 
                  exit when c_getbatches3%NOTFOUND;
                  a:=a+1;
                  IF (v_getbatches3.gl_debit <> v_getbatches3.ap_debit) then 
                    ErrorPrint('General Ledger debit balance of '||v_getbatches3.gl_debit||
                    ' not equal to Payables debit balance of '||v_getbatches3.ap_debit);
                    ok := FALSE;
                  END IF;
                  IF (v_getbatches3.gl_credit <> v_getbatches3.ap_credit) then
                    ErrorPrint('Payables Journal  '||v_getbatches3.journal||' has General '||
                    'Ledger credit balance of '||v_getbatches3.gl_credit||' not equal to '||
                    'Payables credit balance of '||v_getbatches3.ap_credit);
                    ok := FALSE;
                  END IF;
                  IF v_getbatches3.gl_credit <> v_getbatches3.gl_debit then
                    ErrorPrint('Payables Journal '||v_getbatches3.journal||' has General '||
                    'Ledger credit balance of '||v_getbatches3.gl_credit||' not equal to '||
                    'General Ledger debit balance of '||v_getbatches3.gl_debit);
                    ok := FALSE;
                  END IF;
                  fetch c_getbatches3 into v_getbatches3;
                end loop;
                IF  ok = TRUE then
                  Tab1Print('Payables Batches in General Ledger for  '||:v_orig_periodname||
                  ' have had no changes applied to them');
                ELSIF ok = FALSE then
                  ActionErrorPrint('Please review the Journals in General Ledger and '||
                  'Payables to resolve the discrepancies.  Should further assistance be '||
                  'required, please log an iTAR with  Support provide the output of '||
                  'this Diagnostic tool');
                END IF;
              END IF;
            EXCEPTION 
              WHEN OTHERS then   
              Errorprint(sqlerrm||' occurred in Test when checking reconcilation between '||
              'General Ledger Journals and Payables transactions for '||:v_orig_periodname);
              ActionErrorPrint('Please use the Feedback option to contact support');
              raise STOPEXECUTION;
            END; -- reconciling balances between journal tables and ap tables

            -- Check the balance of the journals to ap trans by ap liability a/c
            DECLARE
              v_periodname varchar2(15);
              v_ccid number(15);
              v_cur_code varchar2(15);
              v_gldebit number(15,2):=0;
              v_apdebit number(15,2):=0;
              v_glcredit number(15,2):=0;
              v_apcredit number(15,2):=0;
            BEGIN
              counter := 0;
              select count(*)
              into   counter
              from   ap_ae_headers aeh, gl_je_lines jl, 
                     gl_je_headers jh, ap_ae_lines ael 
              where  ael.ae_header_id = aeh.ae_header_id 
              and    ael.gl_sl_link_id =jl.gl_sl_link_id 
              and    ael.CODE_COMBINATION_ID =jl.CODE_COMBINATION_ID 
              and    jl.je_header_id =jh.je_header_id 
              and    upper(jh.je_source) ='PAYABLES' 
              and    jl.period_name =aeh.period_name 
              and    aeh.SET_OF_BOOKS_ID = v_sobid
              and    upper(jl.PERIOD_NAME) = p_periodname 
              and    ael.CURRENCY_CODE=jh.CURRENCY_CODE 
              and    jh.Currency_code = v_currency_code
              and    ael.CODE_COMBINATION_ID = v_liabilityAccount
              and    jl.status = 'P' 
              and    jh.actual_flag = 'A' 
              and    aeh.GL_TRANSFER_FLAG = 'Y' 
              and    ael.gl_sl_link_id is not null 
              and    jl.gl_sl_link_id is not null 
              ; 

              BRPrint;
              SectionPrint('Payables - Liability Account Reconciliation '||
              'with General Ledger for '||:v_orig_periodname);
               BRPrint;
              IF counter = 0 then 
                Tab1Print('Transactions have not been posted to the Payables '||
                'Liability Account during for ('||:v_orig_periodname||')');
              ELSE
                select jl.PERIOD_NAME 
                ,      ael.CODE_COMBINATION_ID
                ,      ael.CURRENCY_CODE 
                ,      sum(jl.ENTERED_DR) gl_debit
                ,      sum(ael.entered_dr) ap_debit
                ,      sum(jl.entered_cr) gl_credit
                ,      sum(ael.entered_cr) ap_credit
                into   v_periodname, v_ccid, v_currency_code
                ,      v_gldebit, v_apdebit, v_glcredit, v_apcredit
                from   ap_ae_headers aeh
                ,      gl_je_lines jl
                ,      gl_je_headers jh
                ,      ap_ae_lines ael 
                where  ael.ae_header_id = aeh.ae_header_id 
                and    ael.gl_sl_link_id = jl.gl_sl_link_id 
                and    ael.CODE_COMBINATION_ID = jl.CODE_COMBINATION_ID 
                and    jl.je_header_id = jh.je_header_id 
                and    upper(jh.je_source) = 'PAYABLES' 
                and    jl.period_name = aeh.period_name 
                and    aeh.SET_OF_BOOKS_ID = v_sobid
                and    upper(jl.PERIOD_NAME) = p_periodname 
                and    ael.CURRENCY_CODE=jh.CURRENCY_CODE 
                and    jh.Currency_code = v_currency_code
                and    ael.CODE_COMBINATION_ID = v_liabilityAccount
                and    jl.status = 'P' 
                and    jh.actual_flag = 'A' 
                and    aeh.GL_TRANSFER_FLAG = 'Y' 
                and    ael.gl_sl_link_id is not null 
                and    jl.gl_sl_link_id is not null 
                group by jl.PERIOD_NAME,ael.CODE_COMBINATION_ID,ael.CURRENCY_CODE
                ; 

                IF (v_gldebit <> v_apdebit) or (v_glcredit <> v_apcredit) then
                  ErrorPrint('The Payables Liability Account is out of balance '||
                  'in General Ledger for ('||:v_orig_periodname||') and '||
                  'Set of Books ='||v_sobname);
                  ActionErrorPrint('Please ensure that all records are posted '||
                  'properly in General ledger');
                  Tab1Print('The Payables Total Debit Balance = '||v_apdebit||
                  ' while General Ledger total debit balance = '||v_gldebit);
                  Tab1Print(' The Payables Total Credit Balance = '||v_apcredit||
                  ' while General Leger total credit balance = '||v_glcredit);
                ELSIF (v_gldebit = v_apdebit) and (v_glcredit = v_apcredit) 
                  and (v_gldebit = 0) then 
                  Tab1Print(counter||' transactions were posted to the Payables '||
                  'Liability Account but it has zero balances both in Payables '||
                  'and General Ledger');
                ELSIF (v_gldebit = v_apdebit) and (v_glcredit = v_apcredit) then
                  Tab1Print('The Payables Liability Account (CCID = '||v_liabilityAccount||
                  ') is balanced with General Ledger for '||:v_orig_periodname);
                  Tab1Print('A total of '||counter||' transactions with currency = '||
                  v_currency_code ||' were processed for this period');
                  Tab1Print('The Payables Total Debit Balance of '||v_apdebit ||' is '||
                  'equal to the General Ledger total debit balance of '||v_gldebit);
                  Tab1Print('The Payables Total Credit Balance of '||v_apcredit ||
                  ' is equal to the General Ledger total credit balance of '||v_glcredit);
                END IF;
              END IF;
            EXCEPTION
              WHEN OTHERS then   
              ErrorPrint(sqlerrm||' occurred in Test when checking that balances '||
              'by Payables Liability Account for '||:v_orig_periodname);
              ActionErrorPrint('Please use the Feedback option to contact support');
              raise STOPEXECUTION;
            END;            

            --Check that no non-ap transactions have been posted to the ap liability account
            BEGIN
              counter := 0;
              select count(*) 
              into   counter
              from   ap_ae_headers aeh, gl_je_lines jl,
                     gl_je_headers jh, ap_ae_lines ael
              where  ael.ae_header_id =aeh.ae_header_id
              and    ael.gl_sl_link_id =jl.gl_sl_link_id
              and    jl.je_header_id =jh.je_header_id
              and    upper(jh.je_source) = 'PAYABLES'
              and    upper(aeh.PERIOD_NAME) = p_periodname
              and    jl.period_name !=aeh.period_name 
              and    aeh.GL_TRANSFER_FLAG = 'Y'
              and    jh.actual_flag = 'A'
              and    aeh.SET_OF_BOOKS_ID =v_sobid;

              IF counter = 0 then
                Tab1Print('Transactions from sources other than Payables have not been '||
                'posted to the Payables Liability Account for ('||:v_orig_periodname||')');
              ELSE
                WarningPrint('The following batches from other sources than Payables have '||
                'transactions posted to the Payables Liability Account for '||:v_orig_periodname);
                ActionWarningPrint('Please ensure that these entries were not inadvertently'||
                'posted to the liability account');
                sqltxt:=
                ' select jh.name "Batch" , '||
                ' jh.JE_CATEGORY "Category" , '||
                ' jh.JE_SOURCE "Source" ,  '||                        
                ' jh.PERIOD_NAME "Period", '||
                ' jh.CURRENCY_CODE "Currency",'||
                ' sum(jl.ENTERED_DR) "Total|Debits" ,sum(jl.ENTERED_CR) "Total|Credits" '||
                ' from gl_je_headers jh, gl_je_lines jl '||
                ' where jh.JE_HEADER_ID=jl.JE_HEADER_ID '||
                ' and jh.period_name =jl.period_name '||
                ' and jh.set_of_books_id =jl.set_of_books_id '||
                ' and upper(jh.JE_SOURCE) != ''PAYABLES'' '||
                ' and upper(jh.period_name) ='''||p_periodname||''''||
                ' and jh.status =''P'' '||
                ' and jl.status = ''P'' '||
                ' and jl.code_combination_id = '||v_liabilityAccount||
                ' and jh.set_of_books_id ='||v_sobid||
                ' group by jh.name, jh.JE_CATEGORY,jh.JE_SOURCE, jh.PERIOD_NAME,jh.CURRENCY_CODE'
                ;
                Run_Sql(null, sqltxt);
              END IF;
            EXCEPTION 
              WHEN OTHERS then   
              ErrorPrint(sqlerrm||' occurred in Test when trying to retrieve '||
              'incorrectly posted transactions to the Payables Liablity Account '||
              ' for '||:v_orig_periodname);
              ActionErrorPrint('Please use the Feedback option to contact support');
              raise STOPEXECUTION;
            END;
          ELSE
            Tab1Print('No further Reconciliation is required as no Payables '||
            'Transactions have been Transferred to General Ledger');
          END IF; -- End if there are not Transferred AP Balances for period
        ELSE
          Tab1Print('Payables to General Ledger Reconciliation '||
          'is not required for '||:v_orig_periodname||' as there are '||
          'no transactions created and accounted in Payables');
        END IF; -- End if there are any transactions in AP for the period.
	else
	tab1Print('No Accounts Payable Transactions were entered the for period');
 END IF; --End if Transfer Mode = D
 If Transfer_Mode = 'S'
 then
 tab1Print('Accounts Payable Transactions were Transferred to General Ledger in Summary Mode');
 tab1print('Details of AP to GL Reconciliation for this transfer mode are not available at this time');
 end if;
	EXCEPTION
        WHEN OTHERS then   
        ErrorPrint(sqlerrm||' occurred in Test when trying complete Payables '||
        'reconciliation for '||:v_orig_periodname);
        ActionErrorPrint('Please use the Feedback option to contact support');
      END;
    END IF; -- End if AP is installed

    IF -- Check if AR is installed 
      v_arinstalled = 'I' then

      Sectionprint('Receivables to General Ledger Reconciliation for '||:v_orig_periodname);
      BRPrint;
      Tab0Print('Reviewing Receivables batches transferred to General Ledger'); 

      DECLARE
        cursor c_getARinfo is
        select a.posting_control_id,
               a.creation_date,a.start_date,
               a.post_thru_date, a.status,
               a.run_gl_journal_import_flag
        from   ar_posting_control a
        where  a.gl_posted_date >= 
               (select start_date from gl_period_statuses
               where set_of_books_id =v_sobid
               and upper(period_name) = p_periodname
               and application_id = 101
               and closing_status <> 'N')
        and    a.gl_posted_date <=
               (select end_date from gl_period_statuses
               where set_of_books_id =v_sobid
               and upper(period_name) = p_periodname
               and application_id = 101
               and    closing_status <> 'N')
        and    not exists (select * from gl_je_batches b 
               where b.name like 'AR%' and b.name like '%Receivables%' 
               and b.name like 'AR ' || a.posting_control_id || '%') 
        and    ((a.posting_control_id in (select z.posting_control_id 
               from ar_receivable_applications z 
               where a.posting_control_id = z.posting_control_id )) 
        or     (a.posting_control_id in (select zz.posting_control_id 
               from ar_cash_receipt_history zz 
               where a.posting_control_id = zz.posting_control_id )) 
        or     (a.posting_control_id in (select zzz.posting_control_id 
               from ar_misc_cash_distributions zzz 
               where a.posting_control_id = zzz.posting_control_id )) 
        or     (a.posting_control_id in (select zzzz.posting_control_id 
               from ra_cust_trx_line_gl_dist zzzz 
               where a.posting_control_id = zzzz.posting_control_id )) 
        or     (a.posting_control_id in (select zzzzz.posting_control_id 
               from ar_adjustments zzzzz
               where a.posting_control_id = zzzzz.posting_control_id ) ) )
        and    exists (select * from gl_interface xx 
        where  a.posting_control_id = xx.group_id) 
        ;
        v_getARinfo c_getARinfo%ROWTYPE;

      BEGIN
        open c_getARinfo;
        fetch c_getARinfo into v_getARinfo;
        if c_getARinfo%NOTFOUND then
          Tab1Print('There are no posted Receivables Transactions '||
          ' for this period that are still in the GL_INTERFACE table');   
        else
          WarningPrint('The following transactions have been posted in '|| 
          'Receivables for this period but are not yet in General Ledger as '||
          'Journal Import has not yet picked them up to import into General Ledger');
          WarningPrint('If Journal Import Flag = N, then this means that '|| 
          'the transfer process was submitted from Receivables, but '||
          'Journal Import process has not been submitted for these batches');
          ActionWarningPrint('Please run the Journal Import process in '|| 
          'General Ledger to import the batch(s) into General Ledger ');
          WarningPrint('If Journal Import Flag = Y, and the records '||
          'are still in the GL_INTERFACE table then Journal '||
          'Import process may have errored out');
          ActionWarningPrint('Please review the transactions, the Journal '|| 
          'import log file as well as the output of the execution report and '||
          'make the corrections using the General Ledger Correct Journal screen '||
          'before re-running Journal Import from a General Ledger responsibility');
          sqltxt :=
          ' select a.posting_control_id "Posting|ID", '||
          ' a.creation_date "Creation|Date",a.start_date "Start|date", '||
          ' a.post_thru_date "Post|Thru|Date" , a.status "Status", '||
          ' a.run_gl_journal_import_flag "Journal|Import|Flag" '||
          ' from ar_posting_control a '||
          ' where a.gl_posted_date >= '||
          ' (select start_date from gl_period_statuses '||
          ' where set_of_books_id ='||v_sobid||
          ' and upper(period_name) ='''||p_periodname||''''||
          ' and application_id = 101 and   closing_status <> ''N'') '||
          ' and a.gl_posted_date <= '||
          ' (select end_date from gl_period_statuses '||
          ' where set_of_books_id = '||v_sobid||
          ' and upper(period_name) ='''||p_periodname||''''||
          ' and application_id = 101 and   closing_status <> ''N'') '||
          ' and not exists (select * from gl_je_batches b '|| 
          ' where b.name like ''AR%'' and b.name like ''%Receivables%'' '|| 
          ' and b.name like ''AR '' || a.posting_control_id || ''%'') '|| 
          ' and ((a.posting_control_id in (select z.posting_control_id '|| 
          ' from ar_receivable_applications z '||
          ' where a.posting_control_id = z.posting_control_id )) '|| 
          ' or (a.posting_control_id in (select zz.posting_control_id '|| 
          ' from ar_cash_receipt_history zz  '||
          '  where a.posting_control_id = zz.posting_control_id )) '|| 
          ' or (a.posting_control_id in (select zzz.posting_control_id '|| 
          ' from ar_misc_cash_distributions zzz '||
          ' where a.posting_control_id = zzz.posting_control_id )) '|| 
          ' or (a.posting_control_id in (select zzzz.posting_control_id '|| 
          ' from ra_cust_trx_line_gl_dist zzzz '||
          ' where a.posting_control_id = zzzz.posting_control_id )) '|| 
          ' or (a.posting_control_id in (select zzzzz.posting_control_id '||
          ' from ar_adjustments zzzzz '||
          ' where a.posting_control_id = zzzzz.posting_control_id ) ) ) '||
          ' and  exists (select * from gl_interface xx  '||
          ' where a.posting_control_id = xx.group_id) ' 
          ;
        end if;
      EXCEPTION 
        WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in Test during check for Receivables '||
        'transactions not yet posted into General Ledger for '||:v_orig_periodname);
        ActionErrorPrint('Please use the Feedback option to contact support');
        raise STOPEXECUTION;
      END ;

      DECLARE
        cursor c_getarinfo11 is
        select a.posting_control_id,
               a.creation_date,a.start_date,
               a.post_thru_date, a.status,
               a.run_gl_journal_import_flag
        from   ar_posting_control a
        where  a.gl_posted_date >= 
               (select start_date from gl_period_statuses
               where set_of_books_id =v_sobid
               and upper(period_name) = p_periodname
               and application_id = 101
               and closing_status <> 'N')
        and    a.gl_posted_date <=
               (select end_date from gl_period_statuses
               where set_of_books_id =v_sobid
               and upper(period_name) = p_periodname
               and application_id = 101
               and  closing_status <> 'N')
        and    not exists 
               (select * from gl_je_batches b 
               where b.name like 'AR%' and b.name like '%Receivables%' 
               and b.name like 'AR ' || a.posting_control_id || '%') 
        and    ((a.posting_control_id in 
               (select z.posting_control_id 
               from ar_receivable_applications z 
               where a.posting_control_id = z.posting_control_id )) 
        or     (a.posting_control_id in 
               (select zz.posting_control_id 
               from ar_cash_receipt_history zz 
               where a.posting_control_id = zz.posting_control_id )) 
        or     (a.posting_control_id in (select zzz.posting_control_id 
               from ar_misc_cash_distributions zzz 
               where a.posting_control_id = zzz.posting_control_id )) 
        or     (a.posting_control_id in (select zzzz.posting_control_id 
               from ra_cust_trx_line_gl_dist zzzz 
               where a.posting_control_id = zzzz.posting_control_id )) 
        or     (a.posting_control_id in (select zzzzz.posting_control_id 
               from ar_adjustments zzzzz
               where a.posting_control_id = zzzzz.posting_control_id ) ) )
        and    not exists (select * from gl_interface xx 
               where a.posting_control_id = xx.group_id);
        v_getarinfo11 c_getarinfo11%ROWTYPE;

      BEGIN
        open c_getarinfo11;
        fetch c_getarinfo11 into v_getarinfo11;
        if  c_getarinfo11%NOTFOUND then
          Tab1Print('Posted Receivables Transactions for '||
          '('||:v_orig_periodname||') have been successfully transferred to General Ledger '||
          'and imported via Journal Import');
        else
          ErrorPrint('The following transactions have been posted in Receivables '||
          'for this period but are not in General Ledger');
          ActionErrorPrint('Review all the following notes detailed below for '||
          'information on how to resolve these issues. If additional help is '||
          'required, please log a TAR with  Support providing an output '||
          'of this report');
          ActionErrorLink('Please see note','1015419.6', 'How to unpost '|| 
          'Transactions in Accounts Receivable'); 
          --All messages to tab1print to make it easier to read 
          Tab1Print('Records with status = Running  means that '||
          'an error occurred during the original posting run in Receivables. Please '||
          'address this problem by reviewing the logs for that Receivables to General '||
          'Ledger post');
          Tab1Print('Records with Journal Import Flag = N, means '||
          'that the batch was transferred from Receivables, but the records were not '||
          'imported into General Ledger.  These records are no longer in General Ledger '||
          'Interface Table');          
          Tab1Print('Records with Journal Import Flag = Y means '||
          'that the batch was successfully transferred and imported in to General '||
          'Ledger but the record cannot now be found in the General Ledger');
          Tab2Print('If the Unposted run will be done in Receivables to unpost the '||
          'records and re-process them. It should be remembered that the '||
          'gl_date on these records should be in an open period.');
          sqltxt := 
          ' select a.posting_control_id "Posting|Control|ID" , '||
          ' a.creation_date "Creation|Date" , '||
          ' a.start_date "Start|Date" , '||
          ' a.post_thru_date "Post|Through|Date" , '||
          ' a.status "Status", '||
          ' a.run_gl_journal_import_flag "Journal|Import|Flag" '||
          ' from ar_posting_control a '||
          ' where a.gl_posted_date >= '||
          '   (select start_date from gl_period_statuses '||
          '   where set_of_books_id = '||v_sobid||
          '   and upper(period_name) ='''||p_periodname||''' '||
          '   and application_id = 101 and   closing_status <> ''N'') '||
          ' and a.gl_posted_date <= '||
          '   (select end_date from gl_period_statuses '||
          '   where set_of_books_id ='||v_sobid||
          '   and upper(period_name) ='''||p_periodname||''' '||
          '   and application_id = 101 and    closing_status <> ''N'') '||
          ' and not exists '||
          '   (select * from gl_je_batches b '|| 
          '   where b.name like ''AR%'' '|| 
          '   and b.name like ''%Receivables%'' '|| 
          '   and b.name like  ''AR'' || a.posting_control_id ||  ''%'' '|| 
          '   )  '||
          ' and ((a.posting_control_id in '||
          '   (select z.posting_control_id '|| 
          '   from ar_receivable_applications z  '||
          '   where a.posting_control_id = z.posting_control_id )) '|| 
          ' or (a.posting_control_id in '||
          '   (select zz.posting_control_id '|| 
          '   from ar_cash_receipt_history zz '||
          '   where a.posting_control_id = zz.posting_control_id )) '|| 
          ' or (a.posting_control_id in '||
          '   (select zzz.posting_control_id '||
          '   from ar_misc_cash_distributions zzz '||
          '   where a.posting_control_id = zzz.posting_control_id )) '|| 
          ' or (a.posting_control_id in '||
          '   (select zzzz.posting_control_id '|| 
          '   from ra_cust_trx_line_gl_dist zzzz '||
          '   where a.posting_control_id = zzzz.posting_control_id )) '|| 
          ' or (a.posting_control_id in '||
          '   (select zzzzz.posting_control_id '|| 
          '   from ar_adjustments zzzzz '||
          '   where a.posting_control_id = zzzzz.posting_control_id ) ) ) '||
          ' and not exists (select * from gl_interface xx '||
          ' where a.posting_control_id = xx.group_id) '
          ;
          Run_SQL(null,sqltxt);
        end if;
      EXCEPTION 
        WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in Test during check for missing Receivables '||
        'transactions in General Ledger for '||:v_orig_periodname);
        ActionErrorPrint('Please use the Feedback option to contact support');
        raise STOPEXECUTION;
      END;

      DECLARE
        cursor c_getARinfo13 is
        select a.posting_control_id,
               a.creation_date,a.start_date,
               a.post_thru_date, a.status,
               a.run_gl_journal_import_flag
        from   ar_posting_control a
        where  a.gl_posted_date >= 
               (select start_date from gl_period_statuses
               where set_of_books_id =v_sobid
               and upper(period_name) = p_periodname
               and application_id = 101
               and closing_status <> 'N')
        and    a.gl_posted_date <=
               (select end_date from gl_period_statuses
               where set_of_books_id =v_sobid
               and upper(period_name) = p_periodname
               and application_id = 101
               and closing_status <> 'N')
        and    exists (select * from gl_je_batches b ,gl_je_headers a
               where b.name like 'AR%' and b.name like '%Receivables%' 
               --  and b.name like 'AR ' || a.posting_control_id || '%' 
               and  a.je_batch_id = b.je_batch_id
               and a.je_batch_id is not null
               and a.set_of_books_id = b.set_of_books_id
               and a.set_of_books_id = v_sobid
               and upper(a.period_name) !=p_periodname)
        and    ((a.posting_control_id in (select z.posting_control_id 
               from ar_receivable_applications z 
               where a.posting_control_id = z.posting_control_id )) 
        or     (a.posting_control_id in (select zz.posting_control_id 
               from ar_cash_receipt_history zz 
               where a.posting_control_id = zz.posting_control_id )) 
        or     (a.posting_control_id in (select zzz.posting_control_id 
               from ar_misc_cash_distributions zzz 
               where a.posting_control_id = zzz.posting_control_id )) 
        or     (a.posting_control_id in (select zzzz.posting_control_id 
               from ra_cust_trx_line_gl_dist zzzz 
               where a.posting_control_id = zzzz.posting_control_id )) 
        or     (a.posting_control_id in (select zzzzz.posting_control_id 
               from ar_adjustments zzzzz
               where a.posting_control_id = zzzzz.posting_control_id ) ) )
        ;
        v_getARinfo13 c_getARinfo13%ROWTYPE;

      BEGIN
        open c_getARinfo13;
        fetch c_getARinfo13 into v_getARinfo13;
        if c_getARinfo13%NOTFOUND then
          Tab1Print('Period changes were not made in General Ledger to any '||
          'of the Receivables batches that were transferred to '||
          'General Ledger for this period');
        else
          WarningPrint('The following transactions have been posted in '||
          'Receivables for this period but are in General Ledger '||
          'with a different period name');
          ActionWarningPrint('If required, please review the transactions and take '||
          'appropriate action');
          sqltxt :=
          ' select a.posting_control_id "Posting|Control|ID" , '||
          ' a.creation_date "Creation|Date" ,a.start_date "Start|Date" , '||
          ' a.post_thru_date "Post|Thru|Date" , a.status "Status", '||
          ' a.run_gl_journal_import_flag "Journal|Import|Flag" '||
          '  from ar_posting_control a '||
          ' where a.gl_posted_date >=  '||
          ' (select start_date from gl_period_statuses '||
          ' where set_of_books_id = '||v_sobid||
          ' and upper(period_name) ='''||p_periodname||''''||
          ' and application_id = 101 and    closing_status <> ''N'') '||
          ' and a.gl_posted_date <= '||
          ' (select end_date from gl_period_statuses '||
          ' where set_of_books_id ='||v_sobid||
          ' and upper(period_name) ='''||p_periodname||''''||
          ' and application_id = 101 and  closing_status <> ''N'') '||
          '  and  exists (select * from gl_je_batches b ,gl_je_headers a '||
          '  where b.name like ''AR%'' and b.name like ''%Receivables%'' '|| 
          --'   and b.name like ''AR '' || a.posting_control_id || ''%''  '||
          '   and  a.je_batch_id = b.je_batch_id '||
          '   and a.je_batch_id is not null '||
          '   and a.set_of_books_id = b.set_of_books_id '||
          '   and a.set_of_books_id = '||v_sobid||
          '   and upper(a.period_name) !='''||p_periodname||''''||
          ' )   and ((a.posting_control_id in (select z.posting_control_id '|| 
          '       from ar_receivable_applications z  '||
          '        where a.posting_control_id = z.posting_control_id )) '|| 
          '      or (a.posting_control_id in (select zz.posting_control_id '||
          '       from ar_cash_receipt_history zz  '||
          '      where a.posting_control_id = zz.posting_control_id )) '|| 
          '     or (a.posting_control_id in (select zzz.posting_control_id '||
          '     from ar_misc_cash_distributions zzz '||
          '    where a.posting_control_id = zzz.posting_control_id )) '|| 
          '     or (a.posting_control_id in (select zzzz.posting_control_id '||
          '     from ra_cust_trx_line_gl_dist zzzz  '||
          '    where a.posting_control_id = zzzz.posting_control_id )) '|| 
          '    or (a.posting_control_id in (select zzzzz.posting_control_id '||
          '     from ar_adjustments zzzzz '||
          '     where a.posting_control_id = zzzzz.posting_control_id ) ) ) ' ;
          Run_Sql(null, sqltxt);
          ActionWarningPrint('Please review the Receivables batch in '||
          'General Ledger to determine why the periods were changed. If this '||
          'was done in error then it may be possible to reverse the batch in '||
          'the current General Ledger period and then reverse the reversed '||
          'batch and post it in the correct Receivables period ');
        end if;
      EXCEPTION 
        WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in Test during check for Receivables '||
        'transactions where period has been changed in General Ledger for '||:v_orig_periodname);
        ActionErrorPrint('Please use the Feedback option to contact support');
        raise STOPEXECUTION;
      END;

    END IF; -- End AR Section

    SectionPrint('References');
    BRPrint;
    BEGIN
      Show_link('131471.1');
      Actionprint('Self Service Tool Kit for General Ledger');
      Show_link('116938.1');
      ActionPrint('How to Keep Users From Modifying Imported Unposted Batches');
      Show_link('135610.1');
      ActionPrint('Troubleshooting Journal Import');
      Show_link('130542.1');
      ActionPrint('General Ledger: Journal Import Process ');
      Show_link('106647.1');
      ActionPrint('AP Transfer to GL (Posting) Troubleshooting Guide');
      Show_link('135433.1');
      ActionPrint('General Ledger Open/Close Period FAQ');
    EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in Test during check for missing Receivables '||
      'transactions in General Ledger for '||:v_orig_periodname);
      ActionErrorPrint('Please use the Feedback option to contact support');
      raise STOPEXECUTION;

    END;

    /* ------------------------ Feedback ------------------------------------- */
    Brprint; 
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    /* --------------------------------- Exception Section --------------------------------
*/ 

  EXCEPTION
    WHEN gl_set_of_books_id then 
    ErrorPrint('The Set of books id profile option is not set for this responsibility');
    ActionErrorPrint('This Profile Option must be set in order for a more '||
    'comprehensive General Ledger set up test to be done');
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    WHEN gl_set_of_books_name then
    ErrorPrint('The Set of books name profile option is not set for this responsibility');
    ActionErrorPrint('This Profile Option should be set in order for a more '||
    'comprehensive General Ledger set up test to be done'); 
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    WHEN period_name then
    ErrorPrint('The period name entered is invalid');
    ActionErrorprint('Please enter a valid period name for this calendar making sure that the'||
    'correct case is used');
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    WHEN STOPEXECUTION then 
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    WHEN OTHERS then -- exception begin 2
    brprint;
    ErrorPrint(sqlerrm||' occurred in Test');
    ActionErrorPrint('Please use the Feedback option to contact support');
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');
    brprint; 

  END; -- MAIN PROGRAM

EXCEPTION 
  WHEN OTHERS then   -- exceptions begin 1
  Brprint;
  Errorprint(sqlerrm||' occurred in Test');
  ActionErrorPrint('Please use the Feedback option to contact support');
  Brprint; 
    Show_Footer('&v_Testlongname', '&v_headerinfo');
  Brprint;
END; -- API
/  

REM  ==============SQL PLUS Environment setup=================================
Spool off
Set termout on
set feedback on
set verify off 
set echo off 
set trimout off
set trimspool off
set heading on
set autoprint off

PROMPT 
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================
