undefine v_headerinfo
Define   v_headerinfo = '$Header: GLCheckSetup115.sql 1.14 03-DEC-2003 support $'
undefine v_testlongname
Define   v_testlongname = 'General Ledger Setup Diagnostic Test'

REM ====================================================================
REM Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM Oracle Support Services. All rights reserved.
REM ====================================================================
REM PURPOSE:                Check Setup
REM PRODUCT:                General Ledger (GL)
REM PRODUCT VERSIONS:       11.5
REM PLATFORM:               Generic
REM PARAMETERS:             Apps username
REM                         Responsibility to be chosen from list
REM                         OFAInstall ('Y' or 'N')
REM
REM ====================================================================
REM ====================================================================
REM USAGE:              sqlplus <username>/<pwd>[@<TNS alias>]
REM EXAMPLE:            start GLCheckSetup115.sql
REM OUTPUT:             GLCheckSetup115_<respID>_diag.html
REM ====================================================================
REM ====================================================================
REM CHANGE HISTORY:
REM  1.0  02-Jul-2002 bbrown   Created
REM  1.1  29-Jul-2002 azwarren modifications for team qa
REM  1.3  02-Aug-2002 mcasalgr minor mods for final QA
REM  1.5  06-Feb-2003 avmulroy modification made to all calls to checkprofile
REM                            changed parameters passed to correct order
REM  1.6  26-Apr-2003 bbrown   Increase description variable to 240 to 
REM                            match the table column size
REM  1.7  07-OCT-2003 dbezemer Indentation, code fixing, enhancements
REM  1.8  24-OCT-2003 dbezemer Enhancements, add respID to output file
REM  1.9  12-NOV-2003 dbezemer Team QA feedback
REM  1.10 24-NOV-2003 dbezemer minor changes
REM  1.11 24-NOV-2003 amulroy  TQA changes: Added exception handling to
REM                            all blocks.  Aligned all table output
REM                            to last indentation used (ignoring Error/Warnings)
REM                            Amend document sequence checks.  Fixed
REM                            all displays from je_category_name to
REM                            user_je_category_name and je_source_name to
REM                            user_je_source_name.  Changed Journal
REM                            category checkProfile call to return error
REM                            rather than warning.  Fixed Profile Calls for: 
REM                            GLDI: Converted Entry Threshold and 
REM                            GLDI: Maximum Effective Ranges for Drilldown
REM                            Changed from Error Message to Warning.
REM                            Added GIS enhancement request
REM  1.12 24-NOV-2003 amulroy  added sqlerrm to all when others
REM                            errors
REM  1.13 03-DEC-2003 amulroy  Minor changes according to FQA
REM  1.14 03-DEC-2003 amulroy  Changed calendar gap error/action message
REM                            Added: g_sql_date_format := 'DD-MON-YYYY';
REM ====================================================================
REM ============== SQL PLUS Environment setup ==========================

set serveroutput on size 1000000
set verify off
set echo off
set autoprint off
set termout on
set feedback off

REM ============== Define SQL Variables for input parameters =============
VARIABLE v_username VARCHAR2(100);
VARIABLE v_respid   VARCHAR2(100);
VARIABLE v_ofa      VARCHAR2(1);

REM ============== Validate DATABASE Version =========================================
REM ============== NOTE - This section only needed for tests using HTML API's ========
DECLARE
  l_version         VARCHAR2(30);
BEGIN

  SELECT MAX(version)
    INTO l_version
    FROM v$instance;

  IF l_version < '8.1.6.0.0' THEN
     DBMS_OUTPUT.PUT_LINE(chr(10));
     DBMS_OUTPUT.PUT_LINE('ERROR - Unsupported Database Version '||l_version||'. The test requires RDBMS version 8.1.6 or higher');
     DBMS_OUTPUT.PUT_LINE('ACTION - Type Ctrl-C <Enter> to exit the test.');
     DBMS_OUTPUT.PUT_LINE(chr(10));
  END IF;

EXCEPTION
  when others then
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - Database Version check error : '||sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM ============Validate SQL*Plus Version Character Set Combination============
REM =======NOTE - This section only needed for tests using HTML APIs ==========

DECLARE
  l_nls_characterset    nls_database_parameters.value%TYPE;
  l_sql_release_int     INTEGER(20) :=  to_number('&_SQLPLUS_RELEASE');
  l_sql_release_chr     VARCHAR2(50) := '&_SQLPLUS_RELEASE';

BEGIN

  SELECT value
    INTO l_nls_characterset
    FROM nls_database_parameters
   WHERE parameter = 'NLS_CHARACTERSET';

  FOR i IN 1..4 LOOP
    l_sql_release_chr := substr(l_sql_release_chr,1,(2*i)-1)||'.'||
      substr(l_sql_release_chr,(2*i)+1);
  END LOOP;

  IF l_nls_characterset LIKE 'UTF%' THEN
    IF l_sql_release_int is null THEN
      DBMS_OUTPUT.PUT_LINE(chr(10));
      DBMS_OUTPUT.PUT_LINE('ATTENTION - Cannot determine version of SQL*Plus being used for test run.');
      DBMS_OUTPUT.PUT_LINE('.           This test may fail if not run using a version 8.1.X of SQL*Plus or higher.');
      DBMS_OUTPUT.PUT_LINE('Attempting to run the test.......');
      DBMS_OUTPUT.PUT_LINE(chr(10));
    ELSIF l_sql_release_int < 801000000 THEN
      DBMS_OUTPUT.PUT_LINE(chr(10));
      DBMS_OUTPUT.PUT_LINE('ERROR - Unsupported SQL*Plus version '||l_sql_release_chr);
      DBMS_OUTPUT.PUT_LINE('ACTION - On databases using the '||l_nls_characterset||' NLS characterset this test should not be run using this ');
      DBMS_OUTPUT.PUT_LINE('.        SQL*Plus version. Please rerun this test using version 8.1.X of SQL*Plus or higher.');
      DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
      DBMS_OUTPUT.PUT_LINE(chr(10));
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - SQL*Plus version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

-- prompt for username
prompt
undefine Application_user_name
accept Application_user_name char PROMPT 'Application User Name (required) : '
prompt


REM =============== Show responsibilities assigned to given user ==============
DECLARE
  l_applversion  fnd_product_groups.release_name%TYPE;
  l_counter      INTEGER;
  l_cursor       INTEGER;
  sqltxt         VARCHAR2(3000);
  l_resp_id      INTEGER;
  l_resp_name    VARCHAR2(300);
  invalidApps    exception;

BEGIN
  SELECT nvl(rtrim(ltrim(upper('&Application_user_name'))), '<NULL username>')
    INTO :v_username
    FROM dual;

  SELECT substr(release_name,1,4)
    INTO l_applversion
    FROM fnd_product_groups;

  IF (l_applversion = '11.5') THEN
    sqltxt := 'select to_char(a.responsibility_id) id, '||
              '       b.responsibility_name name '||
              'from   fnd_user_resp_groups a, '||
              '       fnd_responsibility_vl b, '||
              '       fnd_user u '||
              'where  a.user_id = u.user_id '||
              'and    a.responsibility_id = b.responsibility_id '||
              'and    a.responsibility_application_id = b.application_id '||
              'and    sysdate between '||
              '          a.start_date and nvl(a.end_date,sysdate+1) '||
              'and    upper(u.user_name) = '''|| :v_username ||''''||
              'order  by b.responsibility_name';

    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('Responsibilities assigned to User:  '|| :v_username);
    DBMS_OUTPUT.PUT_LINE('=================================================================' || chr(10) );

    l_cursor := dbms_sql.open_cursor;
    dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
    dbms_sql.define_column(l_cursor, 1, l_resp_id);
    dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
    l_counter := dbms_sql.EXECUTE(l_cursor);
    l_counter := 0;
    WHILE (dbms_sql.fetch_rows(l_cursor) > 0) LOOP
      l_counter := l_counter + 1;
      dbms_sql.column_value(l_cursor, 1, l_resp_id);
      dbms_sql.column_value(l_cursor, 2, l_resp_name);
      DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
    END LOOP;
    dbms_sql.close_cursor(l_cursor);

    IF (l_counter = 0) THEN
      RAISE no_data_found;
    END IF;

  ELSE
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR  - Invalid Application Version  '|| l_applversion);
    DBMS_OUTPUT.PUT_LINE('ACTION - This test is not intended for this Application version.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
    DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.  Rerun the test with a valid user name.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM ===================== Accept Responsibility ==============================
PROMPT
undefine v_respid
accept v_respid NUMBER PROMPT 'Please choose a Responsibility ID from the list : '
define v_respidc = &v_respid
PROMPT

REM ===================== Accept OFA input parameter =========================
PROMPT
undefine OFA_Install
accept OFA_Install CHAR DEFAULT 'N' PROMPT -
   'Financial Analyzer is setup to be used with GL (Y/[N]) ? '

BEGIN
  :v_ofa:= '&OFA_Install';
  DBMS_OUTPUT.PUT_LINE(chr(9));
END;
/

REM ============ Spooling the output file ====================================
define v_spoolfilename  = 'GLCheckSetup115_&v_respidc._diag.html'

PROMPT  ======================================================================
PROMPT  Output will be spooled to &v_spoolfilename
PROMPT  ======================================================================
PROMPT
PROMPT Running.....
PROMPT

spool &v_spoolfilename


REM ====================== Run the PL/SQL API file ===========================
@@CoreApiHtml.sql

  -- Function to check if a given Code Combination is valid
  FUNCTION CheckCCID(p_ccid varchar2, p_sobid number) return boolean is
    l_validCCID integer;
  BEGIN
    select count(1)
      into l_validCCID
      from gl_code_combinations gcc, gl_sets_of_books gsob
     where gcc.chart_of_accounts_id = gsob.chart_of_accounts_id
       and NVL(gcc.start_date_active, SYSDATE) <= SYSDATE
       and NVL(gcc.end_date_active, SYSDATE) >= SYSDATE
       and gcc.code_combination_id = p_ccid
       and gcc.enabled_flag = 'Y'
       and gsob.set_of_books_id = p_sobid;

    if (l_validCCID = 1) then
      return(TRUE);
    else
      return(FALSE);
    end if;

  EXCEPTION
    WHEN others then
      ErrorPrint(sqlerrm||' error occurred checking the CCID');
      ActionErrorPrint('Please report this error using the feedback option on this test');

      return(FALSE);
  END CheckCCID;

  -- Function to check if a given Currency is valid
  FUNCTION CheckCurrency(p_currcode varchar2) return boolean is
    l_validCurrency number(15);
  BEGIN
    select count(1)
      into l_validCurrency
      from fnd_currencies fc
     where fc.currency_code = p_currcode
       and NVL(fc.start_date_active, SYSDATE) <= SYSDATE
       and NVL(fc.end_date_active, SYSDATE) >= SYSDATE
       and fc.enabled_flag = 'Y';

    if (l_validCurrency = 1) then
      return(TRUE);
    else
      ErrorPrint('The currency entered is either disabled or end dated');
      ActionErrorPrint('Please correct the currency or use a different one');

      return(FALSE);
    end if;
  END CheckCurrency;

  -- function to get the account number using the CCID and CoA
  FUNCTION getAccountNumber(p_CCID number, p_coaID number) return varchar2 is
    l_concatseg gl_code_combinations_kfv.concatenated_segments%type;
  BEGIN
    select concatenated_segments
      into l_concatseg
      from gl_code_combinations_kfv
     where code_combination_id = p_CCID
       and chart_of_accounts_id = p_coaID;

    return l_concatseg;

  EXCEPTION
    WHEN others then
      ErrorPrint(sqlerrm ||' occurred in getAccountNumber('||p_CCID||','||p_coaID||')');
      ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      return 'ERROR';
  END getAccountNumber;

BEGIN  -- 1

  DECLARE -- 2
    -- parameters
    p_username                    varchar2(100);         -- Oracle APPS username
    p_respid                      number;                -- Responsibility ID

    -- variables
    v_userid                      fnd_user.user_id%type; -- Oracle APPS UserID
    v_respname                    fnd_responsibility_vl.responsibility_name%type;
    v_sobid                       gl_sets_of_books_v.set_of_books_id%type;
    v_sobname                     fnd_profile_option_values.profile_option_value%type;
    v_cross_seg_val_flag          fnd_id_flex_structures_vl.cross_segment_validation_flag%type;
    -- Profiles: GL_OWNERS_EQUITY_TRANSLATION_RULE, INTERCOMPANY: SUBSIDIARY, GL_DEFAULT_JE_CATEGORY
    v_equity                      fnd_profile_option_values.profile_option_value%type;
    v_intercomp                   fnd_profile_option_values.profile_option_value%type;
    v_default_je_cat              fnd_profile_option_values.profile_option_value%type;
    l_sequential		  fnd_profile_option_values.profile_option_value%type;
    sqltxt                        varchar2(32767);       -- for storing SQL statements
    counter                       integer;
    counter2                      integer;

    -- gl_sets_of_books_v
    v_LAST_UPDATE_DATE            gl_sets_of_books_v.last_update_date%type               := null;
    v_LAST_UPDATED_BY             gl_sets_of_books_v.last_updated_by%type                := null;
    v_CURRENCY_CODE               gl_sets_of_books_v.currency_code%type                  := null;
    v_CHART_OF_ACCOUNTS_ID        gl_sets_of_books_v.chart_of_accounts_id%type           := null;
    v_NAME                        gl_sets_of_books_v.name%type                           := null;
    v_PERIOD_SET_NAME             gl_sets_of_books_v.period_set_name%type                := null;
    v_SUSPENSE_ALLOWED_FLAG       gl_sets_of_books_v.suspense_allowed_flag%type          := null;
    v_ALLOW_POSTING_WARNING_FLAG  gl_sets_of_books_v.allow_posting_warning_flag%type     := null;
    v_ACCOUNTED_PERIOD_TYPE       gl_sets_of_books_v.accounted_period_type%type          := null;
    v_SHORT_NAME                  gl_sets_of_books_v.short_name%type                     := null;
    v_REQUIRE_BUDGET_JOURNALS_FLAG gl_sets_of_books_v.require_budget_journals_flag%type  := null;
    v_ENABLE_BUDGET_CONTROL_FLAG  gl_sets_of_books_v.enable_budgetary_control_flag%type  := null;
    v_ALLOW_INTERCOM_POST_FLAG    gl_sets_of_books_v.allow_intercompany_post_flag%type   := null;
    v_CREATION_DATE               gl_sets_of_books_v.creation_date%type                  := null;
    v_LATEST_ENCUMBRANCE_YEAR     gl_sets_of_books_v.latest_encumbrance_year%type        := null;
    v_CUM_TRANS_CODE_COM_ID       gl_sets_of_books_v.cum_trans_code_combination_id%type  := null;
    v_FUTURE_PERIODS_LIMIT        gl_sets_of_books_v.future_enterable_periods_limit%type := null;
    v_LATEST_OPENED_PERIOD_NAME   gl_sets_of_books_v.latest_opened_period_name%type      := null;
    v_RET_EARN_CODE_COM_ID        gl_sets_of_books_v.ret_earn_code_combination_id%type   := null;
    v_RES_ENCUMB_CODE_COM_ID      gl_sets_of_books_v.res_encumb_code_combination_id%type := null;
    v_TRANSLATE_QATD_FLAG         gl_sets_of_books_v.translate_qatd_flag%type            := null;
    v_TRANSLATE_YATD_FLAG         gl_sets_of_books_v.translate_yatd_flag%type            := null;
    v_DAILY_TRANS_RATE_TYPE       gl_sets_of_books_v.daily_translation_rate_type%type    := null;
    v_NET_INCOME_CODE_COM_ID      gl_sets_of_books_v.net_income_code_combination_id%type := null;
    v_ENABLE_AUTO_TAX_FLAG        gl_sets_of_books_v.enable_automatic_tax_flag%type      := null;
    v_ENABLE_JE_APPROVAL_FLAG     gl_sets_of_books_v.enable_je_approval_flag%type        := null;
    v_MRC_SOB_TYPE_CODE           gl_sets_of_books_v.mrc_sob_type_code%type              := null;
    v_TRACK_ROUNDING_IMBAL_FLAG   gl_sets_of_books_v.track_rounding_imbalance_flag%type  := null;
    v_ROUNDING_CCID               gl_sets_of_books_v.rounding_ccid%type                  := null;
    v_DESCRIPTION                 gl_sets_of_books_v.description%type                    := null;
    v_USER_PERIOD_TYPE            gl_sets_of_books_v.user_period_type%type               := null;
    v_CHART_OF_ACCOUNTS_NAME      gl_sets_of_books_v.chart_of_accounts_name%type         := null;
    v_SUSPENSE_CCID               gl_sets_of_books_v.suspense_ccid%type                  := null;
    v_ENABLE_AVGBAL_FLAG          gl_sets_of_books_v.enable_avgbal_flag%type             := null;
    v_CONSOLIDATION_SOB_FLAG      gl_sets_of_books_v.consolidation_sob_flag%type         := null;
    v_TRANSACTION_CAL_NAME        gl_sets_of_books_v.transaction_calendar_name%type      := null;
    v_DAILY_USER_TRANS_TYPE       gl_sets_of_books_v.daily_user_translation_type%type    := null;
    v_TRANSLATE_EOD_FLAG          gl_sets_of_books_v.translate_eod_flag%type             := null;

    -- Exceptions
    STOPEXECUTION                 exception;

  BEGIN  -- 2

    /* ---------- Set Client ( validate user and responsibility ) --------- */
    Show_Header('205198.1','General Ledger Setup Diagnostic Test');
    -- made modification to line up get parameter section changes
    if (:v_username is null) then
      p_username := 'DUMMY';
    else
      p_username := :v_username;
    end if;

    if (&v_respid is null) then
      p_respid := -10;
    else
      p_respid := &v_respid;
    end if;

    BEGIN -- 3
      select user_id
        into v_userid
        from fnd_user
       where user_name = p_username;
    EXCEPTION
      WHEN no_data_found then
        ErrorPrint('The given APPS username ('||p_username||') is not valid');
        ActionErrorPrint('Please re-run the test and enter a valid APPS username');
        raise STOPEXECUTION;
    END; -- 3

    BEGIN -- 3
      select b.responsibility_name
        into v_respname
        from fnd_responsibility_vl b
       where b.responsibility_id = p_respid;
    EXCEPTION -- 3
      WHEN no_data_found then
        ErrorPrint('The given responsibility ID ('||to_char(p_respid)||') is unknown');
        ActionErrorPrint('Please re-run the test and enter valid responsibility ID from the list');
        raise STOPEXECUTION;
    END; -- 3

    BEGIN -- 3
      select b.responsibility_name
        into v_respname
        from fnd_responsibility_vl b
       where b.responsibility_id = p_respid
         and application_id = 101;
    EXCEPTION -- 3
      WHEN no_data_found then
        ErrorPrint('The given responsibility ID ('||to_char(p_respid)||') is not a GL responsibility ID');
        ActionErrorPrint('Please re-run the test and enter a valid GL responsibility ID from the list');
        raise STOPEXECUTION;
    END; -- 3

    set_client(p_username, p_respid);
    g_sql_date_format := 'DD-MON-YYYY';

    SectionPrint('Parameters');
    BRPrint;
    Tab1Print('Username           = '||p_username);
    Tab1Print('Responsibility     = '||v_respname||' (ID = '||p_respid||')');
    Tab1Print('Financial Analyzer = '||:v_ofa);

    /* ----------- Patch Levels ------------------------------------------- */
    BRPrint;
    SectionPrint('Patch Levels');
    BRPrint;
    DECLARE
      FUNCTION getPatchLevel(p_appid number) return varchar2 is
        l_patchlevel fnd_product_installations.patch_level%type := null;
      BEGIN
        select patch_level
          into l_patchLevel
          from fnd_product_installations
         where application_id = p_appid;

        return l_patchLevel;

      EXCEPTION
        WHEN others then
          return 'unknown';
      END getPatchLevel;
    BEGIN -- 3
      Tab1Print('General Ledger Patch Level = '||getPatchLevel(101));
      Tab1Print('Financial Statement Generator (FSG) Patch Level = '||getPatchLevel(168));
    EXCEPTION -- 3
      WHEN OTHERS then
        ErrorPrint(sqlerrm||' occurred in "Patch Levels"');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3


    -- Check GL Set of Books Name and ID Profiles
    BRPrint;
    SectionPrint('Main General Ledger Profile Options');
    BRPrint;
    DECLARE
      l_seq    fnd_profile_option_values.profile_option_value%type;
    BEGIN -- 3
      v_sobname := CheckProfile('GL_SET_OF_BKS_NAME', v_userid, p_respid, 101, null, 1,null,'N');
      if (v_sobname is null) then
        ErrorPrint('The Set of books name profile option is not set for this responsibility');
        ActionErrorPrint('Please set the Set of books name profile option for this responsibility');
        raise STOPEXECUTION;
      end if;

      v_sobid := CheckProfile('GL_SET_OF_BKS_ID', v_userid, p_respid, 101, null, 1,null,'N');
      if (v_sobid is null) then
        ErrorPrint('The Set of books id profile option is not set for this responsibility');
        ActionErrorPrint('Please set the GL Set of Books ID profile option for this responsibility and re-run the Diagnostic test');
        raise STOPEXECUTION;
      end if;

      v_equity := CheckProfile('GL_OWNERS_EQUITY_TRANSLATION_RULE', v_userid, p_respid, 101, null, 1);
      v_default_je_cat := CheckProfile('GL_DEFAULT_JE_CATEGORY', v_userid, p_respid, 101, null, 1,null,'E');

    EXCEPTION -- 3
      WHEN STOPEXECUTION then
        raise;
      WHEN OTHERS then
        ErrorPrint(sqlerrm||' occurred in "Main General Ledger Profile Options"');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3


    /* ----------- Set of Books Details ----------------------------------- */
    BRPrint;
    SectionPrint('Set of Books Details');
    BRPrint;
    BEGIN -- 3
      select last_update_date, last_updated_by, currency_code, chart_of_accounts_id,
             name, period_set_name, suspense_allowed_flag, allow_posting_warning_flag,
             accounted_period_type, short_name, require_budget_journals_flag,
             enable_budgetary_control_flag, allow_intercompany_post_flag, creation_date,
             latest_encumbrance_year, cum_trans_code_combination_id,
             future_enterable_periods_limit, latest_opened_period_name, ret_earn_code_combination_id,
             res_encumb_code_combination_id, translate_qatd_flag, translate_yatd_flag,
             daily_translation_rate_type, net_income_code_combination_id,
             enable_automatic_tax_flag, enable_je_approval_flag, mrc_sob_type_code,
             track_rounding_imbalance_flag, rounding_ccid, description, chart_of_accounts_name,
             user_period_type, suspense_ccid, enable_avgbal_flag, consolidation_sob_flag,
             transaction_calendar_name, daily_user_translation_type, translate_eod_flag
        into v_LAST_UPDATE_DATE, v_LAST_UPDATED_BY, v_CURRENCY_CODE, v_CHART_OF_ACCOUNTS_ID,
             v_NAME, v_PERIOD_SET_NAME, v_SUSPENSE_ALLOWED_FLAG, v_ALLOW_POSTING_WARNING_FLAG,
             v_ACCOUNTED_PERIOD_TYPE, v_SHORT_NAME, v_REQUIRE_BUDGET_JOURNALS_FLAG,
             v_ENABLE_BUDGET_CONTROL_FLAG, v_ALLOW_INTERCOM_POST_FLAG, v_CREATION_DATE,
             v_LATEST_ENCUMBRANCE_YEAR, v_CUM_TRANS_CODE_COM_ID,
             v_FUTURE_PERIODS_LIMIT, v_LATEST_OPENED_PERIOD_NAME, v_RET_EARN_CODE_COM_ID,
             v_RES_ENCUMB_CODE_COM_ID, v_TRANSLATE_QATD_FLAG, v_TRANSLATE_YATD_FLAG,
             v_DAILY_TRANS_RATE_TYPE , v_NET_INCOME_CODE_COM_ID,
             v_ENABLE_AUTO_TAX_FLAG, v_ENABLE_JE_APPROVAL_FLAG, v_MRC_SOB_TYPE_CODE,
             v_TRACK_ROUNDING_IMBAL_FLAG, v_ROUNDING_CCID, v_DESCRIPTION, v_CHART_OF_ACCOUNTS_NAME,
             v_USER_PERIOD_TYPE, v_SUSPENSE_CCID, v_ENABLE_AVGBAL_FLAG, v_CONSOLIDATION_SOB_FLAG,
             v_TRANSACTION_CAL_NAME, v_DAILY_USER_TRANS_TYPE, v_TRANSLATE_EOD_FLAG
        from gl_sets_of_books_v
       where set_of_books_id = v_sobid;

      Tab1Print('Generic Settings');
      BEGIN -- 4
        Tab2Print('Set of Books Name = '||v_NAME||' (ID='||to_char(v_sobid)||')');
        Tab2Print('Short Name        = '||v_SHORT_NAME);
        Tab2Print('Description       = '||v_DESCRIPTION);
        Tab2Print('Created date      = '||v_CREATION_DATE);
        Tab2Print('Last updated date = '||v_LAST_UPDATE_DATE);

        if (v_CHART_OF_ACCOUNTS_NAME is null) then
          ErrorPrint('Chart of accounts is not defined for set of books '||v_name);
          ActionErrorPrint('Please assign a valid chart of accounts to this set of books');
        else
          Tab2Print('Chart of Accounts = '||v_CHART_OF_ACCOUNTS_NAME||' (ID='||v_CHART_OF_ACCOUNTS_ID||')');
        end if;

        if (CheckCurrency(v_currency_code) = FALSE) then
          ErrorPrint('Functional currency is not defined for this set of books');
          ActionErrorPrint('Please ensure that the functional currency is enabled and not end dated');
        else
          Tab2Print('Functional Currency = '||v_CURRENCY_CODE);
        end if;
        BRPrint;
      EXCEPTION -- 4
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Generic Settings"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Generic Settings

      -- Value from profile and from gl_sets_of_books_v should be the same
      if (v_NAME != v_sobname) then
        ErrorPrint('Set of books name / id from the profiles are not equal to the ones found in view "gl_sets_of_books_v"');
        ActionErrorPrint('Please make sure that the information in the view matches the profile option.');
        raise STOPEXECUTION;
      end if;

      Tab1Print('Accounting Calendar');
      BEGIN -- 4
        if (v_PERIOD_SET_NAME is null) then
          ErrorPrint('An accounting calendar is not assigned to Set of Books '||v_sobname);
          ActionErrorPrint('Please assign an accounting calendar to the Set of Books');
        else
          Tab2Print('Name = '||v_PERIOD_SET_NAME);
        end if;

        if (v_USER_PERIOD_TYPE is null) then
          ErrorPrint('Period Type is not assigned to Set of Books '||v_sobname);
          ActionErrorPrint('Please assign a valid period type');
        else
          Tab2Print('Period Type = '||v_USER_PERIOD_TYPE);
        end if;

        if (v_FUTURE_PERIODS_LIMIT is null) then
          WarningPrint('There are no future periods defined for this set of books');
          ActionWarningPrint('If future periods are required, please set the number of future periods in the set of books define form');
        else
          Tab2Print('Number of Future Periods = '||v_FUTURE_PERIODS_LIMIT);
        end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Accounting Calendar"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Accounting Calendar

      BRPrint;
      Tab1Print('Closing');
      DECLARE -- 4
        l_RetEarnCodeValid    boolean;
        l_CumTransCodeValid   boolean;
      BEGIN -- 4
        l_RetEarnCodeValid := CheckCCID(v_RET_EARN_CODE_COM_ID, v_sobid);
        l_CumTransCodeValid := CheckCCID(v_CUM_TRANS_CODE_COM_ID, v_sobid);

        if (v_RET_EARN_CODE_COM_ID is null) then
          ErrorPrint('Retained earnings account is not set for this set of books');
          ActionErrorPrint('Please enter a valid retained earnings account in the set of books define form');
        end if;
        if (l_RetEarnCodeValid = FALSE) then
          ErrorPrint('Retained earnings account ('||getAccountNumber(v_RET_EARN_CODE_COM_ID,v_CHART_OF_ACCOUNTS_ID)||') is either disabled or end dated.');
          ActionErrorPrint('Please enter a valid retained earnings account in the set of books define form');
        end if;
        if (v_RET_EARN_CODE_COM_ID is not null) and (l_RetEarnCodeValid = TRUE) then
          Tab2Print('Retained earnings account = '||getAccountNumber(v_RET_EARN_CODE_COM_ID,v_CHART_OF_ACCOUNTS_ID)||' (CCID = '||v_RET_EARN_CODE_COM_ID||')');
        end if;

        if (v_CUM_TRANS_CODE_COM_ID is null) then
          WarningPrint('Translation adjustment account is not set for this set of books');
          ActionWarningPrint('If translation is to be used, please enter a valid translation adjustment account in the Set of Books Define form');
        end if;
        if (l_CumTransCodeValid = FALSE) then
          WarningPrint('Translation adjustment account ('||getAccountNumber(v_CUM_TRANS_CODE_COM_ID, v_CHART_OF_ACCOUNTS_ID)||') is disabled or is end dated.');
          ActionWarningPrint('If translation is to be used, please enter a valid translation adjustment account in the Set of Books Define form');
        end if;
        if (v_CUM_TRANS_CODE_COM_ID is not null) and (l_CumTransCodeValid = TRUE) then
          Tab2Print('Translation adjustment account = '||getAccountNumber(v_CUM_TRANS_CODE_COM_ID, v_CHART_OF_ACCOUNTS_ID)||
                    ' (CCID = '||v_CUM_TRANS_CODE_COM_ID||')');
        end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Closing"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Closing

      BRPrint;
      Tab1Print('Journalling');
      DECLARE
        l_SuspenseCCIDValid boolean;
        l_RoundingCCIDValid boolean;
      BEGIN -- 4
        Tab2Print('Balance Intercompany Journal flag = '||v_ALLOW_INTERCOM_POST_FLAG);
        Tab2Print('Journal Approval flag = '||v_ENABLE_JE_APPROVAL_FLAG);
        Tab2Print('Journal Entry Tax flag = '||v_ENABLE_AUTO_TAX_FLAG);
        Tab2Print('Suspense Accounts flag = '||v_SUSPENSE_ALLOWED_FLAG);

        if (v_SUSPENSE_ALLOWED_FLAG = 'Y') then
          if (v_SUSPENSE_CCID is null) then
            ErrorPrint('Suspense account is not entered');
            ActionErrorPrint('Please enter a valid suspense account in the Set of Books Define form');
          else
            l_suspenseCCIDValid := CheckCCID(v_SUSPENSE_CCID,v_sobid);
            if (l_suspenseCCIDValid = FALSE) then
              ErrorPrint('Suspense account ('||getAccountNumber(v_SUSPENSE_CCID,v_CHART_OF_ACCOUNTS_ID)||') is either disabled or end dated');
              ActionErrorPrint('Please enter a valid suspense account in the Set of Books Define form');
            else
              Tab2Print('Suspense account = '||getAccountNumber(v_SUSPENSE_CCID,v_CHART_OF_ACCOUNTS_ID)||' (CCID = '||v_SUSPENSE_CCID||')');
            end if;
          end if;
        end if;

        Tab2Print('Rounding Difference Account flag = '||v_TRACK_ROUNDING_IMBAL_FLAG);
        if (v_TRACK_ROUNDING_IMBAL_FLAG = 'Y') then
          if (v_ROUNDING_CCID is null) then
            ErrorPrint('Rounding difference account is not entered');
            ActionErrorPrint('Please enter a valid rounding difference account in the set of books define form');
          else
            l_RoundingCCIDValid := CheckCCID(v_ROUNDING_CCID,v_sobid);
            if (l_RoundingCCIDValid = FALSE) then
              ErrorPrint('Rounding difference account ('||getAccountNumber(v_ROUNDING_CCID, v_CHART_OF_ACCOUNTS_ID)||
                         ' is either disabled or end dated');
              ActionErrorPrint('Please enter a valid rounding difference account in the set of books define form');
            else
              Tab2Print('Rounding Difference Account = '||getAccountNumber(v_ROUNDING_CCID, v_CHART_OF_ACCOUNTS_ID)||
                        ' (CCID = '||v_ROUNDING_CCID||')');
            end if;
          end if;
        end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Journalling"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Journalling

      BRPrint;
      Tab1Print('Average Balance');
      DECLARE -- 4
        l_NetIncomeCCIDValid boolean;
        l_averageCount       number;

        FUNCTION getAverageBalanceCount(p_psobid number) return number is
          l_count number := 0;
        BEGIN
          select count(1)
            into l_count
            from gl_sets_of_books
           where enable_average_balances_flag = 'Y'
             and set_of_books_id not in (select gsob.set_of_books_id
                                           from gl_transaction_calendar gtc, gl_sets_of_books gsob
                                          where gsob.transaction_calendar_id = gtc.transaction_calendar_id)
             and set_of_books_id = p_psobid;

          return l_count;

        EXCEPTION
           WHEN others then
             ErrorPrint(sqlerrm ||' occurred executing getAverageBalanceCount('||p_psobid||')');
             ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
             return null;
        END getAverageBalanceCount;

      BEGIN -- 4
        Tab2Print('Consolidation Set of Books flag = '||v_CONSOLIDATION_SOB_FLAG);
        Tab2Print('Enable Average Balance flag = '||v_ENABLE_AVGBAL_FLAG);

        if (v_ENABLE_AVGBAL_FLAG = 'Y') then
          -- only if Average balancing is enabled
          if (v_TRANSACTION_CAL_NAME is null) then
            ErrorPrint('Transaction calendar is not entered');
            ActionErrorPrint('Please enter a transaction calendar in the set of books define form');
          else
            Tab2Print('Transaction calendar = '||v_TRANSACTION_CAL_NAME);
          end if;

          if (v_NET_INCOME_CODE_COM_ID is null) then
            ErrorPrint('Net income account is not entered');
            ActionErrorPrint('Please enter a valid net income account in the set of books define form');

            l_NetIncomeCCIDValid := CheckCCID(v_NET_INCOME_CODE_COM_ID,v_sobid);
            if (l_NetIncomeCCIDValid = TRUE) then
              Tab2Print('Net Income Account = '||getAccountNumber(v_NET_INCOME_CODE_COM_ID, v_CHART_OF_ACCOUNTS_ID)||
                        ' (CCID = '||v_NET_INCOME_CODE_COM_ID||')');
            end if;
          end if;

          l_averageCount := getAverageBalanceCount(v_sobid);
          if (l_averageCount = 0) then
            Tab2Print('Transaction calendar assigned to the set of books exists');
          elsif (l_averageCount = 1) then
            WarningPrint('Average balances is enabled but is not linked to a transaction calendar which exists');
            ActionWarningPrint('Please enter an existing transaction calendar in the set of books define form');
          end if;
        else
          if (v_NET_INCOME_CODE_COM_ID is null) then
            Tab2Print('Net Income Account is correctly set to null (this account only needs to be set when average balances is enabled)');
          end if;
        end if; -- only if Average balancing is enabled
      EXCEPTION -- 4
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Average Balance"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Average Balance

      BRPrint;
      Tab1Print('Translation');
      BEGIN -- 4
        if (v_ENABLE_AVGBAL_FLAG = 'Y') and (v_DAILY_USER_TRANS_TYPE is null) then
          ErrorPrint('Rate type is not defined');
          ActionErrorPrint('A rate type must be defined when average balances is enabled');
        end if;

        if (v_ENABLE_AVGBAL_FLAG = 'Y') and (v_DAILY_USER_TRANS_TYPE is not null) then
          Tab2Print('Rate Type = '||v_DAILY_USER_TRANS_TYPE);
        end if;

        Tab2Print('Maintained Amount flags');
	if (v_TRANSLATE_EOD_FLAG is null) then
	  Tab3Print('End of Date balance flag is not set');
	else
	  Tab3Print('End of Date balance flag = '||v_TRANSLATE_EOD_FLAG);
	end if;

	if (v_TRANSLATE_QATD_FLAG is null) then
	  Tab3Print('Quarter Average to date balance flag is not set');
	else
	  Tab3Print('Quarter Average to date flag = '||v_TRANSLATE_QATD_FLAG);
	end if;

	if (v_TRANSLATE_YATD_FLAG is null) then
	  Tab3Print('Year Average to date balance flag is not set');
	else
	  Tab3Print('Year Average to date flag = '||v_TRANSLATE_YATD_FLAG);
	end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Translation"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Translation

      BRPrint;
      Tab1Print('Budgetary Control');
      DECLARE -- 4
        l_resEncumbCCIDValid   boolean;
        l_accountNumber        gl_code_combinations_kfv.concatenated_segments%type := 0;
      BEGIN -- 4
        Tab2Print('Enabled Budgetary Control flag = '||v_ENABLE_BUDGET_CONTROL_FLAG);
        Tab2Print('Require Budget Journal flag = '||v_REQUIRE_BUDGET_JOURNALS_FLAG);

        if (v_ENABLE_BUDGET_CONTROL_FLAG = 'Y') then
          Tab2Print('The Latest Opened Encumbrance Year = '||v_LATEST_ENCUMBRANCE_YEAR);
          if (v_RES_ENCUMB_CODE_COM_ID is null) then
            ErrorPrint('Reserve for encumbrance account is not defined');
            ActionErrorPrint('Please enter a reserve for encumbrance account in the set of books define form');
          else
            l_resEncumbCCIDValid := CheckCCID(v_RES_ENCUMB_CODE_COM_ID, v_sobid);
            l_accountNumber := getAccountNumber(v_RES_ENCUMB_CODE_COM_ID, v_CHART_OF_ACCOUNTS_ID);
            if (l_resEncumbCCIDValid = FALSE) then
              ErrorPrint('Reserve for encumbrance account ('||l_accountNumber||') is either disabled or end dated');
              ActionErrorPrint('Please enter a reserve for encumbrance account in the set of books define form');
            else
              Tab2Print('Reserve for Encumbrance Account = '||l_accountNumber||
                        ' (CCID = '||v_RES_ENCUMB_CODE_COM_ID||')');
            end if;
          end if;
        else
          if (v_RES_ENCUMB_CODE_COM_ID is null) then
            Tab2Print('Reserve for encumbrance account is correctly set to null (this account only needs to be set when budgetary control is enabled)');
          end if;
        end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Budgetary Control"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Budgetary Control

      BRPrint;
      Tab1Print('Multiple Reporting Currencies (MRC)');
      DECLARE
        l_count          number;
        l_MRCEnabledFlag varchar2(1);
      BEGIN -- 4
        select multi_currency_flag
          into l_MRCEnabledFlag
          from fnd_product_groups;

        -- Check for Multi Currencies in FND_PRODUCT_GROUPS table
        if (l_MRCEnabledFlag = 'N') then
          Tab2Print('Multiple Reporting Currencies is not enabled');
          Show_Link('66916.1');
          ActionPrint('Oracle Multiple Currencies User Manual lli');
        else
          Tab2Print('Multiple Reporting Currencies is enabled');
        end if;

        if (v_MRC_SOB_TYPE_CODE = 'R') then
          -- Reporting set of books
          Tab2Print(v_NAME||' is a Reporting MRC book');
        elsif (v_MRC_SOB_TYPE_CODE = 'P') then
          -- Primary set of books
          Tab2Print(v_NAME||' is a Primary MRC book');
          -- Display reporting set of books (if present)
          select count(1)
            into l_count
            from gl_mc_reporting_options gmro, gl_sets_of_books gsob
           where gmro.primary_set_of_books_id = gsob.set_of_books_id
             and gmro.primary_set_of_books_id = v_sobid
             and gmro.enabled_flag = 'Y';

          if (l_count = 0) then
            Tab2Print('There are no enabled reporting set of books');
          else
            BRPrint;
            Tab2Print('Reporting Set Of Books');
            sqltxt := 'select gmro.reporting_set_of_books_id "Reporting Set of Books id", ' ||
                      'gsob.name Name, gmro.reporting_currency_code "Currency Code" , count(1) Count '||
                      'from gl_mc_reporting_options gmro, gl_sets_of_books gsob '||
                      'where gmro.primary_set_of_books_id = gsob.set_of_books_id '||
                      'and gmro.enabled_flag = ''Y'' '||
                      'and gmro.primary_set_of_books_id = '||v_sobid||' '||
                      'group by gmro.reporting_set_of_books_id, gsob.name, gmro.reporting_currency_code';
            Run_SQL(null,sqltxt,'Y',null,2);
          end if;
        else -- End check on Primary SOBS
          -- No reporting or primary set of books
          Tab2Print(v_NAME||' is not a multiple reporting currency book');
        end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Multiple Reporting Currencies (MRC)"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Multiple Reporting Currencies (MRC)

      BRPrint;
      Tab1Print('Miscellaneous Settings');
      DECLARE
        l_taxCount  number;
        l_suspenseCount number;
      
      BEGIN -- 4
        -- Intercompany flag
        Tab2Print('Allow Intercompany flag = '||v_ALLOW_INTERCOM_POST_FLAG);
        -- Automatic Tax flag
        Tab2Print('Automatic Tax flag = '||v_ENABLE_AUTO_TAX_FLAG);

	select count(1)
	  into l_taxCount
	  from gl_tax_options
	 where set_of_books_id = v_sobid;

	Tab2Print('Automatic Tax calculation flag = '||v_ENABLE_AUTO_TAX_FLAG);
	if (l_taxCount = 0) and (v_ENABLE_AUTO_TAX_FLAG = 'Y') then
	  WarningPrint('Automatic Tax Calculation is enabled but no tax options are defined');
	  ActionWarningPrint('Please setup Tax options if automatic tax calculations is used');
	end if;
	if (l_taxCount > 0) and (v_ENABLE_AUTO_TAX_FLAG <> 'Y') then
	  WarningPrint('Tax Options have been defined but Automatic Tax calculation is not enabled');
	  ActionWarningPrint('Please enable Automatic Tax calculation for this set of books if required');
	end if;

	select count(1)
	  into l_suspenseCount
	  from gl_suspense_accounts_v
	 where set_of_books_id = v_sobid;

	Tab2Print('Suspense Accounting flag = '||v_SUSPENSE_ALLOWED_FLAG);
	if (l_suspenseCount = 0) and (v_SUSPENSE_ALLOWED_FLAG = 'Y') then
	  WarningPrint('Suspense Accounting is enabled but no Suspense accounts categories are defined for this set of books');
	  ActionWarningPrint('Please setup Suspense accounts categories if Suspense Accounting is to be enabled');
	elsif (l_suspenseCount > 0) and (v_SUSPENSE_ALLOWED_FLAG != 'Y') then
	  WarningPrint('Suspense account categories are defined but Suspense Accounting is not enabled for this set of books');
	  ActionWarningPrint('Please enable Suspense Accounting for this set of books if required');
	elsif (l_suspenseCount > 0) and (v_SUSPENSE_ALLOWED_FLAG = 'Y') then
	  Tab2Print('Suspense Accounts setup for Journal Source names');
	  BRPrint;
	  sqltxt := 'select s.user_je_source_name "Source|Name" '||
		    ',      c.user_je_category_name "Category|Name" '||
		    'from   gl_suspense_accounts_v s '||
		    ',      gl_je_categories c '||
		    'where  s.je_category_name = c.je_category_name '||
		    'and    s.set_of_books_id = '||v_sobid||
		    'and    1=1';
	  Run_SQL(null,sqltxt,'Y',null,2);
	  BRPrint;
	end if;
      EXCEPTION -- 4
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Miscellaneous Settings"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Miscellaneous Settings
    EXCEPTION -- 3
      WHEN STOPEXECUTION then
        raise; -- Make sure we exit the test
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about GL Set of Books');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Finish Checking and validation Values for GL Set of Books

    /* Checking the and validating the Chart of Accounts that is assigned to this Set of books */
    BRPrint;
    SectionPrint('Chart of Accounts Details');
    BRPrint;
    DECLARE
      l_chartCount   number;
      l_freezeFlag   varchar2(1);
      l_enableFlag   varchar2(1);
      l_dynamicFlag  varchar2(1);
      l_chartName    fnd_id_flex_structures_vl.id_flex_structure_name%type;
    BEGIN -- 3 -- Chart of accounts
      -- Next SQL should return count of 1
      select count(1)
        into l_chartCount
        from fnd_id_flexs fif, fnd_id_flex_structures_vl fifsv
       where fif.application_id = 101
         and fif.id_flex_code = fifsv.id_flex_code
         and fifsv.id_flex_num = v_chart_of_accounts_id;
      -- commented out as id_flex_name is not chart_of_account_name it is flexfield
      -- type e.g. Accounting Flexfield
      -- and b.ID_FLEX_NAME =v_CHART_OF_ACCOUNTS_NAME

      if (l_chartCount = 0) then
        ErrorPrint('A Chart of Accounts was not defined');
        ActionErrorPrint('Please ensure that a key flexfield is setup, enabled and frozen');
      elsif (l_chartCount = 1) then
        select fifsv.id_flex_structure_name, fifsv.freeze_flex_definition_flag, fifsv.enabled_flag,
               fifsv.dynamic_inserts_allowed_flag, fifsv.cross_segment_validation_flag
          into l_chartName, l_freezeFlag, l_enableFlag, l_dynamicFlag, v_cross_seg_val_flag
          from gl_sets_of_books gsob, fnd_id_flexs fif, fnd_id_flex_structures_vl fifsv
         where fif.application_id = 101
           and gsob.chart_of_accounts_id = fifsv.id_flex_num
           and fif.id_flex_code = fifsv.id_flex_code
           and fifsv.id_flex_num = v_chart_of_accounts_id
           and gsob.set_of_books_id = v_sobid;

        -- Already done by API CheckKeyFlexfield
--        Tab1Print('Chart of Accounts name = '||l_chartName);
        -- Details of Accounting Key Flexfield
        CheckKeyFlexfield('GL#',v_chart_of_accounts_id,false);

        if (l_freezeFlag != 'Y') then
          WarningPrint('Chart of Accounts is not frozen');
          ActionWarningPrint('Please freeze the accounting flexfield and recompile');
        end if;

        if (l_enableFlag != 'Y') then
          ErrorPrint('Chart of Accounts is not enabled');
          ActionErrorPrint('Please enable the accounting flexfield and recompile');
        end if;

      else -- if (l_chartCount > 1) then
        ErrorPrint('Multiple Chart of Accounts are associated with the same sets of books');
        ActionErrorPrint('A Set of books can only be associated with one chart of accounts');
      end if;

      -- Checking for overlapping children or cases where one child has more than one parents
      BRPrint;
      Tab1Print('Overlapping Child Ranges');
      DECLARE -- 4
        cursor g_flex_count is
          select count(1) flex_count
            from fnd_flex_value_hierarchies fvh1, fnd_flex_value_hierarchies fvh2, fnd_flex_value_sets fvs
           where fvh1.parent_flex_value = fvh2.parent_flex_value
             and fvh1.rowid != fvh2.rowid
             and fvh1.flex_value_set_id = fvh2.flex_value_set_id
             and fvh2.flex_value_set_id = fvs.flex_value_set_id
             and NVL(fvh2.child_flex_value_low,'X') <= NVL(fvh1.child_flex_value_high,'X')
             and NVL(fvh2.child_flex_value_high,'X') >= NVL(fvh1.child_flex_value_low,'X')
           group by fvs.flex_value_set_name, fvh1.parent_flex_value, SUBSTR(fvh1.child_flex_value_low,1,30),
                 SUBSTR(fvh1.child_flex_value_high,1,30), SUBSTR(fvh2.child_flex_value_low,1,30),
                 SUBSTR(fvh2.child_flex_value_high,1,30);
        v_flex_count  g_flex_count%rowtype;
      BEGIN -- 4
        open g_flex_count;
        fetch g_flex_count into v_flex_count;
        if (g_flex_count%NOTFOUND) then
          Tab2Print('No overlapping child segment ranges or multiple parents for one child exist');
        else
          BRPrint;
          ErrorPrint('There are overlapping child ranges and/ or children with multiple parents');
          ActionErrorLink('Please review the following table to identify the overlapping child '||
            'ranges. For further information please see Note ', '118130.1',
            ' - How to Read Output of Script to Detect Overlapping Child Ranges in a Value Set');
          BRPrint;
          sqltxt := 'select distinct fvs.flex_value_set_name "Flex|Value|Set Name", '||
                    'fvh1.parent_flex_value "Parent", '||
                    'SUBSTR(fvh1.child_flex_value_low,1,30)  "Overlapping|Low", '||
                    'SUBSTR(fvh1.child_flex_value_high,1,30) "Overlapping|High", '||
                    'SUBSTR(fvh2.child_flex_value_low,1,30)  "Overlapped|Low", '||
                    'SUBSTR(fvh2.child_flex_value_high,1,30) "Overlapped|High" '||
                    'from fnd_flex_value_hierarchies fvh1, fnd_flex_value_hierarchies fvh2, '||
                    'fnd_flex_value_sets fvs '||
                    'where fvh1.parent_flex_value = fvh2.parent_flex_value '||
                    'and fvh1.rowid != fvh2.rowid '||
                    'and fvh1.flex_value_set_id = fvh2.flex_value_set_id '||
                    'and fvh2.flex_value_set_id = fvs.flex_value_set_id '||
                    'and NVL(fvh2.child_flex_value_low,''X'') <= NVL(fvh1.child_flex_value_high,''X'') '||
                    'and NVL(fvh2.child_flex_value_high,''X'') >= NVL(fvh1.child_flex_value_low,''X'')';
          Run_SQL(null,sqltxt,'Y',null,2);
        end if;
        close g_flex_count;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Overlapping Child Ranges"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Overlapping Child Ranges

      BRPrint;
      Tab1Print('Cross Validate Segments');
      DECLARE -- 4 -- Cross Validation Rules Check
        l_flexRulesCount     number;
        l_flexRulesCountAll  number;
      BEGIN -- 4
        if (v_cross_seg_val_flag = 'Y') then
          select count(1)
            into l_flexRulesCount
            from fnd_flex_vdation_rules_vl ffvrv, gl_sets_of_books gsob
           where ffvrv.id_flex_num = gsob.chart_of_accounts_id
             and ffvrv.application_id = 101
             and ffvrv.enabled_flag = 'Y'
             and NVL(ffvrv.start_date_active, SYSDATE) <= SYSDATE
             and NVL(ffvrv.end_date_active, SYSDATE) >= SYSDATE
             and ffvrv.id_flex_num = v_CHART_OF_ACCOUNTS_ID
             and gsob.set_of_books_id = v_sobid;

          Tab2Print('Cross validation rules can be setup as cross validate segments is enabled');
          if (l_flexRulesCount > 0) then
            Tab2Print('Number of cross validation rules defined = '||to_char(l_flexRulesCount));
          else
            WarningPrint('Cross Validation rules are enabled but no valid Cross Validation rules are defined');
            ActionWarningPrint('Please define cross validation rules or ensure that the appropriate rules are enabled and not end dated');
          end if;
        else
          Tab2Print('Cross validation rules cannot be setup as cross validate segments is not enabled');
        end if;

        select count(1)
          into l_flexRulesCountAll
          from fnd_flex_vdation_rules_vl ffvrv, gl_sets_of_books gsob
         where ffvrv.id_flex_num = gsob.chart_of_accounts_id
           and ffvrv.application_id = 101
           and ffvrv.enabled_flag <> 'Y'
           and NVL(ffvrv.start_date_active, SYSDATE) > SYSDATE
           and NVL(ffvrv.end_date_active, SYSDATE) < SYSDATE
           and ffvrv.id_flex_num = v_CHART_OF_ACCOUNTS_ID
           and gsob.set_of_books_id = v_sobid;

        Tab2Print('Number of disabled and/ or end dated cross validation rules = '||to_char(l_flexRulesCountAll));

      EXCEPTION -- 4
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Cross Validation Rules Check"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Cross Validation Rules Check

      BRPrint;
      Tab1Print('Security Rules');
      DECLARE -- 4 -- Cross Validation Rules
        l_securityRulesCountAll number;
        l_securityRulesCount    number;
      BEGIN -- 4
        select count(1)
          into l_securityRulesCountAll
          from fnd_flex_value_rules_vl;

        if (l_securityRulesCountAll > 0) then
          Tab2Print('Number of security rules defined = '||to_char(l_securityRulesCountAll));

          select count(1)
            into l_securityRulesCount
            from fnd_flex_value_rule_usages ffvru, fnd_flex_value_rules_vl ffvrv
           where ffvru.flex_value_rule_id = ffvrv.flex_value_rule_id
             and ffvru.flex_value_set_id = ffvrv.flex_value_set_id
             and ffvru.application_id = 101
             and ffvru.RESPONSIBILITY_ID = :v_respid;

          if (l_securityRulesCount = 0) then
            WarningPrint('Security Rules are not assigned to this responsibility');
            ActionWarningPrint('If security rules need to implemented for this responsibility, please '||
                          'assign security rules to this responsibility in the Assign Flexfield Security Rules form');
          elsif (l_securityRulesCount > l_securityRulesCountAll) then
            WarningPrint(to_char(l_securityRulesCount-l_securityRulesCountAll)||' security rule(s) are not assigned to this responsibility');
            ActionWarningPrint('If security rules need to implemented for this responsibility, please assign '||
                          'security rules to this responsibility in the Assign Flexfield Security Rules form');
          end if;
        else
          Tab2Print('No security rules are setup');
        end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Security Rules"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Security Rules

      BRPrint;
      Tab1Print('Summary Templates');
      DECLARE -- 4 -- Summary templates
        l_summaryCount number;
      BEGIN -- 4
        select count(gst.template_name)
          into l_summaryCount
          from gl_summary_templates gst
         where gst.set_of_books_id = v_sobid
           and gst.status = 'F';

        if (l_summaryCount = 0) then
          Tab2Print('No summary templates are setup');
        else
          Tab2Print('Number of summary templates setup and enabled = '||l_summaryCount);
        end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Summary Template"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Summary templates

      BRPrint;
      Tab1Print('Units of Measure');
      DECLARE -- 4 -- Unit of measure
        l_UOMCount number;
      BEGIN -- 4
        select count(gsauv.unit_of_measure)
          into l_UOMCount
          from gl_stat_account_uom_v gsauv
         where gsauv.chart_of_accounts_id = v_CHART_OF_ACCOUNTS_ID;

        if (l_UOMCount = 0) then
          Tab2Print('No statistical units of measure are setup for this chart of accounts');
        else
          Tab2Print('Number of statistical units of measure defined = '||l_UOMCount);
        end if;
      EXCEPTION
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Units of Measure"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Unit of measure
    EXCEPTION
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about Chart of Accounts');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Chart of accounts

    /* Checking the details of the Calendar SetUp */
    BRPrint;
    SectionPrint('Calendar Details');
    BRPrint;
    DECLARE -- 3
      l_problemDatesCount number;
    BEGIN -- 3
      Tab1Print('Calendar name = '||v_PERIOD_SET_NAME);
      CheckFinPeriod(v_sobid,101);
      Tab1Print('Number of defined future periods = '||v_FUTURE_PERIODS_LIMIT);

      /* There are two inline views each with a nested inline view.
      // The reason is that the gl_periods table needs to be joined back on to itself
      // with the periods in order for each period type.
      */
      select count(1) into l_problemDatesCount
        from (select rownum row_num, period_name, period_set_name, start_date, end_date, period_type
                from
               (select per.period_name, per.period_set_name, per.period_type, per.start_date, per.end_date
                  from gl.gl_sets_of_books glsob, gl.gl_periods per
                 where glsob.period_set_name = per.period_set_name
                   and per.adjustment_period_flag = 'N'
                   and glsob.set_of_books_id = v_sobid
                 order by per.period_type, per.start_date
               )
             ) perset1,
             (select rownum row_num, period_name, period_set_name, start_date, end_date, period_type
                from
               (select per.period_name, per.period_set_name, per.period_type, per.start_date, per.end_date
                  from gl.gl_sets_of_books glsob, gl.gl_periods per
                 where glsob.period_set_name = per.period_set_name
                   and per.adjustment_period_flag = 'N'
                   and glsob.set_of_books_id = v_sobid
                 order by per.period_type, per.start_date
                )
             ) perset2
       where perset2.row_num = perset1.row_num + 1
         and perset2.start_date != perset1.end_date + 1
         and perset2.period_type = perset1.period_type;

      if (l_problemDatesCount = 0) then
        Tab1Print('No overlapping periods or gaps in periods found for this set of books');
      else
        ErrorPrint('Overlapping periods or gaps between periods have been detected');
        ActionErrorLink('Please correct in the Accounting Calendar form. Modify the '||
         'period(s) as indicated in the table.  If the form does not allow this please '||
         'raise a Service Request with Oracle Support Services providing the output of '||
         'report.  Please see ', 184436.1, ' for further information');
        BRPrint;
        sqltxt := 'select perset1.period_set_name "Accounting|Calendar|Name", '||
                  '       pt.user_period_type "Period|Type", '||
                  '       perset1.period_name "Period Name", '||
                  '       perset1.end_date "End Date", '||
                  '       perset2.period_name "Next Period Name", '||
                  '       perset2.start_date "Start Date", '||
                  '       decode(sign(perset2.start_date - perset1.end_date - 1),-1,''OVERLAP'',1,''GAP'',0,null) "Problem" '||
                  'from (select rownum row_num, period_name, period_set_name, start_date, end_date, period_type '||
                          'from '||
                            '(select per.period_name, per.period_set_name, per.period_type, per.start_date, per.end_date '||
                                'from gl.gl_sets_of_books glsob, gl.gl_periods per '||
                               'where glsob.period_set_name = per.period_set_name '||
                                 'and per.adjustment_period_flag = ''N'' '||
                                 'and glsob.set_of_books_id = '||v_sobid||' '||
                               'order by per.period_type, per.start_date '||
                             ') '||
                           ') perset1, '||
                           '(select rownum row_num, period_name, period_set_name, start_date, end_date, period_type '||
                              'from '||
                             '(select per.period_name, per.period_set_name, per.period_type, per.start_date, per.end_date '||
                                'from gl.gl_sets_of_books glsob, gl.gl_periods per '||
                               'where glsob.period_set_name = per.period_set_name '||
                                 'and per.adjustment_period_flag = ''N'' '||
                                 'and glsob.set_of_books_id = '||v_sobid||' '||
                               'order by per.period_type, per.start_date '||
                              ') '||
                           ') perset2 '||
                   ',      gl_period_types pt '||
                     'where perset2.row_num = perset1.row_num + 1 '||
                       'and perset2.start_date != perset1.end_date + 1 '||
                       'and perset2.period_type = perset1.period_type '||
                       'and perset2.period_type = pt.period_type';
        Run_SQL(null, sqltxt,'Y',null,1);
        BRPrint;
      end if;
    EXCEPTION -- 3
      WHEN OTHERS then
        ErrorPrint(sqlerrm||' occurred in "Calendar Details"');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Calendar Details

    /* Checking the details of the functional currency setup */
    BRPrint;
    SectionPrint('Functional Currency Details');
    BRPrint;
    DECLARE -- 3 -- Currency Set Up
      l_currencyFlag varchar2(1);
      l_creationDate date;
      cursor c_currencies is
        select fc.currency_flag, fc.creation_date
          from fnd_currencies fc
         where fc.currency_code = v_CURRENCY_CODE
           and fc.enabled_flag = 'Y'
           and NVL(fc.start_date_active, SYSDATE) <= SYSDATE
           and NVL(fc.end_date_active, SYSDATE) >= SYSDATE;
      r_currencies c_currencies%rowtype;
    BEGIN -- 3
      Tab1Print('Functional currency = '||v_CURRENCY_CODE);

      open c_currencies;
      fetch c_currencies into l_currencyFlag, l_creationDate;
      if (c_currencies%NOTFOUND) then
        ErrorPrint('Unable to retrieve functional currency information');
        ActionErrorPrint('Please enter a valid functional for the set of books in the Define Set of Books form');
      else
        Tab1Print('Enabled Flag = Y');
        Tab1Print('Currency Flag = '||l_currencyFlag);
        Tab1Print('Created Date = '||l_creationDate);
      end if;
      close c_currencies;
    EXCEPTION -- 3
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about Currency Setup');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Currency Setup

    /* Checking the details of Budgetary Control Set. This check is only performed if the
       budgetary control is enabled for this set of books.
    */
    BRPrint;
    SectionPrint('Budgetary Control Details');
    BRPrint;
    BEGIN -- 3
      -- Checking Budgetary Control is set up
      if (v_ENABLE_BUDGET_CONTROL_FLAG != 'Y') then
        Tab1Print('Budgetary Control is not enabled. Budgetary Control set up checks will not be performed.');
      else
        Tab1Print('Budgetary Control is enabled');

        -- Check profile option for BUDGETARY_CONTROL_OPTION
        /*CheckProfile('BUDGETARY_CONTROL_OPTION', userIDStr,  respid, appid, null,1); */

        DECLARE -- 4
          l_controlGroupCount  number;
        BEGIN -- 4
          -- Checking for Budgetary Control Group
          select count(1)
            into l_controlGroupCount
            from gl_bc_options gbo, gl_bc_option_details_v gbod
           where gbo.bc_option_id = gbod.bc_option_id;

          if (l_controlGroupCount = 0) then
            ErrorPrint('No Budgetary Control groups have been setup');
            ActionErrorPrint('Please define at least one Budgetary Control group when budgetary control is enabled');
          else
            Tab1Print('Number of defined budgetary control groups = '||to_char(l_controlGroupCount));
            BRPrint;
            sqltxt := 'select gbod.user_je_source_name "Source", gbod.user_je_category_name "Category Name", '||
                      '       gbod.user_funds_check_level "Funds Level" '||
                      '  from gl_bc_options gbo, gl_bc_option_details_v gbod '||
                      ' where gbo.bc_option_id = gbod.bc_option_id';
            Run_SQL(null,sqltxt,'Y',null,1);
            BRPrint;
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "Checking for Budgetary Control Group"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END; -- 4 -- Checking for Budgetary Control Group

        -- Display Summary Templates Information
        DECLARE -- 4
          l_sumCount number;
        BEGIN -- 4
          select count(1)
            into l_sumCount
            from gl_summary_templates glt
           where glt.status = 'F' and glt.set_of_books_id = v_sobid;

          if (l_sumCount = 0) then
            Tab1Print('No enabled Summary templates are defined');
          else
            Tab1Print('General Ledger Summary Templates');
            BRPrint;
            sqltxt := 'select template_name "Template Name", '||
                      'funds_check_level_code "Funds Check|Level Code" '||
                      'from gl_summary_templates '||
                      'where status =''F'' and set_of_books_id = '||v_sobid;
            Run_SQL(null, sqltxt,'Y',null,1);
            BRPrint;
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "Display Summary Templates Information"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END; -- 4 -- Display Summary Templates Information

        -- Display Encumbrance Types Information
        DECLARE -- 4
          l_encumCount number;
        BEGIN -- 4
          select count(1)
            into l_encumCount
            from gl_encumbrance_types
           where enabled_flag = 'Y';

          if (l_encumCount = 0) then
            WarningPrint('No Encumbrance Types are defined');
            ActionWarningPrint('Please define appropriate Encumbrance Types');
          else
            Tab1Print('Encumbrance Types Setup Details');
            BRPrint;
            sqltxt := 'select encumbrance_type_id "Encumbrance|Type ID", '||
                      'encumbrance_type "Encumbrance|Type" '||
                      'from gl_encumbrance_types '||
                      'where enabled_flag = ''Y'' ';
            Run_SQL(null,sqltxt,'Y',null,1);
            BRPrint;
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "Display Encumbrance Types Information"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END; -- 4 -- Display Encumbrance Types Information

        -- Unposted encumbrance transactions
        DECLARE -- 4 -- Unposted Encumbrance lines
          l_unpostedCount number;
        BEGIN -- 4
          select count(1)
            into l_unpostedCount
            from gl_bc_packets gbp, gl_sets_of_books gsob
           where gbp.set_of_books_id = gsob.set_of_books_id
             and gbp.result_code like 'P%'
             and gsob.set_of_books_id = v_sobid
             and gbp.status_code  in ('A','C','P','S')
             and gsob.enable_budgetary_control_flag = 'Y';

          if (l_unpostedCount = 0) then
            Tab1Print('There are no unposted encumbrance transactions in the GL_BC_PACKETS table');
          else
            WarningPrint('Number of waiting postable Encumbrance transactions = '||to_char(l_unpostedCount));
            ActionWarningPrint('The Encumbrance Create Journals program needs to be run - to bring these transactions into General Ledger');
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "Unposted encumbrance transactions"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END; -- 4 -- Unposted encumbrance transactions

        DECLARE -- 4 -- Checking for Transaction Codes
          l_transCodeCount number;
          l_PSAStatus      fnd_product_installations.status%type;
        BEGIN -- 4
          select count(1)
            into l_transCodeCount
            from gl_ussgl_transaction_codes gutc, gl_sets_of_books gsob
           where gutc.chart_of_accounts_id = gsob.CHART_OF_ACCOUNTS_ID
             and gsob.chart_of_accounts_id = v_chart_of_accounts_id
             and NVL(gutc.start_date_active, SYSDATE) > SYSDATE
             and NVL(gutc.end_date_active, SYSDATE) < SYSDATE
             and gsob.enable_budgetary_control_flag = 'Y';

          select fpi.status
            into l_PSAStatus
            from fnd_product_installations fpi, fnd_application fa
           where fpi.application_id = fa.application_id
             and fa.application_short_name = 'PSA';

          -- Both Installed and Shared are ok now
          if (l_PSAStatus = 'I' or l_PSAStatus = 'S') then
            Tab1Print('Public Sector General Ledger is installed');
            if (l_transCodeCount = 0) then
              WarningPrint('No transaction codes are setup');
              ActionWarningPrint('Please define transactions codes if this functionality is to be used with PSA');
            else
              Tab1Print('Number of Codes defined = '||l_transCodeCount);
            end if;
          else
            Tab1Print('Public Sector General Ledger is not installed');
            if (l_transCodeCount > 0) then
              WarningPrint('Number of defined Transaction codes = '||l_transCodeCount);
              ActionWarningPrint('Transaction Codes do not need to be defined when Public Sector General Ledger is not installed');
            else
              Tab1Print('Transaction Codes are not setup');
            end if;
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "Unposted Encumbrance lines"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END; -- 4 -- Unposted Encumbrance lines
      end if;
    EXCEPTION -- 3
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about Budgetary Control Details');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Budgetary Control Details

    -- Display budget Information
    BRPrint;
    SectionPrint('Budgets');
    BRPrint;
    DECLARE -- 3
      l_budgetCount number;
    BEGIN -- 3
      select count(1)
        into l_budgetCount
        from gl_budgets gb, gl_sets_of_books gsob
       where gb.set_of_books_id = gsob.set_of_books_id
         and gb.set_of_books_id = v_sobid
         and gb.status = 'O'
         and gb.date_closed is null;

      if (l_budgetCount = 0) then
        Tab1Print('No open budgets are available');
      else
        Tab1Print('Budget Information details');
        BRPrint;
        sqltxt := 'select gl.budget_name "Budget|Name", '||
                  'gl.budget_type "Budget|Type", '||
                  'decode(gl.status,''O'',''Open'',gl.status) "Status", '||
                  'gl.date_created "Date|Created", '||
                  'gl.require_budget_journals_flag "Require|Budget|Journals|Flag", '||
                  'gl.last_update_date "Last|Update|Date" '||
                  'from gl_budgets gl, gl_sets_of_books gsob '||
                  'where gl.set_of_books_id = gsob.set_of_books_id '||
                  'and gl.set_of_books_id = '||v_sobid||' '||
                  'and gl.status = ''O'' '||
                  'and gl.date_closed is null';

        Run_SQL(null,sqltxt,'Y',null,1);
        BRPrint;
      end if;
    EXCEPTION
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about Budget Information');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Display budget Information

    -- Display Budget Organization Details
    BRPrint;
    SectionPrint('Budget Organization Details');
    BRPrint;
    DECLARE -- 3
      l_budorgCount number;
    BEGIN -- 3
      select count(1)
        into l_budorgCount
        from gl_budget_entities gbe, gl_sets_of_books gsob, gl_budget_assignment_ranges_v gbarv
       where gbe.set_of_books_id = gsob.set_of_books_id
         and gsob.set_of_books_id = gbarv.set_of_books_id
         and gsob.set_of_books_id = v_sobid
         and gbe.budget_entity_id = gbarv.budget_entity_id
         and NVL(gbe.start_date, SYSDATE) <= SYSDATE
         and NVL(gbe.end_date, SYSDATE) >= SYSDATE
         and gbe.status_code = 'C';

      if (l_budorgCount = 0) then
        Tab1Print('No valid budget organization is available');
      else
        Tab1Print('Budget Organization Information details');
        BRPrint;
        sqltxt := 'select gbe.name "Name", '||
                  'gbe.budget_password_required_flag "Budget|Password|Required|Flag", '||
                  'decode(gbe.status_code, ''C'',''Current'',gbe.status_code) "Status|Code", '||
                  'gbe.last_update_date "Last|Update|Date", '||
                  'gbarv.currency_code "Currency|Code" '||
                  'from gl_budget_entities gbe, '||
                  'gl_sets_of_books gsob, gl_budget_assignment_ranges_v gbarv '||
                  'where gbe.set_of_books_id = gsob.set_of_books_id '||
                  'and gsob.set_of_books_id = gbarv.set_of_books_id '||
                  'and gsob.set_of_books_id = '||v_sobid||' '||
                  'and gbe.budget_entity_id = gbarv.budget_entity_id '||
                  'and NVL(gbe.start_date, SYSDATE) <= SYSDATE '||
                  'and NVL(gbe.end_date, SYSDATE) >= SYSDATE '||
                  'and gbe.status_code = ''C'' ';
        Run_SQL(null,sqltxt,'Y',null,1);
        BRPrint;
      end if;
    EXCEPTION
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about Budget Organization Details');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Display Budget Organization Details

    /* This checks for the and validates all the Financial Analyzer setup. This section will
       only be performed if the user indicate 'Y' for the OFA parameter when running the diagnostic test.
    */
    SectionPrint('Oracle Financial Analyzer Details');
    BRPrint;
    BEGIN -- 3
      if (upper(:v_ofa) = 'Y') then
        DECLARE -- 4
          l_datasetCount     number;
        BEGIN -- 4
          select count(1)
            into l_datasetCount
            from rg_dss_systems rds, gl_sets_of_books gsob
           where rds.id_flex_num = gsob.chart_of_accounts_id
             and rds.period_set_name = gsob.period_set_name
             and gsob.set_of_books_id = v_sobid
             and rds.freeze_flag = 'Y';

          if (l_datasetCount <= 0) then
            WarningPrint('No Frozen Financial data sets are setup');
            ActionWarningPrint('Please define at least one frozen Financial Data Set in order to '||
                               'correctly setup the GL to OFA link');
          else
            Tab1Print('Number of Financial data sets defined = '||l_datasetCount);
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "OFA - Financial data sets"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END; -- 4

        DECLARE -- 4
          l_dataItemsCount  number;
        BEGIN -- 4
          select count(1)
            into l_dataItemsCount
            from rg_dss_variables_v rdv, gl_sets_of_books gsob
           where rdv.id_flex_num = gsob.chart_of_accounts_id
             and rdv.set_of_books_id = gsob.set_of_books_id
             and rdv.func_curr_code = gsob.currency_code
             and gsob.set_of_books_id = v_sobid;

          if (l_dataItemsCount <= 0) then
            WarningPrint('No Financial data items are setup');
            ActionWarningPrint('Please ensure that at least one Financial Data Item is defined');
          else
            Tab1Print('Number of Financial data items defined = '||l_dataItemsCount);
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "OFA - Financial Data Items"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END; -- 4

        DECLARE -- 4
          l_hierarchiesCount number;
        BEGIN -- 4
          select count(1)
            into l_hierarchiesCount
            from rg_dss_hierarchies_v rdh, gl_sets_of_books gsob
           where rdh.id_flex_num = gsob.chart_of_accounts_id
             and gsob.set_of_books_id = v_sobid;

          if (l_hierarchiesCount <= 0) then
            WarningPrint('No Hierarchies are setup');
            ActionWarningPrint('Please ensure at least one Hierarchy is defined');
          else
             Tab1Print('Number of Hierarchies defined = '||l_hierarchiesCount);
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "OFA - Hierarchies"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END;

        DECLARE -- 4
          l_dimensionsCount  number;
        BEGIN -- 4
          select count(1)
            into l_dimensionsCount
            from rg_dss_dimensions rdd, gl_sets_of_books gsob
           where rdd.id_flex_num = gsob.chart_of_accounts_id
             and gsob.set_of_books_id = v_sobid;

          if (l_dimensionsCount <= 0) then
            WarningPrint('No Dimensions are setup');
            ActionWarningPrint('The transfer from GL to OFA process will not work unless dimensions are setup in GL. '||
                               'Please ensure that at least one dimensions is defined.');
          else
            Tab1Print('Number of dimensions defined = '||l_dimensionsCount);
          end if;
        EXCEPTION -- 4
          WHEN OTHERS then
            ErrorPrint(sqlerrm||' occurred in "OFA - Dimensions"');
            ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
        END; -- 4
      else
        Tab1Print('No Oracle Financial Analyzer setup check was done '||
                  'as it was not requested during parameter entry');
      end if; -- if OFA is selected
    EXCEPTION -- 3
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about OFA Setup');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Oracle Financial Analyzer Setup

    /* Check and validates the Global Intercompany Setup. If the Subsidiary profile
       option is not set then the check will not be performed because GIS cannot be
       used without this profile option being set.
    */
    SectionPrint('Global Intercompany System (GIS) Details');
    BRPrint;
    DECLARE -- 3
      l_acctRulesCount   number;
      l_recurBatchCount  number;
      l_subsidCount      number;
      l_transtypeCount   number;
      l_subsidProfile    number(15);
      l_subsidName       GL_IEA_SUBSIDIARIES.name%type;
    BEGIN /* GIS setup */
      l_subsidProfile:= to_number(Get_Profile_Option('GL_IEA_SUBSIDIARY_ID'));

      if (l_subsidProfile is null) then
        WarningPrint('Profile: Intercompany/Interfund: Subsidiary is not set for this set of books');
        ActionWarningLink('If Global Intercompany System (GIS) is being used in this environment, '||
                          'please set the Intercompany/Interfund: Subsidiary profile option to a '||
                          'valid Subsidiary and rerun the test. See also Note ','137275.1',
                          ' Global Intercompany System(Centra/GIS) Setup - for more details about '||
                          'setting up GIS.');
      else
        -- if subsidiary profile option is set
        select name
        into   l_subsidName
        from   GL_IEA_SUBSIDIARIES
        where  SUBSIDIARY_ID = l_subsidProfile;
        Tab1Print('Profile: Intercompany/Interfund: Subsidiary = '||l_subsidName||
          ' (ID='||l_subsidProfile||')');

        -- display all subsidiaries created --
        sqltxt := 'select '
        ||'        s.NAME "Subsidiary" '
        ||',       s.SUBSIDIARY_ID "Subsidiary|ID" '
        ||',       s.ENABLED_FLAG "Enabled" '
        ||',       s.DESCRIPTION "Description" '
        ||',       sob.name "Intercompany|Book" '
        ||',       s.CHART_OF_ACCOUNTS_ID "Chart|of|Accounts" '
        ||',       s.CURRENCY_CODE "Transaction|Currency" '
        ||',       s.COMPANY_VALUE "Company" '
        ||',       s.AUTO_APPROVE_FLAG "Allow|Auto|Approval" '
        ||',       s.VIEW_PARTNER_LINES_FLAG "Access|Partner|Lines|Flag" '
        ||',       s.NOTIFICATION_THRESHOLD "Threshold|Amount" '
        ||',       s.CONTACT "Contact" '
        ||',       s.REMOTE_INSTANCE_FLAG "Transfer|Opt|Remote|Instance" '
        ||',       sob2.name "Remote/Local|Set of|Books Name" '
        ||',       s.TRANSFER_CURRENCY_CODE "Transfer|Currency" '
        ||',       s.CONVERSION_TYPE "Conversion|Type" '
        ||'from    GL_IEA_SUBSIDIARIES s '
        ||',       gl_sets_of_books sob '
        ||',       gl_sets_of_books sob2 '
        ||'where   s.SET_OF_BOOKS_ID = sob.SET_OF_BOOKS_ID '
        ||'and     s.TRANSFER_SET_OF_BOOKS_ID = sob2.SET_OF_BOOKS_ID ';
        Run_SQL(null,sqltxt,'Y',null,1);
        
        select count(1)
        into   l_acctRulesCount
        from   gl_iea_autogen_map_v;
        if (l_acctRulesCount = 0) then
          WarningPrint('No intercompany auto accounting rules are setup');
          ActionWarningPrint('Intercompany auto accounting rules should be setup before GIS can be used');
        else
          Tab1Print('Number of intercompany auto accounting rules setup = '||l_acctRulesCount);
        end if;

        select count(1)
          into l_transtypeCount
          from gl_iea_transaction_types
         where enabled_flag = 'Y';

        if (l_transtypeCount = 0) then
          WarningPrint('No intercompany transaction types are setup and/ or enabled');
          ActionWarningPrint('Intercompany transactions types should be setup and enabled for GIS');
        else
          Tab1Print('Number of intercompany transaction types setup and enabled = '||l_transtypeCount);
        end if;

        select count(1)
          into l_subsidCount
          from gl_iea_subsidiaries_v gisv, gl_sets_of_books gsob
         where gisv.set_of_books_id = gsob.set_of_books_id
           and gisv.chart_of_accounts_id = gsob.chart_of_accounts_id
           and gisv.enabled_flag = 'Y';

        if (l_subsidCount = 0) then
          WarningPrint('No Intercompany Subsidiaries are setup/enabled');
          ActionWarningLink('Please define and enable at least one subsidiary company.'||
            'See also Oracle General Ledger User Manual lli, ','66935.1',' chapter - Setting '||
            'up Global Intercompany System ');
        else
          Tab1Print('Number of intercompany subsidiaries setup and enabled = '||l_subsidCount);
        end if;

        select count(1)
          into l_recurBatchCount
          from gl_iea_recur_batches_v girbv, gl_sets_of_books gsob
         where girbv.chart_of_accounts_id = gsob.chart_of_accounts_id
           and gsob.set_of_books_id = v_sobid;

        if (l_recurBatchCount = 0) then
          Tab1Print('No GIS recurring batches are setup for this Chart of accounts');
        else
          Tab1Print('Number of GIS recurring batches defined = '||l_recurBatchCount);
        end if; -- if subsidiary profile option is set
      end if; -- Profile is not set
    EXCEPTION -- 3
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about GIS Details');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- GIS Details


-- --- Miscellaneous General Ledger Section -------------------------------------------------------
    -- Check, validate and report other General Ledger set up
    BRPrint;
    SectionPrint('Miscellaneous General Ledger Details');
    BRPrint;
    DECLARE -- 3
      l_requestCount   number;
      l_dblinkCount    number;
      l_otherDocCount  number;
      l_empCount       number;
      l_docSeqCount    number  := 0;
      l_uomCount       number;
      l_descrFlexCount number;
      l_autoPostCount  number;
    BEGIN -- 3
      -- Concurrent requests for GL
      select count(1)
        into l_requestCount
        from gl_concurrent_schedules gcs, gl_sets_of_books gsob
       where gcs.period_set_name = gsob.period_set_name;

      if (l_requestCount = 0) then
        Tab1Print('No GL concurrent requests are currently set for scheduling');
      else
        Tab1Print('Number of scheduled GL concurrent requests = '||l_requestCount);
      end if;

      -- Database links
      select count(1)
        into l_dblinkCount
        from rg_database_links;

      if (l_dblinkCount = 0) then
        Tab1Print('No database links are setup.');
        Tab1Print('Please note that a valid database link is required for the FSG transfer program to run.');
      else
        Tab1Print('Number of defined database links = '||l_dblinkCount);
      end if;

      -- Document Sequence check
      l_sequential := Get_Profile_Option('UNIQUE:SEQ_NUMBERS');

      select count(*)
      into   counter
      from   fnd_document_sequences fds
      ,      fnd_doc_sequence_assignments fdsa
      where  fds.application_id = 101
      and    fds.application_id = fdsa.application_id
      and    fdsa.set_of_books_id = v_sobid
      and    fdsa.category_code in (select c.je_category_name from gl_je_categories c)
      and    fds.doc_sequence_id = fdsa.doc_sequence_id
      and    fdsa.end_date is null;

      select count(*)
      into   counter2
      from   gl_je_categories;

      if counter2 > 0 then
	if l_sequential = 'A' then
	  Tab1Print('Sequential Number = Always Used');
	  if counter <> counter2 then
	    ErrorPrint('The profile option Sequential Numbering is defined '||
	      'to have sequential numbering always used.  Not all Journal Categories '||
	      'have a sequence assigned.');
	    ActionErrorLink('Go to the Assign Sequences screen and assign a sequence '||
	      'to all Journal Categories.  Alternatively, change the Sequential Numbering '||
	      'profile to "Partially Used" to prevent this error from occurring.  Please '||
	      'see note:','136692.1',' to help with troubleshooting Document Sequencing');
	  else
	    Tab2Print('All Journal Categories have a document sequence assigned');
	  end if;
	elsif l_sequential = 'P' then
	  Tab1Print('Sequential Number = Partially Used');
	  if counter = 0 then
	    WarningPrint('No sequences have been defined for any Journal Category'); 
	    ActionWarningPrint('No action is required unless document sequencing '||
	      'should be used with Journal Categories in this environment');
	  else
	    Tab2Print(counter||' Journal Categories have a document sequence assigned');
	  end if;
	elsif l_sequential = 'N' then
	  Tab1Print('Sequential Number = Not Used');
	  if counter > 0 then
	    ErrorPrint('Document Sequencing has been defined for a Journal Category but '||
	      'Sequential Numbering profile is set to "Not Used"');
	    ActionErrorLink('Please either remove the document sequence from this Journal '||
	      'Category as it will not be used or change the Profile: Sequential Numbering '||
	      'to "Partially Used".   Please see note:','136692.1',
	      ' to help with troubleshooting Document Sequencing');
	  else 
	    Tab2Print('No Journal Categories have a document sequence assigned');
	  end if;
	end if;
      else
        Tab1Print('Journal Categories have not yet been defined');
      end if;
      
      if (v_default_je_cat is not null) then
        select count(1)
          into l_docSeqCount
          from fnd_document_sequences fds, fnd_doc_sequence_assignments fdsa
         where fds.application_id = 101
           and fds.application_id = fdsa.application_id
           and fdsa.set_of_books_id = v_sobid
           and fdsa.category_code = v_default_je_cat
           and fds.doc_sequence_id = fdsa.doc_sequence_id
           and fdsa.end_date is null;

        if (l_docSeqCount = 0) then
          WarningPrint('No document sequence is setup for the default journal category');
          ActionWarningLink('It is recommended that document sequences be setup for '||
            'at least the default journal category. Please see Note: ',66935.1,
            ' Oracle General Ledger User Manual lli - Setting up Document Sequences');
        else
          Tab1Print('Number of document sequences setup for '||v_default_je_cat||' = '||l_docSeqCount);
        end if;
      end if;

      select count(1)
        into l_otherDocCount
        from fnd_document_sequences
       where application_id = 101
         and (name != v_default_je_cat or v_default_je_cat is null);

      Tab1Print('Number of document sequences setup = '||l_otherDocCount);

      -- Number of employees setup
      select count(1)
        into l_empCount
        from per_people_f
       where 1 = 1;

      if (l_empCount = 0) then
        Tab1Print('No employees have been created. Please create employees if needed');
      else
        Tab1Print('Number of employees setup = '||l_empCount);
      end if;

      -- Automatic Journal Reverse Information
      BRPrint;
      Tab1Print('Automatic Journal Reversal');
      DECLARE -- 4
        l_autorevCount number;
        l_autopostCount number;
      BEGIN -- 4
        -- Automatic Journal Reversal
        select count(1)
          into l_autorevCount
          from gl_autoreverse_options
         where set_of_books_id = v_sobid
           and autoreverse_flag = 'Y';

        if (l_autorevCount = 0) then
          Tab2Print('Automatic Journal Reversal is not enabled for any Journal categories');
        else
          Tab2Print('Automatic Journal Reversal is enabled');
          Tab2Print('Journal categories');
          BRPrint;
          sqltxt := 'select c.user_je_category_name "Category Name" '||
                    ',      decode(a.method_code,''C'',''Switch dr/cr'',''S'',''Change Sign'') "Method|Code" '||
                    ',      a.creation_date "Creation|Date" '||
                    'from   gl_autoreverse_options a '||
                    ',      gl_je_categories c '||
                    'where  c.je_category_name = a.je_category_name '||
                    'and    a.autoreverse_flag = ''Y'' '||
                    'and    a.set_of_books_id = '||v_sobid;
          Run_SQL(null,sqltxt,'Y',null,2);
          BRPrint;
        end if;

        -- Automatic Journal Reversal Posting
        select count(1)
          into l_autopostCount
          from gl_autoreverse_options
         where set_of_books_id = v_sobid
           and autopost_reversal_flag = 'Y';

        if (l_autopostCount = 0) then
          Tab2Print('Automatic Journal Reversal Posting is not enabled for any Journal categories');
        else
          Tab2Print('Automatic Journal Reversal Posting is enabled');
          Tab2Print('Journal categories');
          BRPrint;
          sqltxt := 'select c.user_je_category_name "Category Name" '||
                    ',      decode(a.method_code,''C'',''Switch dr/cr'',''S'',''Change Sign'') "Method|Code" '||
                    ',      a.creation_date "Creation|Date" '||
                    'from   gl_autoreverse_options a '||
                    ',      gl_je_categories c '||
                    'where  c.je_category_name = a.je_category_name '||
                    'and    a.autopost_reversal_flag = ''Y'' '||
                    'and    a.set_of_books_id = '||v_sobid;
          Run_SQL(null,sqltxt,'Y',null,2);
          BRPrint;
        end if;
      EXCEPTION -- 4
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Automatic Journal Reverse Information"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- Automatic Journal Reverse Information

      -- Check, Validate and report unposted transactions in the GL_INTERFACE table
      DECLARE -- 4
        l_interfaceCount number;
      BEGIN -- 4
        select count(1)
          into l_interfaceCount
          from gl_interface
         where set_of_books_id = v_sobid;

        if (l_interfaceCount = 0) then
          Tab2Print('There are NO unposted transactions in the GL interface table');
        else
          WarningPrint('There are pending transactions in the GL Interface table awaiting import into General Ledger');
          ActionWarningPrint('Please run Journal Import to import these transactions into General Ledger');
          BRPRint;
          sqltxt := 'select count(1) "Count", user_je_category_name "Category", '||
                    '       user_je_source_name "Source", group_id "Group ID", status "Status" '||
                    '  from gl_interface '||
                    ' where set_of_books_id = '||v_sobid||' '||
                    ' group by user_je_category_name, user_je_source_name, group_id, status';
          Run_SQL(null,sqltxt,'Y',null,2);
          BRPrint;
        end if;
      EXCEPTION -- 4
        WHEN OTHERS then
          ErrorPrint(sqlerrm||' occurred in "Unposted transactions in GL_INTERFACE"');
          ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
      END; -- 4 -- unposted transactions

      -- Descriptive Flexfields Section ----
      select count(1)
        into l_descrFlexCount
        from fnd_descr_flex_contexts
       where application_id = 101
         and enabled_flag = 'Y'
         and descriptive_flexfield_name not like '%SRS%';

      if (l_descrFlexCount = 0) then
        Tab1Print('No enabled descriptive flexfield are setup for General Ledger');
      else
        Tab1Print('Number of setup and enabled descriptive flexfields for GL = '||l_descrFlexCount);
      end if;

      -- Automatic Posting Setup Section ---
      select count(1)
	into l_autoPostCount
	from gl_automatic_posting_options;

      if (l_autoPostCount = 0) then
	Tab1Print('Automatic Posting is not setup for any journal categories');
      else
	Tab1Print('Automatic Posting setup for Journal Categories');
	BRPrint;
	sqltxt := 'select s.user_je_source_name "Source Name" '||
		  ',      c.user_je_category_name "Category Name" '||
		  ',      p.period_name "Period" '||
		  'from   gl_automatic_posting_options p '||
		  ',      gl_je_categories c '||
		  ',      gl_je_sources s '||
		  'where  p.je_category_name = c.je_category_name '||
		  'and    p.je_source_name = s.je_source_name '||
		  'group by s.user_je_source_name, c.user_je_category_name, p.period_name';
	Run_SQL(null,sqltxt,'Y',null,1);
	BRPrint;
      end if;
    EXCEPTION
      WHEN OTHERS then
        ErrorPrint(sqlerrm ||' occurred when collecting information about Misc. GL Details');
        ActionErrorPrint('Please report the error to the diagnostics team using the feedback link');
    END; -- 3 -- Miscellaneous General Ledger Details


-- --- GL Profile Options Section -------------------------------------------------------
    SectionPrint('GL Profile Options');
    BRPrint;
    CheckProfile('GL_DUAL_CURRENCY', v_userid, p_respid, 101,null,1,null,'N');
    CheckProfile('GL_AUTO_ALLOC_ROLLBACK_ALLOWED', v_userid, p_respid, 101,'Yes',1,null,'N');
    CheckProfile('GL_DEBUG_LOG_DIRECTORY', v_userid, p_respid, 101,'No',1,null,'N');
    CheckProfile('GL_REVAL_INC_ACC_RULE', v_userid, p_respid, 101,'YTD',1,null,'N');
    CheckProfile('GL_NUMBER_OF_PURGE_WORKERS', v_userid, p_respid, 101,'No',1,null,'N');
    CheckProfile('GL_JRNL_REVW_REQUIRED', v_userid, p_respid, 101,'No',1,null,'N');
    CheckProfile('GL_AUTOREV_AFTER_OPEN_PERIOD',v_userid, p_respid, 101,'Yes',1,null,'N');
    CheckProfile('GL_OWNERS_EQUITY_TRANSLATION_RULE',v_userid, p_respid, 101,'PTD',1,null,'N');
    CheckProfile('GL_SUMMARY_DEL_WORKERS', v_userid, p_respid, 101,3,1,null,'N');
    CheckProfile('GL_SUMMARY_ACCT_SET_SIZE', v_userid, p_respid, 101,5000,1,null,'N');
    CheckProfile('GL_SUMMARY_ROWS_PER_COMMIT',v_userid, p_respid, 101,5000,1,null,'N');
    CheckProfile('MULTIPLE_RATES_PER_JE', v_userid, p_respid, 101,'No',1,null,'N');
    CheckProfile('GL_ALLOW_NON_BUSINESS_DAY', v_userid, p_respid, 101,'No',1,null,'N');
    CheckProfile('GL_ALLOW_PREPARER_APPROVAL', v_userid, p_respid, 101,'No',1,null,'N');
    CheckProfile('GL_ENABLE_PRIOR_PERIOD_NOTIFICATION',v_userid, p_respid, 101,'No',1,null,'N');
    CheckProfile('GL_FIND_APPROVER_METHOD', v_userid, p_respid, 101,null,1,null,'N');
    CheckProfile('POP_UP_STAT_ACCOUNT', v_userid, p_respid, 101,'No',1,null,'N');
    CheckProfile('GL_OVERRIDE_REVERSAL_OPTION', v_userid, p_respid, 101,'Yes',1,null,'N');
    CheckProfile('USE_PERFORMANCE_MODULE',v_userid, p_respid, 101,'Yes',1,null,'N');
    CheckProfile('GL_GLCCON_PRESERVE_JE', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GL_GLCCON_FILTER_BY_CATEGORY', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GL_VALIDATE_REFERENCE_DATE', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GL_JAHE_SAVING_ALLOWED', v_userid, p_respid, 101, null,1,null,'N');

-- --- FSG Profile options (168) -------------------------------------------------------
    BRPrint;
    SectionPrint('FSG Profile Options');
    BRPrint;
    CheckProfile('REPORT_FLEX_CODE', v_userid, p_respid, 168, 'Account',1,null,'N');
    CheckProfile('RG_ALLOW_PORTRAIT', v_userid, p_respid, 168, 'No',1,null,'N');
    CheckProfile('RG_USE_NEW_FIND', v_userid, p_respid, 168, null,1,null,'N');
    CheckProfile('RG_LOGFILE_DETAIL_LEVEL', v_userid, p_respid, 168,'Minimal',1,null,'N');
    CheckProfile('RG_ENFORCE_SEGMENT_SECURITY', v_userid, p_respid, 168,'No',1,null,'N');
    CheckProfile('EXPAND_PARENT_VALUE',v_userid, p_respid, 168, 'No',1,null,'N');
    CheckProfile('RG_STRING_COMPARE_MODE',v_userid, p_respid, 168, null,1,null,'N');

-- --- ADI Profile options  -------------------------------------------------------
    BRPrint;
    SectionPrint('ADI Profile Options');
    BRPrint;
    CheckProfile('GL_AHE_SAVING_ALLOWED',v_userid, p_respid, 101, 'Yes',1,null,'N');
    CheckProfile('GLDI_ANALYSIS_PRIVS', v_userid, p_respid, 101, Null,1,null,'N');
    CheckProfile('GLDI_AUTOCOPY_ENF_LEVEL', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GLDI_BUD_WIZ_SEG_VAL_SECURITY',v_userid, p_respid, 101, 'No',1,null,'N');
    CheckProfile('GLDI_REPORT_WIZ_PRIVS', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('ADI_WHEN_SYSADMIN_OUTPUT_VIEW', v_userid, p_respid, 101, 'No',1,null,'N');
    CheckProfile('ADI_USE_FUNCTIONAL_SECURITY', v_userid, p_respid, 101, 'No',1,null,'N');
    CheckProfile('GLDI_AHE_PRIVS', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GLDI_ALLOW_DRILLDOWN_ACROSS_BOOKS', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GLDI_BALANCE_ACCOUNTING_DATE', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GLDI_CONVERTED_ENTRY_THRESHOLD',v_userid, p_respid, 101, null,1,null,'W');
    CheckProfile('GLDI_CREATE_GROUP_ID', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GLDI_JOURNAL_SOURCE', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GLDI_FORCE_JOURNAL_BALANCE', v_userid, p_respid, 101, null,1,null,'N');
    CheckProfile('GLDI_MAX_EFFECT_RANGE_DRILL', v_userid, p_respid, 101, null,1,null,'W');

-- --- References Section -------------------------------------------------------
    BRPrint;
    SectionPrint('References');
    BRPrint;
    Show_Link('131471.1');
    ActionPrint('Self Service Tool Kit for General Ledger');
    Show_Link('116495.1');
    ActionPrint('FSG PRT Financial Statement Generator Printing');
    Show_Link('136633.1');
    ActionPrint('General Ledger Budgets FAQ');
    Show_Link('136685.1');
    ActionPrint('General Ledger Document Sequencing FAQ');
    Show_Link('149019.1');
    ActionPrint('How can I define my first MRC Period?');
    Show_Link('108236.1');
    ActionPrint('FSG Financial Statement Generator FAQ');
    Show_Link('135433.1');
    ActionPrint('General Ledger Open/Close Period FAQ');
    BRPrint;

-- --- Exception Section -------------------------------------------------------
  EXCEPTION -- 2
    WHEN STOPEXECUTION then
      BRPrint;
    WHEN OTHERS then
      BRPrint;
      ErrorPrint(sqlerrm||' occurred in Diagnostic Test');
      ActionErrorPrint('Please use the Feedback option on Readme of the '||
       'Diagnostics Test to contact support');
      BRPrint;
  END; -- 2

-- --- Feedback ----------------------------------------------------------------
  Show_Footer('&v_testlongname','&v_headerinfo');
  BRPrint;

EXCEPTION   -- exceptions (block 1) for API and template code
  WHEN OTHERS THEN
    BRPrint;
    ErrorPrint(sqlerrm ||' occurred in test');
    ActionErrorPrint('Please report the above error to Oracle Support '||
      'Services.');
    BRPrint;
    Show_Footer('&v_testlongname', '&v_headerinfo');
    BRPrint;
END;  -- end (block 1), API and template code
/

REM  ============== SQL PLUS Environment setup ================================
spool off
set feedback on
set verify on
set trimout on
set trimspool off
set heading on
set autoprint off
set long 80
set linesize 80
set longchunksize 80
set pagesize 14
set timing off
set echo off
set termout on

PROMPT
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================

