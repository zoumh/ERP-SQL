================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract          Oracle General Ledger (GL): Setup Diagnostic Test
================================================================================
PRODUCT:          Oracle General Ledger(GL)
SUBCOMPONENT:     Setup and Maintenance
PRODUCT VERSIONS: Release 11.5.x  
PLATFORM:         Generic
DATE CREATED:     25-NOV-2003
PARAMETERS:       User Name (Required)
		  Responsibility ID (Required)
		  Oracle Financial Analyzer (OFA) Installed Flag (Y/N) (Required)
		  
================================================================================
Instructions
================================================================================
Included Files:
	CoreApiHtml.sql
	GLCheckSetup115.sql
	GLCheckSetup115_readme.html
	GLCheckSetup115_readme.txt
	GLCheckSetup115_Sample_Output.html



Execution Environment:
SQL*Plus


Access Privileges:
Requires APPS user access


Usage:
sqlplus <apps user>/<apps pw> @GLCheckSetup115.sql


Instructions:
The files GLCheckSetup115.sql and CoreApiHtml.sql should be unzipped to a
common directory. From this directory, run the file GLCheckSetup115.sql
in SQL*Plus in the APPS schema.

The test will prompt for an applications user name. After entering a valid
user name a list of valid responsibilities appears. Enter the responsibility
id of the responsibility for which the test needs to be executed.

For the parameter on "Financial Analyzer" please enter 'Y' to check and
report on Oracle Financial Analyzer set up in the General Ledger Application
Setup.

The test will produce an output file
GLCheckSetup115_[ResponsibilityID]_diag.html

This file can be viewed in a text editor or browser, or it can be uploaded
for support analysis.


================================================================================
Description
================================================================================
This test checks the basic setup of the Oracle General Ledger release 11i
application by capturing a snapshot of all major setup information.  The
purpose of the test is to check the basic setup (as outlined in 'Setting Up'
Chapter in the User's Guide) of Oracle General Ledger application. If any setup
information is missing or is invalid, the test will output error/warning
messages, the appropriate actions to be taken for each error/warning, and the
impact of the missing setup.  

Prerequisite or Co-requisites not included with this patch : 11i
environment
Dependent Applications : None
Patch to be applied:  None
Pre-patch application steps : None
Post patch application steps : None

================================================================================
Reference
================================================================================
Note.136633.1	General Ledger Budgets FAQ
Note.136685.1	General Ledger Document Sequencing FAQ
Note.108236.1	FSG Financial Statement Generator FAQ

================================================================================
Disclaimer
================================================================================
Except where expressly provided otherwise, the information, software,
provided on an "as is" and "as available" basis. Oracle expressly disclaims
all warranties of any kind, whether express or implied, including, but not
limited to, the implied warranties of merchantability, fitness for a particular
purpose and non-infringement. Oracle makes no warranty that: (a) the results
that may be obtained from the use of the software will be accurate or
reliable; or (b) the information, or other material obtained will meet your
expectations. Any content, materials, information or software downloaded or
otherwise obtained is done at your own discretion and risk. Oracle shall have
no responsibility for any damage to your computer system or loss of data that
results from the download of any content, materials, information or software.


Oracle reserves the right to make changes or updates to the software at any
time without notice.


================================================================================
Limitation Of Liability
================================================================================
In no event shall oracle be liable for any direct, indirect, incidental,
special or consequential damages, or damages for loss of profits, revenue,
data or use, incurred by you or any third party, Whether in an action in
contract or tort, arising from your access to, or use of, the software.
Some jurisdictions do not allow the limitation or exclusion of liability.
accordingly, some of the above limitations may not apply to you.
================================================================================
