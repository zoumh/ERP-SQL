undefine v_headerinfo
Define   v_headerinfo     =  '$Header: GLBalancePerPeriod115.sql 1.15 Date 01-Apr-2003 support $'
undefine v_Testlongname
Define   v_Testlongname = 'General Ledger Period Balances Information'

REM   ==================================================================== 
REM   Copyright � 2002  Corporation Redwood Shores, California, USA 
REM    Support Services.  All rights reserved. 
REM   ====================================================================
REM   PURPOSE:             General Ledger Balances Validation Test 
REM   PRODUCT:             General Ledger (GL)
REM   PRODUCT VERSIONS:    11.5.X 
REM   PLATFORM:            Generic
REM   PARAMETERS           1. Apps username
REM                        2. Responsibility to be chosen from list
REM                        3. Period name (Default = latest open GL period)
REM   ====================================================================
REM   ====================================================================
REM   USAGE:                sqlplus apps/apps@appsdb 
REM                         start GLBalancePerPeriod115.sql
REM   EXAMPLE:  
REM   OUTPUT:               GLBalancePerPeriod115_<Responsibility ID>_diag.html 
REM   ====================================================================   
REM   ==================================================================== 
REM   CHANGE HISTORY: 
REM  12-DEC-2002      bbrown    created v1.0
REM  31-DEC-2002      bbrown	  modified v 1.1
REM  31-DEC-2002      bbrown	  modified v 1.2
REM  03-Jan-2003      bbrown	  modified v 1.3
REM  06-Jan-2003      bbrown	  modified v 1.4
REM  17-Jan-2003      bbrown	  modified v 1.5
REM  17-Jan-2003      bbrown	  modified v 1.6
REM  28-Jan-2003      bbrown	  modified v 1.7
REM  31-Jan-2003      bbrown	  modified v 1.8
REM  19-Feb-2003      bbrown	  modified v 1.12 
REM  
REM  In version 1.12 of this Diagnostic Test, General Ledger Balance validation checks were added for Expense and Revenue 
REM  account types when for first period.
REM  The following Section was added :
REM  'General Ledger Balances for Expense and Revenue Accounts - Period (First Period) = '||:v_orig_periodname)
REM  
REM  28-Mar-2003      bbrown   modified v 1.13 : Modified as per Final QA suggestions
REM  31-Mar-2003      bbrown   modified v 1.14  :Modified as per Final QA suggestions
REM  01-Apr-2003      merickso modified v1.15 :changed Test to test
REM                                            changed version to match repository
REM   ====================================================================   
REM   ==============SQL PLUS Environment setup============================ 

set serveroutput on size 1000000 
set verify off 
set echo off
set autoprint off
set termout on 
set feedback off

REM ============== Define SQL Variables for input parameters ============= 
VARIABLE    v_username       VARCHAR2(100); 
VARIABLE    v_respid         VARCHAR2(100);
VARIABLE    v_periodname     VARCHAR2(15);
VARIABLE    v_orig_periodname     VARCHAR2(15);


PROMPT 
undefine uname
accept uname char PROMPT  'Application User Name (required) : '
PROMPT 

REM ============Validate SQL*Plus Version Character Set Combination============
REM =======NOTE - This section only needed for tests using HTML API's==========

DECLARE
  l_nls_characterset    nls_database_parameters.value%TYPE;
  l_sql_release_int     INTEGER(20) :=  to_number('&_SQLPLUS_RELEASE');
  l_sql_release_chr     VARCHAR2(50) := '&_SQLPLUS_RELEASE';

BEGIN

  SELECT value 
    INTO  l_nls_characterset
    FROM  nls_database_parameters
    WHERE parameter = 'NLS_CHARACTERSET';
    
  FOR i IN 1..4 LOOP
    l_sql_release_chr := substr(l_sql_release_chr,1,(2*i)-1)||'.'||
      substr(l_sql_release_chr,(2*i)+1);
  END LOOP;
  
 
  IF l_nls_characterset LIKE 'UTF%' THEN
    IF l_sql_release_int IS null THEN 
      DBMS_OUTPUT.PUT_LINE(chr(10));
      DBMS_OUTPUT.PUT_LINE('ATTENTION - Cannot determine version of SQL*plus being used for test run.');
      DBMS_OUTPUT.PUT_LINE('.           This test may fail if not run using a version 8.1.X of SQL*plus or higher.');
      DBMS_OUTPUT.PUT_LINE('Attempting to run the test.......');
      DBMS_OUTPUT.PUT_LINE(chr(10));
    ELSIF l_sql_release_int < 801000000 THEN
      DBMS_OUTPUT.PUT_LINE(chr(10));
      DBMS_OUTPUT.PUT_LINE('ERROR - Invalid SQL*plus Version '||l_sql_release_chr);
      DBMS_OUTPUT.PUT_LINE('ACTION - On databases using the '||l_nls_characterset||' NLS characterset this test should not be run using this ');
      DBMS_OUTPUT.PUT_LINE('.        SQL*plus Version.  Please rerun this test using version 8.1.X of SQL*plus or higher.');
      DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
      DBMS_OUTPUT.PUT_LINE(chr(10));
    END IF;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - SQL*plus Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/



REM ================ Show responsibilities assigned to given user ======== 
DECLARE   
  p_username_l    varchar2(100);
  l_applversion   fnd_product_groups.release_name%type;
  l_counter       integer;
  l_cursor        integer;
  sqltxt          varchar2(3000);
  l_resp_id       integer;
  l_resp_name     varchar2(300);  
  invalid_apps   exception; --exception when run on incorrect Test

BEGIN
  select nvl(rtrim(ltrim(upper('&uname'))), '<NULL username>')
  into :v_username
  from dual;

  select substr(release_name,1,4)  
  into   l_applversion 
  from   fnd_product_groups;

  IF l_applversion = '11.5' then
     BEGIN 
       sqltxt := 'select to_char(a.responsibility_id) id, '||
                 '       b.responsibility_name name '||
                 'from   fnd_user_resp_groups a, '||
                 '       fnd_responsibility_vl b, '||
                 '       fnd_user u '||
                 'where  a.user_id = u.user_id '||
                 'and    a.responsibility_id = b.responsibility_id '||
                 'and    a.responsibility_application_id = b.application_id '||
                 'and    sysdate between '|| 
                 '          a.start_date and nvl(a.end_date,sysdate+1) '||
                 'and    upper(u.user_name) = '''||:v_username||''''||
                 'order  by b.responsibility_name';
     

       DBMS_OUTPUT.PUT_LINE(chr(9));
       DBMS_OUTPUT.PUT_LINE('Following are the Responsibilities assigned to User:  '|| :v_username );
       DBMS_OUTPUT.PUT_LINE('=================================================================');

       l_cursor := dbms_sql.open_cursor;
       dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
       dbms_sql.define_column(l_cursor, 1, l_resp_id);
       dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
       l_counter := dbms_sql.execute(l_cursor);
       l_counter := 0; 

       WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
             l_counter := l_counter + 1;
             dbms_sql.column_value(l_cursor, 1, l_resp_id);
             dbms_sql.column_value(l_cursor, 2, l_resp_name);
             DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
       END LOOP; 
       DBMS_OUTPUT.PUT_LINE(chr(9));

       IF l_counter = 0 then
          raise no_data_found;
       END IF;   
       dbms_sql.close_cursor(l_cursor);
  
     EXCEPTION
     when NO_DATA_FOUND then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
       DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.' || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the test.  Rerun the test with a valid user name.' || chr(10));
     when OTHERS then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error: '|| sqlerrm);
       DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the test.'  || chr(10) );
     END; 
  ELSE  -- apps version is not 11.5
     DBMS_OUTPUT.PUT_LINE('ERROR  - This test is not designed to run against version '|| l_applversion ||' of applications');
     DBMS_OUTPUT.PUT_LINE('ACTION - Please run the test against an 11I instance'  || chr(10) ||
                          '         Type Ctrl-C <Enter> to exit the test'  || chr(10) );
  END IF; 

END; 
/

REM ===================== Accept Responsibility ====================================

PROMPT 
undefine v_respid
accept v_respid number PROMPT  'Please choose a Responsibility ID from the list : '
define v_respidc = &v_respid 
PROMPT 

REM ===================== Accept Period name input parameters ===============================
PROMPT
undefine Period_Name
accept Period_Name char prompt -
'Enter period name [default is the latest opened GL period]: ' 

BEGIN
  select nvl(rtrim(ltrim(upper('&Period_Name'))), 'NONE')
  into :v_periodname
  from dual;
DBMS_OUTPUT.PUT_LINE(chr(9));
  EXCEPTION
      when others then
      DBMS_OUTPUT.PUT_LINE('ERROR - Unexpected error occurred when period name was entered');
      DBMS_OUTPUT.PUT_LINE('ACTION - Please report this error using the feedback option on this test');
END;
/

BEGIN
  select nvl(rtrim(ltrim('&Period_Name')), 'NONE')
  into :v_orig_periodname
  from dual;
DBMS_OUTPUT.PUT_LINE(chr(9));
  EXCEPTION
      when others then
      DBMS_OUTPUT.PUT_LINE('ERROR - Unexpected error occurred when period name was entered');
      DBMS_OUTPUT.PUT_LINE('ACTION - Please report this error using the feedback option on this test');
END;
/

REM ===================== Spooling the output file ================================== 
Define v_spoolfilename  = 'GLBalancePerPeriod115_&v_respidc._diag.html'

PROMPT  =======================================================================
PROMPT  Output will be spooled to &v_spoolfilename
PROMPT  =======================================================================
PROMPT
PROMPT Running.....
PROMPT 

spool  &v_spoolfilename

REM ====================== Run the Pl/SQL api file ================================== 
@@CoreApiHtml.sql

BEGIN  -- begin API

  DECLARE -- declare main program
    -- parameter variables 
    p_username                  varchar2(100);   
    p_respid                    number;
    p_respname                  varchar2(100);
    p_applversion               varchar2(10);
    p_periodname                varchar2(15);

    -- gl sobs
    v_sobid                     number;
    v_sobname                   varchar2(30);
    v_appid                     number;
    v_SET_OF_BOOKS_ID           NUMBER(15) :=null;
    v_CURRENCY_CODE             VARCHAR2(15) := null;              
    v_CHART_OF_ACCOUNTS_ID      NUMBER(15) := null;        
    v_NAME                      VARCHAR2(30) := null;                        
    v_SUSPENSE_ALLOWED_FLAG     VARCHAR2(1) := null;       
    v_ACCOUNTED_PERIOD_TYPE     VARCHAR2(15) := null;        
    v_MRC_SOB_TYPE_CODE         VARCHAR2(1):= null;          
    v_TRACK_ROUNDING_IMBAL_FLAG VARCHAR2(1) := null;
    v_ROUNDING_CCID             NUMBER(15):= null;
    v_USER_PERIOD_TYPE          VARCHAR2(15):= null;
    v_CHART_OF_ACCOUNTS_NAME    VARCHAR2(30):=null;
    v_SUSPENSE_CCID             NUMBER(15):= null;
    v_CONSOLIDATION_SOB_FLAG    VARCHAR2(1) := null;
    v_enable_flag               VARCHAR2(1);
    v_chart_name                VARCHAR2(30);
    v_dynamic_flag              VARCHAR2(1);
    v_cross_seg_val_flag        VARCHAR2(1);
    p_userid                    number(15);
    v_liabilityAccount          number(15);
    v_apinstalled               varchar2(1);
    v_arinstalled               varchar2(1);

    -- gl periods
    v_PERIOD_SET_NAME           VARCHAR2(15) := null;             
    v_LATEST_OPENED_PERIOD_NAME VARCHAR2(15):= null;  
    p_previous_period              varchar2(10);


    -- gl_balances 
    Begin_dr                    number(15,2):=0;
    Begin_cr                    number(15,2):=0;
    Period_dr                   number(15,2):=0;
    Period_cr                   number(15,2):=0;
    End_dr                      number(15,2):=0;
    End_cr                      number(15,2):=0;

    -- sql variables
    l_count                     number  := 0;
    sqltxt                      varchar2(32767);
    count00                     Number(15) := null;
    p_profile                   varchar2(150);
    p_mo_org_id                 number(15);
    p_mo_orgname                hr_all_organization_units.name%type;
    v_mrc_count                 number(15):=null;
    rsob_count                  number;
    v_chart_count               number;
    counter                     integer;
    counter2                    integer;
    aptranscounter              integer;
    Transfer_mode               varchar2(1);

    -- exceptions
    gl_set_of_books_name        exception;
    gl_set_of_books_id          exception;
    period_name                 exception;
    STOPEXECUTION               exception; 
    default_category            exception;
    leav_prog                   exception;

    --Program Units

    /*------- Function to check if a given Code Combination is valid --------------------*/

    Function  CheckCCID (p_ccid varchar2,p_sob_id number) return boolean
    Is
    valid_ccid  integer;
    is_valid boolean := TRUE;
    BEGIN
      select count(*)  into valid_ccid
      from   gl_code_combinations a, gl_sets_of_books b
      where  a.CHART_OF_ACCOUNTS_ID =b.CHART_OF_ACCOUNTS_ID
      and    NVL(a.start_date_active, sysdate ) <= sysdate
      and    NVL( a.end_date_active , sysdate ) >= sysdate
      and    a.code_combination_id = p_ccid
      and    a.enabled_flag = 'Y'
      and    b.set_of_books_id = p_sob_id;
      if valid_ccid = 1
        then return(is_valid);
      else 
        ErrorPrint('Invalid Code Combination id was detected');
        ActionErrorPrint('Please review the Code combination and make the necessary corrections');
        return(FALSE);
      end if;
    EXCEPTION
      when others then
      ErrorPrint('Unexpected error occurred during Function CheckCCID');
      ActionErrorPrint('Please report this error using the feedback option on this test');
    END;

    /*----------- Function to check and validate period names entered ---------------*/

    Function CheckPeriod(p_period varchar2, p_sobid number) return boolean
    is
    v_period_count number;
    
    is_valid boolean := TRUE;
    BEGIN
     select count(*) into v_period_count
      from   gl_period_statuses
      where  set_of_books_id = p_sobid
      and    application_id = 101
      and    upper(period_name) = :v_periodname
      and    closing_status <> 'N'
      ;
      if v_period_count= 1 
        then return is_valid;
      else
        return(FALSE);
      end if;
    EXCEPTION 
      when others then
      WarningPrint('Invalid Period Name was detected');
      ActionWarningPrint('Please ensure that this period exist in the calendar '||
      'and have status of Open or Future enterable');
    END; -- end check period 

    /*------------ Function to check and validate Currency code --------------------*/

    Function  CheckCurrency (p_currcode varchar2) return boolean
    Is
    valid_currency number(15);
    is_valid boolean := TRUE;
    BEGIN
      select count(*)  into valid_currency
      from fnd_currencies a
      where a.currency_code = p_currcode 
      and NVL(a.start_date_active, sysdate ) <= sysdate
      and    NVL( a.end_date_active , sysdate ) >= sysdate
      and    a.enabled_flag = 'Y';
      if valid_currency= 1
        then return(is_valid);
      else
        ErrorPrint('Invalid Currency code was detected');
        ActionErrorPrint('Please review the Code combination and make the necessary corrections');
        return(FALSE);
      end if;
    EXCEPTION
      when others then
      WarningPrint('Unable to retrieve currency information');
      ActionWarningPrint('Please ensure that this currency '||p_currcode||' exists');
    END;
    
    FUNCTION Previous_Period(p_current_period varchar2, p_appl_id number,
        p_sob_id number) return varchar2 is
    
        p_prev_period varchar2(10);
        p_period_counter  number;
        p_period_num number;
        p_max_num number;
    
    BEGIN    
        select EFFECTIVE_PERIOD_NUM, period_num into p_period_counter
        , p_period_num
        from  gl_period_statuses
        where application_id = p_appl_id
        and   set_of_books_id = p_sob_id
        and   closing_status <> 'N'
        and   upper(period_name) = p_current_period;
        
        select max(period_num) into p_max_num
        from  gl_period_statuses
        where application_id = p_appl_id
        and   set_of_books_id = p_sob_id;
        
        if (p_period_num >1)
         then 
          select period_name into p_prev_period
          from  gl_period_statuses
          where application_id = p_appl_id
          and   set_of_books_id = p_sob_id
          and    closing_status <> 'N'
          and   effective_period_num = (p_period_counter - 1);
         else
          select period_name into p_prev_period
          from  gl_period_statuses
          where application_id = p_appl_id
          and   set_of_books_id = p_sob_id
          and closing_status <> 'N'
          and   effective_period_num = (p_period_counter - 10001 + p_max_num);
        end if;
    
     return (p_prev_period); 
    
    EXCEPTION when others then
            ErrorPrint('Failed to get previous period name');
            ActionErrorPrint('Please enter a valid period name');
    
    END;

 
Function CheckFirstPeriod(p_sobid number, period varchar2) return boolean
	is 
	v_first_count integer;
	
	is_valid boolean := TRUE;
 	
   Begin
   
	select count(*) 
	into v_first_count
	from   gl_period_statuses
	where  set_of_books_id = p_sobid
	and    application_id = 101
	and    upper(period_name) = period
	and    closing_status <> 'N'
	and    period_num = 1
        and    closing_status <> 'N'
       ;
	
   if (v_first_count = 1) 	
   	then return is_valid;
      else
        return(FALSE);
      end if;
   
  exception when others then
   	ErrorPrint('Unable to validate period name');
        ActionErrorPrint('Please enter a valid period name');
  end;

    -- END Declare Section for Main Program

  BEGIN  -- main program

    -- Set Client ( validate user and responsibility )   
    Show_Header('222628.1','&v_Testlongname');
    IF :v_username is null THEN
      p_username := 'DUMMY';
    ELSE  
      p_username := :v_username;
    END IF;

    IF &v_respid IS NULL THEN
      p_respid := -10;     
    ELSE        
      p_respid := &v_respid;
    END IF;      

    BEGIN
      SELECT user_id into p_userid
      FROM   fnd_user where user_name = p_username;
    EXCEPTION when no_data_found then
      ErrorPrint('Username does not exist');
      ActionErrorPrint('Please enter a valid Username');
    END;
   
    Set_Client(p_username, p_respid);

    BEGIN
      SELECT b.responsibility_name
      INTO   p_respname
      FROM   fnd_responsibility_vl b
      WHERE  b.responsibility_id = p_respid;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           p_respname := Null;
    END;


    /******* Provide Parameter Information on output ***************************/
    SectionPrint('Running Diagnostics for');
    BRPrint;
    Tab0Print('Username          = '|| p_username || ' (ID ='||p_userid||')'); 
    Tab0Print('Responsibility    = '|| p_respname || ' (ID ='||p_respid||')');

    /* -- Check GL Set of Books Name and ID Profiles--*/
    BEGIN
      v_sobname:=CheckProfile('GL_SET_OF_BKS_NAME',p_userid, p_respid, 101, NULL,0);
      IF v_sobname is null then
        raise gl_set_of_books_name;
      END IF;

      
      v_sobid:=CheckProfile('GL_SET_OF_BKS_ID',p_userid, p_respid, 101, NULL,0);
      IF v_sobid is null then
        raise gl_set_of_books_id;
      END IF;
      EXCEPTION
      WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in test when trying to retrieve '||
        'General Ledger Set of Books Profile Options');
        ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;
    END;

    /*-- ---------------Get and validate GL SET OF BOOKS Settings -----------------*/
    BEGIN --Validation of Set of Books and return data
      Select 
      SET_OF_BOOKS_ID,
      CURRENCY_CODE,
      CHART_OF_ACCOUNTS_ID,
      NAME,
      PERIOD_SET_NAME,
      SUSPENSE_ALLOWED_FLAG,
      ACCOUNTED_PERIOD_TYPE,
      LATEST_OPENED_PERIOD_NAME,
      MRC_SOB_TYPE_CODE,
      TRACK_ROUNDING_IMBALANCE_FLAG,
       ROUNDING_CCID,
      CHART_OF_ACCOUNTS_NAME,
      USER_PERIOD_TYPE,
      SUSPENSE_CCID,
      CONSOLIDATION_SOB_FLAG
      into
      v_SET_OF_BOOKS_ID, 
      v_CURRENCY_CODE,
      v_CHART_OF_ACCOUNTS_ID,
      v_NAME,
      v_PERIOD_SET_NAME,
      v_SUSPENSE_ALLOWED_FLAG,
      v_ACCOUNTED_PERIOD_TYPE,
      v_LATEST_OPENED_PERIOD_NAME,
      v_MRC_SOB_TYPE_CODE,
      v_TRACK_ROUNDING_IMBAL_FLAG,
      v_ROUNDING_CCID,
      v_CHART_OF_ACCOUNTS_NAME,
      v_USER_PERIOD_TYPE,
      v_SUSPENSE_CCID,
      v_CONSOLIDATION_SOB_FLAG
      FROM gl_sets_of_books_v
      WHERE set_of_books_id = v_sobid;
        
      /* -- Get and validate period name. If no period name is entered then the latest
      open period name will be used for the anlaysis -- */

      IF :v_periodname = 'NONE' THEN
        p_periodname := upper(v_LATEST_OPENED_PERIOD_NAME);
      ELSIF :v_periodname IS NOT NULL THEN 
        p_periodname := :v_periodname; 
        IF CheckPeriod(p_periodname, v_sobid) = FALSE then
        Tab0Print('Invalid Period Name Entered       = '||:v_orig_periodname); 
        BrPrint;
          raise period_name;
        END IF;
      END IF;
      
	IF :v_periodname = 'NONE' THEN
      Tab0Print('Period Name       = '||v_LATEST_OPENED_PERIOD_NAME);
      :v_orig_periodname := v_LATEST_OPENED_PERIOD_NAME;
      ELSE
      Tab0Print('Period Name       = '||:v_orig_periodname);
      END IF;
    
     p_previous_period := Previous_Period(p_periodname, 101 , v_sobid);
       

      /* -- Display MO Information in parameters ----------------------------------- */
      p_mo_org_id := Get_Profile_Option('ORG_ID');
      if p_mo_org_id is null then
        Tab0Print('Operating Unit    = Not set for this responsiblity');
      else
        select name
        into   p_mo_orgname
        from   HR_ALL_ORGANIZATION_UNITS
        where  organization_id = p_mo_org_id;
        if p_mo_orgname is null then
          Tab0Print('Operating Unit    = '|| p_mo_org_id);
        else
          Tab0Print('Operating Unit    = '||p_mo_orgname||' (ID = '||p_mo_org_id||')');
        end if;       
      end if;    
 
      /*******************End Parameter Validation Section***************************/

      SectionPrint('General Ledger Setup Information for Set of Books = '||v_sobname);

      Tab0Print('Set of Books - General Information');
      Tab1Print('Chart of Accounts    = '||v_CHART_OF_ACCOUNTS_NAME); 
      Tab1Print('Functional Currency  = '||v_CURRENCY_CODE); 
      Tab1Print('Calendar Name        = '||v_PERIOD_SET_NAME);
      Tab1Print('Period Type          = '||v_USER_PERIOD_TYPE);
      Tab1Print('Latest Opened Period = '||v_LATEST_OPENED_PERIOD_NAME);

      BRPrint;
      Tab0Print('Set of Books - Account Information');
      if v_SUSPENSE_ALLOWED_FLAG = 'N' then
        Tab1Print('Suspense Accounting is not enabled for this Set of Books');
      elsif (v_SUSPENSE_ALLOWED_FLAG ='Y') and (v_SUSPENSE_CCID is null) then
        ErrorPrint('Suspense Accounting is enabled for this set of books but a '||
	'Suspense Account has not been defined');
        ActionErrorPrint('Please enter a valid suspense account in the General Ledger '||
	'Sets of Books Define Screen');
      elsif (v_SUSPENSE_ALLOWED_FLAG ='Y') and (v_SUSPENSE_CCID is not null) and
        CheckCCID(v_suspense_ccid,v_sobid) = false then
        ErrorPrint('The suspense account code combination entered for this Set of '||
	'Books is either not enabled, or todays date = '||sysdate||' falls outside of '||
	'the start and end dates for the code combination');
        ActionErrorPrint('Please review the Suspense Accounts code combination in '||
	'GL Accounts screen in General Ledger to ensure it is not end dated, it '||
	'is enabled and the start date falls before todays date '||sysdate);
      elsif (v_SUSPENSE_ALLOWED_FLAG = 'Y') and (v_SUSPENSE_CCID is not null) and CheckCCID(v_suspense_ccid,v_sobid) = true then
        Tab1Print('Suspense Accounting is enabled for this set of books.');
	Tab1Print('The Suspense Account (CCID = '||v_SUSPENSE_CCID||') in use for the set of books is enabled');
	Tab1Print(' and todays date = '||sysdate||' falls inside the start and end dates '||
	'for this combination.');
      end if; 

      BEGIN --Suspense Accounting category and sources check 
        counter := 0;
        select count(*) into counter
        from gl_suspense_accounts_v
        where  set_of_books_id = v_sobid;

        if (counter = 0) and (v_SUSPENSE_ALLOWED_FLAG = 'Y')
          then
          WarningPrint('Suspense Accounting is enabled but Suspense Account Categories '||
	  'are not defined for this Set of Books');
          ActionWarningPrint('Please define Suspense accounts categories when the Suspense '||
	  'Accounting flag is checked');
        elsif (counter > 0) and (v_SUSPENSE_ALLOWED_FLAG <> 'Y')
          then
          WarningPrint('Suspense Account categories are defined but Suspense '||
	  'Accounting is not enabled for this Set of Books');
          ActionWarningPrint('If required, please enable Suspense Accounting for this Set '||
	  'of Books');
        elsif (counter > 0) and (v_SUSPENSE_ALLOWED_FLAG = 'Y')
          then
          Tab1Print('Suspense Accounts are set up for the following Journal Source '||
	  'Names and Categories');
          sqltxt :=
          ' select user_je_source_name "Journal|Source|Name" '||
          ', je_category_name "Category|Name" '||
          ' from gl_suspense_accounts_v '||
          ' where '||
          ' set_of_books_id = '||v_sobid|| 
          ' and 1=1';
          Run_SQL(null,sqltxt,'N');
        end if;
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
        v_liabilityAccount := -1;
        ErrorPrint('Suspense Accounts are not setup.');
        ActionErrorPrint('Please verify whether Suspense Accounting should be setup');
        WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in test when trying to retrieve Suspense '||
	'Account information');
        ActionErrorPrint('Please report this error using the feedback option on this test');
      END; --Suspense Accounting check


      if v_TRACK_ROUNDING_IMBAL_FLAG = 'N' then
        Tab1Print('Rounding Difference Account option is not enabled for this Set of Books');
      elsif (v_TRACK_ROUNDING_IMBAL_FLAG = 'Y') and (v_ROUNDING_CCID is null) then
        ErrorPrint('Rounding Differences is enabled for this set of books but a '||
	'Rounding Differences Account has not been defined');
        ActionErrorPrint('Please enter a valid Rounding Differences account in '||
	'the General Ledger Sets of Books Define Screen');
      elsif (v_TRACK_ROUNDING_IMBAL_FLAG = 'Y') and (v_ROUNDING_CCID is null) and CheckCCID(v_ROUNDING_CCID,v_sobid) = false then
        ErrorPrint('The Rounding Differences account code combination entered for '||
	'this Set of Books is either not enabled, or system date = '||sysdate||
	'falls outside of the start and end dates for the code combination');
        ActionErrorPrint('Please review the Rounding Differences Accounts code '||
	'combination in GL Accounts screen in General Ledger to ensure it is not end dated,it '||
	'is enabled and the start date falls before system date = '||sysdate);
      elsif (v_TRACK_ROUNDING_IMBAL_FLAG = 'Y') and (v_ROUNDING_CCID is not null)
        and CheckCCID(v_ROUNDING_CCID,v_sobid) = true then
        Tab1Print('The Rounding Differences option is enabled for this set of books.');
	Tab1Print('The Rounding Differences Account (CCID = '||v_ROUNDING_CCID||') in use for the set of books is enabled');
	Tab1Print(' and todays date = '||sysdate||' falls inside the start and end dates '||
	'for this combination.');
      end if;

      BRPrint;
      Tab0Print('Set of Books - Consolidation');
      if v_CONSOLIDATION_SOB_FLAG = 'Y'
        then
        Tab1Print('This is a Consolidation Set of Books');
      else
        Tab1Print('This is not a Consolidation Set of Books'); 
      end if;

       BRPrint;
      Tab0Print('Set of Books - Multiple Reporting Currencies');
      BEGIN
        select count(*) into v_mrc_count
        from fnd_product_groups 
        where multi_currency_flag = 'Y' ;

        IF v_mrc_count = 0
          then 
          Tab1Print('Multiple Reporting Currencies is not enabled for this Environment');
        ELSE 
          Tab1Print('Multiple Reporting Currencies is enabled for this Environment');
        END IF; 
      EXCEPTION 
        WHEN OTHERS then   
        Errorprint(sqlerrm||' occurred in test when trying to retrieve MRC '||
        'Environment setup');
        ActionErrorPrint('Please report this error using the feedback option on this test');
        raise STOPEXECUTION;
      END;  -- Check for Multi Currencies

      IF v_mrc_count <> 0 then
        IF v_MRC_SOB_TYPE_CODE = 'R'
          then 
          Tab1Print('This is a Reporting Set of Books');
        ELSIF v_MRC_SOB_TYPE_CODE = 'P' then
          Tab1Print(v_sobname||' is a Primary Set of Books');
          -- Check for Multi Currencies  
          BEGIN --Reporting set of books 
            select count(*) into rsob_count
            from gl_mc_reporting_options a, gl_sets_of_books b 
            where a.primary_set_of_books_id = b.set_of_books_id
            and a.primary_set_of_books_id = v_sobid
            and a.enabled_flag = 'Y'
            ;
            IF rsob_count = 0 then 
              --Warning here as if a primary book, there should be a
              --reporting sobs associated
              WarningPrint('MRC is enabled but there are no Reporting Set of '||
              'Books associated to this Primary Set of Books');
              ActionWarningPrint('If required, assign a Reporting Set of Books '||
              'to this Primary Set of Books');
            ELSE
              Tab2Print('List of Reporting Sets of Books associated to '||
              'this Primary Set of Books');
              sqltxt := 
              'select a.reporting_set_of_books_id "Reporting|Set Of|Books ID" '||
              ', b.name "Name" '||
              ',a.reporting_currency_code "Reporting|Currency|Code" '||
              ' from gl_mc_reporting_options a, gl_sets_of_books b '||
              ' where a.primary_set_of_books_id = b.set_of_books_id '||
              ' and a.enabled_flag = ''Y''  '|| 
              ' and a.primary_set_of_books_id = '||v_sobid||
              ' group by a.reporting_set_of_books_id, b.name, reporting_currency_code' ;
              Run_SQL(null,sqltxt,'N');
            END IF;
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
            ErrorPrint('Unable to determine MRC Reporting Set of Books information');
            ActionErrorprint('Please ensure that the MRC option table has at least one record');
          END; --Reporting set of books
        ELSE
          Tab1Print('This is not a MRC Set of Books');
        END IF;
        /**************** End Validation of MRC and Multi CurrencyInformation *************/
      END IF;
    EXCEPTION 
      WHEN NO_DATA_FOUND then
      ErrorPrint('Unable to determine Set of Books Information for Set of Books Name '||
      v_sobname||' set in Profile GL: Set of Books Name');
      ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;

      WHEN period_name then
      ErrorPrint('The period name entered is either invalid or has a status of Never Opened');
      ActionErrorprint('Please enter a valid period name for this calendar making sure that the'||
    ' the period does not have a Never Opened status');
      raise STOPEXECUTION; 

      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in test when trying to retrieve General Ledger Set of '||
      'Books information');
      ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;
    END; --validation of Set of books Information

    /******************* End Validation of Set of Books Information ******************/


IF CheckFirstPeriod(v_sobid,p_periodname ) = False  /* Check if the entered Period is the first period */
Then
BRPrint;
SectionPrint('General Ledger Balances for Period = '||:v_orig_periodname||' and Previous Period = '||p_previous_period);

BRPrint;
Declare  
cursor c_allccids is

SELECT 
glcc.CODE_COMBINATION_ID A, 
glcc.CONCATENATED_SEGMENTS AA,
glbalclsng.period_name B,
glbalclsng.currency_code C, 
glbalopng.period_name D ,
sum(glbalclsng.period_net_dr +  glbalclsng.begin_balance_dr) "Closing Debit", 
sum(glbalclsng.period_net_cr  +  glbalclsng.begin_balance_cr) "Closing Credit", 
sum(glbalopng.begin_balance_dr) "Debit", 
sum(glbalopng.begin_balance_cr) "Credit" 
FROM     gl_code_combinations_kfv glcc,
         gl.gl_balances glbalclsng,
         gl.gl_sets_of_books glsob,
         gl.gl_balances glbalopng
   WHERE (    (glsob.set_of_books_id = glbalopng.set_of_books_id)
          AND (glsob.set_of_books_id = glbalclsng.set_of_books_id)
          AND (glbalclsng.CODE_COMBINATION_ID = glbalopng.code_combination_id)
          AND (glcc.code_combination_id = glbalclsng.code_combination_id)
          AND (glbalclsng.currency_code = glbalopng.currency_code)
          AND (glsob.SET_OF_BOOKS_ID = v_sobid)
          AND  upper(glbalclsng.period_name) = p_previous_period
          AND upper(glbalopng.period_name) = p_periodname
          AND (glbalclsng.actual_flag = 'A')
          AND (glbalopng.actual_flag = 'A')
          AND (glbalclsng.currency_code <> 'STAT')
          AND (glbalopng.currency_code <> 'STAT')
          AND (glbalclsng.template_id IS NULL)
          AND (glbalopng.template_id IS NULL))
	  Group BY glcc.CODE_COMBINATION_ID ,glcc.CONCATENATED_SEGMENTS,glbalclsng.period_name ,glbalclsng.currency_code ,glbalopng.period_name  
	  Having sum(glbalclsng.period_net_dr + glbalclsng.begin_balance_dr) != sum(glbalopng.begin_balance_dr) 
			OR sum(glbalclsng.period_net_cr +  glbalclsng.begin_balance_cr) != sum(glbalopng.begin_balance_cr) 
     ;

v_allccids c_allccids%ROWTYPE;

BEGIN
      open  c_allccids;
      fetch c_allccids into v_allccids;
      if c_allccids%NOTFOUND then
Tab1print('The Closing Balances for all CCIDS for Period = '||p_previous_period||' were checked and found to be equal to the opening balances for period = '||:v_orig_periodname);

ELSE
Errorprint('The Closing Balances for some CCIDS for Period = '||p_previous_period||' are not equal to the opening balances for period = '|| :v_orig_periodname);
ActionErrorPrint('Please log an iTAR with Support providing the output of the following report : ');

--Added 2 extra columns for debit and credit differences

sqltxt :=
' SELECT   '||
'         glcc.CODE_COMBINATION_ID "CCID", '||
'         glcc.CONCATENATED_SEGMENTS "Account|Structure",'||
'         decode(glcc.GL_ACCOUNT_TYPE,''A'',''Asset'',''E'',''Expense'',''L'',''Liability'',''O'',''Equity'',''R'',''Revenue'', ''Unknown'') "Account|Type" ,'||
'         glbalclsng.period_name "Previous|Period", '||
'         glbalclsng.currency_code "Currency", '||
'         glbalopng.period_name "Current|Period", '||
'         sum(glbalclsng.period_net_dr '||
'          +  glbalclsng.begin_balance_dr) "Previous Period|Closing Debit", '||
'         sum(glbalclsng.period_net_cr '||
'          +  glbalclsng.begin_balance_cr) "Previous Period|Closing Credit", '||
'         sum(glbalopng.begin_balance_dr) "Current Period|Opening Debit", '||
'         sum(glbalopng.begin_balance_cr) "Current Period|Opening Debit", '||
'         abs(sum(glbalclsng.period_net_dr+glbalclsng.begin_balance_dr) '||
'         - sum(glbalopng.begin_balance_dr)) " Debit|Differences" ,'||
'         abs(sum(glbalclsng.period_net_cr + glbalclsng.begin_balance_cr)  '||
'         - sum(glbalopng.begin_balance_cr)) "Credit|Difference" '||
'    FROM gl_code_combinations_kfv glcc, '||
'         gl.gl_balances glbalclsng, '||
'         gl.gl_sets_of_books glsob, '||
'         gl.gl_balances glbalopng '||
'   WHERE (    (glsob.set_of_books_id = glbalopng.set_of_books_id) '||
'          AND (glsob.set_of_books_id = glbalclsng.set_of_books_id) '||
'          AND (glbalclsng.CODE_COMBINATION_ID = glbalopng.code_combination_id) '||
'          AND (glcc.code_combination_id = glbalclsng.code_combination_id) '||
'          AND (glbalclsng.currency_code = glbalopng.currency_code) '||
'          AND glsob.SET_OF_BOOKS_ID ='||v_sobid|| ' '||
'          AND upper(glbalclsng.period_name) ='''||p_previous_period||''''||
'          AND upper(glbalopng.period_name) = '''||p_periodname||''''||
'          AND glbalclsng.actual_flag = ''A'' '||
'          AND glbalopng.actual_flag = ''A'' '||
'          AND (glbalclsng.currency_code <> ''STAT'') '||
'          AND (glbalopng.currency_code <> ''STAT'') '||
'          AND (glbalclsng.template_id IS NULL) '||
'          AND (glbalopng.template_id IS NULL)) '||
'          Group BY glcc.CODE_COMBINATION_ID,glcc.CONCATENATED_SEGMENTS,glcc.GL_ACCOUNT_TYPE,glbalclsng.period_name,glbalclsng.currency_code,glbalopng.period_name '||
'	   Having sum(glbalclsng.period_net_dr + glbalclsng.begin_balance_dr) != '||
'		         sum(glbalopng.begin_balance_dr) '||
'			OR sum(glbalclsng.period_net_cr +  glbalclsng.begin_balance_cr) != '|| 
'		         sum(glbalopng.begin_balance_cr) '||
'          ORDER BY  glbalclsng.currency_code, glcc.CODE_COMBINATION_ID '
;

Run_Sql(null,sqltxt, 'N');
end if;
EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in test when validating period balances for period = '||:v_orig_periodname);
      ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;
    END;

Else

BRPrint;
SectionPrint('General Ledger Balances for Liability and Asset Accounts - Period (First Period) = '||:v_orig_periodname||' and  Previous Period = '||p_previous_period);

BRPrint;
Declare  
cursor Liability_c is
SELECT 
glcc.CODE_COMBINATION_ID A, 
glcc.CONCATENATED_SEGMENTS AA,
glbalclsng.period_name B,
glbalclsng.currency_code C, 
glbalopng.period_name D ,
sum(glbalclsng.period_net_dr +  glbalclsng.begin_balance_dr) "Closing Debit", 
sum(glbalclsng.period_net_cr  +  glbalclsng.begin_balance_cr) "Closing Credit", 
sum(glbalopng.begin_balance_dr) "Debit", 
sum(glbalopng.begin_balance_cr) "Credit" 
FROM     gl_code_combinations_kfv glcc,
         gl.gl_balances glbalclsng,
         gl.gl_sets_of_books glsob,
         gl.gl_balances glbalopng
WHERE (    (glsob.set_of_books_id = glbalopng.set_of_books_id)
          AND (glsob.set_of_books_id = glbalclsng.set_of_books_id)
          AND (glbalclsng.CODE_COMBINATION_ID = glbalopng.code_combination_id)
          AND (glcc.code_combination_id = glbalclsng.code_combination_id)
          AND (glbalclsng.currency_code = glbalopng.currency_code)
          AND (glsob.SET_OF_BOOKS_ID = v_sobid)
          AND upper(glbalclsng.period_name) = p_previous_period
          AND upper(glbalopng.period_name) = p_periodname
          AND (glbalclsng.actual_flag = 'A')
          AND (glbalopng.actual_flag = 'A')
          AND (glcc.gl_account_type in ('L','A')
          AND glcc.CODE_COMBINATION_ID != glsob.RET_EARN_CODE_COMBINATION_ID)
          AND (glbalclsng.template_id IS NULL)
          AND (glbalopng.template_id IS NULL))
          Group BY glcc.CODE_COMBINATION_ID ,glcc.CONCATENATED_SEGMENTS,glbalclsng.period_name ,glbalclsng.currency_code ,glbalopng.period_name  
	  Having sum(glbalclsng.period_net_dr + glbalclsng.begin_balance_dr) != sum(glbalopng.begin_balance_dr) 
			OR sum(glbalclsng.period_net_cr +  glbalclsng.begin_balance_cr) != sum(glbalopng.begin_balance_cr) 
		  

     ;

v_Liability Liability_c%ROWTYPE;

    BEGIN
      open  Liability_c;
      fetch Liability_c into v_Liability;
IF Liability_c%NOTFOUND then

Tab1print('The Closing Balances for Liabilities and Assets Accounts for Period = '||p_previous_period||' were checked and found to be equal to the opening balances for period = '||:v_orig_periodname);

ELSE
Errorprint('The Closing Balances for some Liabilities and Assets Accounts for Period = '||p_previous_period||' are not equal to the opening balances for period = '|| :v_orig_periodname);
ActionErrorPrint('Please log an iTAR with Support providing the output of the following report : ');

--Added 2 extra columns for debit and credit differences

sqltxt :=
' SELECT   '||
'         glcc.CODE_COMBINATION_ID "CCID", '||
'         glcc.CONCATENATED_SEGMENTS "Account|Structure",'||
'         decode(glcc.GL_ACCOUNT_TYPE,''A'',''Asset'',''E'',''Expense'',''L'',''Liability'',''O'',''Equity'',''R'',''Revenue'', ''Unknown'') "Account|Type" ,'||
'         glbalclsng.period_name "Previous|Period", '||
'         glbalclsng.currency_code "Currency", '||
'         glbalopng.period_name "Current|Period", '||
'         sum(glbalclsng.period_net_dr '||
'          +  glbalclsng.begin_balance_dr) "Previous Period|Closing Debit", '||
'         sum(glbalclsng.period_net_cr '||
'          +  glbalclsng.begin_balance_cr) "Previous Period|Closing Credit", '||
'         sum(glbalopng.begin_balance_dr) "Current Period|Opening Debit", '||
'         sum(glbalopng.begin_balance_cr) "Current Period|Opening Credit", '||
'         abs(sum(glbalclsng.period_net_dr+glbalclsng.begin_balance_dr) '||
'         - sum(glbalopng.begin_balance_dr)) " Debit|Differences" ,'||
'         abs(sum(glbalclsng.period_net_cr + glbalclsng.begin_balance_cr)  '||
'         - sum(glbalopng.begin_balance_cr)) "Credit|Difference" '||
'    FROM gl_code_combinations_kfv glcc, '||
'         gl.gl_balances glbalclsng, '||
'         gl.gl_sets_of_books glsob, '||
'         gl.gl_balances glbalopng '||
'   WHERE (    (glsob.set_of_books_id = glbalopng.set_of_books_id) '||
'          AND (glsob.set_of_books_id = glbalclsng.set_of_books_id) '||
'          AND (glbalclsng.CODE_COMBINATION_ID = glbalopng.code_combination_id) '||
'          AND (glcc.code_combination_id = glbalclsng.code_combination_id) '||
'          AND (glbalclsng.currency_code = glbalopng.currency_code) '||
'          AND glsob.SET_OF_BOOKS_ID ='||v_sobid|| ' '||
'          AND upper(glbalclsng.period_name) ='''||p_previous_period||''''||
'          AND upper(glbalopng.period_name) = '''||p_periodname||''''||
'          AND glbalclsng.actual_flag = ''A'' '||
'          AND glbalopng.actual_flag = ''A'' '||
'	   AND (glcc.gl_account_type in (''L'',''A'')'||
'          AND glcc.CODE_COMBINATION_ID != glsob.RET_EARN_CODE_COMBINATION_ID)'||
'          AND (glbalclsng.template_id IS NULL) '||
'          AND (glbalopng.template_id IS NULL)) '||
'          Group BY glcc.CODE_COMBINATION_ID,glcc.CONCATENATED_SEGMENTS,glcc.GL_ACCOUNT_TYPE,glbalclsng.period_name,glbalclsng.currency_code,glbalopng.period_name '||
'	   Having sum(glbalclsng.period_net_dr + glbalclsng.begin_balance_dr) != '||
'		         sum(glbalopng.begin_balance_dr) '||
'			OR sum(glbalclsng.period_net_cr +  glbalclsng.begin_balance_cr) != '|| 
'		         sum(glbalopng.begin_balance_cr) '||
'          ORDER BY  glbalclsng.currency_code, glcc.CODE_COMBINATION_ID '
;

Run_Sql(null,sqltxt, 'N');
end if;


EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in test when validating period balances for period = '||:v_orig_periodname);
      ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;
    END;

end if;

-- New Section was added

IF CheckFirstPeriod(v_sobid,p_periodname ) = True  /* Check if the entered Period is the first period */
Then
BRPrint;
SectionPrint('General Ledger Balances for Expense and Revenue Accounts - Period (First Period) = '||:v_orig_periodname);

BRPrint;
Declare  
v_Expense_count number;

Begin
SELECT count(*) into v_Expense_count
from  gl_code_combinations_kfv a,gl_balances b, gl_sets_of_books c
where c.set_of_books_id = b.set_of_books_id
and   b.code_combination_id = a.code_combination_id
and   c.set_of_books_id = v_sobid
and   upper(b.period_name) = p_periodname
and   b.actual_flag = 'A'
and  (b.begin_balance_dr <> 0 or b.begin_balance_cr <> 0)
and   a.gl_account_type in ('E','R')
AND   a.CODE_COMBINATION_ID != c.RET_EARN_CODE_COMBINATION_ID
AND   b.template_id IS NULL
;


If v_Expense_count = 0
Then

Tab1print('The Opening  Balances for Expenses and Revenue Accounts for Period = '||:v_orig_periodname||' were checked and found to be correct');

ELSE
Errorprint('The Opening Balances for some Expenses and Revenue Accounts for Period (first period) = '||:v_orig_periodname||' are not equal to zeros');
ActionErrorPrint('The Opening Balances for Expense and Revenue Accounts must be zero for the Opening Period. Please log an iTAR with Support providing the output of the following report : ');

sqltxt :=
' SELECT   '||
'         glcc.CODE_COMBINATION_ID "CCID", '||
'         glcc.CONCATENATED_SEGMENTS "Account|Structure",'||
'         decode(glcc.GL_ACCOUNT_TYPE,''A'',''Asset'',''E'',''Expense'',''L'',''Liability'',''O'',''Equity'',''R'',''Revenue'', ''Unknown'') "Account|Type" ,'||
'         glb.period_name "Period|name", '||
'         glb.currency_code "Currency", '||
'         glb.begin_balance_dr "Begin Balance|Debit", '||
'         glb.begin_balance_cr "Begin Balance|Credit" '||
'    FROM gl_code_combinations_kfv glcc, '||
'         gl.gl_balances glb, '||
'         gl.gl_sets_of_books glsob '||
'   WHERE glsob.set_of_books_id = glb.set_of_books_id '||
'   AND   glb.CODE_COMBINATION_ID = glcc.code_combination_id '||
'   AND   glsob.SET_OF_BOOKS_ID ='||v_sobid|| ' '||
'   AND   upper(glb.period_name) = '''||p_periodname||''''||
'   AND   glb.actual_flag = ''A'' '||
'   and   (glb.begin_balance_dr <> 0 or glb.begin_balance_cr <> 0) '||
'   AND   glcc.gl_account_type in (''E'',''R'') '||
'   AND   glcc.CODE_COMBINATION_ID != glsob.RET_EARN_CODE_COMBINATION_ID '||
'   AND   glb.template_id IS NULL '
;

Run_Sql(null,sqltxt, 'N');
end if;
EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in test when validating period balances for period = '||:v_orig_periodname);
      ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;
    END;

end if;


BRPrint;
    SectionPrint('General Ledger Functional Currency Balances for Period = '||:v_orig_periodname);
    BRPrint;
    -- First check that sum of the begin, period and end balances match in both debits
    -- and credits in GL_Balances.
    BEGIN
      SELECT round(sum(nvl(begin_balance_dr,0)),2)   
      ,      round(sum(nvl(begin_balance_cr,0)),2) 
      ,      round(sum(nvl(period_net_dr,0)),2) 
      ,      round(sum(nvl(period_net_cr,0)),2) 
      ,      round(sum(nvl(begin_balance_dr,0)) + sum(nvl(period_net_dr,0)),2) 
      ,      round(sum(nvl(begin_balance_cr,0)) + sum(nvl(period_net_cr,0)),2) 
      into   Begin_dr
      ,      Begin_cr
      ,      Period_dr
      ,      Period_cr
      ,      End_dr
      ,      End_cr
      FROM   gl_balances
      WHERE  set_of_books_id = v_sobid
      AND    upper(period_name) = p_periodname
      AND    template_id is null
      AND    actual_flag = 'A' 
      AND    currency_code = v_CURRENCY_CODE
      ;

      --Table output for gl balances as easier to read
      sqltxt :=  'select '
      ||'       round(sum(nvl(begin_balance_dr,0)),2) "Begin|Balance|Debit"  '
      ||',      round(sum(nvl(begin_balance_cr,0)),2) "Begin|Balance|Credit" '
      ||',      round(sum(nvl(period_net_dr,0)),2) "Period|Balance|Debit" '
      ||',      round(sum(nvl(period_net_cr,0)),2) "Period|Balance|Credit" '
      ||',      round(sum(nvl(begin_balance_dr,0)) + sum(nvl(period_net_dr,0)),2)
"Ending|Balance|Debit" '
      ||',      round(sum(nvl(begin_balance_cr,0)) + sum(nvl(period_net_cr,0)),2)
"Ending|Balance|Credit" '
      ||'FROM   gl_balances '
      ||'WHERE  set_of_books_id = '||v_sobid||' '
      ||'AND    upper(period_name) = '''||p_periodname||''' '
      ||'AND    template_id is null '
      ||'AND    actual_flag = ''A'' '
      ||'AND    currency_code = '''||v_CURRENCY_CODE||''' ';
      Tab0Print('Total General Ledger Actual Balances for Period '||:v_orig_periodname||' and Currency = '||v_currency_code);
      Run_SQL(null,sqltxt,'N');
      BRPrint;

      
      --Check that opening balances agree credits/debits
      if begin_dr <> begin_cr then
        Errorprint('The General Ledger opening actual debit balance for Set of Books '||
        v_sobname||' does not equal the total opening actual credit balance '||
        'for currency = '||v_CURRENCY_CODE);
        ActionErrorPrint('Please log an TAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('Opening debit and credit balances for period = '||:v_orig_periodname||' agree');
      end if;

      --Check whether the opening balances are zero..
      if begin_dr = 0 or begin_cr = 0 then
        WarningPrint('The Opening debit and/or credit General Ledger balances are '||
        'equal to zero');
        ActionWarningPrint('If required, check that all transactions for the previous period '||
        'are posted');
      end if;

      --Check whether period debits equal period credits for functional currency
      if Period_dr <> Period_cr then 
        Errorprint('The period transactions debit balance is not equal to the credit balance '||
        'for Set of Bookx '||v_sobname);
        ActionErrorPrint('Please log an TAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('Debits equal credits for the period balances for period = '||:v_orig_periodname);
      end if;

      --Check whether any period movement occurred for functional currency
      if  period_dr = 0 and period_cr =0 then 
        Tab1Print('Transactions have not been posted during period = '||:v_orig_periodname);
      end if;

      --Check whether ending balances agree for functional currency
      if end_dr <> end_cr then
        Errorprint('The total General Ledger ending Actual debit balance not equal to the total '||
        ' ending actual credit balance for  currency = '||v_CURRENCY_CODE||' and '||
        'period = '||:v_orig_periodname);
        ActionErrorPrint('Please log an iTAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('Debits equal credits for the closing balances for period = '||:v_orig_periodname);
      end if;      

      -- check for zeros in end balances for functional currency
      if begin_dr = 0 or begin_cr = 0 then
        WarningPrint('The total actual General Ledger closing debit and credit balances equal '||
        'to zero ');
        ActionWarningPrint('Please ensure that all transactions from the previous period are '||
        'posted properly and brought over to this period');
      end if;

      -- check that open balance + period transact = closing balance for debits
      if (begin_dr + period_dr) <> end_dr then
        ErrorPrint('The opening balance plus the sum of all period transactions is not equal to the ending balance');
        ActionErrorPrint('Please log a iTAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('The opening balance plus the sum of all period transactions is equal to the ending balance for period = '||
        :v_orig_periodname);
      end if;

      -- check that open balance + period transact = closing balance for credits
      if (begin_cr + period_cr) <> end_cr then
        ErrorPrint('The opening balances plus the sum of all period transactions is NOT equal to the ending balance');
        ActionErrorPrint('Please log an iTAR with  Support providing the output '||
        'of this report');
      else
        Tab1Print('The open and period credit balance sums to the closing balance for period '||
        :v_orig_periodname);
      end if;
    EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in test when trying to retrieve GL_BALANCES information '||
      'for period '||:v_orig_periodname);
      ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;
    END;


 SectionPrint('General Ledger NON Functional Currency Balances for Period = '||:v_orig_periodname);
    BRPrint;

DECLARE
Cursor c_nonfunctional is
SELECT currency_code,
 	     round(sum(nvl(begin_balance_dr,0)),2) sum_dr  
      ,      round(sum(nvl(begin_balance_cr,0)),2) sum_cr
      ,      round(sum(nvl(period_net_dr,0)),2) net_dr
      ,      round(sum(nvl(period_net_cr,0)),2) net_cr
      ,      round(sum(nvl(begin_balance_dr,0)) + sum(nvl(period_net_dr,0)),2)end_dr 
      ,      round(sum(nvl(begin_balance_cr,0)) + sum(nvl(period_net_cr,0)),2) end_cr
    
FROM   gl_balances
WHERE  set_of_books_id = v_sobid
AND    upper(period_name) = p_periodname
AND    template_id is null
AND    actual_flag = 'A' 
AND    currency_code != 'STAT'
AND    currency_code != v_currency_code
group by currency_code
having round(sum(nvl(begin_balance_dr,0)) + sum(nvl(period_net_dr,0)),2) >0
or  round(sum(nvl(begin_balance_cr,0)) + sum(nvl(period_net_cr,0)),2) > 0
;

v_nonfunctional c_nonfunctional%ROWTYPE;

BEGIN
open  c_nonfunctional;
      fetch c_nonfunctional into v_nonfunctional;
      if c_nonfunctional%NOTFOUND then
     Tab1Print('There are NO other Currencies other than the functional currency with BALANCES in the GL_Balances table');   
      else

     Tab1Print('The following Balances exist for NON FUNCTIONAL currencies in the GL Balances table for period = '||:v_orig_periodname);

sqltxt :=  'select currency_code "Currency", '
      ||'       round(sum(nvl(begin_balance_dr,0)),2) "Begin|Balance|Debit"  '
      ||',      round(sum(nvl(begin_balance_cr,0)),2) "Begin|Balance|Credit" '
      ||',      round(sum(nvl(period_net_dr,0)),2) "Period|Balance|Debit" '
      ||',      round(sum(nvl(period_net_cr,0)),2) "Period|Balance|Credit" '
      ||',      round(sum(nvl(begin_balance_dr,0)) + sum(nvl(period_net_dr,0)),2) "Ending|Balance|Debit" '
      ||',      round(sum(nvl(begin_balance_cr,0)) + sum(nvl(period_net_cr,0)),2) "Ending|Balance|Credit" '
      ||'FROM   gl_balances '
      ||'WHERE  set_of_books_id = '||v_sobid||' '
      ||'AND    upper(period_name) = '''||p_periodname||''' '
      ||'AND    template_id is null '
      ||'AND    actual_flag = ''A'' '
      ||'AND    currency_code != ''STAT'' '
      ||'AND    currency_code != '''||v_currency_code||''' '
      ||' group by currency_code '
      ||' having round(sum(nvl(begin_balance_dr,0)) + sum(nvl(period_net_dr,0)),2) >0 '
      ||' or  round(sum(nvl(begin_balance_cr,0)) + sum(nvl(period_net_cr,0)),2) > 0 '

;
    
      Run_SQL(null,sqltxt,'N');
      BRPrint;
end if;
EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in test when checking non functional currencies balance for  period '||:v_orig_periodname);
      ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;
 END;



SectionPrint('GL_Balances and GL_JE_Lines Tables Information for Period = '||:v_orig_periodname);
BRPrint;

DECLARE
Cursor c_functional is
select b.code_combination_id ccid,        
b.period_name period,        
b.currency_code currency,        
nvl(b.period_net_cr, 0) balances_cr,        
nvl(b.period_net_dr, 0) balances_dr,        
sum(nvl(l.accounted_cr, 0)) lines_cr,        
sum(nvl(l.accounted_dr, 0)) lines_dr 
from   gl.gl_je_headers h, 
gl.gl_je_lines l, 
gl.gl_balances b 
where b.set_of_books_id = v_sobid 
and  upper(b.period_name) = p_periodname 
and  b.actual_flag = 'A' 
and  b.currency_code != 'STAT' 
and  b.currency_code = v_currency_code 
and  l.set_of_books_id = b.set_of_books_id 
and  l.period_name = b.period_name 
and    l.code_combination_id = b.code_combination_id 
and    (b.translated_flag <> 'Y' or b.translated_flag is null) 
and    h.je_header_id = l.je_header_id 
and    h.actual_flag = b.actual_flag 
and    h.currency_code != 'STAT' 
and    h.status = 'P' 
group by b.code_combination_id, b.period_name,b.currency_code, 
nvl(b.period_net_cr, 0), nvl(b.period_net_dr, 0) 
having   nvl(b.period_net_cr,0) <> sum(nvl(accounted_cr,0)) 
or nvl(b.period_net_dr,0) <> sum(nvl(accounted_dr,0)) 
;

 v_functional c_functional%ROWTYPE;

    BEGIN
      open  c_functional;
      fetch c_functional into v_functional;
      if c_functional%NOTFOUND then
        Tab1Print('The Total Dollar value of all Journal lines posted for period = '||:v_orig_periodname|| ' agrees with GL BALANCES total');   
      else
        ErrorPrint('The Total Dollar value of all Journal lines posted for period = '||:v_orig_periodname|| ' does not agree with GL BALANCES total for this period');
        ActionErrorPrint('Please review the following transactions and make the necessary corrections or log an iTar with Oracle Support Services');
        sqltxt :=
' select b.code_combination_id "CCID", '||        
' b.period_name "Period|Name",'||        
' b.currency_code currency, '||       
' nvl(b.period_net_cr, 0) "Period|Credit|Balance", '||       
' nvl(b.period_net_dr, 0) "Period|Debit|Balance",  '||    
' sum(nvl(l.accounted_cr, 0)) "Total|Journal|Debit",  '||      
' sum(nvl(l.accounted_dr, 0)) "Total|Journal|Credit" , '||
' abs(nvl(b.period_net_dr, 0)-sum(nvl(l.accounted_dr, 0))) "Debit|Difference", '||
' abs(nvl(b.period_net_cr, 0)-sum(nvl(l.accounted_cr, 0))) "Credit|Difference" '||
' from   gl.gl_je_headers h, '||
' gl.gl_je_lines l, gl.gl_balances b '||
' where b.set_of_books_id = '||v_sobid ||' '||
' and  upper(b.period_name) = '''||p_periodname||''' '|| 
' and  b.actual_flag = ''A'' '|| 
' and  b.currency_code != ''STAT'' '|| 
--' and  b.currency_code = '''||v_currency_code||''' '||
' and  l.set_of_books_id = b.set_of_books_id '||
' and  l.period_name = b.period_name '||
' and    l.code_combination_id = b.code_combination_id '||
' and    (b.translated_flag <> ''Y'' or b.translated_flag is null) '||
' and    h.je_header_id = l.je_header_id '||
' and    h.actual_flag = b.actual_flag '||
' and    h.currency_code != ''STAT'' '|| 
' and    h.status = ''P'' '|| 
' group by b.code_combination_id, b.period_name,b.currency_code, '||
' nvl(b.period_net_cr, 0), nvl(b.period_net_dr, 0) '||
' having   nvl(b.period_net_cr,0) <> sum(nvl(accounted_cr,0)) '||
' or nvl(b.period_net_dr,0) <> sum(nvl(accounted_dr,0)) '
;
Run_SQL(null,sqltxt,'N');
BRPrint;
end if;
EXCEPTION 
      WHEN OTHERS then   
      Errorprint(sqlerrm||' occurred in test when trying to compare GL_JE_LINES table with GL_BALANCES table for period '||:v_orig_periodname);
      ActionErrorPrint('Please report this error using the feedback option on this test');
      raise STOPEXECUTION;
 END;


    /* ----------------------- Feedback ------------------------------------- */
    Brprint; 
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    /* --------------------------------- Exception Section --------------------------------
*/ 

  EXCEPTION
    WHEN gl_set_of_books_id then 
    ErrorPrint('The Set of books id profile option is not set for this responsibility');
    ActionErrorPrint('This Profile Option must be set in order for a more '||
    'comprehensive General Ledger set up test to be done');
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    WHEN gl_set_of_books_name then
    ErrorPrint('The Set of books name profile option is not set for this responsibility');
    ActionErrorPrint('This Profile Option should be set in order for a more '||
    'comprehensive General Ledger set up test to be done'); 
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    /* WHEN period_name then
    ErrorPrint('The period name entered is invalid');
    ActionErrorprint('Please enter a valid period name for this calendar making sure that the'||
    'correct case is used');
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo'); */

           
    WHEN STOPEXECUTION then 
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');

    WHEN OTHERS then -- exception begin 2
    brprint;
    ErrorPrint(sqlerrm||' occurred in test');
    ActionErrorPrint('Please report this error using the feedback option on this test');
    brprint;
    Show_Footer('&v_Testlongname', '&v_headerinfo');
    brprint; 

  END; -- MAIN PROGRAM

EXCEPTION 
  WHEN OTHERS then   -- exceptions begin 1
  Brprint;
  Errorprint(sqlerrm||' occurred in test');
  ActionErrorPrint('Please report this error using the feedback option on this test');
  Brprint; 
    Show_Footer('&v_Testlongname', '&v_headerinfo');
  Brprint;
END; -- API
/  

REM  ==============SQL PLUS Environment setup=================================
Spool off
Set termout on
set feedback on
set verify off 
set echo off 
set trimout off
set trimspool off
set heading on
set autoprint off

PROMPT 
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================
