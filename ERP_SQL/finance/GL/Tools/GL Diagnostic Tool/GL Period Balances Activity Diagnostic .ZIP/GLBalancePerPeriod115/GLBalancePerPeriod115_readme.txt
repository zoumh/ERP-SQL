================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract        This test diagnoses and reports differences in General Ledger 
                Balances between the current and prior periods.
================================================================================
FILE NAME:        GLBalancePerPeriod115.sql
PRODUCT:          General Ledger (GL)
SUBCOMPONENT:     Balances
PRODUCT VERSIONS: 11.5.X
PLATFORM:         Generic
DATE CREATED:     03-Feb-2003
PARAMETERS:       Username, Responsibility id, Period Name
    
================================================================================
Instructions
================================================================================
Included Files:
     CoreApiHtml.sql 
     GLBalancePerPeriod115.sql 
     GLBalancePerPeriod115_readme.txt
     GLBalancePerPeriod115_readme.html   

Execution Environment:
     SQL*Plus

Access Privileges:
      APPS user access

Usage:
     sqlplus <apps user>/<apps pw>  @GLBalancePerPeriod115.sql 

Instructions:

The files GLBalancePerPeriod.sql and CoreApiHtml.sql should be unzipped
to a common directory. From this directory run the file GLBalancePerPeriod115.sql
in SQL*Plus in the APPS schema.

You will be prompted for an applications user name.

You should then see a list of valid responsibilities for the user entered.

When prompted, enter the responsibility id of the responsibility used when
the problem is occuring.

After selecting the respondibility id, you will be prompted for the the period 
name. This will default to the latest opened period name if you do not enter a 
specific period name.

The test will produce an output file named 
     GLBalancePerPeriod115_<Responsibility ID>_diag.html.
This file can be viewed in a browser or uploaded for support analysis.

================================================================================
Description
================================================================================

Description: 
This diagnostic test will display any inconcsistencies in balances between
the closing period and the opening period. If the period entered is the first 
period of the year, then the difference between the Liabilities and Assets are 
displayed. The test also displays differences in balances for the entered 
current period in the GL_Balances table.

It gives quick balance differences information for the functional currency and 
also displays information on balance differences for other currencies.

These details/balances (actual, encumbrance or budget) can be analysed for 
inconsistencies or for informational purposes. 
 
This test is very useful for diagnosing differences between the Closing Balance 
for one Period and the Opening Balance for the next period.

From the output from this test, it is possible to view all the balance information
between the current period and the previous period. It assists in verifying the 
inconsistencies in the GL Balances between the current and previous period.

Please be advised that this test will not attempt to do any data-fixes, therefore
discrepancies or inconsistencies that are reported by this test will need to be 
fixed by another process, for example the GL transactions rollback process.

================================================================================
References
================================================================================
None


================================================================================
Disclaimer
================================================================================
EXCEPT WHERE EXPRESSLY PROVIDED OTHERWISE, THE INFORMATION, SOFTWARE,
PROVIDED ON AN "AS IS" AND "AS AVAILABLE" BASIS. ORACLE EXPRESSLY DISCLAIMS
ALL WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NON-INFRINGEMENT. ORACLE MAKES NO WARRANTY THAT: (A) THE RESULTS
THAT MAY BE OBTAINED FROM THE USE OF THE SOFTWARE WILL BE ACCURATE OR
RELIABLE; OR (B) THE INFORMATION, OR OTHER MATERIAL OBTAINED WILL MEET YOUR
EXPECTATIONS. ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE DOWNLOADED OR
OTHERWISE OBTAINED IS DONE AT YOUR OWN DISCRETION AND RISK. ORACLE SHALL HAVE
NO RESPONSIBILITY FOR ANY DAMAGE TO YOUR COMPUTER SYSTEM OR LOSS OF DATA THAT
RESULTS FROM THE DOWNLOAD OF ANY CONTENT, MATERIALS, INFORMATION OR SOFTWARE.

ORACLE RESERVES THE RIGHT TO MAKE CHANGES OR UPDATES TO THE SOFTWARE AT ANY
TIME WITHOUT NOTICE.

================================================================================
Limitation of Liability
================================================================================
IN NO EVENT SHALL ORACLE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL OR CONSEQUENTIAL DAMAGES, OR DAMAGES FOR LOSS OF PROFITS, REVENUE,
DATA OR USE, INCURRED BY YOU OR ANY THIRD PARTY, WHETHER IN AN ACTION IN
CONTRACT OR TORT, ARISING FROM YOUR ACCESS TO, OR USE OF, THE SOFTWARE.

SOME JURISDICTIONS DO NOT ALLOW THE LIMITATION OR EXCLUSION OF LIABILITY.
ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS MAY NOT APPLY TO YOU.

