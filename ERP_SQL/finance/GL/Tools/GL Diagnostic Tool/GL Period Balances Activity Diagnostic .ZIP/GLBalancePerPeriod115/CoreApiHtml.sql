set termout off
prompt <html lang="en,us"><head><!--
REM $Header: CoreApiHtml.sql 1.27 26-FEB-2003 support $
REM +=========================================================================+
REM |  Copyright (c) 2001 Oracle Corporation Belmont, California, USA         |
REM |                          All rights reserved.                           |
REM +=========================================================================+
REM ##########################################################################
REM PURPOSE: PLSQL API
REM PROGRAM: CoreApiHtml.sql
REM    NOTE: No Note to Associate
REM  CONFIG: support.cfg, Requires files to source (.env) and Passwords.
REM   USAGE:  API only, included in others as: @CoreApiHtml
REM FRAMEWORK: SDF OHS
REM PRODUCT_VER: 11.5.X
REM PRODUCT_CODE: 510
REM SUBCOMPONENT: FND
REM    NODE: WEB
REM  PARAMS: NONE
REM
REM ##########################################################################
REM ##########################################################################
REM Change History
REM   05-JUN-2002 ALUMPE Modified Display_SQL so that headers print only
REM                      if rows are returned
REM   02-JUL-2002 ALUMPE 1) Added Column_Exists API
REM                      2) Added Show_Invalids API
REM                      3) Added Feedback option and Number of rows option
REM                         To Run_SQL and Display_SQL API's
REM                      4) Modified Get_DB_Patch_List to give appropriate
REM                         feedback if no rows retrieved
REM                      5) Added CheckFinPeriod API
REM                      6) Added CheckKeyFlexfield API
REM                      7) Fixed font inconsistencies with Tab0Print
REM   05-AUG-2002 ALUMPE Added Init_Block and End_Block API's to enable
REM                      multi-block script without reprinting header info
REM   14-AUG-2002 ALUMPE Added NoticePrint API.
REM   30-AUG-2002 ALUMPE Modified Display_profiles to use the _VL views 
REM                      rather than the _TL tables with a language condition
REM                      as userenv('LANG') = 'US' but language = 'AMERICAN'
REM                      on some 10.7 instances
REM   07-NOV-2002 ALUMPE Modified Display_SQL/Run_SQL to allow for indenting
REM                      of the table output.
REM   06-DEC-2002 ALUMPE Modified Display_SQL to convert chr(10) to html
REM                      <BR> in text values
REM   02-JAN-2003 ALUMPE Modified Display_SQL to fix bug with dates displaying
REM                      in DD-MON-  format on certain DB versions.
REM   05-FEB-2003 ALUMPE Modified Compare_Pkg_Version to handle branched
REM                      code versions
REM   17-FEB-2003 ALUMPE Fixed bug in ActionWarningLink "spanclass" corrected
REM                      to "span class" to get correct text color.
REM   26-FEB-2003 ALUMPE Fixed issue with Show_Invalids.  Error storing 
REM                      variable was not being initialized for each object
REM ##########################################################################
REM Procedures/Functions Implemented
REM   ActionErrorPrint()
REM   ActionPrint()
REM   ActionWarningPrint()
REM   Begin_Pre()
REM   BRPrint()
REM   CheckFinPeriod()
REM   CheckKeyFlexfield()
REM   CheckProfile()
REM   Column_Exists()
REM   Compare_Pkg_Version()
REM   Display_Profiles()
REM   Display_SQL()
REM   Display_Table()
REM   End_Pre()
REM   ErrorPrint()
REM   Get_DB_Apps_Version()
REM   Get_DB_Patch_List()
REM   Get_Package_Body()
REM   Get_Package_Spec()
REM   Get_Package_Version()
REM   Get_Profile_Option()
REM   Get_RDBMS_Header()
REM   Insert_HTML()
REM   Insert_Style_Sheet()
REM   NoticePrint()
REM   Run_SQL()
REM   SectionPrint()
REM   Send_Email()
REM   Set_Client()
REM   Set_Org()
REM   Show_Header()
REM   Show_Invalids()
REM   Show_Link()
REM   Show_Table()
REM   Tab0Print()
REM   Tab1Print()
REM   Tab2Print()
REM   Tab3Print()
REM   WarningPrint()
REM
REM Procedures/Functions Removed
REM   BlackPrint() - 508 Compatibility
REM   BluePrint() - 508 Compatibility
REM   GreenPrint() - 508 Compatibility
REM     Plain_SectionPrint()  -  Same as ActionPrint()
REM   RedPrint()  - 508 Compatibility
REM   Steps_Results() - Standards Modification
REM     SuccessPrint() - Same as Tab1Print()
REM
REM Functions to possibly implement
REM   Compare_SQL_Data()
REM   Execute_URL()
REM   Validate_Apps_User()
REM

set serveroutput on size 1000000
set feedback off
set verify off
set echo off
set long 2000000000
set linesize 32767
set longchunksize 32767
set pagesize 0
set timing off
set trimout on
set trimspool on
set heading off
set autoprint on

undefine nbsp
define nbsp = ''
column lnbsp new_value nbsp noprint
select chr(38) || 'nbsp' lnbsp from dual;

undefine p_id
define p_id = ''
column lp_id new_value p_id noprint
select chr(38) || 'p_id' lp_id from dual;

undefine lt
define lt = ''
column llt new_value lt noprint
select chr(38) || 'lt' llt from dual;

undefine gt
define gt = ''
column lgt new_value gt noprint
select chr(38) || 'gt' lgt from dual;

undefine AMPER
define AMPER = ''
column lAMPER new_value AMPER noprint
select chr(38) lAMPER from dual;

undefine T_VARCHAR2
undefine T_ROWID
undefine T_NUMBER
undefine T_LONG
undefine T_DATE
undefine T_CHAR
undefine T_CLOB

variable g_hold_output clob;

declare
   counter      number       := 0;
   failures     number       := 0;
   g_curr_loc   number       := 1;

/* Global variables set by Set_Client which can be used throughout a script */
   g_user_id      number;
   g_resp_id      number;
   g_appl_id      number;
   g_org_id       number;

/* Global variable set by Set_Client or Get_DB_Apps_Version which can 
   be referenced in scripts which branch based on applications release */

   g_appl_version varchar2(10);

   type V2T is table of varchar2(32767);


procedure line_out (text varchar2) is
   l_ptext      varchar2(32767);
   l_hold_num   number;
begin
   l_hold_num := mod(g_curr_loc, 32767);
   if l_hold_num + length(text) > 32759 then
      l_ptext := '<!--' || rpad('*', 32761-l_hold_num,'*') || '-->';
      dbms_lob.write(:g_hold_output, length(l_ptext), g_curr_loc, l_ptext);
      g_curr_loc := g_curr_loc + length(l_ptext);
   end if;
   dbms_lob.write(:g_hold_output, length(text)+1, g_curr_loc, text || chr(10));
   g_curr_loc := g_curr_loc + length(text)+1;
end line_out;


-- Procedure Name: Insert_Style_Sheet
--
-- Usage:
--      Insert_Style_Sheet;
--
-- Output:
--      Inserts a Style Sheet into the output
--
-- Comments:
--      This is not normally needed as the style sheet is automatically
--      inserted with the header.
--
procedure Insert_Style_Sheet is
begin
line_out('<STYLE TYPE="text/css">');
   line_out('<!--');
   line_out('.ind1 {margin-left: .25in}');
   line_out('.ind2 {margin-left: .50in}');
   line_out('.ind3 {margin-left: .75in}');
   line_out('.tab0 {font-size: 10pt; font-weight: normal}');
   line_out('.tab1 {text-indent: .25in; font-size: 10pt; font-weight: normal}');
   line_out('.tab2 {text-indent: .5in; font-size: 10pt; font-weight: normal}');
   line_out('.tab3 {text-indent: .75in; font-size: 10pt; font-weight: normal}');
   line_out('.error {color: #cc0000; font-size: 10pt; font-weight: normal}');
   line_out('.errorbold {font-weight: bold; color: #cc0000; font-size: 10pt}');
   line_out('.warning {font-weight: normal; color: #336699; font-size: 10pt}');
   line_out('.warningbold {font-weight: bold; color: #336699; font-size: 10pt}');
   line_out('.notice {font-weight: normal; font-style: italic; color: #663366; font-size: 10pt}');
   line_out('.noticebold {font-weight: bold; font-style: italic; color: #663366; font-size: 10pt}');
   line_out('.section {font-weight: normal; font-size: 10pt}');
   line_out('.sectionbold {font-weight: bold; font-size: 10pt}');
   line_out('.BigPrint {font-weight: bold; font-size: 14pt}');
   line_out('.SmallPrint {font-weight: normal; font-size: 8pt}');
   line_out('.BigError {color: #cc0000; font-size: 12pt; font-weight: bold}');
   line_out('body {background-color: white; font: normal 12pt Ariel;}');
   line_out('table {background-color: #000000 color:#000000; font-size: 10pt; font-weight: bold; line-height:1.5; padding:2px; text-align:left}');
   line_out('h1, h2, h3, h4 {color: #00000}');
   line_out('h3 {font-size: 16pt}');
   line_out('td {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt; border-style: solid; border-width: 1; border-color: #CCCC99; white-space: nowrap}');
   line_out('tr {background-color: #f7f7e7; color: #000000; font-weight: normal; font-size: 9pt; white-space: nowrap}');
   line_out('th {background-color: #CCCC99; color: #336699; height: 20; border-style: solid; border-width: 1; border-left-color: #f7f7e7; border-right-color: #f7f7e7; border-top-width: 0; border-bottom-width: 0; white-space: nowrap}');
   line_out('th.rowh {background-color: #CCCC99; color: #336699; height: 20; border-style: solid; border-width: 1; border-top-color: #f7f7e7; border-bottom-color: #f7f7e7; border-left-width: 0; border-right-width: 0; white-space: nowrap}');
   line_out('-->');
   line_out('</style>');
end;

-- Procedure Name: Insert_HTML
--
-- Usage:
--      Insert_HMTL('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string
--
-- Examples:
--      begin
--         Insert_HTML('<em>This can be any text you want.</em>');
--      end;
--
-- Notes:
--      Usage of this procedure may make the script not compatible with
--      standards or 508.  Please avoid if possible.
--
procedure Insert_HTML(p_text varchar2) is
begin
   line_out(p_text);
end Insert_HTML;

-- Procedure Name: ActionErrorPrint
--
-- Usage:
--      ActionErrorPrint('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string with the word ACTION - prior to the string
--
-- Examples:
--      begin
--         ActionErrorPrint('Run Gather Schema Statistics');
--      end;
--
procedure ActionErrorPrint(p_text varchar2) is
begin
   line_out('<span class="errorbold">ACTION - </span><span class="error">'  || p_text || '</span><br>');
end ActionErrorPrint;

-- Procedure Name: ActionPrint
--
-- Usage:
--      ActionPrint('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string
--
-- Examples:
--      begin
--         ActionPrint('Run Gather Schema Statistics');
--      end;
--
procedure ActionPrint(p_text varchar2) is
begin
   line_out(p_text || '<br>');
end ActionPrint;

-- Procedure Name: ActionWarningPrint
--
-- Usage:
--      ActionWarningPrint('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string in warning format
--
-- Examples:
--      begin
--         ActionWarningPrint('Run Gather Schema Statistics');
--      end;
--
procedure ActionWarningPrint(p_text varchar2) is
begin
   line_out('<span class="warningbold">ACTION - </span><span class="warning">'  || p_text || '</span><br>');
end ActionWarningPrint;

-- Procedure Name: WarningPrint
--
-- Usage:
--      WarningPrint('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string in warning format
--
-- Examples:
--      begin
--         WarningPrint('Statistics are not up to date');
--      end;
--
procedure WarningPrint(p_text varchar2) is
begin
   line_out('<span class="warningbold">WARNING - </span><span class="warning">'  || p_text || '</span><br>');
end WarningPrint;

-- Procedure Name: ActionErrorLink
--
-- Usage:
--      ActionErrorLink('Pre_String','Note_Number','Post_String');
--      ActionErrorLink('Pre_String','URL','Link_Text', 'Post_String');
--
-- Parameters:
--      Pre_String - Text to appear prior to the link
--      Note_Number - Number of a metalink note to link to
--      URL - Any valid URL
--      Link_Text - Text for the link to URL
--      Post_String - Text to appear after the link
--
-- Output:
--      Displays the pre-link string, the link (as specified either by the
--      note number or by the URL and link text), and the post-link string
--      all in the format of an Error Action
--
-- Examples:
--      begin
--         ActionErrorLink('For clarification see note', 112233.1,
--           'which provides more information on the subject');
--         ActionErrorLink('For clarification see the',
--           'http://someurl.us.com/somepage.html','Development Homepage',
--           'which provides more information on the subject');
--      end;
--
procedure ActionErrorLink(p_txt1 varchar2
         , p_note varchar2
         , p_txt2 varchar2) is
begin
   line_out('<span class="errorbold">ACTION - </span><span class="error">'
         || p_txt1
         || ' <a href="http://metalink.oracle.com/metalink/plsql/ml2_documents.showDocument?p_database_id=NOT&p_id='
         || p_note
         || '">'
         || p_note
         || '</a> '
         || p_txt2
         || '</span><br>');
end ActionErrorLink;

procedure ActionErrorLink(p_txt1 varchar2
         , p_url varchar2
         , p_link_txt varchar2
         , p_txt2 varchar2) is
begin
   line_out('<span class="errorbold">ACTION - </span><span class="error">'
         || p_txt1
         || ' <a href="'
         || p_url
         || '">'
         || p_link_txt
         || '</a> '
         || p_txt2
         || '</span><br>');
end ActionErrorLink;

-- Procedure Name: ActionWarningLink
--
-- Usage:
--      ActionWarningLink('Pre_String','Note_Number','Post_String');
--      ActionWarningLink('Pre_String','URL','Link_Text', 'Post_String');
--
-- Parameters:
--      Pre_String - Text to appear prior to the link
--      Note_Number - Number of a metalink note to link to
--      URL - Any valid URL
--      Link_Text - Text for the link to URL
--      Post_String - Text to appear after the link
--
-- Output:
--      Displays the pre-link string, the link (as specified either by the
--      note number or by the URL and link text), and the post-link string
--      all in the format of a Warning Action
--
-- Examples:
--      begin
--         ActionWarningLink('For clarification see note', 112233.1,
--           'which provides more information on the subject');
--         ActionWarningLink('For clarification see the',
--           'http://someurl.us.com/somepage.html','Development Homepage',
--           'which provides more information on the subject');
--      end;
--

procedure ActionWarningLink(p_txt1 varchar2
                          , p_note varchar2
                          , p_txt2 varchar2) is
begin
   line_out('<span class="warningbold">ACTION - </span><span class="warning">'
         || p_txt1
         || ' <a href="http://metalink.oracle.com/metalink/plsql/'
         || 'ml2_documents.showDocument?p_database_id=NOT&p_id='
         || p_note
         || '">'
         || p_note
         || '</a> '
         || p_txt2
         || '</span><br>');
end ActionWarningLink;

procedure ActionWarningLink(p_txt1 varchar2
           , p_url varchar2
           , p_link_txt varchar2
           , p_txt2 varchar2) is
begin
   line_out('<span class="warningbold">ACTION - </span><span class="warning">'
         || p_txt1
         || ' <a href="'
         || p_url
         || '">'
         || p_link_txt
         || '</a> '
         || p_txt2
         || '</span><br>');
end ActionWarningLink;

-- Procedure Name: ErrorPrint
--
-- Usage:
--      ErrorPrint('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string
--
-- Examples:
--      begin
--         ErrorPrint('Statistics have not been run');
--      end;
--
procedure ErrorPrint(p_text varchar2) is
begin
   line_out('<span class="errorbold">ERROR - </span><span class="error">'  || p_text || '</span><br>');
end ErrorPrint;

-- Procedure Name: NoticePrint
--
-- Usage:
--      NoticePrint('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string in italics preceded by the word 'ATTENTION - '
--
-- Examples:
--      begin
--         NoticePrint('Be alert to this information');
--      end;
--
procedure NoticePrint (p_text varchar2) is
begin
   line_out('<span class="noticebold">ATTENTION - </span>'||
     '<span class="notice">'||p_text||'</span><br>');
end NoticePrint;

-- Procedure Name: SectionPrint
--
-- Usage:
--      SectionPrint('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string in bold print
--
-- Examples:
--      begin
--         SectionPrint('Checking OE Parameters');
--      end;
--
procedure SectionPrint (p_text varchar2) is
begin
   line_out('<br><span class="sectionbold">' || p_text || '</span><br>');
end SectionPrint;

-- Procedure Name: Tab0Print
--
-- Usage:
--      Tab0Print('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string with no indentation
--
-- Examples:
--      begin
--         Tab0Print('Layer 0');
--      end;
--
procedure Tab0Print (p_text varchar2) is
begin
   line_out('<div class="tab0">' || p_text || '</div>');
end Tab0Print;

-- Procedure Name: Tab1Print
--
-- Usage:
--      Tab1Print('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string indented .25 inch
--
-- Examples:
--      begin
--         Tab1Print('Layer 1');
--      end;
--
procedure Tab1Print (p_text varchar2) is
begin
   line_out('<div class="tab1">' || p_text || '</div>');
end Tab1Print;

-- Procedure Name: Tab2Print
--
-- Usage:
--      Tab2Print('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string indented .50 inch
--
-- Examples:
--      begin
--         Tab2Print('Layer 2');
--      end;
--
procedure Tab2Print (p_text varchar2) is
begin
   line_out('<div class="tab2">' || p_text || '</div>');
end Tab2Print;

-- Procedure Name: Tab3Print
--
-- Usage:
--      Tab3Print('String');
--
-- Parameters:
--      String - Any text string
--
-- Output:
--      Displays the text string indented .75 inch
--
-- Examples:
--      begin
--         Tab3Print('Layer 3');
--      end;
--
procedure Tab3Print (p_text varchar2) is
begin
   line_out('<div class="tab3">' || p_text || '</div>');
end Tab3Print;

-- Procedure Name: BRPrint
--
-- Usage:
--      BRPrint;
--
-- Output:
--      Displays a blank Line
--
-- Examples:
--      begin
--         Tab3Print('Layer 3');
--         BRPrint;
--         Tab3Print('Layer 4');
--      end;
--
procedure BRPrint is
begin
   line_out('<br>');
end BRPrint;

-- Procedure Name: CheckFinPeriod
--
-- Usage:
--    CheckFinPeriod('Set of Books ID','Application ID');
--
-- Paramteters:
--    Set of Books ID - ID for the set of books
--    Application ID - ID of the application whose periods are being checked
--
-- Output:
--    List the number of defined and open periods. Indicate the latest
--    open period. Produce warnings if no periods are open or if the
--    current date is not in an open period.
--
-- Examples:
--    CheckFinPeriod(62, 222);  -- Check open periods for AR SOB 62
--    CheckFinPeriod(202, 201); -- Check open periods for PO SOB 202
--
procedure checkFinPeriod (p_sobid NUMBER, p_appid NUMBER ) IS 
l_appname            VARCHAR2(50) :=NULL;
l_period_name        VARCHAR2(50);
l_user_period_type   VARCHAR2(50);
l_start_date         DATE;
l_end_date           DATE;
l_sysdate            DATE;
l_sysopen            VARCHAR2(1); 

CURSOR C1 IS 
  select   a.name sobname, 
           count(b.period_name) total_periods, 
           count(decode(b.closing_status,'O',b.PERIOD_NAME,null)) open_periods,
           a.accounted_period_type period_type
  from     gl_sets_of_books a, 
           gl_period_statuses b 
  where    a.set_of_books_id = b.set_of_books_id (+) 
  and      b.application_id = p_appId 
  and      a.set_of_books_id = p_sobId
  and      b.period_type = a.accounted_period_type
  group by a.name, a.accounted_period_type; 

c1_rec  c1%rowtype;
no_rows exception;

BEGIN 

select application_name 
into   l_appname
from   fnd_application_vl 
where  application_id = p_appid ;

open c1;
fetch c1 into c1_rec;
IF c1%notfound THEN
  raise no_rows;
END IF;

select user_period_type into l_user_period_type
from   gl_period_types
where  period_type = c1_rec.period_type;

Tab1Print('Set of books '|| c1_rec.sobname ||' for application '
  || l_appname || ' has ' || to_char(c1_rec.total_periods) 
  || ' periods defined and '|| to_char(c1_rec.open_periods)
  || ' periods open for period type '|| l_user_period_type);
IF c1_rec.total_periods = 0 THEN 
  WarningPrint('There are no periods defined for this Set of books');
  ActionWarningPrint('There must be periods defined for this set of books');
END IF;
IF c1_rec.open_periods = 0 THEN 
  WarningPrint('There are no open periods defined for this Set of books');
  ActionWArningprint('Please consider opening a period for this '||
    'application and set of books'); 
ELSE 
  BEGIN 
    SELECT  period_name, start_date, end_date, sysdate
    INTO    l_period_name, l_start_date, l_end_date, l_sysdate 
    FROM gl_period_statuses 
    WHERE adjustment_period_flag = 'N' 
    AND   period_type = c1_rec.period_type
    AND   start_date = (
      SELECT MAX(start_date) 
      FROM gl_period_statuses 
      WHERE  closing_status = 'O' 
      AND    adjustment_period_flag = 'N' 
      AND    period_type = c1_rec.period_type
      AND    application_id = p_appId
      AND    set_of_books_id = p_sobId )
    AND closing_status  = 'O' 
    AND application_id  =  p_appId
    AND set_of_books_id = p_sobId;
            
/* check if sysdate is in the latest open period*/
    l_sysopen := 'N';
    IF  l_sysdate >= l_start_date AND l_sysdate <= l_end_date THEN  
       l_sysOpen := 'Y';
    END IF; 
    Tab1Print('Latest open period is '|| l_period_name 
      || ' with a start date of '|| to_char(l_start_date)
      || ' and an end date of ' || to_char(l_end_date) );
    IF l_sysopen = 'Y' THEN 
      Tab2Print('Current date '|| to_char(l_sysdate) 
        || ' is in the latest open period');
    ELSE      
      BEGIN 
        SELECT period_name, start_date, end_date, sysdate 
        INTO   l_period_name, l_start_date, l_end_date, l_sysdate
        FROM   gl_period_statuses 
        WHERE  adjustment_period_flag = 'N' 
        AND    period_type = c1_rec.period_type
        AND    sysdate between start_date and end_date 
        AND    closing_status = 'O' 
        AND    application_id = p_appId
        AND    set_of_books_id = p_sobId;

        Tab2Print('Current date '|| to_char(sysDate)
          || ' is in the open period ' || l_period_name
          || ' with a start date of ' || to_char(l_start_date)
          || ' and an end date of ' || to_char(l_end_date) );
 
      EXCEPTION WHEN NO_DATA_FOUND THEN 
        WarningPrint('Current date '|| to_char(l_sysdate)
          || ' is not in an open period');
        ActionwarningPrint('Please consider opening the current period');
      END;
    END IF; 
  EXCEPTION WHEN NO_DATA_FOUND THEN
    /* not really possible to fall in this exception as we already
       checked that there were open periods */ 
    WarningPrint('There are no open periods defined for this Set of books');
    ActionWArningprint('Please consider opening a period for this '||
      'application and set of books'); 
  END; 
END IF;
EXCEPTION
  WHEN NO_ROWS THEN
    WarningPrint('There are no accounting periods defined in '||
      'gl_period_statuses for this application and set of books');
    ActionWArningprint('If required, define the accounting calendar for this '||
      'application and set of books'); 
  WHEN NO_DATA_FOUND THEN 
    ErrorPrint('Invalid Application id passed to checkFinPeriod');
    ActionErrorPrint('Application id ' || to_char(p_appid)
      || ' is not valid on this system');    
  WHEN OTHERS THEN
    ErrorPrint(sqlerrm||' occurred in CheckFinPeriod');
    ActionErrorPrint('Report this error to your support representative');
END checkFinPeriod;   


-- Function  Name: CheckKeyFlexfield
-- Procedure Name: CheckKeyFlexfield
--
-- Usage:
--      CheckKeyFlexfield('Key Flex Code','Flex Structure ID','Print Header');
--
-- Parameters:
--      Key Flex Code - The code of the Key Flexfield to be displayed.  For 
--                      example, for the Accounting Flexfield use 'GL#'.
--      Flex Structure ID - The id_flex_num of the specific structure 
--                          of the key flexfield whose details are to be
--                          displayed.  If null, print details of all
--                          structures. (default NULL)
--      Print Header - A boolean (true or false) indicating whether the output
--                     should print a heading before outputting the details
--                     of the key flexfield. (default TRUE)
-- Returns:
--      If value has been provided for the Flex Structure ID, the function
--      will returns an array of character strings with the following structure
--         1 name of the flexfield
--         2 enabled flag
--         3 frozen flag
--         4 dynamic instert flag
--         5 cross validation allowed flag
--         6 number of enabled segments defined
--         7 number of enabled segments with value sets
--         8 Y if any segment has security otherwise N
--      If no value is passed to the parameter the function will return an
--      array will null values.:w
--
-- Output:
--      Displays key information about the flexfield, its structure, and the
--      individual flexfield segments that make it up.
--
-- Examples:
--      declare
--         flexarray V2T;
--      begin
--         CheckKeyFlexfield('GL#', 50577, true);
--         CheckKeyFlexfield('MSTK',  null, false);
--         flexarray := CheckKeyFlexfield('GL#', 12345, false);
--      end;
--
Function CheckKeyFlexfield(p_flex_code     in varchar2
                       ,   p_flex_num  in number default null
                       ,   p_print_heading in boolean default true) 
return V2T is

l_ret_array         V2T := V2T(null,null,null,null,null,null,null,null);
l_no_value_sets     integer := 0;
l_any_sec_enabled   varchar2(1) := 'N';
l_sec_enabled       varchar2(1) := 'N';
l_flex_name         fnd_id_flexs.id_flex_name%type;
l_counter           integer := 0;
l_counter2          integer := 0;
l_num_segs          integer := 0;
l_num_segs_vs       integer := 0;
l_rule_count        integer := 0;
l_rule_assign_count integer := 0;
l_value_set_str     varchar2(400);
leave_api           exception;

cursor get_structs (p_f_code varchar2, p_f_num number) is
  select id_flex_num                   flex_str_num,
         id_flex_structure_name        flex_str_name,
         to_char(last_update_date,'DD-MON-YYYY HH24:MI:SS') last_updated,
         cross_segment_validation_flag cross_val,
         dynamic_inserts_allowed_flag  dyn_insert,
         enabled_flag                  enabled,
         freeze_flex_definition_flag   frozen
  from   fnd_id_flex_structures_vl 
  where  id_flex_code = p_f_code
  and    enabled_flag ='Y'
  and    id_flex_num = nvl(p_f_num,id_flex_num);

cursor get_segments (p_f_code varchar2, p_f_num number) is
  select s.application_column_name          col_name,
         s.segment_name                     seg_name,                  
         s.segment_num                      seg_num,
         s.enabled_flag                     enabled,
         s.required_flag                    required,
         s.display_flag                     displayed,
         s.flex_value_set_id                value_set_id,
         vs.flex_value_set_name             value_set_name,         
         DECODE(vs.validation_type,
              'I', 'Independent', 'N', 'None',  'D', 'Dependent',
              'U', 'Special',     'P', 'Pair',  'F', 'Table',
              'X', 'Translatable Independent',  'Y', 'Translatable Dependent',
              vs.validation_type)           validation_type,
         s.security_enabled_flag            seg_security,
         nvl(vs.security_enabled_flag,'N')  value_set_security       
  from   fnd_id_flex_segments_vl s, fnd_flex_value_sets vs
  where  s.flex_value_set_id = vs.flex_value_set_id (+)                
  and    s.id_flex_code = p_f_code                    
  and    s.id_flex_num =  p_f_num
  order by s.segment_num ;

cursor get_qualifiers(p_f_code varchar2, p_f_num number, p_col_name varchar2) is
  select segment_prompt 
  from fnd_segment_attribute_values sav,
       fnd_segment_attribute_types  sat
  where sav.attribute_value = 'Y'
  and   sav.segment_attribute_type <> 'GL_GLOBAL'
  and   sav.application_id = sat.application_id
  and   sav.id_flex_code = sat.id_flex_code
  and   sav.segment_attribute_type = sat.segment_attribute_type
  and   sav.id_flex_code = p_f_code
  and   sav.id_flex_num =  p_f_num
  and   sav.application_column_name = p_col_name;

begin
  begin
    select id_flex_name into l_flex_name
    from   fnd_id_flexs
    where id_flex_code = p_flex_code;
  exception when no_data_found then
    WarningPrint('ID Flex Code passed '||p_flex_code||' is not valid on this '||
      'system');
    ActionWarningPrint('ID Flex Code '||p_flex_code||' will not be tested');
  end;
  
  BRPrint;
  if p_flex_num is null then
    if (p_print_heading) then
      SectionPrint('Details of Key flexfield: '||l_flex_name);
    else
      Tab0Print('Key flexfield: '||l_flex_name);
    end if;
  else
    l_ret_array(1) := l_flex_name;
    if (p_print_heading) then
      SectionPrint('Details of Key flexfield: '||l_flex_name
        ||' with id_flex_num '||to_char(p_flex_num));
    else
      Tab0Print('Key flexfield: '||l_flex_name||' with id_flex_num ' 
        || to_char(p_flex_num));
    end if;
  end if;

  l_counter := 0;
  for str in get_structs(p_flex_code, p_flex_num) loop
    l_counter := l_counter + 1;
    if p_flex_num is not null then
      l_ret_array(2) := str.enabled;
      l_ret_array(3) := str.frozen;
      l_ret_array(4) := str.dyn_insert;
      l_ret_array(5) := str.cross_val;
    end if;
    if l_counter > 1 then
      BRPrint;
    end if;
    Tab1Print('Structure '||str.flex_str_name||' (ID='||
      to_char(str.flex_str_num) ||')');
    Tab1Print('Enabled Flag = '||str.enabled||', Frozen = '||str.frozen
      ||', Dynamic Inserts = '||str.dyn_insert||', Cross Validation Allowed = '
      ||str.cross_val||', Last Updated '||str.last_updated);


    l_counter2    := 0;
    l_num_segs    := 0;
    l_num_segs_vs := 0;
    for seg in get_segments(p_flex_code, str.flex_str_num) loop
      if l_counter2 = 0 then
        Tab1Print('Segment Details for '||str.flex_str_name);
        BRPrint;
      end if;
      l_counter2 := l_counter2 + 1;

      if (p_flex_num is not null) then
        if seg.enabled = 'Y' then
          l_num_segs := l_num_segs + 1;
          if (seg.value_set_id is not null) then
            l_num_segs_vs := l_num_segs_vs + 1;
          end if; 
        end if;
      end if;
      l_sec_enabled := 'N';
      if (seg.seg_security = 'Y' and seg.value_set_security in ('Y','H')) then
        l_any_sec_enabled := 'Y';
        l_sec_enabled := 'Y';
      end if;
      if (seg.value_set_id is not null) then
        l_value_set_str := ', Value Set = '||seg.value_set_name||
          ', Value Set Type = '||seg.validation_type;
      else
        l_value_set_str := ' with no value set assigned';
      end if;
      Tab2Print('Segment Name = '||seg.seg_name);
      Tab2Print('Enabled      = '||seg.enabled||', Displayed = '||
        seg.displayed||l_value_set_str); 

      for qual in get_qualifiers(p_flex_code,str.flex_str_num,seg.col_name) loop
        Tab3Print('Qualifier '||qual.segment_prompt||' is assigned to '||
          'segment '|| seg.seg_name);
      end loop;

      if l_sec_enabled = 'Y' then
        select count(*) into l_rule_count
        from   fnd_flex_value_rules_vl
        where  flex_value_set_id = seg.value_set_id;

        select count(*) into l_rule_assign_count
        from   fnd_flex_value_rules_vl r, 
               fnd_flex_value_rule_usages ru
        where  r.flex_value_rule_id = ru.flex_value_rule_id
        and    r.flex_value_set_id =  seg.value_set_id;

        Tab3Print('Security is enabled for this segment and value set with '||
          to_char(l_rule_count)||' rules defined and '||
          to_char(l_rule_assign_count)||' rule assignments');
      end if;
    end loop;
    if (p_flex_num is not null) then
      l_ret_array(6) := to_char(l_num_segs);
      l_ret_array(7) := to_char(l_num_segs_vs);
      l_ret_array(8) := l_any_sec_enabled;
    end if;
    if l_counter2 = 0 then
      ErrorPrint('There are no segments defined for this structure'); 
      ActionErrorPrint('Please enable or define at least one segment for '||
        str.flex_str_name);
    end if;
  end loop;
  if l_counter = 0 then
    if p_flex_num is null then
      ErrorPrint('There are no Key Flexfields enabled for ' || p_flex_code);
      ActionErrorPrint('Please enable or define a Key Flexfield for ' ||
        p_flex_code);
    else
      ErrorPrint('The requested flexfield structure (ID_FLEX_NUM='||
        to_char(p_flex_num)||') is inactive or does not exist');
      ActionErrorPrint('Verify that the flexfield structure is defined '||
        'and enabled for Key Flexfield '||p_flex_code);
    end if;
  end if;
  return l_ret_array;
exception
  when leave_api then
    return l_ret_array;
end CheckKeyFlexfield;

procedure CheckKeyFlexfield(p_flex_code     in varchar2
                        ,   p_flex_num  in number default null
                        ,   p_print_heading in boolean default true)  is
dummy_v2t  V2T;
begin
  dummy_v2t := CheckKeyFlexfield(p_flex_code, p_flex_num, p_print_heading);
end CheckKeyFlexfield;

-- Function  Name: CheckProfile
--
-- Usage:
--      CheckProfile('Profile Name', UserID, ResponsibilityID,
--                   ApplicationID, 'Default Value', Indent Level, Align At);
--
-- Parameters:
--      Profile Name - System name of the profile option being checked
--      UserID - The identifier of that applications user for which the 
--               profile option is to be checked.
--      ResponsibilityID - The identifier of the responsibility for which
--                         the profile option is to be checked
--      ApplicationID - The identifier of the application for which the profile
--                      option is to be checked
--      Default Value - The value that will be used as a default if the profile
--                      option is not set by the users (Default=NULL)
--      Indent Level - Number of tabs (0,1,2,3) that output should be indented
--                     (Default=0)
--      Align At - Not used in HTML API's.  Only present for consistency 
--                 with text API's where this will place the '=' at the 
--                 indicated character position from the beginning of the 
--                 text.
--
-- Returns:
--      If called as a function the return value will be either --
--         1 the value of the profile option if set
--         2 'DOESNOTEXIST' if the profile option does not exist
--         3 'DISABLED' if the profile option has been end dated 
--         4 null if the profile option is not set
--
-- Output:
--      If the profile is set, displays its current setting.  If not set and
--      a default value exists, displays a warning indicating that the default
--      value will be used and indicating the value of the default.  If not set
--      and no default value is supplied, displays an error indicating that
--      the profile option should be set. Output will be indented according
--      to the Indent Level parameter supplied. 
--
--      If the profile option does not exist or is disabled there is no
--      output.
--
-- Examples:
--      declare
--         profile_val fnd_profile_option_values.profile_option_value%type;
--      begin
--         profile_val := CheckProfile('PA_SELECTIVE_FLEX_SEG',g_user_id,
--            g_resp_id, g_appl_id, null, 1);
--      end;
--
function CheckProfile(p_prof_name in varchar2
                    , p_user_id   in number
                    , p_resp_id   in number
                    , p_appl_id   in number
                    , p_default   in varchar2 default null
                    , p_indent    in integer default 0
                    , p_align_at  in integer default 0) 
return varchar2 is
l_user_prof_name  fnd_profile_options_tl.user_profile_option_name%type;
l_prof_value      fnd_profile_option_values.profile_option_value%type;
l_start_date      date;
l_end_date        date;
l_opt_defined     boolean;
l_output_txt      varchar2(500);
begin
   begin
      select user_profile_option_name,
             nvl(start_date_active,sysdate-1),
             nvl(end_date_active,sysdate+1) 
      into   l_user_prof_name, l_start_date, l_end_date
      from   fnd_profile_options_vl
      where  profile_option_name = p_prof_name;
   exception 
      when no_data_found then
         l_prof_value := 'DOESNOTEXIST';
         return(l_prof_value);
      when others then
         ErrorPrint(sqlerrm||' occured while getting profile option '||
            'information'); 
         ActionErrorPrint('Report the above information to your support '||
            'representative');
         return(null);
   end;
   if ((sysdate < l_start_date) or (sysdate > l_end_date)) then
      l_prof_value := 'DISABLED';
      return(l_prof_value);
   end if;
   fnd_profile.get_specific(p_prof_name, p_user_id, p_resp_id, p_appl_id,
      l_prof_value, l_opt_defined);
   if not l_opt_defined then
      l_prof_value := null;
   end if; 
   if l_prof_value is null then
      if p_default is null then 
         ErrorPrint(l_user_prof_name || ' profile option is not set');
         ActionErrorPrint('Please set the profile option according to '||
            'the user manual');
         return(l_prof_value);
      else
         WarningPrint(l_user_prof_name || ' profile option is not set '||
            'and will default to ' || p_default);
         ActionWarningPrint('Please set the profile option according to '||
            'the user manual if you do not want to use the default');
         return(l_prof_value);
      end if;
   else
      l_output_txt := l_user_prof_name || ' = "' || l_prof_value||'"';
      if p_indent = 1 then
         Tab1Print(l_output_txt);
      elsif p_indent = 2 then
         Tab2Print(l_output_txt);
      elsif p_indent = 3 then
         Tab3Print(l_output_txt);
      else
         Tab0Print(l_output_txt);
      end if;
      return(l_prof_value);
   end if; 
exception when others then
   ErrorPrint(sqlerrm||' occured in CheckProfile');
   ActionErrorPrint('Please report this error to your support representative');
end CheckProfile;

-- Procedure Name: CheckProfile
--
-- Usage:
--      CheckProfile('Profile Name', UserID, ResponsibilityID,
--                   ApplicationID, 'Default Value', Indent Level, Align At);
--
-- Parameters:
--      Profile Name - System name of the profile option being checked
--      UserID - The identifier of that applications user for which the 
--               profile option is to be checked.
--      ResponsibilityID - The identifier of the responsibility for which
--                         the profile option is to be checked
--      ApplicationID - The identifier of the application for which the profile
--                      option is to be checked
--      Default Value - The value that will be used as a default if the profile
--                      option is not set by the users (Default=NULL)
--      Indent Level - Number of tabs (0,1,2,3) that output should be indented
--                     (Default=0)
--      Align At - Not used in HTML API's.  Only present for consistency 
--                 with text API's where this will place the '=' at the 
--                 indicated character position from the beginning of the 
--                 text.
--
-- Output:
--         Same as the function CheckProfile
--
-- Examples:
--         CheckProfile('PA_DEBUG_MODE',g_user_id, g_resp_id, g_appl_id);
--         CheckProfile('PA_DEBUG_MODE',g_user_id, g_resp_id, g_appl_id,'Y',2);
--
procedure CheckProfile(p_prof_name in varchar2
                    , p_user_id   in number
                    , p_resp_id   in number
                    , p_appl_id   in number
                    , p_default   in varchar2 default null
                    , p_indent    in integer default 0
                    , p_align_at  in integer default 0) is
l_dummy_prof_value fnd_profile_option_values.profile_option_value%type;
begin
   l_dummy_prof_value := CheckProfile(p_prof_name, p_user_id, p_resp_id,
                            p_appl_id, p_default, p_indent, p_align_at);
end CheckProfile;

-- Function Name: Column_Exists
--
-- Usage:
--    Column_Exists('Table Name','Column Name');
--
-- Paramteters:
--    Table Name - Table in which to check for the column
--    Column Name - Column to check
--
-- Returns:
--    'Y' if the column exists in the table, 'N' if not.
--
-- Example:
--   declare
--      sqltxt varchar2(1000);
--   begin
--      if Column_Exists('PA_IMPLEMENTATIONS_ALL','UTIL_SUM_FLAG') = 'Y' then ;
--         sqltxt := sqltxt||' and i.util_sum_flag is not null';
--      end if;
--   end;
--
function Column_Exists(p_tab in varchar, p_col in varchar) return varchar2 is
l_counter integer:=0;
begin
  select count(*) into l_counter
  from   all_tab_columns
  where  table_name = upper(p_tab)
  and    column_name = upper(p_col);
  if l_counter > 0 then
    return('Y');
  else
    return('N');
  end if;
exception when others then
  ErrorPrint(sqlerrm||' occured in Column_Exists');
  ActionErrorPrint('Report this information to your support analyst');
  raise;
end Column_Exists;

-- Procedure Name: Begin_Pre
--
-- Usage:
--      Begin_Pre;
--
-- Output:
--      Allows the following output to be preformatted
--
-- Examples:
--      begin
--         Begin_Pre;
--      end;
--
procedure Begin_Pre is
begin
   line_out('<pre>');
end Begin_Pre;

-- Procedure Name: End_Pre
--
-- Usage:
--      End_Pre;
--
-- Output:
--      Closes the Begin_Pre procedure
--
-- Examples:
--      begin
--         End_Pre;
--      end;
--
procedure End_Pre is
begin
   line_out('</pre>');
end End_Pre;

procedure Show_Table(p_type varchar2, p_values V2T, p_caption varchar2 default null, p_options V2T default null) is
   l_hold_option   varchar2(500);
begin
   if upper(p_type) in ('START','TABLE') then
      if p_caption is null then
         line_out('<table cellspacing=0>');
      else
         line_out('<br><table cellspacing=0 summary="' || p_caption || '">');
      end if;
   end if;
   if upper(p_type) in ('TABLE','ROW', 'HEADER') then
      line_out('<tr>');
      for i in 1..p_values.COUNT loop
         if p_options is not null then
            l_hold_option := ' ' || p_options(i);
         end if;
         if p_values(i) = '&nbsp;'
         or p_values(i) is null then
            if upper(p_type) = 'HEADER' then
               line_out('<th id=' || i || '>&nbsp;</th>');
            else
               line_out('<td headers=' || i || '>&nbsp;</td>');
            end if;
         else
            if upper(p_type) = 'HEADER' then
               line_out('<th' || l_hold_option || ' id=' || i || '>' || p_values(i) || '</th>');
            else
               line_out('<td' || l_hold_option || ' headers=' || i || '>' || p_values(i) || '</td>');
            end if;
         end if;
      end loop;
      line_out('</tr>');
   end if;
   if upper(p_type) in ('TABLE','END') then
      line_out('</TABLE>');
   end if;
end Show_Table;

procedure Show_Table(p_values V2T) is
begin
   Show_Table('TABLE',p_values);
end Show_Table;

procedure Show_Table(p_type varchar2) is
begin
   Show_Table(p_type,null);
end Show_Table;

procedure Show_Table_Row(p_values V2T, p_options V2T default null) is
begin
   Show_Table('ROW', p_values, null, p_options);
end Show_Table_Row;

procedure Show_Table_Header(p_values V2T, p_options V2T default null) is
begin
   Show_Table('HEADER', p_values, null, p_options);
end Show_Table_Header;

procedure Start_Table (p_caption varchar2 default null) is
begin
   Show_Table('START',null, p_caption);
end Start_Table;

procedure End_Table is
begin
   Show_Table('END',null);
end End_Table;

-- Function Name: Display_SQL
--
-- Usage:
--     a_number := Display_SQL('SQL statement','Name for Header','Long Flag',
--                 'Feedback','Max Rows','Indent Level');
--
-- Parameters:
--     SQL Statement - Any valid SQL Select Statement
--     Name for Header - Text String to for heading the output
--     Long Flag - Y or N  - If set to N then this will not output
--                 any LONG columns (default = Y)
--     Feedback - Y or N indicates whether to indicate the number of rows
--                selected automatically in the output (default = Y)
--     Max Rows - Limits the number of rows output to this number. NULL or
--                ZERO value indicates unlimited. (Default = NULL)
--     Indent Level - Indicates if the table should be indented and if so
--                    how far: 0 = no indent, 1=.25in, 2=.5in, 3 = .75in
--                    (Default = 0)
--
-- Returns:
--      The function returns the # of rows selected.
--      If there is an error then the function returns -1.
--
-- Output:
--      Displays the output of the SQL statement as an HTML table.
--
-- Examples:
--      declare
--         num_rows number;
--      begin
--         num_rows := Display_SQL('select * from ar_system_parameters_all',
--                                 'AR Parameters', 'Y', 'N',null);
--         num_rows := Display_SQL('select * from pa_implementations_all',
--                                 'PA Implementation Options');
--      end;
--

function Display_SQL (p_sql_statement  varchar2
                    , table_alias      varchar2
                    , display_longs    varchar2 default 'Y'
                    , p_feedback       varchar2 default 'Y'
                    , p_max_rows       number   default null
                    , p_ind_level      number   default 0
                    , p_current_exec   number default 0) return number is

   error_position       number;
   error_position_end   number;
   row_counter          number;
   hold_exclude_cols    boolean;
   hold_sql_needed      varchar2(3);
   hold_string          varchar2(32767)  default null;
   hold_option          varchar2(32767)  default null;
   hold_sql             varchar2(32767)  default null;
   hold_sql_remain      varchar2(32767)  default null;
   hold_element         varchar2(32767)  default null;
   hold_long            long;
   hold_clob            clob;
   hold_length          integer;
   hold_bgcolor         varchar2(40);
   hold_color           varchar2(40);
   hold_open_paren      number;
   hold_curr_loc        number;
   hold_end_pos         number;
   column_counter       binary_integer  default 1;
   value_counter        binary_integer  default 1;

   column_high          binary_integer  default 1;
   value_high           binary_integer  default 1;
   v_cursor_id          number;
   v_dummy              integer;
   l_hold_date_format   varchar2(40);
   l_hold_type          varchar2(40);
   l_max_rows           integer;
   l_feedback_txt       varchar2(200);

   v_values     V2T;
   v_options    V2T;
   v_describe   dbms_sql.desc_tab;

   T_VARCHAR2   constant integer := 1;
   T_NUMBER     constant integer := 2;
   T_LONG       constant integer := 8;
   T_ROWID      constant integer := 11;
   T_DATE       constant integer := 12;
   T_RAW        constant integer := 23;
   T_CHAR       constant integer := 96;
   T_TYPE       constant integer := 109;
   T_CLOB       constant integer := 112;
   T_BLOB       constant integer := 113;
   T_BFILE      constant integer := 114;

begin

   if nvl(p_max_rows,0) = 0 then
     l_max_rows := null;
   else
     l_max_rows := p_max_rows;
   end if;

   if p_current_exec = 0 then
      select value into l_hold_date_format
      from   nls_session_parameters where parameter = 'NLS_DATE_FORMAT';
      execute immediate 'alter session set nls_date_format =
         ''DD-MON-YYYY HH24:MI''';
   end if;
   begin
      v_cursor_id := DBMS_SQL.OPEN_CURSOR;
      DBMS_SQL.PARSE(v_cursor_id, p_sql_statement, DBMS_SQL.V7);
      DBMS_SQL.DESCRIBE_COLUMNS(v_cursor_id, column_high, v_describe);
      hold_sql := 'select ';
      hold_sql_needed := null;
      hold_exclude_cols := false;
      hold_sql_remain := ltrim(substr(replace(p_sql_statement,chr(10),' '), 7));
      for value_counter in 1..column_high loop
         if v_describe(value_counter).col_type = T_LONG then
            hold_length := 25000;
         else
            hold_length := to_number(v_describe(value_counter).col_max_len);
         end if;
         if v_describe(value_counter).col_type in (T_DATE, T_VARCHAR2,
         T_NUMBER, T_CHAR, T_ROWID) then
            DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter,
              hold_string, greatest(hold_length,30));
         elsif v_describe(value_counter).col_type = T_CLOB then
            DBMS_SQL.DEFINE_COLUMN(v_cursor_id, value_counter, hold_clob);
         else
            null;
         end if;
         hold_string := v_describe(value_counter).col_name;
         if value_counter = 1 then
            v_values := V2T(replace(initcap(hold_string),'|','<br>'));
         else
            v_values.EXTEND;
            v_values(value_counter) := replace(initcap(hold_string),'|','<br>');
         end if;
         if substr(hold_sql_remain,1,1) != '*' then
            hold_end_pos := 1;
            hold_open_paren := 0;
            loop
               if substr(hold_sql_remain,hold_end_pos,1) = '(' then
                  hold_open_paren := hold_open_paren + 1;
               elsif substr(hold_sql_remain,hold_end_pos,1) = ')' then
                  hold_open_paren := hold_open_paren - 1;
               elsif substr(hold_sql_remain,hold_end_pos,1) = ',' or
               lower(substr(hold_sql_remain, hold_end_pos, 4)) = ' from ' then
                  if hold_open_paren = 0 then
                     exit;
                  end if;
               end if;
               hold_end_pos := hold_end_pos + 1;
               if hold_end_pos > length(p_sql_statement) then
                  exit;
               end if;
            end loop;
            hold_element := substr(hold_sql_remain, 1, hold_end_pos);
            hold_sql_remain := ltrim(substr(hold_sql_remain, hold_end_pos + 1));
         else
            hold_element := v_describe(value_counter).col_name;
         end if;
         if v_describe(value_counter).col_type in
         (T_VARCHAR2, T_CHAR, T_NUMBER, T_DATE, T_LONG, T_CLOB, T_ROWID) then
            hold_sql := hold_sql || hold_sql_needed || hold_element;
         else
            hold_exclude_cols := true;
         end if;
         hold_sql_needed := ', ';
      end loop;
      if hold_exclude_cols then
         DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
         hold_sql := hold_sql || ' ' ||
            substr(p_sql_statement,instr(lower(p_sql_statement),' from '));
         row_counter := Display_SQL (hold_sql, table_alias, display_longs,
            p_feedback, p_max_rows, p_ind_level, p_current_exec + 1) + 1;
      else
         if nvl(p_ind_level,0) != 0 then
            line_out('<div class=ind'||to_char(p_ind_level)||'>');
         end if;
         if table_alias is not null then
            line_out('<br><span class="BigPrint">' || table_alias || '</span>');
         end if;

         v_dummy := DBMS_SQL.EXECUTE(v_cursor_id);

         row_counter := 1;
         loop
            if DBMS_SQL.FETCH_ROWS(v_cursor_id) = 0 then
               exit;
            end if;
            if row_counter = 1 then
               Start_Table(table_alias);
               Show_Table_Header(v_values);
            end if;
            for value_counter in 1..column_high loop
               if v_describe(value_counter).col_type in
               (T_DATE, T_VARCHAR2, T_NUMBER, T_CHAR, T_ROWID) then
                  DBMS_SQL.COLUMN_VALUE(v_cursor_id,value_counter,hold_string);
               else
                  DBMS_SQL.COLUMN_VALUE(v_cursor_id,value_counter,hold_clob);
                  hold_string := 'CLOB';
               end if;
               hold_string := nvl(hold_string,'&nbsp;');
               hold_option := null;
               if v_describe(value_counter).col_type = T_DATE then
                  hold_string := replace(hold_string,' ','&nbsp;');
                  hold_option := 'nowrap align=right';
               elsif v_describe(value_counter).col_type = T_VARCHAR2 then
                  hold_string := replace(replace(hold_string,'<','&lt;'),
                     '>','&gt;');
                  hold_string := replace(hold_string, chr(10),'<BR>');
                  if hold_string != rtrim(hold_string) then
                     hold_option := 'nowrap bgcolor=yellow';
                  else
                     hold_option := 'nowrap';
                  end if;
               elsif v_describe(value_counter).col_type = T_NUMBER then
                  hold_option := 'nowrap align=right';
               else
                  null;
               end if;
               if value_counter = 1 then
                  v_values := V2T(hold_string);
                  v_options := V2T(hold_option);
               else
                  v_values.EXTEND;
                  v_values(value_counter) := hold_string;
                  v_options.EXTEND;
                  v_options(value_counter) := hold_option;
               end if;
            end loop;
            Show_Table_Row(v_values, v_options);
            row_counter := row_counter + 1;
            if row_counter >  nvl(l_max_rows,row_counter) then
               exit;
            end if;
         end loop;
         DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
         End_Table;
         if nvl(p_ind_level,0) != 0 then
            line_out('</div>');
         end if;
      end if;
      if p_current_exec = 0 and p_feedback = 'Y' then
         if row_counter = 1 then
           l_feedback_txt := '<BR><span class="SmallPrint">'||
              '0 Rows Selected</span><br>';
         elsif row_counter = 2 then
           l_feedback_txt := '<span class="SmallPrint">'||
              '1 Row Selected</span><br>';
         else
           l_feedback_txt := '<span class="SmallPrint">'||
              ltrim(to_char(row_counter - 1,'9999999')) ||
              ' Rows Selected</span><br>';
         end if;
         line_out(l_feedback_txt);
         execute immediate 'alter session set nls_date_format = ''' ||
            l_hold_date_format || '''';
      end if;
      if p_current_exec = 0 and row_counter = 1 then
         line_out('<BR>');
      end if;
      return row_counter-1;
   exception
      when others then
         line_out('</table><br>');
         error_position := DBMS_SQL.LAST_ERROR_POSITION;
         ErrorPrint(sqlerrm || ' occurred in Display_SQL');
         ActionErrorPrint('Please report the error below to your support '||
            'representative');
         line_out('Position: ' || error_position  || ' of ' ||
            length(p_sql_statement) || '<br>');
         line_out(replace(substr(p_sql_statement,1,error_position),chr(10),
            '<br>'));
         error_position_end := instr(p_sql_statement,' ',error_position+1) -
            error_position;
         line_out('<span class="error">' ||
            replace(substr(p_sql_statement,error_position+1,
            error_position_end),chr(10),'<br>') || '</span>');
         line_out(replace(substr(p_sql_statement,error_position+
            error_position_end+1),chr(10),'<br>') || '<br>');
         DBMS_SQL.CLOSE_CURSOR(v_cursor_id);
         if p_current_exec = 0 then
            execute immediate 'alter session set nls_date_format = ''' ||
               l_hold_date_format || '''';
         end if;
         return -1;
   end;
end Display_SQL;

-- Function Name: Run_SQL
--
-- Usage:
--      a_number := Run_SQL('Heading', 'SQL statement');
--      a_number := Run_SQL('Heading', 'SQL statement', 'Feedback');
--      a_number := Run_SQL('Heading', 'SQL statement', 'Max Rows');
--      a_number := Run_SQL('Heading', 'SQL statement', 'Feedback', 'Max Rows');
--      a_number := Run_SQL('Heading', 'SQL statement', 'Feedback', 'Max Rows',
--                          'Indent Level');
--
-- Parameters:
--      Heading - Text String to for heading the output
--      SQL Statement - Any valid SQL Select Statement
--      Feedback - Y or N to indicate whether to automatically print the 
--                 number of rows returned (default 'Y')
--      Max Rows - Limit the output to this many rows.  NULL or ZERO values
--                 indicate unlimited rows (default NULL)
--      Indent Level - Indicate if table should be indented and by how much
--                     0=No indentation, 1=.25in, 2=.5in, 3=.75in (default 0)
--
-- Returns:
--      The function returns the # of rows selected.
--      If there is an error then the function returns -1.
--
-- Output:
--      Displays the output of the SQL statement as an HTML table.
--
-- Examples:
--      declare
--         num_rows number;
--      begin
--         num_rows := Run_SQL('AR Parameters',
--                             'select * from ar_system_parameters_all');
--      end;
--
function Run_SQL(p_title varchar2, p_sql_statement varchar2) return number is
begin
   return(Display_SQL(p_sql_statement , p_title ,'Y','Y',null));
end Run_SQL;

function Run_SQL(p_title varchar2
               , p_sql_statement varchar2
               , p_feedback varchar2) return number is
begin
   return(Display_SQL(p_sql_statement , p_title ,'Y',p_feedback,null,0));
end Run_SQL;

function Run_SQL(p_title varchar2
               , p_sql_statement varchar2
               , p_max_rows number) return number is
begin
   return(Display_SQL(p_sql_statement , p_title ,'Y','Y',p_max_rows,0));
end Run_SQL;

function Run_SQL(p_title varchar2
               , p_sql_statement varchar2
               , p_feedback varchar2
               , p_max_rows number) return number is
begin
   return(Display_SQL(p_sql_statement , p_title ,'Y',p_feedback,p_max_rows,0));
end Run_SQL;

function Run_SQL(p_title         varchar2
               , p_sql_statement varchar2
               , p_feedback      varchar2
               , p_max_rows      number
               , p_ind_level     number) return number is
begin
   return(Display_SQL(p_sql_statement , p_title ,'Y',p_feedback,p_max_rows,
                      p_ind_level));
end Run_SQL;

-- Procedure Name: Run_SQL
--
-- Usage:
--      Run_SQL('Heading', 'SQL statement');
--      Run_SQL('Heading', 'SQL statement', 'Feedback');
--      Run_SQL('Heading', 'SQL statement', 'Max Rows');
--      Run_SQL('Heading', 'SQL statement', 'Feedback', 'Max Rows');
--      Run_SQL('Heading', 'SQL statement', 'Feedback', 'Max Rows',
--              'Indent Level');
--
-- Parameters:
--     Heading - Text String to for heading the output
--     SQL Statement - Any valid SQL Select Statement
--     Feedback - Y or N to indicate whether to automatically print the
--                number of rows returned (default 'Y')
--     Max Rows - Limit the output to this many rows.  NULL or ZERO values
--                indicate unlimited rows (default NULL)
--     Indent Level - Indicate if table should be indented and by how much
--                    0=No indentation, 1=.25in, 2=.5in, 3=.75in (default 0)
--
-- Output:
--      Displays the output of the SQL statement as an HTML table.
--
-- Examples:
--      begin
--         Run_SQL('AR Parameters', 'select * from ar_system_parameters_all');
--      end;
--
procedure Run_SQL(p_title varchar2, p_sql_statement varchar2) is
   dummy   number;
begin
   dummy := Display_SQL (p_sql_statement , p_title , 'Y','Y',null,0);
end Run_SQL;

procedure Run_SQL(p_title varchar2
                , p_sql_statement varchar2
                , p_feedback varchar2) is
   dummy   number;
begin
   dummy := Display_SQL (p_sql_statement , p_title , 'Y', p_feedback, null,0);
end Run_SQL;

procedure Run_SQL(p_title varchar2
                , p_sql_statement varchar2
                , p_max_rows number) is
   dummy   number;
begin
   dummy := Display_SQL (p_sql_statement , p_title , 'Y', 'Y', p_max_rows,0);
end Run_SQL;

procedure Run_SQL(p_title varchar2
                , p_sql_statement varchar2
                , p_feedback varchar2
                , p_max_rows number) is
   dummy   number;
begin
   dummy := Display_SQL (p_sql_statement , p_title , 'Y',
      p_feedback, p_max_rows,0);
end Run_SQL;

procedure Run_SQL(p_title varchar2
                , p_sql_statement varchar2
                , p_feedback varchar2
                , p_max_rows number
                , p_ind_level number) is
   dummy   number;
begin
   dummy := Display_SQL (p_sql_statement , p_title , 'Y',
      p_feedback, p_max_rows, p_ind_level);
end Run_SQL;


-- Procedure Name: Display_Table
--
-- Usage:
--      Display_Table('Table Name', 'Heading', 'Where Clause', 'Order By', 'Long Flag');
--
-- Parameters:
--      Table Name - Any Valid Table or View
--      Heading - Text String to for heading the output
--      Where Clause - Where clause to apply to the table dump
--      Order By - Order By clause to apply to the table dump
--      Long Flag - 'Y' or 'N'  - If set to 'N' then this will not output any LONG columns
--
-- Output:
--      Displays the output of the 'select * from table' as an HTML table.
--
-- Examples:
--      begin
--         Display_Table('AR_SYSTEM_PARAMETERS_ALL', 'AR Parameters', 'Where Org_id != -3113'
--                         , 'order by org_id, set_of_books_id', 'N');
--      end;
--
procedure Display_Table (p_table_name   varchar2,
          p_table_alias   varchar2,
          p_where_clause   varchar2,
          p_order_by_clause varchar2 default null,
          p_display_longs   varchar2 default 'Y') is
   dummy      number;
   hold_char   varchar(1) := null;
begin
   if p_where_clause is not null then
      hold_char := chr(10);
   end if;
   dummy := Display_SQL ('select * from ' ||
      replace(upper(p_table_name),'V_$','V$') || chr(10) || p_where_clause ||
      hold_char || nvl(p_order_by_clause,'order by 1')
      , nvl(p_table_alias, p_table_name)
      , p_display_longs);
end Display_Table;

-- Function Name: Display_Table
--
-- Usage:
--      a_number := Display_Table('Table Name', 'Heading', 'Where Clause', 'Order By', 'Long Flag');
--
-- Parameters:
--      Table Name - Any Valid Table or View
--      Heading - Text String to for heading the output
--      Where Clause - Where clause to apply to the table dump
--      Order By - Order By clause to apply to the table dump
--      Long Flag - 'Y' or 'N'  - If set to 'N' then this will not output any LONG columns
--
-- Output:
--      Displays the output of the 'select * from table' as an HTML table.
--
-- Returns:
--      Number of rows displayed.
--
-- Examples:
--      declare
--         num_rows   number;
--      begin
--         num_rows := Display_Table('AR_SYSTEM_PARAMETERS_ALL', 'AR Parameters', 'Where Org_id != -3113'
--                                     , 'order by org_id, set_of_books_id', 'N');
--      end;
--
function Display_Table (p_table_name   varchar2,
          p_table_alias   varchar2,
          p_where_clause   varchar2,
          p_order_by_clause varchar2 default null,
          p_display_longs   varchar2 default 'Y') return number is
begin
   return(Display_SQL ('select * from ' ||
      replace(upper(p_table_name),'V_$','V$') || chr(10) || p_where_clause ||
      chr(10) || nvl(p_order_by_clause,'order by 1')
      , nvl(p_table_alias, p_table_name)
      , p_display_longs));
end Display_Table;

-- Function Name: Get_DB_Apps_Version
--
-- Usage:
--      a_varchar := Get_DB_Apps_Version;
--
-- Returns:
--      The version of applications from fnd_product_groups
--      Also sets the variable g_appl_version to '10.7','11.0', or '11.5'
--      as appropriate.
--
-- Examples:
--      declare
--         apps_ver   varchar2(20);
--      begin
--         apps_ver := Get_DB_Apps_Version;
--      end;
--
function Get_DB_Apps_Version return varchar2 is
   l_appsver   fnd_product_groups.release_name%type := null;
begin
   select release_name into l_appsver from fnd_product_groups;
        g_appl_version := substr(l_appsver,1,4);
   return(l_appsver);
end;

-- Procedure Name: Init_Block
--
-- Usage:
--      Init_Block;
--
-- Parameters:
--      None
--
-- Output:
--      No output.  Simple initializes the output CLOB for use in 
--      multi-block scripts. 
--
-- Examples:
--      begin
--        Init_Block; 
--      end;
--
procedure Init_Block is
   l_instance_name   varchar2(16) := null;
   l_host_name   varchar2(64) := null;
   l_version   varchar2(17) := null;
begin
   DBMS_LOB.CREATETEMPORARY(:g_hold_output,TRUE,DBMS_LOB.SESSION);
   line_out('-->');
   Insert_Style_Sheet;
   line_out('</head><body>');
end Init_Block;

-- Procedure Name: End_Block
--
-- Usage:
--      End_Block;
--
-- Output:
--      No output. Adds the closing body and html tags to end a pl/sql
--      block without calling Show_Footer (for use in multi-block scripts).
--
-- Examples:
--      begin
--         End_Block;
--      end;
--
procedure End_Block is
begin
   line_out('</body></html>');
end End_Block;

-- Procedure Name: Show_Header
--
-- Usage:
--      Show_Header('Note Number', 'Title');
--
-- Parameters:
--      Note Number - Any Valid Metalink Note Number
--      Title - Text string to go beside the note link
--
-- Output:
--      Displays Standard Header Information
--
-- Examples:
--      begin
--         Show_Header('139684.1', 'Oracle Applications Current Patchsets Comparison to applptch.txt');
--      end;
--
procedure Show_Header(p_note varchar2, p_title varchar2) is
   l_instance_name   varchar2(16) := null;
   l_host_name   varchar2(64) := null;
   l_version   varchar2(17) := null;
begin
   DBMS_LOB.CREATETEMPORARY(:g_hold_output,TRUE,DBMS_LOB.SESSION);
   select instance_name
        , host_name
        , version
   into l_instance_name
      , l_host_name
      , l_version
   from v$instance;
        line_out('-->');
   Insert_Style_Sheet;
   line_out('</head><body>');
    line_out('<table cellspacing=0 summary="Header Table to start off Script"><tr>');
    line_out('<th class=rowh align=LEFT id="note" nowrap>Note</th>');
    line_out('<td align=left headers="note" nowrap><a href=http://metalink.oracle.com/metalink/plsql/ml2_documents.showDocument?p_database_id=NOT&p_id=' || p_note || ' target=new>' || p_note || '</a><a href=http://metalink.oracle.com/metalink/plsql/ml2_documents.showDocument?p_database_id=NOT&p_id=' || p_note || 'target=new></a>' || p_title || '</td>');
   line_out('</tr><tr>');
   line_out('<th class=rowh align=left id="machine" nowrap>Machine</th>');
   line_out('<td align=left headers="machine" nowrap>' || l_host_name || '</td>');
   line_out('</tr><tr>');
   line_out('<th class=rowh align=left id="date" nowrap>Date Run</th>');
   line_out('<td align=left headers="date" nowrap>' || to_char(sysdate,'DD-MON-YYYY HH24:MI') || '</td>');
   line_out('</tr><tr>');
   line_out('<th class=rowh align=left id="info" nowrap>Oracle Info</th>');
   line_out('<td align=left headers="info" nowrap>SID: ' || l_instance_name || ' Version: ' || l_version || '</td>');
   line_out('</tr><tr>');
   line_out('<th class=rowh align=left id="appver" nowrap>Apps Version</th>');
   line_out('<td align=left headers="appver" nowrap>' || Get_DB_Apps_Version || '</td>');
   line_out('</tr></table><br>' );
end Show_Header;

-- Procedure Name: Show_Footer
--
-- Usage:
--      Show_Footer('Script Name','Header');
--
-- Output:
--      Displays Standard Footer
--
-- Examples:
--      begin
--         Show_Footer('AR Setup Script',
--            '$Header: ARTrxInfo.sql 1.0 01/12/11 12:33:24 support $');
--      end;
--
procedure Show_Footer(p_script_name varchar2, p_header varchar2) is
begin
   Tab0Print('<br><br>Please provide <a href="'||
      'mailto:support-diagnostics_ww@oracle.com?Subject=Standalone '||
      'Diagnostic feedback for ' || p_script_name || '&AMPER.BODY=' ||
      p_script_name || ' - ' || p_header || '">feedback</a> regarding '||
      'the usefulness of this test and/or tool.');
   Tab0Print('We appreciate your feedback, however, there will be no '||
      'replies to feedback emails.');
   Tab0Print('For support issues, please log an iTar (Service Request).');
   line_out('</body></html>');
end Show_Footer;

-- Procedure Name: Show_Link
--
-- Usage:
--      Show_Link('Note #');
--
-- Output:
--      Displays A link to a Metalink Note
--
-- Examples:
--      begin
--         Show_Link('139684.1');
--      end;
--
procedure Show_Link(p_note varchar2) is
begin
   line_out('Click to see Note: <a href=http://metalink.oracle.com/metalink/plsql/ml2_documents.showDocument?p_database_id=NOT&p_id='  || p_note || '>' || p_note || '</a>');
end Show_Link;

-- Procedure Name: Show_Link
--
-- Usage:
--   Show_Link('URL', 'Name');
--
-- Output:
--      Displays A link to a URL using the Name Parameter
--
-- Examples:
--      begin
--         Show_Link('http://metalink.us.oracle.com', 'Metalink');
--      end;
--
procedure Show_Link(p_link varchar2, p_link_name varchar2 ) is
begin
   line_out('<a href='  || p_link || '>' || p_link_name || '</a>');
end Show_Link;


-- Procedure Name: Send_Email
--
-- Usage:
--   Send_Email('Sender', 'Recipient', 'Subject', 'Message', 'SMTP Host');
--
-- Output:
--      Sends E-mail - No screen output.
--
-- Examples:
--      begin
--         Send_Email ('somebody@oracle.com','tosomebody@oracle.com','this is a subject', 'this is a body','gmsmtp01.oraclecorp.com');
--      end;
--
procedure Send_Email ( p_sender varchar2
                     , p_recipient varchar2
                     , p_subject varchar2
                     , p_message varchar2
                     , p_mailhost varchar2) is

   l_mail_conn   utl_smtp.connection;
begin
   l_mail_conn := utl_smtp.open_connection(p_mailhost, 25);
   utl_smtp.helo(l_mail_conn, p_mailhost);
   utl_smtp.mail(l_mail_conn, p_sender);
   utl_smtp.rcpt(l_mail_conn, p_recipient);
   utl_smtp.open_data(l_mail_conn);
   if p_subject is not null then
      utl_smtp.write_data(l_mail_conn, 'Subject: ' || p_subject || utl_tcp.CRLF);
   end if;
   utl_smtp.write_data(l_mail_conn, utl_tcp.CRLF || p_mailhost);
   utl_smtp.close_data(l_mail_conn);
   utl_smtp.quit(l_mail_conn);
exception
   when others then
      utl_smtp.quit(l_mail_conn);
      ErrorPrint('<br>Error in Sending Mail' || sqlerrm);
end Send_Email;

-- Function Name: Get_Package_Version
--
-- Usage:
--   a_varchar := Get_Package_Version ('Object Type', 'Schema', 'Package Name');
--
-- Returns:
--      The version of the package or spec or null if the package does not 
--      exist
--
-- Examples:
--   declare
--         spec_ver   varchar2(20);
--         body_ver   varchar2(20);
--      begin
--         spec_ver := Get_Package_Version('PACKAGE','APPS','ARH_ADDR_PKG');
--         body_ver := Get_Package_Version('PACKAGE BODY','APPS','ARH_ADDR_PKG');
--      end;
--
function Get_Package_Version (p_type varchar2, p_schema varchar2, p_package varchar2) return varchar2 is
   hold_version   varchar2(50);
begin
   select substr(text, instr(text,'$Header')+10, 40)
     into hold_version
     from all_source
    where name = p_package
      and type = p_type
      and owner = p_schema
      and text like '%$Header%'
      and rownum = 1;
   hold_version := substr(hold_version, instr(hold_version,' ')+1, 50);
   hold_version := substr(hold_version, 1, instr(hold_version,' ')-1);
   return (hold_version);
exception
  when no_data_found then
    ErrorPrint(p_type||' '||p_package||' owned by '||p_schema||
      ' does not exist');
    ActionErrorPrint('Verify that this object is valid for your version of '||
      'applications and that the owner indicated is correct');
    return(null);
  when others then
    ErrorPrint(sqlerrm||' occured in Get_Package_Version');
    ActionErrorPrint('Please provide this information to your support '||
      'representative');
    raise;
end Get_Package_Version;

-- Function Name: Get_Package_Spec
--
-- Usage:
--      a_varchar := Get_Package_Spec('Package Name');
--
-- Returns:
--      The version of the package specification in the APPS schema
--
-- Examples:
--      declare
--         spec_ver   varchar2(20);
--      begin
--         spec_ver := Get_Package_Spec('ARH_ADDR_PKG');
--      end;
--
function Get_Package_Spec(p_package varchar2) return varchar2 is
begin
   return Get_Package_Version('PACKAGE','APPS',p_package);
end Get_Package_Spec;

-- Function Name: Get_Package_Body
--
-- Usage:
--      a_varchar := Get_Package_Body('Package Name');
--
-- Returns:
--      The version of the package body in the APPS schema
--
-- Examples:
--      declare
--         body_ver   varchar2(20);
--      begin
--         body_ver := Get_Package_Body('ARH_ADDR_PKG');
--      end;
--
function Get_Package_Body(p_package varchar2) return varchar2 is
begin
   return Get_Package_Version('PACKAGE BODY','APPS',p_package);
end Get_Package_Body;

-- Procedure Name: Display_Profiles
--
-- Usage:
--      Display_Profiles(application id, 'profile short name');
--
-- Output:
--      Displays all Profile settings for the application or profile
--      in an HTML table
--
-- Examples:
--      begin
--         Display_Profiles(222,null);
--         Display_Profiles(null, 'AR_ALLOW_OVERAPPLICATION_IN_LOCKBOX');
--      end;
--
procedure Display_Profiles (p_application_id varchar2
                          , p_short_name     varchar2 default null) is
begin
   Run_SQL('Profile Options',
      'select b.user_profile_option_name "Long<br>Name"'
      || ' , a.profile_option_name "Short<br>Name"'
      || ' , decode(to_char(c.level_id),''10001'',''Site'''
      || '                             ,''10002'',''Application'''
      || '                             ,''10003'',''Responsibility'''
      || '                             ,''10004'',''User'''
      || '                             ,''Unknown'') "Level"'
      || ' , decode(to_char(c.level_id),''10001'',''Site'''
      || '    ,''10002'',nvl(h.application_short_name,to_char(c.level_value))'
      || '    ,''10003'',nvl(g.responsibility_name,to_char(c.level_value))'
      || '    ,''10004'',nvl(e.user_name,to_char(c.level_value))'
      || '    ,''Unknown'') "Level<br>Value"'
      || ' , c.PROFILE_OPTION_VALUE "Profile<br>Value"'
      || ' , c.profile_option_id "Profile<br>ID"'
      || ' , to_char(c.LAST_UPDATE_DATE,''DD-MON-YYYY HH24:MI'') '
      || '      "Updated<br>Date"'
      || ' , nvl(d.user_name,to_char(c.last_updated_by)) "Updated<br>By"'
      || ' from fnd_profile_options a'
      || '   , FND_PROFILE_OPTIONS_VL b'
      || '   , FND_PROFILE_OPTION_VALUES c'
      || '   , FND_USER d'
      || '   , FND_USER e'
      || '   , FND_RESPONSIBILITY_VL g'
      || '   , FND_APPLICATION h'
      || ' where a.application_id = nvl(' || nvl(p_application_id,'null')
      || '          , a.application_id)'
      || '   and a.profile_option_name = nvl(''' || p_short_name 
      || '''        , a.profile_option_name)'
      || '   and a.profile_option_name = b.profile_option_name'
      || '   and a.profile_option_id = c.profile_option_id'
      || '   and a.application_id = c.application_id'
      || '   and c.last_updated_by = d.user_id (+)'
      || '   and c.level_value = e.user_id (+)'
      || '   and c.level_value = g.responsibility_id (+)'
      || '   and c.level_value = h.application_id (+)'
      || ' order by b.user_profile_option_name, c.level_id, '
      || '          decode(to_char(c.level_id),''10001'',''Site'''
      || '    ,''10002'',nvl(h.application_short_name,to_char(c.level_value))'
      || '    ,''10003'',nvl(g.responsibility_name,to_char(c.level_value))'
      || '    ,''10004'',nvl(e.user_name,to_char(c.level_value))'
      || '    ,''Unknown'')');
end;

-- Procedure Name: Get_Profile_Option
--
-- Usage:
--      a_varchar := Get_Profile_Option('Short Name');
--
-- Parameters:
--      Short Name - The Short Name of the Profile Option
--
-- Returns:
--      The value of the profile option based on the user.
--      If Set_Client has not been run successfully then
--      it will return the site level.
--
-- Output:
--      None
--
-- Examples:
--      declare
--         prof_value   varchar2(150);
--      begin
--         prof_value := Get_Profile_Option('AR_ALLOW_OVERAPPLICATION_IN_LOCKBOX')
--      end;
--
function Get_Profile_Option (p_profile_option varchar2) return varchar2 is
begin
   return FND_PROFILE.VALUE(p_profile_option);
end;

-- Procedure Name: Set_Org
--
-- Usage:
--      Set_Org(org_id);
--
-- Parameters:
--      Org_ID - The id of the organization to set.
--
-- Output:
--      None
--
-- Examples:
--      begin
--         Set_Org(204);
--      end;
--
procedure Set_Org (p_org_id number) is
begin
   fnd_client_info.set_org_context(p_org_id);
end Set_Org;

-- Procedure Name: Set_Client
--
-- Description:
--   Validates user_name, responsibility_id, and application_id  parameters
--   If valid it initializes the session (which results in the operating
--   unit being set for the session as well.  Also sets the global variables
--   g_user_id, g_resp_id, g_appl_id, and g_org_id which can then be used
--   throughout the script.
--
-- Usage:
--   Set_Client(UserName, Responsibility_ID);
--   Set_Client(UserName, Responsibility_ID, Application_ID);
--   Set_Client(UserName, Responsibility_ID, Application_ID, SecurityGrp_ID);
--
-- Parameters:
--   UserName - The Name of the Applications User
--   Responsibility_ID - Any Valid Responsibility ID
--   Application_ID - Any Valid Application ID (275=PA) If no value
--                    provided, attempt to obtain from responsibility_id
--   SecurityGrp_ID - A valid security_group_id
--
-- Examples:
--   begin
--      Set_Client('JOEUSER',50719, 222);
--   end;

procedure Set_Client(p_user_name varchar2, p_resp_id number,
                     p_app_id number, p_sec_grp_id number) is
   l_cursor     integer;
   l_num_rows   integer;
   l_user_name  fnd_user.user_name%type;
   l_user_id    number;
   l_app_id     number;
   l_counter    integer;
   l_appl_vers  fnd_product_groups.release_name%type;
   sqltxt       varchar2(2000);
   inv_user exception;
   inv_resp exception;
   inv_app  exception;
   no_app   exception;
begin
  l_user_name := upper(p_user_name);
  begin
    select user_id into l_user_id
    from fnd_user where user_name = l_user_name;
  exception
    when others then
      raise inv_user;
  end;
  l_appl_vers := get_db_apps_version; -- sets g_appl_version
  if g_appl_version = '11.0' or g_appl_version = '10.7' then
    sqltxt := 'select distinct rg.application_id '||
              'from   fnd_user_responsibility rg '||
              'where  rg.responsibility_id = '||to_char(p_resp_id)||' '||
              'and    rg.user_id = '||to_char(l_user_id);
  elsif g_appl_version = '11.5' then
    sqltxt := 'select distinct rg.responsibility_application_id '||
              'from   fnd_user_resp_groups rg '||
              'where  rg.responsibility_id = '||to_char(p_resp_id)||' '||
              'and    rg.user_id = '||to_char(l_user_id);
  end if;
  begin
    l_cursor := dbms_sql.open_cursor;
    dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
    dbms_sql.define_column(l_cursor, 1, l_app_id);
    l_num_rows := dbms_sql.execute_and_fetch(l_cursor, TRUE);
    dbms_sql.column_value(l_cursor, 1, l_app_id);
    dbms_sql.close_cursor(l_cursor);

  exception
    when no_data_found then
      raise inv_resp;
    when too_many_rows then
      if p_app_id is null then
        raise no_app;
      else
        dbms_sql.close_cursor(l_cursor);
        l_cursor := dbms_sql.open_cursor;
        dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
        dbms_sql.define_column(l_cursor, 1, l_app_id);
        l_num_rows := dbms_sql.execute(l_cursor);
        while dbms_sql.fetch_rows(l_cursor) > 0 loop
          dbms_sql.column_value(l_cursor, 1, l_app_id);
          if l_app_id = p_app_id then
            exit;
          end if;
        end loop;
        dbms_sql.close_cursor(l_cursor);
        if l_app_id != p_app_id then
          raise inv_app;
        end if;
      end if;
  end;
  l_cursor := dbms_sql.open_cursor;
  if g_appl_version = '11.5' then
    sqltxt := 'begin '||
                'fnd_global.apps_initialize(:user, :resp, '||
                ':appl, :secg); '||
              'end; ';
    dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
    dbms_sql.bind_variable(l_cursor,':user',l_user_id);
    dbms_sql.bind_variable(l_cursor,':resp',p_resp_id);
    dbms_sql.bind_variable(l_cursor,':appl',l_app_id);
    dbms_sql.bind_variable(l_cursor,':secg',p_sec_grp_id);
  else
    sqltxt := 'begin '||
                'fnd_global.apps_initialize(:user,:resp,:appl); '||
              'end; ';
    dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
    dbms_sql.bind_variable(l_cursor,':user',l_user_id);
    dbms_sql.bind_variable(l_cursor,':resp',p_resp_id);
    dbms_sql.bind_variable(l_cursor,':appl',l_app_id);
  end if;
  l_num_rows := dbms_sql.execute(l_cursor);
  g_user_id := l_user_id;
  g_resp_id := p_resp_id;
  g_appl_id := l_app_id;
  g_org_id := Get_Profile_Option('ORG_ID');
exception
  when inv_user then
    ErrorPrint('Unable to initialize client due to invalid username: '||
      l_user_name);
    ActionErrorPrint('Set_Client has been passed an invalid username '||
      'parameter.  Please correct this parameter if possible, and if not, '||
      'inform your support representative.');
    raise;
  when inv_resp then
    ErrorPrint('Unable to initialize client due to invalid responsibility '||
      'ID: '||to_char(p_resp_id));
    ActionErrorPrint('Set_Client has been passed an invalid responsibility '||
      'ID parameter. This responsibility_id either does not exist or has not '||
      'been assigned to the user ('||l_user_name||'). Please correct these '||
      'parameter values if possible, and if not inform your support '||
      'representative.');
    raise;
  when inv_app then
    ErrorPrint('Unable to initialize client due to invalid application ID: '||
      to_char(p_app_id));
    ActionErrorPrint('Set_Client has been passed an invalid application ID '||
      'parameter. This application either does not exist or is not '||
      'associated with the responsibility id ('||to_char(p_resp_id)||'). '||
      'Please correct this parameter value if possible, and if not inform '||
      'your support representative.');
    raise;
  when no_app then
    ErrorPrint('Set_Client was unable to obtain an application ID to '||
      'initialize client settings');
    ActionErrorPrint('No application_id was supplied and Set_Client was '||
      'unable to determine this from the responsibility because multiple '||
      'responsibilities with the same responsibility_id have been assigned '||
      'to this user ('||l_user_name||').');
    raise;
  when others then
    ErrorPrint(sqlerrm||' occured in Set_Client');
    ActionErrorPrint('Please inform your support representative');
    raise;
end Set_Client;

procedure Set_Client(p_user_name varchar2, p_resp_id number) is
begin
  Set_Client(p_user_name, p_resp_id, null, null);
end Set_Client;

procedure Set_Client(p_user_name varchar2, p_resp_id number,
                     p_app_id number ) is
begin
  Set_Client(p_user_name, p_resp_id, p_app_id, null);
end Set_Client;

-- Procedure Name: Get_DB_Patch_List
--
-- Usage:
--      a_string := Get_DB_Patch_List('heading', 'short name', 'bug number', 'start date');
--
-- Parameters:
--      Heading = Title to go at the top of TABLE or TEXT outputs
--      Short Name = Limits to Bugs that match this expression for the Applications Production Short Name (LIKE)
--      Bug Number = Limits to bugs that match this expression (LIKE)
--      Start Date = Limits to Bugs created after this date
--
-- Output:
--      An HTML table of patches applied for the application since the date
--      indicated is displayed.
--
-- Examples:
--      begin
--         Get_DB_Patch_List(null, 'AD','%', '03-MAR-2002', 'SILENT');
--      end;
--
procedure Get_DB_Patch_List (p_heading varchar2 default 'AD_BUGS'
           , p_app_short_name varchar2 default '%'
           , p_bug_number varchar2 default '%'
           , p_start_date date default to_date('01-JAN-1960','DD-MON-YYYY')
           , p_output_option varchar2 default 'TABLE')  is
   l_cursor      integer;
   l_sqltxt      varchar2(5000);
   l_list_out      varchar2(32767);
   l_hold_comma      varchar2(2);
   l_counter      integer;
   l_app_short_name   varchar2(50);
   l_bug_number      varchar2(30);
   l_creation_date      date;

begin
   select count(*) into l_counter
     from all_tables
    where table_name = 'AD_BUGS';
   if l_counter > 0 then
      l_sqltxt := 'select application_short_name' 
         || '     , bug_number' 
         || '     , creation_date' 
         || ' from ad_bugs'
         || ' where upper(application_short_name) like '''
         ||     upper(p_app_short_name)
         || '''   and creation_date >= '''
         ||     nvl(to_char(p_start_date,'DD-MON-YYYY'),'01-JAN-1960')
         || '''   and bug_number like '''||p_bug_number||'''';
      Run_SQL(p_heading, l_sqltxt);
   else
      WarningPrint('Table AD_BUGS does not exist');
      ActionWarningPrint('Unable to retrieve a patch list from the database as this feature is not available on this version of the applications');
   end if;
end Get_DB_Patch_List;

-- Function Name: Get_RDBMS_Header
--
-- Usage:
--      Get_RDBMS_Header;
--
-- Returns:
--      Version of the Database from v$version
--
-- Examples:
--      declare
--         RDBMS_Ver := v$version.banner%type;
--      begin
--         RDBMS_Ver := Get_RDBMS_Header;
--      end;
--
Function Get_RDBMS_Header return varchar2 is
   l_hold_name   v$database.name%type;
   l_DB_Ver   v$version.banner%type;
begin
   begin
      select name
        into l_hold_name
        from v$database;
   exception
      when others then
         l_hold_name := 'Not Available';
   end;
   begin
      select banner
        into l_DB_Ver
        from v$version
       where banner like 'Oracle%';
   exception
      when others then
         l_DB_Ver := 'Not Available';
   end;
   return(l_hold_name || ' - ' || l_DB_Ver);
end Get_RDBMS_Header;

-- Function Name: Compare_Pkg_Version
--
-- Usage:
--      Compare_Pkg_Version('package_name','obj_type','obj_owner', 'outversvar',
--                          'reference_version');
--      Compare_Pkg_Version('package_name','obj_type', 'outversvar',
--                          'reference_version');
--
-- Parameters:
--       package_name - Name of the package whose version is being checked
--       obj_type - Either BODY or SPEC to determine which piece to check
--       obj_owner - The owner of the package being checked.  If null or
--                   not supplied the default is APPS.
--       outversvar - A text out variable to hold the actual package version
--                    of the package as returned from the database
--       reference_version - A string containing the version to which the
--                           package version should be compared (in
--                           format ###.##, ie, in a format convertible
--                           to a number.  As opposed to, for example,
--                           11.5.119, use 115.119.
--
-- Returns:
--      'greater' if the version of the object is greater than the reference
--      'less'    if the version of the object is less than the reference
--      'equal'   if the version of the object is equal to the reference
--      'null'    if either the reference or db version is null
--
-- Examples:
--      declare
--         Comparison_Var  varchar2(8);
--         Package_Version varchar2(10);
--      begin
--         Comparison_Var := Compare_Pkg_Version('PA_UTILS2','BODY','APPS',
--                                Package_Version, '115.13');
--         Comparison_Var := Compare_Pkg_Version('PA_UTILS2','BODY',
--                                Package_Version, '115.13');
--      end;
--
Function Compare_Pkg_Version(
     package_name   in varchar2,
     object_type in varchar2,
     object_owner in varchar2,
     version_str in out varchar2,
     compare_version in varchar2)
return varchar2 is
  vers_line varchar2(1000);
  l_object_owner varchar2(250);
  db_vers_key_chr varchar2(30);
  db_vers_key number;
  in_vers_key number;
begin
  l_object_owner := object_owner;
  if l_object_owner is null then
    l_object_owner := 'APPS';
  end if;
  in_vers_key :=
    to_number(substr(compare_version,instr(compare_version,'.')+1));
  if upper(object_type) = 'BODY' then
    select text into vers_line
    from   dba_source
    where  name = package_name
    and    owner = l_object_owner
    and    text like '%$Header%'
    and    type = 'PACKAGE BODY';
  else
    select text into vers_line
    from   dba_source
    where  name = package_name
    and    owner = l_object_owner
    and    text like '%$Header%'
    and    type = 'PACKAGE';
  end if;
  vers_line := substr(vers_line,instr(vers_line,'$Header:')+9);
  vers_line := ltrim(vers_line);
  vers_line := substr(vers_line,1,instr(vers_line,' ',1,2)-1);
  vers_line := substr(vers_line,instr(vers_line,' ')+1);
  version_str := vers_line;

  db_vers_key_chr := substr(vers_line,instr(vers_line,'.')+1);
  if instr(db_vers_key_chr,'.',1,1) != 0 then
    db_vers_key_chr :=
      substr(db_vers_key_chr,1,instr(db_vers_key_chr,'.',1,1)-1)||'.'||
      replace(substr(db_vers_key_chr,instr(db_vers_key_chr,'.',1,1)+1),
        '.','');
  end if;
  db_vers_key := to_number(db_vers_key_chr);

  if db_vers_key < in_vers_key then
    return('less');
  elsif db_vers_key > in_vers_key then
    return('greater');
  elsif db_vers_key = in_vers_key then
    return('equal');
  elsif db_vers_key is null or in_vers_key is null then
    return('null');
  end if;
exception when others then
  ErrorPrint('Unable to verify package version for '||package_name||' ('||
    object_type||') -- '||sqlerrm||' occured in Compare_Pkg_Version');
  ActionErrorPrint('Contact your support representative and supply the '||
    'above error information');
  return('null');
end Compare_Pkg_Version;

Function Compare_Pkg_Version(
     package_name   in varchar2,
     object_type in varchar2,
     version_str in out varchar2,
     compare_version in varchar2 default null)
return varchar2 is
begin
  return(compare_pkg_version(
    package_name, object_type, null, version_str,compare_version));
end Compare_Pkg_Version;

-- Procedure Name: Show_Invalids
--
-- Usage:
--      Show_Invalids('start string', 'include errors', 'heading');
--
-- Parameters: 
--      start string - An string indicating the beginning of object names to
--                     be included.  The underscore '_' character will be
--                     escaped in this string so that it does not act as a
--                     wild card character.  For example, 'PA_' will not match
--                     'PAY' even though it normally would in SQL*Plus.
--      include errors - Y or N to indicate whether to search on and report
--                       the errors from  ALL_ERRORS for each of the invalid
--                       objects found. (DEFAULT = N)
--      heading - An optional heading for the table.  If null the heading will 
--                be "Invalid Objects (Starting with 'XXX')" where XXX is 
--                the start string parameter.
--
-- Output:
--      A listing of invalid objects whose name starts with the 'start string'.
--      For packages, procedures, and functions, file versions will be included,
--      and when requested, error messages associated with the object will
--      be reported. 
--
-- Examples:
--      Show_Invalids('PA_','Y');
--      Show_Invalids('GL_');
--
Procedure Show_Invalids (p_start_string   varchar2 
                      ,  p_include_errors varchar2 default 'N'
                      ,  p_heading        varchar2 default null) is
l_start_string   varchar2(60);
l_errors         varchar2(32767);
l_file_version   varchar2(100);
l_heading        varchar2(500);
l_first_row      boolean := true;
l_table_row      V2T;
l_row_options    V2T;

cursor get_invalids(c_start_string varchar2) is
select o.object_name, o.object_type, o.owner
from   all_objects o
where  o.status = 'INVALID'
and    o.object_name like c_start_string escape '~'
order by o.object_name;

cursor get_file_version(
            c_obj_name varchar2
          , c_obj_type varchar2
          , c_obj_owner varchar2) is
select substr(substr(s.text,instr(s.text,'$Header')+9),1,
          instr(substr(s.text,instr(s.text,'$Header')+9),' ',1,2)-1) file_vers
from   all_source s
where  name = c_obj_name
and    type = c_obj_type
and    owner = c_obj_owner
and    text like '%$Header%';

cursor get_errors (
            c_obj_name varchar2
          , c_obj_type varchar2
          , c_obj_owner varchar2) is
select to_char(sequence)||') LINE: '||to_char(line)||' CHR: '||
          to_char(position)||'  '||text error_row
from   all_errors
where  name = c_obj_name
and    type = c_obj_type
and    owner = c_obj_owner;
       
begin
   l_start_string := upper(replace(p_start_string,'_','~_')) || '%';
   if p_heading is null then
      l_heading := 'Invalid Objects (Starting with '''||p_start_string||''')';
   else
      l_heading := p_heading;
   end if;
   line_out('<br><span class="BigPrint">' || l_heading || '</span>');
   for inv_rec in get_invalids(l_start_string) loop
      if l_first_row then
         Start_Table('Invalid Objects');
         if p_include_errors = 'Y' then
            Show_Table_Header(V2T('Object Name','Object Type', 'Owner',
               'File Version', 'Errors'));
         else
            Show_Table_Header(V2T('Object Name', 'Object Type', 'Owner', 
               'File Version'));
         end if;
         l_first_row := false;
      end if;
         
      if inv_rec.object_type like 'PACKAGE%' or
         inv_rec.object_type in ('PROCEDURE','FUNCTION') then
         open get_file_version(inv_rec.object_name, inv_rec.object_type,
            inv_rec.owner);
         fetch get_file_version into l_file_version;
         if get_file_version%notfound then
            l_file_version := null;
         end if;
         close get_file_version;
      else
         l_file_version := null;
      end if;

      if p_include_errors = 'Y' then
         l_errors := null;
         for err_rec in get_errors(inv_rec.object_name, inv_rec.object_type,
             inv_rec.owner) loop
           l_errors := l_errors||err_rec.error_row||'<br>';
         end loop;
         l_table_row := V2T(inv_rec.object_name, inv_rec.object_type, 
            inv_rec.owner, l_file_version, l_errors);
         l_row_options := V2T(null,'nowrap',null,'nowrap','nowrap');
         Show_Table_Row(l_table_row,l_row_options);
      else
         l_table_row := V2T(inv_rec.object_name, inv_rec.object_type, 
            inv_rec.owner, l_file_version);
         Show_Table_Row(l_table_row);
      end if;
   end loop;
   End_Table;
   if l_first_row then
      Insert_HTML('<br><span class="SmallPrint">No Rows Selected</span><br>');
   end if;
exception when others then
  ErrorPrint(sqlerrm||' occured in Show_Invalids');
  ActionErrorPrint('Use the feedback link to report the above error to '||
     'support');
end Show_Invalids;
