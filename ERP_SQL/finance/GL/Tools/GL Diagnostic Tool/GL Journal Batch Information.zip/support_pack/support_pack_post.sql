REM $Header: support_pack_post.sql 115.0 2003/07/24 08:22:02 cmdrake noship $
REM
REM dbdrv: sql ~PROD ~PATH ~FILE none none none sql &phase=daa+52 \
REM
REM +======================================================================+
REM | Copyright (c) 2003 Oracle Corporation Redwood Shores, California, USA|
REM |                       All rights reserved.                           |
REM +======================================================================+
REM NAME
REM   support_pack_post.sql
REM
REM DESCRIPTION
REM
REM NOTES
REM
REM HISTORY
REM   07/24/03  Carey Drake   Added standard header
REM
REM +======================================================================+

SET VERIFY OFF
set SERVEROUT ON
set HEAD off
set FEEDB on
whenever sqlerror exit failure rollback;
whenever oserror exit failure rollback;

declare
  cursor apps is
    select appid from jtf_diagnostic_app 
    where appid not in (select application_short_name from fnd_application)
    and appid <> 'SYSTEM_TESTS';

  cursor groups is
    select appid, groupname from jtf_diagnostic_group 
    where appid not in (select application_short_name from fnd_application)
    and appid <> 'SYSTEM_TESTS';

  cursor tests is
    select appid, groupname, testclassname from jtf_diagnostic_test 
    where appid not in (select application_short_name from fnd_application)
    and appid <> 'SYSTEM_TESTS';
begin
  for apprec in apps
  loop
    delete from jtf_diagnostic_app where appid = apprec.appid;
  end loop;

  for grouprec in groups
  loop
      jtf_diagnostic.delete_group(grouprec.appid, grouprec.groupname);
  end loop;

  for testrec in tests
  loop
      jtf_diagnostic.delete_test(testrec.appid, testrec.groupname, testrec.testclassname);
  end loop;
end;
/
commit;
exit;
