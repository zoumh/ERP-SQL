REM $Header: support_pack_pre.sql 115.0 2003/07/24 08:22:02 jaobrien noship $
REM
REM dbdrv: sql ~PROD ~PATH ~FILE none none none sql &phase=daa+50 \
REM
REM +======================================================================+
REM | Copyright (c) 2003 Oracle Corporation Redwood Shores, California, USA|
REM |                       All rights reserved.                           |
REM +======================================================================+
REM NAME
REM   support_pack_pre.sql
REM
REM DESCRIPTION
REM
REM NOTES
REM
REM HISTORY
REM   07/24/03  Carey Drake   Added standard header
REM   09-JUN-2004  JAOBRIEN   Updated to accomodate new group names.
REM
REM +======================================================================+

SET VERIFY OFF
set SERVEROUT ON
whenever sqlerror exit failure rollback;
whenever oserror exit failure rollback;


declare

  cursor tests is
    select appid, groupname, testclassname
    from jtf_diagnostic_test
    where testclassname like 'oracle.support.diag%'
    or testclassname like 'oracle.support.apps.diag.%';

  cursor groups is
    select g.appid, g.groupname
    from jtf_diagnostic_group g
    where not exists 
      (select t.groupname 
       from jtf_diagnostic_test t
       where t.groupname = g.groupname
       and t.appid = g.appid);
begin

  dbms_output.put_line('Removing test definitions');
  for testrec in tests
  loop
      jtf_diagnostic.delete_test(testrec.appid, testrec.groupname, testrec.testclassname);
  end loop;

  dbms_output.put_line('Removing group definitions');
  for grouprec in groups
  loop
      jtf_diagnostic.delete_group(grouprec.appid, grouprec.groupname);
  end loop;

end;
/
commit;
exit;
