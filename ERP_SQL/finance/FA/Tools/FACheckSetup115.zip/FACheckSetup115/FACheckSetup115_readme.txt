================================================================================
Copyright (c) 2002 Oracle Corporation Redwood Shores, California, USA
Oracle Support Services.  All rights reserved.
================================================================================

================================================================================
Abstract           Oracle Assets - Check Setup Test
================================================================================
PRODUCT:           Oracle Assets (FA)
SUBCOMPONENT:      Implementation
PRODUCT VERSIONS:  11.5.X
PLATFORM:          GENERIC
DATE CREATED:      10-Jul-2002
PARAMETERS:        User Name 
                   Responsibility Id 

================================================================================
Instructions
================================================================================
Included Files:
     CoreApiHtml.sql
     FACheckSetup115.sql
     FACheckSetup115_readme.html
     FACheckSetup115_readme.txt
     FACheckSetup115_Sample_Output.html

Execution Environment:
     SQL*Plus

Access Privileges:
     Requires APPS user access

Usage:
     sqlplus <apps user>/<apps pw> @FACheckSetup115

Instructions:

The files FACheckSetup115.sql and CoreApiHtml.sql should be unzipped
to a common directory. From this directory run the file FACheckSetup115.sql
in SQL*Plus in the APPS schema.

You will be prompted for an applications user name.  
Next you see a list of valid responsibilities for the user entered.
When prompted, enter a responsibility which falls under Oracle Assets.

The test will produce an output file named 
    FACheckSetup115_[responsibility_id]_diag.html.
This file can be viewed in a browser or uploaded for support analysis.


================================================================================
Description
================================================================================

This test collects and verifies the following : 
    
    Driving Profile Options
    Related Product Installation Status
    System Controls
    Details of Key flexfield: Category Flexfield
    Details of Key flexfield: Location Flexfield
    Details of Key flexfield: Asset Key Flexfield
    Accounting Flexfields not having FA Cost Center qualified  
    Fiscal Years
    Asset Calendars
    Prorate Conventions
    Depreciation Methods
    Primary Asset Books 
    Asset Category Setup 
    Asset Books ( posting allowed ) with Periods not defined in GL
    FA Account Generator Workflow 
    Book Controls Setup and Status Information
    Book Controls Period and Calendar Information
    Book Controls Accounting Setup Information
    Book Controls Depreciation Setup Information
    Book Controls Mass Copy Information 
    Reporting Asset Books
    Summary of Reporting Asset Books
    Fixed Asset Profile Options
    Invalid FA Objects
    References
 

================================================================================
References
================================================================================

Note 67049.1 Oracle Assets Product Documentation
Note 131510.1 Self Service Toolkit for Oracle Assets
Note 67050.1 Oracle Assets Technical Bulletins

================================================================================
Disclaimer
================================================================================
Except where expressly provided otherwise, the information, software, provided 
on an "AS IS" and "AS AVAILABLE" basis. Oracle expressly disclaims all 
warranties of any kind, whether express or implied, including, but not limited 
to, the implied warranties of merchantability, fitness for a particular purpose 
and non-infringement.  Oracle makes no warranty that: (A) the results that may 
be obtained from the use of the software will be accurate or reliable; or (B) 
the information, or other material obtained will meet your expectations.  Any 
content, materials, information or software downloaded or otherwise obtained is 
done at your own discretion and risk.  Oracle shall have no responsibility for 
any damage to your computer system or loss of data that results from the 
download of any content, materials, information or software.

Oracle reserves the right to make changes or updates to the software at any time
without notice.

================================================================================
Limitation of Liability
================================================================================
In no event shall Oracle be liable for any direct, indirect, incidental, special
or consequential damages, or damages for loss of profits, revenue, data or use, 
incurred by you or any third party, whether in an action in contract or tort, 
arising from your access to, or use of, the software.

Some jurisdictions do not allow the limitation or exclusion of liability.
Accordingly, some of the above limitations may not apply to you.
