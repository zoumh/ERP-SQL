undefine v_headerinfo
Define   v_headerinfo     = '$Header: FACheckSetup115.sql 1.13 06-NOV-2003 support $'
undefine v_scriptlongname
Define   v_scriptlongname = ' Oracle Assets General Setup Diagnostic Test'


REM   ===================================================================================
REM   Copyright � 2002 Oracle Corporation Redwood Shores, California, USA
REM   Oracle Support Services.  All rights reserved.
REM   ===================================================================================
REM   PURPOSE:                FA - Check Setup Test 
REM   PRODUCT:                Oracle Assets (FA)
REM   PRODUCT VERSIONS:       11.5.4 or higher
REM   PLATFORM:               GENERIC
REM   PARAMETERS              1. Apps username
REM                           2. Responsibility to be chosen from list 
REM   ===================================================================================

REM   ===================================================================================
REM   USAGE:                  sqlplus apps/apps@appsdb 
REM                           @FACheckSetup115 
REM   EXAMPLE:  
REM   OUTPUT:                 FACheckSetup115_[responsibility_id]_diag.html 
REM   =================================================================================== 

REM   ===================================================================================
REM   CHANGE HISTORY:
REM     DATE 21-Aug-2002  kcronk        created 
REM     DATE 10-Feb-2003  kcronk        fixed parameter validation
REM     DATE 24-Feb-2003  kronk         sql*plus version verification
REM     DATE 14-Mar-2003  merickso      Fix MLS application status display
REM                                     changed to fnd_application_vl iso _tl
REM     DATE 06-NOV-2003  igovaert      added db version check 
REM                                     Updated to match latest standards 
REM                                     Fixed ORA-1422 regarding responsibilities 
REM                                     Used API functions to pick up profile options
REM                                     Reorganised Layout 
REM                                     Added Depreciation Method Check 
REM                                     Raise Error/Warning for Optional Profile Options 
REM		                            Valid applications : 140, 7000, 7002, 7003, 7004
REM   ===================================================================================

REM  ================SQL PLUS Environment setup==========================================
set serveroutput on size 1000000 
set verify off 
set echo off
set autoprint off
set termout on 
set feedback off

REM ============== Define SQL Variables for input parameters ============================
VARIABLE    p_username       VARCHAR2(100); 
Undefine    Application_user_name
VARIABLE    v_abort          VARCHAR2(1); 

REM =========================Validate DATABASE Version =========================================
REM ======================NOTE - This section only needed for tests using HTML API's============

DECLARE 
  l_version           VARCHAR2(30);
BEGIN 
  SELECT MAX(version)
  INTO   l_version
  FROM   v$instance;

  IF l_version < '8.1.6.0.0' THEN 
     DBMS_OUTPUT.PUT_LINE(chr(10));
     DBMS_OUTPUT.PUT_LINE('ERROR - Invalid Database Version '||l_version || '. The test requires RDBMS version 8.1.6 or higher');
     DBMS_OUTPUT.PUT_LINE('ACTION - Type Ctrl-C <Enter> to exit the test.');
     DBMS_OUTPUT.PUT_LINE(chr(10));
  END IF;

EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - Database Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM =========================Validate SQL*Plus Version Character Set Combination=================
REM ======================NOTE - This section only needed for tests using HTML API's=============

DECLARE
  l_nls_characterset    nls_database_parameters.value%TYPE;
  l_sql_release_int     INTEGER(20) :=  to_number('&_SQLPLUS_RELEASE');
  l_sql_release_chr     VARCHAR2(50) := '&_SQLPLUS_RELEASE';

BEGIN
  SELECT value 
  INTO  l_nls_characterset
  FROM  nls_database_parameters
  WHERE parameter = 'NLS_CHARACTERSET';
    
  FOR i IN 1..4 LOOP
    l_sql_release_chr := substr(l_sql_release_chr,1,(2*i)-1)||'.'||
      substr(l_sql_release_chr,(2*i)+1);
  END LOOP;
  
  IF l_nls_characterset LIKE 'UTF%' THEN
     IF l_sql_release_int IS null THEN 
        DBMS_OUTPUT.PUT_LINE(chr(10));
        DBMS_OUTPUT.PUT_LINE('ATTENTION - Cannot determine version of SQL*plus being used for test run.');
        DBMS_OUTPUT.PUT_LINE('.           This test may fail if not run using a version 8.1.X of SQL*plus or higher.');
        DBMS_OUTPUT.PUT_LINE('Attempting to run the test.......');
        DBMS_OUTPUT.PUT_LINE(chr(10));
     ELSIF l_sql_release_int < 801000000 THEN
        DBMS_OUTPUT.PUT_LINE(chr(10));
        DBMS_OUTPUT.PUT_LINE('ERROR - Invalid SQL*plus Version '||l_sql_release_chr);
        DBMS_OUTPUT.PUT_LINE('ACTION - On databases using the '||l_nls_characterset||' NLS characterset this test should not be run using this ');
        DBMS_OUTPUT.PUT_LINE('.        SQL*plus Version.  Please rerun this test using version 8.1.X of SQL*plus or higher.');
        DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
        DBMS_OUTPUT.PUT_LINE(chr(10));
     END IF;
  END IF;
EXCEPTION
  when others then 
    DBMS_OUTPUT.PUT_LINE(chr(10));
    DBMS_OUTPUT.PUT_LINE('ERROR - SQL*plus Version check error : '|| sqlerrm);
    DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.');
    DBMS_OUTPUT.PUT_LINE('.        Type Ctrl-C <Enter> to exit the test.');
    DBMS_OUTPUT.PUT_LINE(chr(10));
END;
/

REM ================ Show responsibilities assigned to given user ===================== 
DECLARE   
  l_applversion   fnd_product_groups.release_name%type;
  l_counter       integer;
  l_cursor        integer;
  sqltxt          varchar2(3000);
  l_resp_id       integer;
  l_resp_name     varchar2(300);  
BEGIN
  :v_abort    := 'N';

  select nvl(rtrim(ltrim(upper('&Application_user_name'))), '<Null username>')
  into :p_username
  from dual;

  select substr(release_name,1,4)  
  into   l_applversion 
  from   fnd_product_groups;

  IF l_applversion = '11.5' then
     BEGIN 
       sqltxt := 'select to_char(a.responsibility_id) id, '||
                 '       b.responsibility_name name '||
                 'from   fnd_user_resp_groups a, '||
                 '       fnd_responsibility_vl b, '||
                 '       fnd_user u '||
                 'where  a.user_id = u.user_id '||
                 'and    a.responsibility_id = b.responsibility_id '||
                 'and    a.responsibility_application_id = b.application_id '||
                 'and    sysdate between '|| 
                 '          a.start_date and nvl(a.end_date,sysdate+1) '||
                 'and    upper(u.user_name) = '''||:p_username||''''||
                 'order  by b.responsibility_name';
     

       DBMS_OUTPUT.PUT_LINE(chr(9));
       DBMS_OUTPUT.PUT_LINE('Following are the Responsibilities assigned to User:  '|| :p_username );
       DBMS_OUTPUT.PUT_LINE('=================================================================');

       l_cursor := dbms_sql.open_cursor;
       dbms_sql.parse(l_cursor, sqltxt, dbms_sql.native);
       dbms_sql.define_column(l_cursor, 1, l_resp_id);
       dbms_sql.define_column(l_cursor, 2, l_resp_name,100);
       l_counter := dbms_sql.execute(l_cursor);
       l_counter := 0; 

       WHILE dbms_sql.fetch_rows(l_cursor) > 0 LOOP   
             l_counter := l_counter + 1;
             dbms_sql.column_value(l_cursor, 1, l_resp_id);
             dbms_sql.column_value(l_cursor, 2, l_resp_name);
             DBMS_OUTPUT.PUT_LINE(to_char(l_resp_id)||' ... '||l_resp_name);
       END LOOP; 
       DBMS_OUTPUT.PUT_LINE(chr(9));

       IF l_counter = 0 then
          raise no_data_found;
       END IF;   
       dbms_sql.close_cursor(l_cursor);
  
     EXCEPTION
     when NO_DATA_FOUND then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Could not retrieve any responsibilities for this User');
       DBMS_OUTPUT.PUT_LINE('ACTION - Ensure User is valid and has at least one responsibility assigned.' || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the diagnostic test.  Rerun the test with a valid user name.' || chr(10));
     when OTHERS then
       DBMS_OUTPUT.PUT_LINE('ERROR  - Responsibility error: '|| sqlerrm);
       DBMS_OUTPUT.PUT_LINE('ACTION - Please report the above error to Oracle Support Services.'  || chr(10) ||
                            '         Type Ctrl-C <Enter> to exit the diagnostic test.'  || chr(10) );
     END; 
  ELSE  -- apps version is not 11.5
     DBMS_OUTPUT.PUT_LINE('ERROR  - This diagnostic test is not designed to run against version '|| l_applversion ||' of applications');
     DBMS_OUTPUT.PUT_LINE('ACTION - Please run the test against an 11i instance'  || chr(10) ||
                          '         Type Ctrl-C <Enter> to exit the diagnostic test'  || chr(10) );
  END IF; 

END; 
/
 
REM ===================== Accept Responsibility ====================================

PROMPT 
undefine p_respid
accept   p_respid number PROMPT  'Please choose an Oracle Assets Responsibility ID from the list : '
define   p_respidc = &p_respid    

PROMPT
PROMPT  

REM ===================== Spooling the output file ========================================== 

Define   v_spoolfilename  = 'FACheckSetup115_&p_respidc._diag.html'

PROMPT  =======================================================================
PROMPT  Output will be spooled to &v_spoolfilename
PROMPT  =======================================================================
PROMPT 
PROMPT Running..... 
spool  &v_spoolfilename

set    termout off

REM ============================== Run the Pl/SQL api file ================================== 
@@CoreApiHtml.sql

/*------------------------- Start Of the Main Program ( Part 1 ) -----------------------------*/

BEGIN  -- begin 1
  DECLARE -- declare 2 

/*==================================================================================================
 *
 * START DECLARATIONS 
 * 
 *=================================================================================================*/

    STOPEXECUTION                 EXCEPTION;

    p_username                    varchar2(100);   
    p_respid                      number;
       
    v_respname                    varchar2(100)   := NULL;
    v_appid                       number          := 0;
    v_appname                     varchar2(100)   := NULL;
    v_mrc_flag                    varchar2(1)     := null;
    v_multi_org                   varchar2(1)     := null;
    v_fa_status                   varchar2(50)    := NULL;
    v_patch_level                 varchar2(30)    := NULL;   
    v_orgid                       varchar2(15);
    v_orgname                     varchar2(60)    := null;    

    v_CRL_enabled                 boolean         := false;
    v_security_id                 number          := 0;
    v_cat_delimiter               varchar2(1)     := '-';    
    v_book_list                   varchar2(30000);    

--  system controls
    v_company_name                fa_system_controls.COMPANY_NAME%TYPE := null;
    v_oldest_dpis                 varchar2(20) := null;
    v_initial_asset_id            fa_system_controls.INITIAL_ASSET_ID%TYPE := null;
    v_gl_application_id           fa_system_controls.GL_APPLICATION_ID%TYPE := null;
    v_fa_application_id           fa_system_controls.FA_APPLICATION_ID%TYPE := null;
    v_location_flex_structure     fa_system_controls.LOCATION_FLEX_STRUCTURE%TYPE :=null;
    v_category_flex_structure     fa_system_controls.CATEGORY_FLEX_STRUCTURE%TYPE := null;
    v_asset_key_flex_structure    fa_system_controls.ASSET_KEY_FLEX_STRUCTURE%TYPE := null;
    v_group_flex_structure        fa_system_controls.GROUP_FLEX_STRUCTURE%TYPE := null;
    v_super_group_flex_structure  fa_system_controls.SUPER_GROUP_FLEX_STRUCTURE%TYPE := null;
    v_cua_inheritance_flag        fa_system_controls.CUA_INHERITANCE_FLAG%TYPE := null;

--  key flexfields
    v_loc_kff_dynamic             boolean;
    v_key_kff_dynamic             boolean;
     
--  counters 
    v_calendar_count              number := 0;
    v_convention_count            number := 0;
    v_depreciation_count          number := 0; 
    v_primary_book_count          number := 0;
    v_reporting_book_count        number := 0;

--  work variables 
    l_count                       number :=0;
    l_sqltxt                      varchar2(32767) := null;
    l_security_condition          varchar2(30500) := null;
    l_profile_value               varchar2(255)   := null;


/*-------------------------------- Define function getConcatCategory ------------------------------------
 *
 * Purpose : returns Concatenated segments for Category Id entered 
 * 
 *-------------------------------------------------------------------------------------------------------*/

  FUNCTION getConcatCategory( p_category_id NUMBER,
                              p_cat_delim varchar2 ) return VARCHAR2 IS
    l_seg_len         number         := 0;
    l_segment1        varchar2(30)   := null;
    l_segment2        varchar2(30)   := null;
    l_segment3        varchar2(30)   := null;
    l_segment4        varchar2(30)   := null;
    l_segment5        varchar2(30)   := null;
    l_segment6        varchar2(30)   := null;
    l_segment7        varchar2(30)   := null;
    l_concat_segs     varchar2(2000) := null;
  BEGIN   

    SELECT   ct.segment1,
             ct.segment2,
             ct.segment3,
             ct.segment4,
             ct.segment5,
             ct.segment6,
             ct.segment7
    INTO     l_segment1,
             l_segment2,
             l_segment3,
             l_segment4,
             l_segment5,
             l_segment6,
             l_segment7
    FROM     FA_CATEGORIES ct
    WHERE    ct.category_id = p_category_id;
   
    IF (l_segment1 is NOT NULL) THEN
       l_concat_segs := l_segment1;
       l_seg_len := 1;
    END IF;
    IF (l_segment2 is NOT NULL) THEN
       IF l_seg_len > 0 THEN
         l_concat_segs := l_concat_segs || p_cat_delim || l_segment2;
       ELSE
         l_concat_segs := l_segment2;
         l_seg_len := 1;
       END IF;
    END IF;
    IF (l_segment3 is NOT NULL) THEN
       IF l_seg_len > 0 THEN
         l_concat_segs := l_concat_segs || p_cat_delim || l_segment3;
       ELSE
         l_concat_segs := l_segment3;
         l_seg_len := 1;
       END IF;
    END IF;
    IF (l_segment4 is NOT NULL) THEN
       IF l_seg_len > 0 THEN
         l_concat_segs := l_concat_segs || p_cat_delim || l_segment4;
       ELSE
         l_concat_segs := l_segment4;
         l_seg_len := 1;
       END IF;
    END IF;
    IF (l_segment5 is NOT NULL) THEN
       IF l_seg_len > 0 THEN
         l_concat_segs := l_concat_segs || p_cat_delim || l_segment5;
       ELSE
         l_concat_segs := l_segment5;
         l_seg_len := 1;
       END IF;
    END IF;
    IF (l_segment6 is NOT NULL) THEN
       IF l_seg_len > 0 THEN
         l_concat_segs := l_concat_segs || p_cat_delim || l_segment6;
       ELSE
         l_concat_segs := l_segment6;
         l_seg_len := 1;
       END IF;
    END IF;
    IF (l_segment7 is NOT NULL) THEN
       IF l_seg_len > 0 THEN
         l_concat_segs := l_concat_segs || p_cat_delim || l_segment7;
       ELSE
         l_concat_segs := l_segment7;
         l_seg_len := 1;
       END IF;
    END IF;
    return l_concat_segs;
  EXCEPTION
    WHEN OTHERS THEN 
      BRPrint;
      ErrorPrint(sqlerrm ||' occurred in test when calling "getConcatCategory"');
      ActionErrorPrint('Please report the above error to Oracle Support Services');
      raise STOPEXECUTION;
  END getConcatCategory;

/*-------------------------------- Define function bookVisible --------------------------------------- 
 *
 * Purpose : checks if given book is visible for given security id. Returns true or false  
 *
 *----------------------------------------------------------------------------------------------------*/

  FUNCTION bookVisible( p_book  varchar2,
                        p_security_id number ) return BOOLEAN IS
    l_book_count   number := 0;
  BEGIN
    IF p_security_id = 0 THEN
       RETURN true;
    END IF;
    SELECT   count(*)
    INTO     l_book_count
    FROM     FA_BOOK_CONTROLS 
    WHERE    book_type_code = UPPER(p_book)
    AND    ( org_id IS NULL   OR       org_id IN 
           ( SELECT   organization_id 
             FROM     PER_ORGANIZATION_LIST 
             WHERE    security_profile_id = p_security_id ) );
    IF l_book_count > 0 THEN
       RETURN true;
    ELSE
       RETURN false;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN 
      BRPrint;
      ErrorPrint(sqlerrm ||' occurred in test when calling "bookVisible" ( checking book security )');
      ActionErrorPrint('Please verify the security by book setup');
      BRPrint;
      -- assume book is not visible and continue
      RETURN false;
  END bookVisible;

/* ===================================================================================================
 *
 * END DECLARATIONS 
 * 
 * =================================================================================================*/

/* ----------------------------- Start Main Program ------------------------------------------------*/

  BEGIN --begin2

/* ----------------------------- Set Client ( validate user and responsibility ) -------------------*/

    p_username := :p_username;

    IF &p_respid IS NULL THEN
       p_respid := -10;
    ELSE
       p_respid := &p_respid;
    END IF;

    Show_Header('206580.1', '&v_scriptlongname' );
    Set_Client( p_username, p_respid );

/* ----------------------------- Show Parameters ---------------------------------------------------*/

 -- pick up responsibility name and application id assigned to this responsibility

    BEGIN 
      SELECT b.responsibility_name,
             b.application_id,
             a.application_short_name 
      INTO   v_respname,
             v_appid,
             v_appname 
      FROM   FND_RESPONSIBILiTY_VL b,
             FND_APPLICATION a
      WHERE  b.responsibility_id = p_respid
      AND    b.application_id = a.application_id;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN Null;
    END; 

    SectionPrint('Parameters');
    Tab1Print('Username         = '|| upper(:p_username) ); 
    Tab1Print('Responsibility   = '|| v_respname || ' ( ID = ' || p_respid || ' )');

 -- Abort the test if responsibility is not a Fixed Assets responsibility 

    IF v_appid NOT IN ( 140, 7000, 7002, 7003, 7004 )  THEN 
       ErrorPrint('This diagnostic test checks the Oracle Assets set up. The responsibility entered is wrong as ' ||
                  'it is linked with the application ' || v_appname || ' (' || v_appid || ').');
       ActionErrorPrint('Please run the test for a Oracle Assets related responsibility. The associated ' ||
                        'application must be one of : FA(140), JA(7000), JE(7002), JG(7003), JL(7004)' );
       RAISE StopExecution;
    END IF;   

/* ---------------------------------- Application information -------------------------------------------- */ 
 
    SectionPrint('Application Information');
    
 -- pick up installation status of FA 

    BEGIN 
      SELECT   DECODE(status, 'I','INSTALLED', 
                              'N','NOT INSTALLED', 
                              'L','CUSTOM', 
                              'S','SHARED', status )     status,
               patch_level     
      INTO     v_fa_status,
               v_patch_level  
      FROM     FND_PRODUCT_INSTALLATIONS  
      WHERE    application_id = 140;
    EXCEPTION 
      WHEN OTHERS THEN 
           null;
    END;  

    v_orgid := Get_profile_option('ORG_ID');

 -- pick up orgname 

    IF v_orgid is NOT NULL THEN 
       BEGIN -- Level 4
         SELECT  name 
         INTO    v_orgname 
         FROM    HR_ALL_ORGANIZATION_UNITS
         WHERE   organization_id = v_orgid; 
       EXCEPTION
           WHEN NO_DATA_FOUND then NULL;
       END; -- level 4
    END IF; 

 -- pick up multi currency and multi org flag 

    BEGIN 
      SELECT multi_currency_flag,
             multi_org_flag  
      INTO   v_mrc_flag,
             v_multi_org  
      FROM   fnd_product_groups;
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           Null;
      WHEN TOO_MANY_ROWS THEN
           Errorprint('More than one row ( more than one installation ) was found in FND_PRODUCT_GROUPS');
           ActionErrorPrint('Check the installation of Oracle Applications on this instance. Execution of the test will stop');
           RAISE StopExecution;
    END; 

    Tab1Print('MultiOrg Flag = '|| v_multi_org );
    Tab1Print('MultiCurrency Flag = '|| v_mrc_flag );
    Tab1Print('Application Oracle Assets (ID = 140) has an install status = '||
                 v_fa_status );   
    Tab1Print('FA Patch Level = '|| v_patch_level );
    Tab1Print('MO: Operating Unit = ' || v_orgname || ' (ID = ' || v_orgid || ')' );


/* --------------------------- Determine if CRL is enabled ------------------------------------ */ 

    SectionPrint('Driving Profile Options');

    BEGIN 

      v_CRL_enabled := false; 

      l_profile_value := CheckProfile( 'CRL-FA ENABLED', g_user_id, g_resp_id, g_appl_id, '"N"', 1, 0, 'N' );

      IF l_profile_value = 'Y' THEN 
         v_CRL_enabled := true; 
      END IF;

    EXCEPTION 
       WHEN OTHERS THEN 
            -- in case of errors retrieving CRL 
            -- continue the test with v_CRL_enabled := False as the profile may be irrelevant 
            -- in future mini packs this functionality will become core and profile option will disappear   
            Errorprint( sqlerrm ||' occurred in the section "Determine if CRL is Enabled". The test will ' ||
                       'continue assuming CRL is NOT enabled' );
            ActionErrorPrint( 'Please report the above error to Oracle Support Services');
    END; 

/* -------------------------- Determine Security Profile and List of books -------------------- */ 

    DECLARE 
      CURSOR c_book ( p_security_id NUMBER ) IS
        SELECT   book_type_code book
        FROM     FA_BOOK_CONTROLS 
        WHERE    org_id IS NULL OR org_id IN 
               ( SELECT   organization_id
                 FROM     PER_ORGANIZATION_LIST
                 WHERE    security_profile_id = p_security_id );

    BEGIN

      v_security_id   := 0;
      v_book_list     := Null;

      l_count         := 1; 
      l_profile_value := Null;

      l_profile_value := CheckProfile( 'FA_SECURITY_PROFILE_ID', g_user_id, g_resp_id, g_appl_id, null, 1, 0, 'N' );

   -- set v_security_id if profile option is set 

      IF l_profile_value is NOT NULL AND  
         l_profile_value NOT IN ( 'DOESNOTEXIST', 'DISABLED' ) AND  
         l_profile_value <> '0' THEN 
         v_security_id := TO_NUMBER(l_profile_value);

         NoticePrint( 'Test output and checks will be restricted to the books the user has access to' );

      -- set v_book_list ( list of books user has access to ) 

         FOR crec IN c_book ( v_security_id ) LOOP
             IF (l_count = 1) THEN
                v_book_list := '''' || crec.book || '''';
             ELSE
                v_book_list := v_book_list || ',''' || crec.book || '''';
             END IF;
             l_count := l_count + 1; 
         END LOOP;
  
      END IF;  
     
    EXCEPTION     
      WHEN OTHERS THEN 
           Errorprint( sqlerrm ||' occurred in the section "Determine Security Profile and List of Books". ' ||
                'The test is unable to continue' );
           ActionErrorPrint('Please report the above error to Oracle Support Services');
           raise STOPEXECUTION;
    END; 

/* ------------------------- Application information, Related Products -------------------------- */ 

    l_count := 0;

    DECLARE  
      CURSOR C1 IS
        SELECT   a.application_id ,   
                 substr(a.application_name,1,25)    appsname, 
                 DECODE(p.status,'I','INSTALLED', 
                                 'N','NOT INSTALLED', 
                                 'L','CUSTOM', 
                                 'S','SHARED', status )       status,
                 DECODE(a.application_id, 140, 1, 101,  2, 200, 3, 201, 4, 
                                          401, 5, 800,  6, 275, 7, 8 ) seq
        FROM     FND_APPLICATION_ALL_VIEW a, 
                 FND_PRODUCT_INSTALLATIONS p 
        WHERE    a.application_id = p.application_id
        AND      a.application_id in (140,101,200,201,401,800,275)
        ORDER BY seq ;
    BEGIN 

      SectionPrint('Related Product Installation Status');

      FOR c1_rec IN c1 LOOP 
          Tab1Print( c1_rec.appsname || ' = ' || c1_rec.status );
          l_count := l_count + 1;
      END LOOP;
      IF  l_count < 7 THEN 
          BrPrint;   
          WarningPrint('Related Applications are not all registered in Application Object Library');
          ActionWarningPrint('Confirm that all related applications are properly installed and registered');
      END IF; 

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Related Products Installation Status" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ---------------------------------------- System Controls ------------------------------------------- */ 

    DECLARE 
      l_id_flex_structure_code      fnd_id_flex_structures.id_flex_structure_code%TYPE := null;
    BEGIN

      SectionPrint('System Controls');

      SELECT   company_name,
               to_char(date_placed_in_service, 'DD-MON-YYYY'),
               initial_asset_id,
               gl_application_id,
               fa_application_id,
               location_flex_structure,
               category_flex_structure,
               asset_key_flex_structure,
               nvl(group_flex_structure,-1),
               nvl(super_group_flex_structure,-1),
               cua_inheritance_flag
      INTO     v_company_name,
               v_oldest_dpis,
               v_initial_asset_id,
               v_gl_application_id,
               v_fa_application_id,
               v_location_flex_structure,
               v_category_flex_structure,
               v_asset_key_flex_structure,
               v_group_flex_structure,
               v_super_group_flex_structure,
               v_cua_inheritance_flag
      FROM     FA_SYSTEM_CONTROLS;
  
   -- all fields retrieved from FA_SYSTEM_CONTROLS are NOT NULL fields
   -- except for the group and super group flexfield structures which depend on v_CRL_enabled setting 

      Tab1Print('Company Name = ' || v_company_name);
      Tab1Print('Oldest Date Placed In Service = ' || v_oldest_dpis);
      Tab1Print('Intial Asset Id = ' || v_initial_asset_id);
      Tab1Print('GL Application Id = ' || v_gl_application_id);
      Tab1Print('FA Application Id = ' || v_fa_application_id);

   -- Get Location Flex Structure     
      BEGIN 
        l_id_flex_structure_code := null; 

        SELECT   id_flex_structure_code
        INTO     l_id_flex_structure_code
        FROM     FND_ID_FLEX_STRUCTURES
        WHERE    application_id = v_fa_application_id
        AND      id_flex_code = 'LOC#'
        AND      id_flex_num  = v_asset_key_flex_structure;

        Tab1Print('Location Flex Structure = ' || l_id_flex_structure_code || ' ( Id = ' || v_location_flex_structure || ' )'); 

      EXCEPTION 
        WHEN OTHERS THEN 
             Tab1Print('Location Flex Structure Id = ' || v_location_flex_structure );
             ErrorPrint(sqlerrm || ' occured when validating the Location Flexfield structure in section "System Controls"');
             ActionErrorPrint('Assign a valid Location Flexfield structure in the System Controls' );
      END; 

   -- Get Category Flex Structure  
      BEGIN 
        l_id_flex_structure_code := null;

        SELECT   id_flex_structure_code,
                 concatenated_segment_delimiter
        INTO     l_id_flex_structure_code,
                 v_cat_delimiter
        FROM     FND_ID_FLEX_STRUCTURES
        WHERE    application_id = v_fa_application_id
        AND      id_flex_code = 'CAT#'
        AND      id_flex_num = v_category_flex_structure;

        Tab1Print('Category Flex Structure = ' || l_id_flex_structure_code || ' ( Id = ' || v_category_flex_structure || ' )');

      EXCEPTION 
        WHEN OTHERS THEN 
             Tab1Print('Category Flex Structure Id = ' || v_category_flex_structure );
             ErrorPrint(sqlerrm || ' occured when validating the Category Flexfield structure in section "System Controls"');
             ActionErrorPrint('Assign a valid Category Flexfield structure in the System Controls' );
      END;
 
   -- Get Asset Key Flex Structure
      BEGIN 
        l_id_flex_structure_code := null;

        SELECT   id_flex_structure_code
        INTO     l_id_flex_structure_code
        FROM     FND_ID_FLEX_STRUCTURES
        WHERE    application_id = v_fa_application_id
        AND      id_flex_code = 'KEY#'
        AND      id_flex_num = v_asset_key_flex_structure;

        Tab1Print('Asset Key Flex Structure = '|| l_id_flex_structure_code || ' ( Id = ' || v_asset_key_flex_structure || ' )');
      EXCEPTION 
        WHEN OTHERS THEN 
             Tab1Print('Asset Key Flex Structure Id = '|| v_asset_key_flex_structure);
             ErrorPrint(sqlerrm || ' occured when validating the Asset Key Flexfield structure in the section "System Controls"');
             ActionErrorPrint('Assign a valid Asset Key Flexfield structure in the System Controls' );
      END;

   -- In case CRl is enabled also check Group and Super Group Flex 
      IF v_CRL_enabled THEN

      -- Get Group Flex Structure  
         IF (v_group_flex_structure = -1) THEN
            Tab1Print('Group Flex Structure = null');
            ErrorPrint('The Group Flexfield structure has not been defined in the System Controls for a CRL enabled instance');
            ActionErrorPrint('Complete the System Controls as outlined in the Setup section of the User Manual. ' ||
                             'Assign a Group Flexfield structure in the System Controls');
         ELSE                
            BEGIN 
              l_id_flex_structure_code := null;

              SELECT   id_flex_structure_code
              INTO     l_id_flex_structure_code
              FROM     FND_ID_FLEX_STRUCTURES
              WHERE    application_id = 8731
              AND      id_flex_code = 'GRP#'
              AND      id_flex_num = v_group_flex_structure;

              Tab1Print('Group Flex Structure = '|| l_id_flex_structure_code || ' ( Id = ' || v_group_flex_structure || ' )');
            EXCEPTION 
              WHEN OTHERS THEN 
                   Tab1Print('Group Flex Structure Id = ' || v_group_flex_structure);
                   ErrorPrint(sqlerrm || ' occured when validating the Group Flexfield structure in the section "System Controls"');
                   ActionErrorPrint('Assign a valid Group Flexfield structure in the System Controls' );
           END;
         END IF;  

      -- Get Super Group Flex Structure  
         IF (v_super_group_flex_structure = -1) THEN
            Tab1Print('Super Group Flex Structure = null');
            ErrorPrint('The Super Group Flexfield structure has not been defined in the System Controls for a CRL enabled instance');
            ActionErrorPrint('Complete the System Controls as outlined in the Setup section of the User Manual. '||
                       'Assign a Super Group Flexfield structure in the System Controls');
         ELSE                   
            BEGIN 
              l_id_flex_structure_code := null;

              SELECT   id_flex_structure_code
              INTO     l_id_flex_structure_code
              FROM     FND_ID_FLEX_STRUCTURES
              WHERE    application_id = 8731
              AND      id_flex_code = 'SGP#'
              AND      id_flex_num = v_super_group_flex_structure;

              Tab1Print('Super Group Flex Structure = '|| l_id_flex_structure_code || ' ( Id = ' || v_super_group_flex_structure || ' )');
            EXCEPTION 
              WHEN OTHERS THEN 
                   Tab1Print('Super Group Flex Structure Id = ' || v_super_group_flex_structure);
                   ErrorPrint(sqlerrm || ' occured when validating the Super Group Flexfield structure in the section "System Controls"');
                   ActionErrorPrint('Assign a valid Super Group Flexfield structure in the System Controls' );
           END;
         END IF;
  
      END IF; 
  
    EXCEPTION 
      WHEN NO_DATA_FOUND THEN 
           ErrorPrint('System Controls have not been setup');
           ActionErrorPrint('Define System Controls as described in the Setup section of the User Manual');
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "System Controls" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Asset Category Flexfield Setup ----------------------------------------- */ 

    BEGIN
      IF (v_category_flex_structure = 0) THEN
         checkKeyFlexfield('CAT#');
      ELSE
         checkKeyFlexfield('CAT#',v_category_flex_structure);
      END IF;  
      
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Asset Category Flexfield Setup" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ----------------------- Asset Category Flexfield Segment Qualifiers ---------------------------  
 *
 * Asset Category Flexfield Major Segment Qualifier
 * Asset Category Flexfield Minor Segment Qualifier
 * Check if Asset Category Flexfield segment qualifiers are set
 * This will not be reflected in the output as a separate output section 
 * but errors/warnings will be reported only if not set since the regular checkKeyFlexfield routine 
 * already reports the qualified segment names if they exist
 *
 *------------------------------------------------------------------------------------------------*/

    DECLARE
      l_major_defined             boolean := false;
      l_minor_defined             boolean := false;
      l_major_column_name         fnd_segment_attribute_values.application_column_name%TYPE := null;
      l_minor_column_name         fnd_segment_attribute_values.application_column_name%TYPE := null;
      l_major_segment_name        fnd_id_flex_segments.segment_name%TYPE := null;
      l_minor_segment_name        fnd_id_flex_segments.segment_name%TYPE := null;

      CURSOR c_flex_qualifiers( p_id_flex_code VARCHAR2,
                                p_segment_attribute_type VARCHAR2,
                                p_appid NUMBER) IS
        SELECT   sav.application_column_name,
                 ifs.segment_name
        FROM     FND_SEGMENT_ATTRIBUTE_VALUES sav,
                 FND_ID_FLEX_SEGMENTS ifs
        WHERE    sav.application_id = p_appid
        AND      sav.application_id = ifs.application_id
        AND      sav.id_flex_code = p_id_flex_code
        AND      sav.id_flex_code = ifs.id_flex_code
        AND      sav.id_flex_num  = ifs.id_flex_num
        AND      sav.application_column_name = ifs.application_column_name
        AND      sav.segment_attribute_type = p_segment_attribute_type
        AND      sav.attribute_value = 'Y';
      
      l_flex_qualifiers_rec c_flex_qualifiers%ROWTYPE;

    BEGIN

      OPEN  c_flex_qualifiers('CAT#','BASED_CATEGORY', v_fa_application_id);
      FETCH c_flex_qualifiers INTO l_flex_qualifiers_rec;
      IF (c_flex_qualifiers%NOTFOUND) THEN
         BrPrint;
         ErrorPrint('MAJOR flexfield qualifier has NOT been defined for the Asset Category Key Flexfield');
         ActionErrorPrint('Enable the Asset Category MAJOR Key Flexfield Qualifiers');
      ELSE  
        l_major_defined      := true;
        l_major_column_name  := l_flex_qualifiers_rec.application_column_name;
        l_major_segment_name := l_flex_qualifiers_rec.segment_name;
      END IF;
      CLOSE c_flex_qualifiers;

      OPEN c_flex_qualifiers('CAT#','MINOR_CATEGORY', v_fa_application_id);
      FETCH c_flex_qualifiers INTO l_flex_qualifiers_rec;
      IF (c_flex_qualifiers%NOTFOUND) THEN
         BrPrint;
         WarningPrint('MINOR flexfield qualifier has NOT been defined ' ||
                  'for the Asset Category key flexfield');
         ActionWarningPrint('Enable the Asset Category MINOR Key Flexfield Qualifiers');
      ELSE  
         l_minor_defined := true;
         l_minor_column_name  := l_flex_qualifiers_rec.application_column_name;
         l_minor_segment_name := l_flex_qualifiers_rec.segment_name;
      END IF;
      CLOSE c_flex_qualifiers;
    
      IF (l_minor_defined and l_major_defined) THEN
         IF (l_major_column_name = l_minor_column_name) THEN
            BrPrint;
            ErrorPrint('The MAJOR and MINOR Asset Category Qualifiers use the same Segment "' ||
                  l_major_segment_name || '" App Column:' || l_major_column_name);
            ActionErrorPrint('Select different segments for the MAJOR and MINOR Asset Category Qualifiers');
         END IF;
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Asset Category Flexfield Segment Qualifiers" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Location Flexfield Setup ----------------------------------------- */ 

    DECLARE 
      l_loc_kff_array               V2T;
    BEGIN
      v_loc_kff_dynamic := false;
      IF (v_location_flex_structure = 0) THEN
         CheckKeyFlexfield('LOC#');
      ELSE
         l_loc_kff_array := CheckKeyFlexfield('LOC#',v_location_flex_structure);
         IF (l_loc_kff_array(3) = 'Y') THEN
            v_loc_kff_dynamic := true; 
         ELSE
            v_loc_kff_dynamic := false;
         END IF;  
      END IF;
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Location Flexfield Setup" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------- Location Flexfield State Segment Qualifier ---------------------------
 *
 * Location Flexfield State Segment Qualifier
 * Check if Location Flexfield State Segment qualifier is set 
 * This will not be reflected in the output as a separate output section 
 * but errors/warnings will be reported only if not set since the regular checkKeyFlexfield routine 
 * already reports the qualified segment names if they exist
 *
 *--------------------------------------------------------------------------------------------------*/

    l_count := 0;

    DECLARE
      CURSOR c_flex_qualifiers( p_id_flex_code VARCHAR2,
                                p_segment_attribute_type VARCHAR2,
                                p_appid NUMBER ) IS
        SELECT   sav.application_column_name,
                 ifs.segment_name
        FROM     FND_SEGMENT_ATTRIBUTE_VALUES sav,
                 FND_ID_FLEX_SEGMENTS ifs
        WHERE    sav.application_id = p_appid
        AND      sav.application_id = ifs.application_id
        AND      sav.id_flex_code = p_id_flex_code
        AND      sav.id_flex_code = ifs.id_flex_code
        AND      sav.id_flex_num  = ifs.id_flex_num
        AND      sav.application_column_name = ifs.application_column_name
        AND      sav.segment_attribute_type = p_segment_attribute_type
        AND      sav.attribute_value = 'Y';

      l_flex_qualifiers_rec c_flex_qualifiers%ROWTYPE;

    BEGIN

      OPEN c_flex_qualifiers('LOC#','LOC_STATE',v_fa_application_id);
      FETCH c_flex_qualifiers INTO l_flex_qualifiers_rec;
      IF (c_flex_qualifiers%NOTFOUND) THEN
         BrPrint;
         ErrorPrint('STATE Flexfield qualifier has NOT been defined for the Location Key flexfield');
         ActionErrorPrint('Enable the Location Key Flexfield Qualifier');
      ELSE  
         WHILE (c_flex_qualifiers%FOUND) LOOP
           l_count := l_count + 1;
           FETCH c_flex_qualifiers INTO l_flex_qualifiers_rec;
         END LOOP;

         IF (l_count > 1) THEN
            BrPrint;
            ErrorPrint('Multiple segments have the STATE Location Segment Qualifier enabled');
            ActionErrorPrint('Enable only a single segment as the Location Key Flexfield Qualifier');
         END IF;
      END IF;
      CLOSE c_flex_qualifiers;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Location Flexfield State Segment Qualifier" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* --------------------------- Asset Location flexfield combination(s) ------------------------------ */ 

    l_count := 0;

    BEGIN

      BrPrint;

      SELECT   count(*)
      INTO     l_count
      FROM     FA_LOCATIONS
      WHERE    enabled_flag = 'Y'
      AND      sysdate between nvl(start_date_active,sysdate-1) 
      AND      nvl(end_date_active, sysdate+1);

      IF (l_count = 0) THEN
         IF (v_loc_kff_dynamic) THEN
            WarningPrint('No Asset Locations have been defined, dynamic insertion is enabled');
            ActionWarningPrint('Define any desired asset locations');
         ELSE  
            ErrorPrint('No Asset Locations have been defined and dynamic insertion is disabled');
            ActionErrorPrint('Define at least one Asset Location or enable dynamic insertion for the Location Flexfield');
         END IF;
      ELSE
         Tab1Print( l_count || ' enabled Asset Location(s) have been defined' );
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Asset Location flexfield combination(s)" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Asset Key Flexfield Setup ----------------------------------------- */ 

    DECLARE 
      l_key_kff_array               V2T;
    BEGIN
      v_key_kff_dynamic := false;
      IF (v_asset_key_flex_structure = 0) THEN
         CheckKeyFlexfield('KEY#');
      ELSE
         l_key_kff_array := CheckKeyFlexfield('KEY#',v_asset_key_flex_structure);
         IF (l_key_kff_array(3) = 'Y') THEN
            v_key_kff_dynamic := true; 
         ELSE
            v_key_kff_dynamic := false;
         END IF;  
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section  "Asset Key Flexfield Setup" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ---------------------------------- Asset Key flexfield combinations ------------------------------ */ 

    l_count := 0;

    BEGIN

      BrPrint;

      SELECT   count(*)
      INTO     l_count
      FROM     FA_ASSET_KEYWORDS
      WHERE    enabled_flag = 'Y'
      AND      sysdate between nvl(start_date_active,sysdate-1) 
      AND      nvl(end_date_active, sysdate+1);

      IF (l_count = 0) THEN
         IF (v_key_kff_dynamic) THEN
            WarningPrint('No Asset Keys have been defined, dynamic insertion is enabled');
            ActionWarningPrint('Define any desired Asset Keys');
         ELSE  
            ErrorPrint('No Asset Keys have been defined and dynamic insertion is disabled');
            ActionErrorPrint('Define at least one Asset Key or enable dynamic insertion for the Location flexfield');
         END IF;
      ELSE
         Tab1Print( l_count || ' enabled Asset Key(s) have been defined');
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Asset Key flexfield combinations" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Asset Group Flexfield Setup ------------------------------------- */  

    BEGIN
      IF (v_CRL_enabled) THEN
         CheckKeyFlexfield('GRP#');
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Asset Group Key Flexfield Setup" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Asset Super Group Flexfield Setup ------------------------------- */  

    BEGIN
      IF (v_CRL_enabled) THEN
         CheckKeyFlexfield('SPG#');
      END IF;  
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Asset Super Group Key Flexfield Setup" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ----------------------------------- FA Cost Center Segment Qualifier ----------------------------- */  
  
    BEGIN
      SectionPrint('Accounting Flexfields Not Having FA Cost Center Qualified');

      IF v_security_id > 0 THEN 
         l_security_condition := 'AND      fabc.book_type_code IN ( ' || v_book_list || ' ) ';
      ELSE 
         l_security_condition := ' ';
      END IF;

      l_sqltxt := 'SELECT   fabc.book_type_code              "Book Type Code", '
               || '         glsob.short_name                 "Sob Name", '
               || '         glsob.chart_of_accounts_id       "Chart of Accounts Id" '
               || 'FROM     GL_SETS_OF_BOOKS glsob, '
               || '         FA_BOOK_CONTROLS fabc '
               || 'WHERE    fabc.set_of_books_id = glsob.set_of_books_id '
               || 'AND      fabc.date_ineffective IS NULL ' 
               || l_security_condition 
               || 'AND      NOT EXISTS ' 
               || '       ( SELECT   ''enabled FA_COST_CTR segment'' '
               || '         FROM     FND_SEGMENT_ATTRIBUTE_VALUES fnd '
               || '         WHERE    fnd.id_flex_num = glsob.chart_of_accounts_id '
               || '         AND      fnd.application_id = 101 '
               || '         AND      fnd.id_flex_code   = ''GL#'' '            
               || '         AND      fnd.attribute_value = ''Y'' ' 
               || '         AND      fnd.segment_attribute_type = ''FA_COST_CTR'' )';

      l_count := Run_Sql( null, l_sqltxt, 'N', null, 1 );

      IF l_count = 0 THEN 
         Tab1Print('All associated Accounting Flexfields have the FA Cost Center qualified');
      ELSE 
         ErrorPrint('The FA Cost Center qualifier has not been defined for all associated Accounting Flexfields');
         ActionErrorPrint('Define the Cost Center segment qualifier for the above listed Accounting Flexfields' );
      END IF; 

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "FA Cost Center Segment Qualifier" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Fiscal Years ------------------------------------------------ */  

    l_count := 0;

    DECLARE 
      l_total    NUMBER := 0;

    BEGIN
      SectionPrint('Fiscal Years');

      l_sqltxt := 'SELECT   fiscal_year_name   "Fiscal year",  ' 
               || '         MIN(fiscal_year)   "First Year",   '
               || '         MAX(fiscal_year)   "Last Year",    ' 
               || '         count(*)           "Years Defined" ' 
               || 'FROM     FA_FISCAL_YEAR ' 
               || 'GROUP BY fiscal_year_name';

      l_count := Run_Sql( null, l_sqltxt, 'N', null, 1);

      IF l_count = 0 THEN 
         ErrorPrint('No Fiscal Years have been defined in Oracle Assets');
         ActionErrorPrint('Please define the appropriate Fiscal Years pursuant to the User manual');
      ELSE
         BrPrint;
         Tab1Print( l_count || ' Fiscal Year(s) have been defined' );
  
         BrPrint;
         Tab1Print( 'Fiscal Years Not Meeting Depreciation Requirement');  
         
         IF v_security_id > 0 THEN 
            l_security_condition := 'AND      bc.book_type_code IN ( ' || v_book_list || ' ) ';
         ELSE 
            l_security_condition := ' ';
         END IF;

         l_sqltxt := 'SELECT   fy.fiscal_year_name     "Fiscal Year", '
                  || '         count(*)                "Years Defined" ' 
                  || 'FROM     FA_FISCAL_YEAR fy '
                  || 'WHERE    exists ' 
                  || '       ( SELECT   ''book'' '  
                  || '         FROM     FA_BOOK_CONTROLS bc '
                  || '         WHERE    bc.fiscal_year_name = fy.fiscal_year_name '
                  || l_security_condition
                  || 'AND      bc.date_ineffective is null ) '
                  || 'HAVING   count(*) = 1 '
                  || 'GROUP BY fy.fiscal_year_name';

         l_total := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_total > 0 THEN 
            IF ( l_count = 1 ) THEN 
               ErrorPrint('A minimum of two Fiscal Years must be defined to run depreciation');
               ActionErrorPrint('Define another year for the above Fiscal Year(s)');
            ELSE 
               WarningPrint('A minimum of two Fiscal Years must be defined to run depreciation');
               ActionWArningPrint('Define another year for the above Fiscal Year(s)');
            END IF;
         ELSE
            Tab2Print('A minimum of two Fiscal Years has been defined for all years referenced');   
         END IF;         
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Fiscal Years" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Asset Calendars ---------------------------------------------- */  
    
    BEGIN
      SectionPrint('Asset Calendars');

      l_sqltxt := 'SELECT   ct.calendar_type            "Calendar", '
               || '         SUBSTR(ct.description,1,24) "Description", '
               || '         ct.period_suffix_type       "Suffix|Type", '
               || '         ct.number_per_fiscal_year   "Periods|Per Year", '
               || '         ct.fiscal_year_name         "Fiscal|Year", '
               || '         cp1.period_name             "Start|Period", '
               || '         cp2.period_name             "End|Period" '
               || 'FROM     FA_CALENDAR_TYPES   ct, '
               || '         FA_CALENDAR_PERIODS cp1, '
               || '         FA_CALENDAR_PERIODS cp2 '
               || 'WHERE    cp1.calendar_type = ct.calendar_type '
               || 'AND      cp2.calendar_type = ct.calendar_type '
               || 'AND      cp1.start_date = '
               || '       ( SELECT   MIN(cp3.start_date) '
               || '         FROM     FA_CALENDAR_PERIODS cp3 '
               || '         WHERE    cp3.calendar_type = ct.calendar_type) '
               || 'AND      cp2.start_date = '
               || '       ( SELECT   MAX(cp3.start_date) '
               || '         FROM     FA_CALENDAR_PERIODS cp3 '
               || '         WHERE    cp3.calendar_type = ct.calendar_type )';

      v_calendar_count := Run_Sql( null, l_sqltxt, 'N', null, 1);

      IF v_calendar_count = 0 THEN
         ErrorPrint('No Calendars have been defined in Oracle Assets');
         ActionErrorPrint('Please define the appropriate Calendars pursuant to the User manual');
      ELSE
         BrPrint;
         Tab1Print( v_calendar_count || ' Calendar(s) have been defined');      
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Asset Calendars" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* --------------------------------- Checking Gaps/Overlaps in the Calendars --------------------- */ 

    l_count := 0;

    BEGIN
      IF v_calendar_count > 0 THEN
         BrPrint;
         Tab1Print('Gaps/Overlaps in the Asset Calendars');
 
      -- checking Gaps
         l_sqltxt := 'SELECT   ct.calendar_type       "Calendar", '
                  || '         cp.period_name         "Period|Name", '
                  || '         cp.period_num          "Period|Number", '
                  || '         cp.start_date          "Start|Date", '
                  || '         cp.end_date            "End|Date", '
                  || '         ct.fiscal_year_name    "Fiscal|Year" '
                  || 'FROM     FA_CALENDAR_PERIODS cp, '
                  || '         FA_CALENDAR_TYPES   ct  '
                  || 'WHERE    ct.calendar_type = cp.calendar_type '
                  || 'AND      NOT EXISTS '
                  || '       ( SELECT   cp2.start_date '
                  || '         FROM     FA_CALENDAR_PERIODS cp2 '
                  || '         WHERE    cp2.calendar_type = ct.calendar_type '
                  || '         AND      cp2.start_date    = cp.end_date + 1 ) '
                  || 'AND      cp.end_date <> '
                  || '       ( SELECT   max(cp2.end_date) FROM FA_CALENDAR_PERIODS cp2 '
                  || '         WHERE    cp2.calendar_type = ct.calendar_type )';

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count = 0 THEN
            Tab2Print('No gaps were detected');
         ELSE
            ErrorPrint('Gaps were found in the above listed period(s)');
            ActionErrorPrint('Redefine the FA Calendar to eliminate gaps');
         END IF;
  
      -- Checking Overlaps 
         l_sqltxt := 'SELECT   cp1.calendar_type      "Calendar Type", ' 
                  || '         cp1.period_name        "Period", ' 
                  || '         cp1.period_num         "Period|Number", ' 
                  || '         cp1.start_date         "Start|Date", ' 
                  || '         cp1.end_date           "End|Date", ' 
                  || '         cp2.period_name        "Overlap|Period", ' 
                  || '         cp2.period_num         "Overlap|Period|Number", ' 
                  || '         cp2.start_date         "Overlap|Start|Date", ' 
                  || '         cp2.end_date           "Overlap|End|Date" '  
                  || 'FROM     FA_CALENDAR_PERIODS cp1, ' 
                  || '         FA_CALENDAR_PERIODS cp2 ' 
                  || 'WHERE    cp1.calendar_type = cp2.calendar_type ' 
                  || 'AND      cp1.period_name  <> cp2.period_name ' 
                  || 'AND    ( cp2.start_date between cp1.start_date and cp1.end_date ' 
                  || '      OR cp2.end_date between cp1.start_date and cp1.end_date )';

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count = 0 THEN
            Tab2Print('No overlaps were detected');
         ELSE
            ErrorPrint('Overlaps were found in the above listed period(s)');
            ActionErrorPrint('Redefine the FA Calendar to eliminate overlaps');
         END IF;

      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Gaps/Overlaps in the FA calendars"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------------  Prorate Conventions ------------------------------------ */ 

    BEGIN
      SectionPrint('Prorate Conventions');

      l_sqltxt := 'SELECT   ct.prorate_convention_code     "Prorate|Convention|Code", '
               || '         ct.description                 "Description", '
               || '         ct.fiscal_year_name            "Fiscal|Year", '
               || '         ct.depr_when_acquired_flag     "Depr|From|Dpis", '
               || '         to_char(cn1.start_date, ''DD-MON-YYYY'') "Defined|From", '
               || '         to_char(cn2.end_date,   ''DD-MON-YYYY'') "Defined|To" '
               || 'FROM     FA_CONVENTION_TYPES ct, '
               || '         FA_CONVENTIONS cn1, '
               || '         FA_CONVENTIONS cn2 '
               || 'WHERE    cn1.prorate_convention_code = ct.prorate_convention_code '
               || 'AND      cn2.prorate_convention_code = ct.prorate_convention_code '
               || 'AND      cn1.start_date = '
               || '       ( SELECT   MIN(cn3.start_date) '
               || '         FROM     FA_CONVENTIONS cn3 '
               || '         WHERE    cn3.prorate_convention_code = ct.prorate_convention_code ) '
               || 'AND      cn2.start_date = '
               || '       ( SELECT   MAX(cn3.start_date) FROM FA_CONVENTIONS cn3 '
               || '         WHERE cn3.prorate_convention_code = ct.prorate_convention_code )';

      v_convention_count := Run_Sql( null, l_sqltxt, 'N', null, 1 );

      IF v_convention_count = 0 THEN
         ErrorPrint('No Prorate Conventions have been defined in Oracle Assets');
         ActionErrorPrint('Please define the appropriate Prorate Conventions pursuant to the User manual');
      ELSE
         BrPrint;
         Tab1Print( v_convention_count || ' Prorate Convention(s) have been defined');
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Prorate Conventions" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Gaps/Overlaps in the Prorate Conventions ------------------------------ */ 

    l_count := 0;

    BEGIN
      IF v_convention_count > 0 THEN
         BrPrint;
         Tab1Print('Gaps/Overlaps in FA Prorate Conventions');

         l_sqltxt := 'SELECT   cn.prorate_convention_code                "Prorate|Convention|Code", '
                  || '         to_char(cn.start_date, ''DD-MON-YYYY'')   "Start|Date", '
                  || '         to_char(cn.end_date, ''DD-MON-YYYY'')     "End|Date", '
                  || '         to_char(cn.prorate_date, ''DD-MON-YYYY'') "Prorate|Date" '
                  || 'FROM     FA_CONVENTIONS cn '
                  || 'WHERE    NOT EXISTS '
                  || '       ( SELECT   cn2.start_date '
                  || '         FROM     FA_CONVENTIONS cn2 '
                  || '         WHERE    cn2.prorate_convention_code = cn.prorate_convention_code '
                  || '         AND      cn2.start_date = cn.end_date + 1 ) '
                  || 'AND      cn.end_date <> '
                  || '       ( SELECT   max(cn2.end_date) FROM FA_CONVENTIONS cn2 '
                  || '         WHERE    cn2.prorate_convention_code = cn.prorate_convention_code )';

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count = 0 THEN
            Tab2Print('No gaps were detected');
         ELSE
            ErrorPrint('Gaps were found in the above listed period(s)');
            ActionErrorPrint('Redefine the FA Prorate Conventions to eliminate gaps');
         END IF;

         l_count := 0;

         l_sqltxt := 'SELECT   cn1.prorate_convention_code      "Prorate|Convention|Code", ' 
                  || '         cn1.start_date                   "Start|Date", ' 
                  || '         cn1.end_date                     "End|Date", ' 
                  || '         cn2.start_date                   "Overlap|Start|Date", '  
                  || '         cn2.end_date                     "Overlap|End|Date" '  
                  || 'FROM     FA_CONVENTIONS cn1, ' 
                  || '         FA_CONVENTIONS cn2 ' 
                  || 'WHERE    cn1.prorate_convention_code = cn2.prorate_convention_code ' 
                  || 'AND      cn1.start_date  <> cn2.start_date ' 
                  || 'AND    ( cn2.start_date between cn1.start_date and cn1.end_date '  
                  || '      OR cn2.end_date between cn1.start_date and cn1.end_date )';

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count = 0 THEN
            Tab2Print('No overlaps were detected');
         ELSE
            ErrorPrint('Overlaps were found in the above listed period(s)');
            ActionErrorPrint('Redefine the FA Prorate Conventions to eliminate overlaps');
         END IF;
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Gaps/Overlaps in the FA Prorate Conventions" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Depreciation Methods ------------------------------------ */

    BEGIN
      SectionPrint('Depreciation Methods');

      l_sqltxt := 'SELECT    rate_source_rule                "Rate|Source|Rule", ' 
               || '          ''SEEDED''                      "Seeded/Custom", ' 
               || '          COUNT(*)                        "Method|Count" ' 
               || 'FROM      FA_METHODS ' 
               || 'WHERE     method_id < 1000000 ' 
               || 'GROUP BY  rate_source_rule ' 
               || 'UNION '  
               || 'SELECT    rate_source_rule                "Rate|Source|Rule", '  
               || '          ''CUSTOM''                      "Seeded/Custom", ' 
               || '          COUNT(*)                        "Method|Count" ' 
               || 'FROM      FA_METHODS ' 
               || 'WHERE     method_id >= 1000000 ' 
               || 'GROUP BY  rate_source_rule '    
               || 'ORDER BY  2 DESC,1';

      v_depreciation_count := Run_Sql( null, l_sqltxt, 'N', null, 1 );

      IF v_depreciation_count = 0 THEN
         WarningPrint('Depreciation Methods are not defined');
         ActionWarningPrint('Define any required Depreciation Methods as described in the Oracle Assets User Guide');
      ELSE
         BrPrint;
         Tab1Print( 'Depreciation Methods have been defined');
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Depreciation Methods" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Depreciation Method/Life Combinations ------------------------------ */ 

    l_count := 0;

    BEGIN
      IF v_depreciation_count > 0 THEN
         BrPrint;
         Tab1Print('Depreciation Method/Life Combinations');

         IF v_security_id > 0 THEN 
            l_security_condition := 'AND      cb.book_type_code IN ( ' || v_book_list || ' ) ';
         ELSE 
            l_security_condition := ' ';
         END IF;

         l_sqltxt := 'SELECT    cb.book_type_code     "Book Type Code", ' 
                  || '          cb.category_id        "Category Id", ' 
                  || '          cb.deprn_method       "Deprn Method", ' 
                  || '          cb.life_in_months     "Life In Months" '  
                  || 'FROM      FA_CATEGORY_BOOK_DEFAULTS cb ' 
                  || 'WHERE (   cb.deprn_method NOT IN '  
                  || '        ( SELECT   method_code  FROM FA_METHODS ) '  
                  || 'OR        cb.life_in_months NOT IN ' 
                  || '        ( SELECT   life_in_months FROM FA_METHODS ' 
                  || '          WHERE    method_code = cb.deprn_method )) '  
                  || l_security_condition
                  || 'ORDER BY  cb.book_type_code, cb.category_id';

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count = 0 THEN
            Tab2Print('All Depreciation Method/Life combinations in FA_CATEGORY_BOOK_DEFAULTS are defined');
         ELSE
            WarningPrint('The Depreciation Method/Life combinations above are not defined in FA_CATEGORY_BOOK_DEFAULTS');
            ActionWarningPrint('Verify and define missing Depreciation Method/Life combinations as described in the ' || 
                  'Oracle Assets User Guide');
         END IF;

         l_count := 0;

         IF v_security_id > 0 THEN 
            l_security_condition := 'AND      bk.book_type_code IN ( ' || v_book_list || ' ) ';
         ELSE 
            l_security_condition := ' ';
         END IF;

         l_sqltxt := 'SELECT   ad.asset_number         "Asset|Number", ' 
                  || '         bk.asset_id             "Asset Id", ' 
                  || '         bk.book_type_code       "Book Type Code", ' 
                  || '         bk.deprn_method_code    "Deprn Method Code", ' 
                  || '         bk.life_in_months       "Life In Months" ' 
                  || 'FROM     FA_BOOKS bk, ' 
                  || '         FA_ADDITIONS ad ' 
                  || 'WHERE    bk.date_ineffective IS NULL ' 
                  || 'AND      bk.depreciate_flag = ''YES'' ' 
                  || 'AND      bk.period_counter_fully_reserved IS NULL ' 
                  || 'AND      bk.asset_id = ad.asset_id ' 
                  || 'AND      ad.asset_type = ''CAPITALIZED'' ' 
                  || 'AND  (   bk.deprn_method_code NOT IN ' 
                  || '       ( SELECT   method_code FROM FA_METHODS ) ' 
                  || 'OR       bk.life_in_months NOT IN ' 
                  || '       ( SELECT   life_in_months FROM FA_METHODS ' 
                  || '         WHERE    method_code = bk.deprn_method_code )) '
                  || l_security_condition      
                  || 'ORDER BY ad.asset_number, bk.book_type_code';

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count = 0 THEN
            Tab2Print('All Depreciation Method/Life combinations in FA_BOOKS are defined');
         ELSE
            WarningPrint('The Depreciation Method/Life combinations above are not defined in FA_BOOKS');
            ActionWarningPrint('Verify and define missing Depreciation Method/Life combinations as described in the ' || 
                  'Oracle Assets User Guide');
         END IF;
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Depreciation Method/Life Combinations" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  


/* ------------------------------------- Primary Asset Books ------------------------------------------ */ 

    BEGIN
      SectionPrint('Primary Asset Books');

      IF v_security_id > 0 THEN
         SELECT   count(*)
         INTO     v_primary_book_count
         FROM     FA_BOOK_CONTROLS
         WHERE    date_ineffective IS NULL
         AND    ( org_id IS NULL   OR org_id IN 
                ( SELECT   organization_id 
                  FROM     PER_ORGANIZATION_LIST
                  WHERE    security_profile_id = v_security_id ));
      ELSE
         SELECT   count(*)
         INTO     v_primary_book_count
         FROM     FA_BOOK_CONTROLS
         WHERE    date_ineffective IS NULL;
      END IF;  

      IF v_primary_book_count = 0 THEN
         IF v_security_id > 0 THEN
            ErrorPrint('No enabled Asset Books exist or the user does not have access to the enabled Books');
            ActionErrorPrint('Define at least one Asset Book in the Book Controls');
         ELSE
            ErrorPrint('No enabled Asset Books exist');
            ActionErrorPrint('Define at least one Asset Book in the Book Controls');
         END IF;
      ELSE
         Tab1Print( v_primary_book_count || ' enabled Asset Books have been defined');
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Primary Asset Books"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------------- Primary Book Status --------------------------------------- */ 

    l_count := 0;

    BEGIN

      IF v_primary_book_count > 0 THEN
         BrPrint; 
         Tab1Print('Primary Asset Books in Error');
 
         IF v_security_id > 0 THEN
            l_security_condition := 'AND      book_type_code IN ( ' || v_book_list || ' ) ';
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   book_type_code                  "Book|Type|Code", '
                  || '         distribution_source_book        "Distribution|Source|Book", '
                  || '         set_of_books_id                 "Sob Id", '
                  || '         book_class                      "Book|Class", '
                  || '         last_period_counter             "Last|Period|Counter", '
                  || '         last_deprn_run_date             "Last|Deprn|Run Date", '
                  || '         current_fiscal_year             "Current|Fiscal|Year", '
                  || '         deprn_status                    "Deprn|Status", '
                  || '         mass_request_id                 "Mass|Request|Id" '
                  || 'FROM     FA_BOOK_CONTROLS '
                  || 'WHERE    date_ineffective IS NULL '
                  || 'AND    ( deprn_status <> ''C'' OR  mass_request_id IS NOT NULL ) '
                  || l_security_condition 
                  || 'ORDER BY distribution_source_book, book_class, book_type_code';

         l_count := Run_sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count > 0 THEN
            ErrorPrint('The Book(s) above are in error status or are locked for a mass request');
            ActionErrorLink( 'See Note', '1016592.102', ' on Metalink to verify and correct');
         ELSE
            Tab2Print('There are no Primary Asset Books in error status');
         END IF;  
      END IF; 

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Primary Book Status" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ------------------------------------ Min Period Set Up ---------------------------------------- 
 * Check a minimum of two periods exist in FA_DEPRN_PERIODS for each book
 * Only to be checked for Primary books, reporting (MRC) books not affected
 * -----------------------------------------------------------------------------------------------*/   

    BEGIN
      IF v_primary_book_count > 0 THEN
         BrPrint;
         Tab1Print('Minimum Depreciation Period Setup');

         IF v_security_id > 0 THEN
            l_security_condition := 'AND bc.book_type_code in (' || v_book_list || ' ) ';
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   dp.book_type_code         "Book Type Code", ' 
                  || '         count(*)                  "Periods Found" '  
                  || 'FROM     FA_DEPRN_PERIODS dp, ' 
                  || '         FA_BOOK_CONTROLS bc '  
                  || 'WHERE    dp.book_type_code = bc.book_type_code ' 
                  || 'AND      bc.date_ineffective IS NOT null '  
                  || l_security_condition
                  || 'GROUP BY dp.book_type_code ' 
                  || 'HAVING   count(*) < 2';   

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 ); 

         IF l_count = 0 THEN 
            Tab2Print('All Books have a minimum of 2 prerequisite periods in FA_DEPRN_PERIODS');
         ELSE 
            ErrorPrint('The Book(s) above do not have a minimum of 2 prerequisite periods in FA_DEPRN_PERIODS');
            ActionErrorLink('Please see Note', '139841.1',  ' on Metalink to correct the missing period(s)');
         END IF;
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Minimum Depreciation Period Setup" ');
         ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ---------------------------------Category Setup - Books without categories -----------------------*/ 
 
    l_count := 0;

    BEGIN

      IF v_primary_book_count > 0 THEN
         SectionPrint('Asset Category Setup');
         Tab1Print('Books Not Having Asset Categories Defined');

         IF v_security_id > 0 THEN 
            l_security_condition := 'AND      bc.book_type_code IN ( ' || v_book_list || ' ) ';
         ELSE        
            l_security_condition := ' ';
         END IF;

         l_sqltxt := 'SELECT   bc.book_type_code      "Book Type Code" ' 
                  || 'FROM     FA_BOOK_CONTROLS bc ' 
                  || 'WHERE    bc.date_ineffective IS NULL ' 
                  || 'AND      bc.book_class <> ''BUDGET'' '  
                  || 'AND      NOT EXISTS ' 
                  || '       ( SELECT   ''category exists'' ' 
                  || '         FROM     FA_CATEGORY_BOOKS cb, ' 
                  || '                  FA_CATEGORIES ct ' 
                  || '         WHERE    cb.book_type_code = bc.book_type_code ' 
                  || '         AND      cb.category_id = ct.category_id ' 
                  || '         AND      ct.enabled_flag = ''Y'' )'
                  || l_security_condition; 

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count = 0 THEN 
            Tab2Print('All active Books have at least one enabled category assigned');
         ELSE 
            ErrorPrint('Asset Categories are not defined for the book(s) above');
            ActionErrorPrint('Define any required asset categories for these books.');
         END IF;        
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Category Setup - Books without Asset Categories"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ---------------------------------Category Setup - Books with categories -----------------------*/ 
 
    l_count := 0;

    BEGIN

      IF v_primary_book_count > 0 THEN
         BrPrint; 
         Tab1Print('Books Having Asset Categories Defined');

         IF v_security_id > 0 THEN 
            l_security_condition := 'AND      bc.book_type_code IN ( ' || v_book_list || ' ) ';
         ELSE        
            l_security_condition := ' ';
         END IF;

         l_sqltxt := 'select   bc.book_type_code    "Book Type Code", '
                  || '         count(*)             "Number of|Defined Categories" '
                  || 'FROM     FA_CATEGORY_BOOKS cb, '
                  || '         FA_BOOK_CONTROLS  bc, '
                  || '         FA_CATEGORIES ct '
                  || 'WHERE    bc.book_type_code = cb.book_type_code '
                  || 'AND      bc.date_ineffective IS NULL '
                  || 'AND      cb.category_id = ct.category_id '
                  || 'AND      ct.enabled_flag = ''Y'' '
                  || l_security_condition
                  || 'GROUP BY bc.book_type_code ';

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );
         
         IF l_count = 0 THEN  
            WarningPrint('There are no Books with Asset Categories defined');
            ActionWarningPrint('Define Asset Categories for the Books');
         ELSE 
            BRPrint;
            Tab2Print( l_count || ' Book(s) have Asset Categories defined' );
         END IF;
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Category Setup - Books with Asset Categories"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------- Category Setup between Associated Books ------------------------------- */ 

    DECLARE
      CURSOR c_categories IS
        SELECT   bccor.book_type_code corp,
                 bctax.book_type_code tax,
                 cb.category_id
        FROM     FA_CATEGORY_BOOKS cb,
                 FA_CATEGORIES ct,
                 FA_BOOK_CONTROLS bccor,
                 FA_BOOK_CONTROLS bctax
        WHERE    UPPER(bccor.book_class) = 'CORPORATE'
        AND      bctax.distribution_source_book = bccor.book_type_code
        AND      bctax.allow_mass_copy = 'YES'
        AND      cb.book_type_code = bccor.book_type_code
        AND      ct.category_id = cb.category_id
        AND      bctax.date_ineffective IS NULL
        AND  NOT EXISTS
               ( SELECT   cb1.book_type_code
                 FROM     FA_CATEGORY_BOOKS cb1
                 WHERE    cb1.category_id = cb.category_id
                 AND      cb1.book_type_code = bctax.book_type_code )
        ORDER BY cb.category_id, bctax.book_type_code;

      l_categories_rec c_categories%ROWTYPE;
      l_concat_segs    varchar2(2000) := null;
      l_seg_len        number := 0;
      l_category_id    number := 0; 

    BEGIN
      IF v_primary_book_count > 0 THEN
         BrPrint;
         Tab1Print('Category Setup between Associated Books');
         BrPrint;

         OPEN  c_categories;
         FETCH c_categories INTO l_categories_rec;

         IF (c_categories%FOUND) THEN
             WarningPrint('Categories are defined in the CORPORATE book that are not defined in the associated TAX book(s)');
             ActionWarningPrint('Define missing Asset Categories in the Associated Tax Book if required');
         ELSE
             Tab2Print('All Asset Categories defined in CORP Books are also defined in the associated TAX Books');
         END IF;

         WHILE (c_categories%FOUND) LOOP
           IF (l_categories_rec.category_id <> l_category_id) THEN
              l_concat_segs := getConcatCategory(l_categories_rec.category_id,v_cat_delimiter);
              Tab2Print('Category = "' || l_concat_segs || '" is NOT defined for the following Tax Book(s):');
           END IF;  

           IF v_security_id > 0 THEN
              IF (bookVisible(l_categories_rec.tax, v_security_id)) THEN
                 Tab3Print(l_categories_rec.tax  || '  ( Associated CORPORATE Book = ' || l_categories_rec.corp || ' )');
              END IF;
           ELSE
              Tab3Print(l_categories_rec.tax  || '  ( Associated CORPORATE Book = ' || l_categories_rec.corp || ' )');
           END IF;  

           l_category_id := l_categories_rec.category_id;
           FETCH c_categories INTO l_categories_rec;
         END LOOP;

         CLOSE c_categories;
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Category Setup - consistency between" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Category Setup - CIP accounts ------------------------------------- */                             

    DECLARE
      CURSOR c_CIP_categories IS
        SELECT   bccor.book_type_code corp,
                 bctax.book_type_code tax,
                 cbcor.category_id
        FROM     FA_CATEGORY_BOOKS cbcor,
                 FA_CATEGORY_BOOKS cbtax,
                 FA_BOOK_CONTROLS  bccor,
                 FA_BOOK_CONTROLS  bctax,
                 FA_CATEGORIES     ct
        WHERE    UPPER(bccor.book_class) = 'CORPORATE'
        AND      cbcor.book_type_code = bccor.book_type_code
        AND      bctax.distribution_source_book = bccor.book_type_code
        AND      bctax.date_ineffective IS NULL
        AND      bctax.allow_mass_copy = 'YES'
        AND      cbcor.wip_cost_account_ccid IS NOT NULL
        AND      cbtax.wip_cost_account_ccid IS NULL
        AND      cbtax.book_type_code = bctax.book_type_code
        AND      cbtax.category_id = cbcor.category_id
        AND      ct.category_id = cbcor.category_id
        AND      bctax.allow_cip_assets_flag = 'YES'
        ORDER BY 3,2;

      l_CIP_categories_rec c_CIP_categories%ROWTYPE;
      l_concat_segs        varchar2(2000) := null;
      l_seg_len        number := 0;
      l_category_id    number := 0; 

    BEGIN
      IF v_primary_book_count > 0 THEN
         BrPrint;
         Tab1Print('CIP Accounts for Tax Books Having Immediate Copy Enabled');
         BrPrint;

         OPEN  c_CIP_categories;
         FETCH c_CIP_categories INTO l_CIP_categories_rec;

         IF (c_CIP_categories%FOUND) THEN
            WarningPrint('Tax Book Categories do not have the required CIP accounts specified allthough Immediate ' ||
                         'Copy is enabled');
            ActionWarningPrint('Define CIP accounts for the following : ');
         ELSE
            Tab2Print('All Asset Categories requiring CIP accounts have them specified');
         END IF;

         WHILE (c_CIP_categories%FOUND) LOOP
           IF (l_CIP_categories_rec.category_id <> l_category_id) THEN
              l_concat_segs := getConcatCategory(l_CIP_categories_rec.category_id,v_cat_delimiter);
              Tab2Print('Category = "' || l_concat_segs || '" does not have CIP accounts defined for the following ' ||
                        'Tax Book(s): ');
           END IF;  

           IF v_security_id > 0 THEN
              IF bookVisible(l_CIP_categories_rec.tax,v_security_id) THEN
                 Tab3Print(l_CIP_categories_rec.tax  || ' ( Associated CORPORATE Book = ' || l_CIP_categories_rec.corp || ' )');
              END IF;
           ELSE
              Tab3Print(l_CIP_categories_rec.tax  || ' ( Associated CORPORATE Book = ' || l_CIP_categories_rec.corp || ' )');
           END IF;  

           l_category_id := l_CIP_categories_rec.category_id;
           FETCH c_CIP_categories INTO l_CIP_categories_rec;
         END LOOP;

         CLOSE c_CIP_categories;
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Category Setup - CIP accounts" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ------------------------------------------- FA Period Names ------------------------------------- */ 

    BEGIN
      IF v_primary_book_count > 0 THEN
         SectionPrint('Asset Books ( Posting Allowed ) with Periods Not Defined in GL');

         l_count := 0;
         IF v_security_id > 0 THEN
            l_security_condition := 'AND      fabc.book_type_code in ( ' || v_book_list || ' ) '; 
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   fabc.book_type_code     "Book Type Code", '
                  || '         facp.calendar_type      "Calendar", '
                  || '         count(*)                "Number of Periods|Not In GL" '
                  || 'FROM     FA_BOOK_CONTROLS fabc, '
                  || '         FA_CALENDAR_PERIODS facp, '
                  || '         FA_DEPRN_PERIODS fadp, '
                  || '         GL_SETS_OF_BOOKS glsob, '
                  || '         FA_SYSTEM_CONTROLS sys '
                  || 'WHERE    facp.calendar_type = fabc.deprn_calendar '
                  || 'AND      fabc.set_of_books_id = glsob.set_of_books_id '
                  || 'AND      fadp.book_type_code = fabc.book_type_code '
                  || 'AND      fadp.period_counter = fabc.initial_period_counter '
                  || 'AND      facp.start_date > fadp.calendar_period_open_date '
                  || 'AND      facp.start_date > '
                  || '         nvl( sys.date_placed_in_service, fadp.calendar_period_open_date) '
                  || 'AND      upper(fabc.GL_POSTING_ALLOWED_FLAG) = ''YES'' '
                  || 'AND  NOT EXISTS '
                  || '       ( SELECT  1 FROM GL_PERIODS glp '
                  || '         WHERE   glp.period_set_name = glsob.period_set_name '
                  || '         AND     glp.period_name = facp.period_name ) '
                  || l_security_condition 
                  || 'GROUP BY fabc.book_type_code,facp.calendar_type ' 
                  || 'ORDER BY facp.calendar_type, fabc.book_type_code';

         l_count := Run_Sql( null, l_sqltxt, 'N', null, 1 );

         IF (l_count = 0) THEN
            Tab1Print('All Periods in Oracle Assets Calendars exist in General Ledger');
         ELSE
            WarningPrint('Periods do not exist in General Ledger for the Asset Book/Calendar combination(s) listed above');
            ActionWarningPrint('For Journal entries to be created, insure the periods are defined in GL and the ' ||
                         'period names in FA match the period names in GL');
         END IF;                     
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "FA Period Names" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ----------------------------------- FA Account Generator Workflow ---------------------------------- */ 

    BEGIN
      IF v_primary_book_count > 0 THEN
         SectionPrint('FA Account Generator Workflow');

         -- DEFAULT_ACCOUNT_GENERATION (could still be customized) 
         -- FLEXBUILDER_UPGRADE (10.7 upgraded functionality)

         IF v_security_id > 0 THEN
            l_security_condition := 'AND      bc.book_type_code in ( ' || v_book_list || ' ) '; 
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   bc.book_type_code            "Book Type Code", '
                  || '         wp.wf_process_name           "Workflow Process Name" '
                  || 'FROM     FND_FLEX_WORKFLOW_PROCESSES wp, '
                  || '         FA_BOOK_CONTROLS bc '
                  || 'WHERE    bc.accounting_flex_structure = wp.id_flex_num '
                  || 'AND      wp.wf_item_type = ''FAFLEXWF'' '
                  || 'AND      bc.date_ineffective IS NULL '
                  || l_security_condition
                  || 'ORDER BY bc.book_type_code';

         Run_Sql( null, l_sqltxt, 'Y', null, 1 );
      END IF;                     

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "FA Account Generator Workflow"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Book Controls Setup and Status ------------------------------- */ 

    BEGIN
      IF v_primary_book_count > 0 THEN
         SectionPrint('Book Controls Setup and Status Information');

         IF v_security_id > 0 THEN
            l_security_condition := 'AND      bc.book_type_code in ( ' || v_book_list || ' ) '; 
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   bc.book_type_code                "Book Type Code", '
                  || '         bc.distribution_source_book      "Distribution|Source Book", '
                  || '         bc.book_class                    "Book|Class", '
                  || '         bc.set_of_books_id               "Sob Id", '
                  || '         bc.accounting_flex_structure     "Accounting|Flex Structure", '
                  || '         bc.mc_source_flag                "MC Source|Flag", '
                  || '         dp.period_name                   "Open|Period", '
                  || '         bc.deprn_status                  "Deprn|Status", '
                  || '         bc.mass_request_id               "Mass|Request Id"'
                  || 'FROM     FA_BOOK_CONTROLS bc, '
                  || '         FA_DEPRN_PERIODS dp '
                  || 'WHERE    bc.date_ineffective IS NULL '
                  || 'AND      dp.book_type_code = bc.book_type_code '
                  || 'AND      dp.period_close_date IS NULL '
                  || l_security_condition
                  || ' ORDER BY bc.distribution_source_book, bc.book_class, bc.book_type_code';

         Run_Sql( null, l_sqltxt, 'Y', null, 1 );
      END IF;                     

    EXCEPTION 
       WHEN OTHERS THEN 
            Errorprint(sqlerrm||' occurred in test in section "Book Controls Setup and Status Information" ');
            ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ----------------------- Book Controls Period and Calendar Information ------------------------- */ 

    BEGIN
      IF v_primary_book_count > 0 THEN
         SectionPrint('Book Controls Period and Calendar Information');

         IF v_security_id > 0 THEN
            l_security_condition := 'AND      bc.book_type_code in ( ' || v_book_list || ' ) '; 
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   bc.book_type_code                 "Book Type Code", '
                  || '         dp1.period_name                   "Initial|Period", '
                  || '         dp2.period_name                   "Last|Period", '
                  || '         bc.last_deprn_run_date            "Last|Deprn|Run Date", '
                  || '         bc.current_fiscal_year            "Current|Fiscal|Year", '
                  || '         bc.deprn_calendar                 "Deprn|Calendar", '
                  || '         bc.prorate_calendar               "Prorate|Calendar" '
                  || 'FROM     FA_BOOK_CONTROLS bc, '
                  || '         FA_DEPRN_PERIODS dp1, '
                  || '         FA_DEPRN_PERIODS dp2 '
                  || 'WHERE    bc.date_ineffective IS NULL '
                  || 'AND      dp1.book_type_code(+) = bc.book_type_code '
                  || 'AND      dp2.book_type_code(+) = bc.book_type_code '
                  || 'AND      dp1.period_counter(+) = bc.initial_period_counter '
                  || 'AND      dp2.period_counter(+) = bc.last_period_counter '
                  || l_security_condition
                  || 'ORDER BY bc.distribution_source_book, bc.book_class, bc.book_type_code ';

         Run_Sql( null, l_sqltxt, 'Y', null, 1 );
      END IF;                     

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Book Controls Period and Calendar Information"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ----------------------- Book Controls Accounting SetUp -------------------------------------- */ 

    BEGIN
      IF v_primary_book_count > 0 THEN
         SectionPrint('Book Controls Accounting Setup Information');

         IF v_security_id > 0 THEN
            l_security_condition := 'AND      book_type_code in ( ' || v_book_list || ' ) '; 
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT    book_type_code                     "Book Type Code", '
                  || '          gl_posting_allowed_flag            "GL|Posting|Allowed", '
                  || '          amortize_flag                      "Allow|Amort|Adjustments", '
                  || '          allow_mass_changes                 "Allow|Mass|Changes", '
                  || '          allow_purge_flag                   "Allow|Purge|Flag", '
                  || '          allow_reval_flag                   "Allow|Reval|Flag", '
                  || '          allow_cip_assets_flag              "Allow|Cip|Assets Flag", '
                  || '          itc_allowed_flag                   "Itc|Allowed|Flag", '
                  || '          capital_gain_threshold             "Capital|Gain|Threshold" '
                  || 'FROM      FA_BOOK_CONTROLS '
                  || 'WHERE     date_ineffective IS NULL '
                  || l_security_condition 
                  || 'ORDER BY distribution_source_book, book_class, book_type_code';

         Run_Sql( null, l_sqltxt, 'Y', null, 1 );
      END IF;                     

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Book Controls Accounting Setup"');
           ActionErrorPrint('Please report the above error to Oracle Support Services.');
    END;  

/* ------------------------------ Book Controls Depreciation Setup ----------------------------------- */ 

    BEGIN
      IF v_primary_book_count > 0 THEN
         SectionPrint('Book Controls Depreciation Setup Information');

         IF v_security_id > 0 THEN
            l_security_condition := 'AND      book_type_code in ( ' || v_book_list || ' ) '; 
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   book_type_code              "Book Type Code", '
                  || '         allow_deprn_adjustments     "Allow|Deprn|Adjustments", '
                  || '         allow_cost_ceiling          "Allow|Cost|Ceiling", '
                  || '         allow_deprn_exp_ceiling     "Allow|Deprn Exp|Ceiling", '
                  || '         deprn_allocation_code       "Deprn|Allocation|Code", '
                  || '         depr_first_year_ret_flag    "Depr|First Year|Ret Flag" '
                  || 'FROM     FA_BOOK_CONTROLS '
                  || 'WHERE    date_ineffective IS NULL '
                  || l_security_condition    
                  || 'ORDER BY distribution_source_book, book_class, book_type_code';

         Run_Sql( null, l_sqltxt, 'Y', null, 1 );
      END IF;                     

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Book Controls Depreciation Setup"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ----------------------------- Book Controls Mass Copy Information--------------------------------- */

    BEGIN
      IF v_primary_book_count > 0 THEN
         SectionPrint('Book Controls Mass Copy Information');

         IF v_security_id > 0 THEN
            l_security_condition := 'AND      book_type_code in ( ' || v_book_list || ' ) '; 
         ELSE 
            l_security_condition := ' ';
         END IF; 
         
         l_sqltxt := 'SELECT   book_type_code                     "Book Type Code", '
                  || '         distribution_source_book           "Distribution|Source|Book", '
                  || '         allow_mass_copy                    "Allow|Mass|Copy", '
                  || '         last_mass_copy_period_counter      "Last|Mass|Copy|Period", '
                  || '         immediate_copy_flag                "Immediate|Copy|Flag", '
                  || '         copy_additions_flag                "Copy|Additions|Flag", '
                  || '         copy_adjustments_flag              "Copy|Adjustments|Flag", '
                  || '         copy_retirements_flag              "Copy|Retirements|Flag", '
                  || '         copy_salvage_value_flag            "Copy|Salvage|Value Flag" '
                  || 'FROM     FA_BOOK_CONTROLS '
                  || 'WHERE    date_ineffective IS NULL '
                  || 'AND      book_class = ''TAX'' '
                  || l_security_condition
                  || 'ORDER BY distribution_source_book, book_class, book_type_code';

         Run_Sql( null, l_sqltxt, 'Y', null, 1 );
      END IF;                     

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Book Controls Mass Copy Information"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  
/* ------------------------------------- Reporting Asset Books ------------------------------------------ */ 

    BEGIN
      SectionPrint('Reporting Asset Books');

      IF v_security_id > 0 THEN
         SELECT   count(*) 
         INTO     v_reporting_book_count
         FROM     FA_MC_BOOK_CONTROLS 
         WHERE    enabled_flag = 'Y'
         AND      book_type_code IN  
                ( SELECT   x.book_type_code 
                  FROM     FA_BOOK_CONTROLS x
                  WHERE    x.org_id IS NULL    OR x.org_id IN 
                         ( SELECT   organization_id 
                           FROM     PER_ORGANIZATION_LIST 
                           WHERE    security_profile_id = v_security_id ));
      ELSE
         SELECT   count(*) 
         INTO     v_reporting_book_count
         FROM     FA_MC_BOOK_CONTROLS 
         WHERE    enabled_flag = 'Y';
      END IF;  

      IF v_reporting_book_count = 0 THEN
      -- this condition is not an error
         IF v_security_id > 0 THEN
            Tab1Print('No Reporting Assets Books are defined or the user does not have access to any');
         ELSE
            Tab1Print('No Reporting Assets Books are defined');
         END IF;
      ELSE
         Tab1Print( v_reporting_book_count || ' enabled Reporting Assets Book(s) have been defined');
      END IF;  

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Reporting Asset Books" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------- Reporting Currency Book Status ------------------------------- */ 

    l_count := 0;

    BEGIN
      IF v_reporting_book_count > 0 THEN
         BrPrint;
         Tab1Print('Reporting Asset Books in Error');

         IF v_security_id > 0 THEN
            l_security_condition := 'AND      book_type_code IN ( ' || v_book_list || ' ) ';
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   book_type_code                 "Book Type Code", '
                  || '         currency_code                  "Currency|Code", '
                  || '         primary_currency_code          "Primary|Currency|Code", '
                  || '         set_of_books_id                "Sob Id", '
                  || '         primary_set_of_books_id        "Primary|Sob", '
                  || '         last_period_counter            "Last|Period", '
                  || '         last_deprn_run_date            "Last|Deprn|Run Date", '
                  || '         deprn_status                   "Deprn|Status", '
                  || '         mass_request_id                "Mass|Request|Id" '
                  || 'FROM     FA_MC_BOOK_CONTROLS '
                  || 'WHERE    enabled_flag = ''Y'' '
                  || 'AND    ( deprn_status <> ''C'' OR  mass_request_id IS NOT NULL ) '
                  || l_security_condition
                  || 'ORDER BY book_type_code, set_of_books_id';        
            
         l_count := Run_Sql( null, l_sqltxt, 'N', null, 2 );

         IF l_count > 0 THEN
            ErrorPrint('The Reporting Book(s) above are in error status or are locked for a mass request');
            ActionErrorLink('See Note', '1016592.102', ' on Metalink to verify and correct');
         ELSE
            Tab2Print('No Reporting Books are in error status');
         END IF;  
      END IF;  
    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Reporting Asset Books Status" ');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
  END;  

/* ------------------------------ Summary of Reporting Asset Books ----------------------------------- */ 

    BEGIN

      IF v_reporting_book_count > 0 THEN
         SectionPrint('Summary of Reporting Asset Books');

         IF v_security_id > 0 THEN
            l_security_condition := 'AND      book_type_code in ( ' || v_book_list || ' ) '; 
         ELSE 
            l_security_condition := ' ';
         END IF; 

         l_sqltxt := 'SELECT   book_type_code               "Book Type Code", '
                  || '         currency_code                "Currency|Code", '
                  || '         primary_currency_code        "Primary|Currency|Code", '
                  || '         set_of_books_id              "Sob Id", '
                  || '         primary_set_of_books_id      "Primary|Sob", '
                  || '         mrc_converted_flag           "Mrc|Converted|Flag", '
                  || '         conversion_status            "Conversion|Status", '
                  || '         last_period_counter          "Last|Period|Counter" '
                  || 'FROM     FA_MC_BOOK_CONTROLS '
                  || 'WHERE    enabled_flag = ''Y'' '
                  ||  l_security_condition 
                  || 'ORDER BY book_type_code';

         Run_Sql( null, l_sqltxt, 'Y', null, 1 );
      END IF;                     

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Summary of Reporting Asset Books"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------------- FA Profile Options -------------------------------------------- */

    BEGIN
      SectionPrint('Fixed Asset Profile Options');

      Tab1Print('Performance Related Profile Options'); 
      -- FA: Number of Parallel Requests -- optional, default '1'
      CheckProfile( 'FA_NUM_PARALLEL_REQUESTS', g_user_id, g_resp_id, g_appl_id, '"1"', 2, 0, 'N' );
      -- FA: Number Mass Addition Parallel Requests -- optional, default '2'
      CheckProfile( 'FA_NUM_MASSADD_PAR_REQUESTS', g_user_id, g_resp_id, g_appl_id, '"2"', 2, 0, 'N' );
      -- FA: Number of Generate Accounts Parallel Requests - optional, default '1' 
      CheckProfile( 'FA_NUM_GENACCTS_REQUESTS', g_user_id, g_resp_id, g_appl_id, '"1"', 2, 0, 'N' );
      BrPrint;

      Tab1Print('Mass Additions Profile Options');
      -- FA: Default DPIS to Invoice Date - optional, default 'No'
      CheckProfile( 'FA_DEFAULT_DPIS_TO_INV_DATE', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );
      -- FA: Include Nonrecoverable Tax in Mass Addition - optional, default 'No'
      CheckProfile( 'FA_INCLUDE_NONRECOV_TAX_MASSADDS', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );
      BrPrint;

      Tab1Print('Account Generator Profile Options');
      -- FA: Generate Asset Level Account -- optional, default value 'Yes'
      CheckProfile( 'FA_PREGEN_ASSET_ACCOUNT', g_user_id, g_resp_id, g_appl_id, '"Yes"', 2, 0, 'N' );
      -- FA: Generate Book Level Accounts -- optional, default 'Yes'
      CheckProfile( 'FA_PREGEN_BOOK_ACCOUNT', g_user_id, g_resp_id, g_appl_id, '"Yes"', 2, 0, 'N' );
      -- FA: Generate Category Level Accounts - optional, default 'Yes'
      CheckProfile( 'FA_PREGEN_CAT_ACCOUNT', g_user_id, g_resp_id, g_appl_id, '"Yes"', 2, 0, 'N' );
      -- FA:Generate Depreciation Expense Account - optional, default 'No'
      CheckProfile( 'FA_GEN_EXPENSE_ACCOUNT', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );
      BrPrint;

      Tab1Print('Depreciation Profile Options');
      -- FA: Deprn Single - optional, default 'No'
      CheckProfile( 'FA_DEPRN_SINGLE', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );
      -- FA: Annual Rounding - optional, default 'With Restrictions' 
      CheckProfile( 'FA_ANNUAL_ROUND', g_user_id, g_resp_id, g_appl_id, '"With Restrictions"', 2, 0, 'N' );
      BrPrint;

      Tab1Print('Mass Copy Profile Options');
      -- FA: Mass Copy All Cost Adjustments - optional, default 'No'
      CheckProfile( 'FA_MCP_ALL_COST_ADJ', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );
      BrPrint;

      Tab1Print('Debug Profile Options');
      -- FA: Print Timing Diagnostics - optional, default 'No'
      CheckProfile( 'TIME_DIAGNOSTIC', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );
      -- FA: Print Debug  - optional, default 'No'
      CheckProfile( 'PRINT_DEBUG', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );
      -- FA: Debug Filename - optional, default 'request_id'.log
      CheckProfile( 'FA_DEBUG_FILE', g_user_id, g_resp_id, g_appl_id, '"<request_id>.log"', 2, 0, 'N');
      BrPrint;

      Tab1Print('Application Desktop Integrator (ADI) Fixed Asset Profile Options');
      -- FADI: Create Assets Privileges - optional, default 'None'
      CheckProfile( 'FADI_ASSET_CREATION_PRIVS', g_user_id, g_resp_id, g_appl_id, '"None"', 2, 0, 'N' );
      -- FADI: Physical Inventory Privileges - optional, default 'None'
      CheckProfile( 'FADI_ASSET_PI_PRIVS', g_user_id, g_resp_id, g_appl_id, '"None"', 2, 0, 'N' );
      BrPrint;

      Tab1Print('Other FA Profile Options');
      -- FA: Archive Table Sizing Factor - optional, default 100Kb
      CheckProfile( 'FA_ARCHIVE_TABLE_SIZE', g_user_id, g_resp_id, g_appl_id, '"100Kb"', 2, 0, 'N' );
      -- FA: Cache Sizing Factor - optional, default 25
      CheckProfile( 'FA_CACHE_USAGE', g_user_id, g_resp_id, g_appl_id, '"25"', 2, 0, 'N' );
      -- FA: Use Threshold  - optional, default 'Yes'
      CheckProfile( 'FA_USE_THRESHOLD', g_user_id, g_resp_id, g_appl_id, '"Yes"', 2, 0, 'N' );
      -- FA: Allow Swiss special assets  - optional, default 'No'
      CheckProfile( 'FA_INS_SWISS_BUILDING', g_user_id, g_resp_id, g_appl_id, '"No"', 2, 0, 'N' );

      -- FA: Large Rollback Segment Name - optional, if not specified the system will choose 
      CheckProfile('FA_LARGE_ROLLBACK_SEGMENT', g_user_id, g_resp_id, g_appl_id, '"system will choose"', 2, 0, 'N' );
      Tab3Print('Only specify a Large Rollback segment if an unusually large segment was created for this purpose.' );
      Tab3Print('Otherwise the profile should be left NULL so the system can choose the rollback segment' );
      -- FA: Security Profile - Optional, no default value 
      CheckProfile( 'FA_SECURITY_PROFILE_ID', g_user_id, g_resp_id, g_appl_id, '"null - Security id not assigned"', 2, 0, 'N' ); 
      Tab3Print('The security ID is not required, but must be present if the "Security By Book" feature is implemented');

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section "Fixed Asset Profile Options"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* ----------------------------------------  Invalid FA Objects --------------------------------------------- */

    l_count  := 0;

    BEGIN
      SectionPrint('Invalid FA Objects');

      l_sqltxt := 'SELECT   object_name        "Object Name", ' 
               || '         object_type        "Object Type", '
               || '         owner              "Owner", ' 
               || '         status             "Status" '
               || 'FROM     ALL_OBJECTS '
               || 'WHERE    status = ''INVALID'' ' 
               || 'AND      object_name like ''FA/_%'' ESCAPE ''/'' ';

      l_count := Run_Sql( null, l_sqltxt, 'Y', null, 1 );

      IF l_count > 0 THEN
         WarningPrint( 'Invalid FA Object(s) have been found' );
         ActionWarningLink('See Note', '104457.1' , ' : Invalid Objects' );
         ActionWarningLink('See Note', '97839.1' , ' : Invalid Web Views in Oracle Assets' );
      ELSE
         Tab1Print('There are no invalid FA Objects.');
      END IF;

    EXCEPTION 
      WHEN OTHERS THEN 
           Errorprint(sqlerrm||' occurred in test in section  "Invalid FA Objects"');
           ActionErrorPrint('Please report the above error to Oracle Support Services');
    END;  

/* -------------------------------------------- Feedback --------------------------------------------------- */

    SectionPrint('References');

    Show_Link('http://metalink.oracle.com', 'Metalink');
    BrPrint;
    Show_link( '131510.1' );
    ActionPrint( '  : Oracle Assets Self Service Toolkit' );
    Show_link( '67049.1' );
    ActionPrint( ' : Oracle Assets Product Documentation' );
    Show_link( '67050.1' );
    ActionPrint( ' : Oracle Assets Technical Bulletins' );

/* -------------------------------------------- Feedback --------------------------------------------------- */

    Brprint;
    Show_Footer('&v_scriptlongname', '&v_headerinfo'); 

/* -------------------------------- Exception Section  - Main Program ( Part 2 ) --------------------------- */ 

  EXCEPTION -- begin 2 
    WHEN STOPEXECUTION THEN  
         brprint;
         Show_Footer('&v_scriptlongname', '&v_headerinfo');
         brprint;
    WHEN OTHERS then -- exception begin 2
         brprint;
         ErrorPrint(sqlerrm||' occurred in diagnostic test');
         ActionErrorPrint('Please report the above error to Oracle Support Services.');
         brprint;
         Show_Footer('&v_scriptlongname', '&v_headerinfo');
         brprint; 
  END; -- end2 

EXCEPTION -- begin 1 
  WHEN OTHERS THEN   
       Brprint;
       Errorprint(sqlerrm||' occurred in diagnostic test');
       ActionErrorPrint('Please report the above error to Oracle Support Services.');
       Brprint; 
       Show_Footer('&v_scriptlongname', '&v_headerinfo');
       Brprint;
END; 
/
  
REM  ==============SQL PLUS Environment setup===========================================================
Spool off
Set termout on
set feedback on
set verify off 
set echo off 
set trimout off
set trimspool off
set heading on
set autoprint off

PROMPT
PROMPT  =======================================================================
PROMPT  Please review the output file:  &v_spoolfilename
PROMPT  =======================================================================
PROMPT 



